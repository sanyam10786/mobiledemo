import React, { useEffect, useContext, useState } from 'react';
import { StackNav } from './navigation/Navigation';
import { Provider as PaperProvider } from 'react-native-paper';
import Toast from 'react-native-toast-message';
import { Provider } from 'react-redux';
import store from './slices';
import { StatusBar, Text, View } from 'react-native';
import { NetworkProvider, NetworkContext } from './NetworkContext'; // Correct import path
import { ReAuthenticate } from './screens';
import {
  requestUserPermission,
  registerBackgroundMessageHandler,
} from './utils/pushnotification_helper';
import { UiColor } from '../theme/UiColors';
import { GlobalStyles } from '../theme/GlobalStyle';

const App = () => {
  useEffect(() => {
    async function setupNotifications() {
      await requestUserPermission();
      registerBackgroundMessageHandler();
    }
    setupNotifications();
  }, []);

  useEffect(() => {
    console.log('App component reloaded...');
  }, []);

  return (
    <PaperProvider>
      <Provider store={store}>
        <NetworkProvider>
          <AppContent />
        </NetworkProvider>
      </Provider>
    </PaperProvider>
  );
};

const AppContent = () => {
  const isConnected = useContext(NetworkContext);
  const [showOnlineMessage, setShowOnlineMessage] = useState(false);

  useEffect(() => {
    if (isConnected) {
      setShowOnlineMessage(true);
      const timer = setTimeout(() => {
        setShowOnlineMessage(false);
      }, 3000); // Show message for 3 seconds

      return () => clearTimeout(timer); // Clear timeout if isConnected changes
    }
  }, [isConnected]);

  return (
    <>
      <ReAuthenticate />
      <StatusBar
        barStyle="dark-content"
        backgroundColor="transparent"
        translucent={true}
      />
      <StackNav />
      <Toast />
      {(isConnected && showOnlineMessage) || !isConnected ? (
        <View style={[GlobalStyles.StatusOffline, { backgroundColor: isConnected ? UiColor.Success : UiColor.DarkBlue }]}>
          <Text style={GlobalStyles.StatusOfflineText}>
            {isConnected ? 'Back to online' : 'No connection'}
          </Text>
        </View>
      ) : null}
    </>
  );
};

export default App;
