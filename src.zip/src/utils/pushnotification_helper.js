import { Platform } from 'react-native';
import messaging from '@react-native-firebase/messaging';
import AsyncStorage from '@react-native-async-storage/async-storage';
import PushNotification from 'react-native-push-notification';

// Background message handler
const handleFCMBackgroundMessage = async (remoteMessage) => {
  console.log('Handling a background message:', remoteMessage);
  // Add your logic here for handling background messages
};

// Register the background message handler
const registerBackgroundMessageHandler = async () => {
  messaging().setBackgroundMessageHandler(handleFCMBackgroundMessage);
};

// Function to request user permission for notifications
const requestUserPermission = async () => {
  const authStatus = await messaging().requestPermission();
  const enabled =
    authStatus === messaging.AuthorizationStatus.AUTHORIZED ||
    authStatus === messaging.AuthorizationStatus.PROVISIONAL;
  if (enabled) {
    console.log('Authorization status:', authStatus);
    GetFCMToken();
  }
}
// Function to get and store FCM token
async function GetFCMToken() {
  let fcmtoken = await AsyncStorage.getItem('fcmtoken');
  console.log('old fcm token', fcmtoken);
  try {
    const newToken = await messaging().getToken();
    if (newToken) {
      console.log('new token', newToken);
      await AsyncStorage.setItem('fcmtoken', newToken);
    } else {
      const defaultToken =
        'cGLf39lORcaIDOheYM57Ud:APA91bGeSx5hoIP7X9v0qkr5SMu8JrIs6nTtm5JUTv7ea3elYmrVy5I-r7xaJMW7Gh8wWa0g4VQjKI1S8M7cZ0VhD2-JTEG8pvGfkrtStRUYPTQ4XevL4GvvYF-51AJVLJ_VDhv-jx31';
      await AsyncStorage.setItem('fcmtoken', defaultToken);
      // console.log("Default token set:", defaultToken);
    }
  } catch (error) {
    // console.error("Error fetching FCM token:", error);
    // Handle the error by setting a default token
    const defaultToken =
      'cGLf39lORcaIDOheYM57Ud:APA91bGeSx5hoIP7X9v0qkr5SMu8JrIs6nTtm5JUTv7ea3elYmrVy5I-r7xaJMW7Gh8wWa0g4VQjKI1S8M7cZ0VhD2-JTEG8pvGfkrtStRUYPTQ4XevL4GvvYF-51AJVLJ_VDhv-jx31';
    await AsyncStorage.setItem('fcmtoken', defaultToken);
    console.log('Default token set:', defaultToken);
  }
}

let notificationListenerRegistered = false;

// Function to listen for notifications
const NotificationListener = (userId, navigation) => {
  if (notificationListenerRegistered) return;
  notificationListenerRegistered = true;

  console.log('Notification userId:', userId);

  // Handle notification opened while app is in background
  messaging().onNotificationOpenedApp(async (remoteMessage) => {
    console.log('Notification opened from background state:', remoteMessage);
    if (remoteMessage.data && remoteMessage.data.user_id === userId) {
      if (remoteMessage.data.notification_type === 'chat') {
        navigation.navigate('ChatNotification');
      } else {
        navigation.navigate('Notification');
      }
    }
  });

  // Handle initial notification opened when app is closed
  messaging()
    .getInitialNotification()
    .then((remoteMessage) => {
      if (remoteMessage && remoteMessage.data && remoteMessage.data.user_id === userId) {
        console.log('Notification caused app to open from quit state:', remoteMessage.notification);
        navigation.navigate('Notification');
      }
    });

  // Handle notification received while app is in foreground
  messaging().onMessage(async (remoteMessage) => {
    console.log('Notification on foreground state:', remoteMessage);
    console.log('userId:', userId);

    if (remoteMessage.data && remoteMessage.data.user_id === userId) {
      displayNotification(remoteMessage, navigation);
    }
  });
};

// Function to display local notification
const displayNotification = async (remoteMessage, navigation) => {
  const channelId = determineChannelId(remoteMessage);

  // Create notification channel if it doesn't exist
  PushNotification.createChannel(
    {
      channelId: channelId,
      channelName: 'Default Channel',
      channelDescription: 'A default channel for app notifications',
      soundName: 'default',
      importance: 4,
      vibrate: true,
    },
    (created) => console.log(`channel created: ${created}`),
  );

  const { title, body } = remoteMessage.notification;

  // Display the notification
  PushNotification.localNotification({
    channelId: channelId,
    title: title,
    message: body,
    onPress: () => {
      if (navigation) {
        navigation.navigate('Notification');
      }
    },
  });
};

// Function to determine notification channel ID
const determineChannelId = (remoteMessage) => {
  if (remoteMessage.notification.title.includes('Emergency')) {
    return 'emergency_channel';
  } else {
    return 'default_channel';
  }
};

// Export necessary functions and variables
export {
  handleFCMBackgroundMessage,
  registerBackgroundMessageHandler,
  requestUserPermission,
  NotificationListener,
  GetFCMToken,
};
