/* eslint-disable prettier/prettier */
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { axiosClient, endpoints } from '../services';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { doLoginUserThunk, ReAuthenticateThunk, fetchFriends, fetchAPIKeys, fetchYearlyMoonPhase } from '../thunk';
import Snackbar from 'react-native-snackbar';
const initialState = {
    id: '',
    email: '',
    password: '',
    first_name: '',
    last_name: '',
    name: '',
    address: '',
    about_us: '',
    profile_image: '',
    cover_image: '',
    profile_image_path: '',
    cover_image_path: '',
    total_friends: '',
    catch_count: '',
    notification: '',
    notification_count: '',
    reference_id: '',
    reference_media_id: '',
    first_visit: false,
    reference_added: false,
    reference_image: '',
    reference_label: '',
    reference_width: '',
    showPassword: false,
    refreshing: false,
    isLoading: false,
    isRememberme: false,
    isMailVerify: false,
    eyeIcon: 'eye',
    isLogin: false,
    userData: [],
    userObj: {},
    tokens: [],
    accessToken: {},
    refreshToken: {},
    isOnline: true, 
    apikeys: [],
    moonPhase: [],
    third_party_keys : {},

};
const loginSlice = createSlice({
    name: 'loginSlice',
    initialState,
    reducers: {
        onChangeEmail: (state, action) => {
            state.email = action.payload;
        },
        onChangePassword: (state, action) => {
            state.password = action.payload;
        },
        onToggleShowPassword: (state, action) => {
            state.showPassword = !state.showPassword;
        },
        setLogin: (state, action) => {
            state.isLogin = action.payload;
            if (!action.payload) {
                state.first_name = '';
                state.last_name = '';
                state.email = '';
                state.id = '';
                state.accessToken = ''; 
                state.refreshToken = ''; 
            } else {
                state.userObj = action.payload;
            }
        },
        setOnlineStatus: (state, action) => {
            state.isOnline = action.payload;
        },
        setRefreshing: (state, action) => {
            state.refreshing = action.payload;
        },
        setProfileImagePath: (state, action) => {
            state.profile_image_path = action.payload;
        },
        setCoverImagePath: (state, action) => {
            state.cover_image_path = action.payload;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(doLoginUserThunk.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(doLoginUserThunk.fulfilled, (state, action) => {
                state.refreshing = false;
                state.userObj = action.payload.data;
                state.tokens = action.payload.tokens;
                const data = action.payload.data;
                state.userData = [];
                state.userData = state.userData.concat(data);
                state.userData.map((obj)=> {
                    state.id = obj.user ? obj.user._id : obj.user._id;
                    state.name = obj.user ? obj.user.name : obj.user.name;
                    state.first_name = obj.user ? obj.user.first_name : obj.user.first_name;
                    state.last_name = obj.user ? obj.user.last_name : obj.user.last_name;
                    state.email = obj.user ? obj.user.email : obj.user.email;
                    state.address = obj.user ? obj.user.address : obj.user.address;
                    state.about_us = obj.user ? obj.user.about_us : obj.user.about_us;
                    state.profile_image = obj.user.profile_image ? obj.user.profile_image._id : '';
                    state.cover_image = obj.user.cover_image ? obj.user.cover_image._id : '';
                    state.profile_image_path = obj.user.profile_image ? obj.user.profile_image.path : '';
                    state.cover_image_path = obj.user.cover_image ? obj.user.cover_image.path : '';
                    state.total_friends = obj.user.friend_count ? obj.user.friend_count : '';
                    state.catch_count = obj.user.catch_count ? obj.user.catch_count : '';
                    state.reference_id = obj.user?.reference_obj && obj.user.reference_obj._id ? obj.user.reference_obj._id :''; 
                    state.reference_media_id = obj.user?.reference_obj && obj.user.reference_obj.media && obj.user.reference_obj.media._id ? obj.user.reference_obj.media._id  :'';
                    state.reference_image = obj.user?.reference_obj && obj.user.reference_obj.media && obj.user.reference_obj.media.aws_detected_reference_image ? obj.user.reference_obj.media.aws_detected_reference_image  :'';
                    state.reference_label = obj.user?.reference_obj && obj.user.reference_obj.reference_label ? obj.user.reference_obj.reference_label :''; 
                    state.reference_width = obj.user?.reference_obj && obj.user.reference_obj.reference_width ? obj.user.reference_obj.reference_width :'';
                    state.notification_count = obj.user.notification_count ? obj.user.notification_count : '';
                    state.first_visit = obj.user && obj.user.first_visit;
                    state.reference_added = obj.user &&  obj.user.reference_added;
                    state.third_party_keys = obj.user &&  obj.user.third_party_keys;
                })
                state.isLoading = false;
            })
            .addCase(doLoginUserThunk.rejected, (state, error) => {
                console.log("error",error)
                state.isLoading = false;
                if(error.payload === undefined){
                    Snackbar.show({
                        text: 'Invalid credentials',
                    })
                }else{
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }
             
            })
            .addCase(ReAuthenticateThunk.pending, state => {
                state.refreshing = true;
            })
            .addCase(ReAuthenticateThunk.fulfilled, (state, action) => {
                state.refreshing = false;
                const data = action.payload.data;
                state.userData = [];
                state.userData = state.userData.concat(data);
                state.userData.map((obj)=> {
                    state.id = obj.authuser ? obj.authuser._id : obj.authuser._id;
                    state.name = obj.authuser ? obj.authuser.name : obj.authuser.name;
                    state.first_name = obj.authuser ? obj.authuser.first_name : obj.authuser.first_name;
                    state.last_name = obj.authuser ? obj.authuser.last_name : obj.authuser.last_name;
                    state.email = obj.authuser ? obj.authuser.email : obj.authuser.email;
                    state.address = obj.authuser ? obj.authuser.address : obj.authuser.address;
                    state.about_us = obj.authuser ? obj.authuser.about_us : obj.authuser.about_us;
                    state.profile_image = obj.authuser.profile_image ? obj.authuser.profile_image._id : '';
                    state.cover_image = obj.authuser.cover_image ? obj.authuser.cover_image._id : '';
                    state.profile_image_path = obj.authuser.profile_image ? obj.authuser.profile_image.path : '';
                    state.cover_image_path = obj.authuser.cover_image ? obj.authuser.cover_image.path : '';
                    state.total_friends = obj.authuser.friend_count ? obj.authuser.friend_count : '';
                    state.catch_count = obj.authuser.catch_count ? obj.authuser.catch_count : '';
                    state.reference_id = obj.authuser?.reference_obj && obj.authuser.reference_obj._id ? obj.authuser.reference_obj._id :''; 
                    state.reference_media_id = obj.authuser?.reference_obj && obj.authuser.reference_obj.media && obj.authuser.reference_obj.media._id ? obj.authuser.reference_obj.media._id  :'';
                    state.reference_image = obj.authuser?.reference_obj && obj.authuser.reference_obj.media && obj.authuser.reference_obj.media.aws_detected_reference_image ? obj.authuser.reference_obj.media.aws_detected_reference_image  :'';
                    state.reference_label = obj.authuser?.reference_obj && obj.authuser.reference_obj.reference_label ? obj.authuser.reference_obj.reference_label :''; 
                    state.reference_width = obj.authuser?.reference_obj && obj.authuser.reference_obj.reference_width ? obj.authuser.reference_obj.reference_width :'';
                    state.notification_count = obj.authuser.notification_count ? obj.authuser.notification_count : '';
                    state.first_visit = obj.authuser &&  obj.authuser.first_visit;
                    state.reference_added = obj.authuser && obj.authuser.reference_added;
                    state.third_party_keys = obj.authuser &&  obj.authuser.third_party_keys;

                })
            })
            .addCase(ReAuthenticateThunk.rejected, (state, error) => {
                state.refreshing = false;
            })
            .addCase(fetchFriends.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchFriends.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.notification = action.payload.data;
            })
            .addCase(fetchFriends.rejected, (state, error) => {
                state.isLoading = false;
            })
            .addCase(fetchAPIKeys.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchAPIKeys.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.apikeys = action.payload.data;
            })
            .addCase(fetchAPIKeys.rejected, (state, error) => {
                state.isLoading = false;
            })
            .addCase(fetchYearlyMoonPhase.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchYearlyMoonPhase.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.moonPhase = action.payload.data;
            })
            .addCase(fetchYearlyMoonPhase.rejected, (state, error) => {
                state.isLoading = false;
            })
    },
});
const { actions, reducer } = loginSlice;
export default reducer;
export const { setOnlineStatus } = loginSlice.actions;
export const { onChangeEmail, onChangePassword, onToggleShowPassword, setLogin, setRefreshing, setProfileImagePath, setCoverImagePath } =
    actions;
