/* eslint-disable prettier/prettier */
import { Platform } from 'react-native';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { axiosClient, endpoints } from '../services';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SignUpUserThunk } from '../thunk';
import Toast from 'react-native-toast-message';
import Snackbar from 'react-native-snackbar';
const initialState = {
    name: '',
    email: '',
    password: '',
    showPassword: false,
    isLoading: false,
    isRememberme: false,
    eyeIcon: 'eye',
    isLogin: false,
    userSinUpObj: {},
    tokens: [],
    accessToken: {},
    refreshToken: {}
};
const signUpSlice = createSlice({
    name: 'signUpSlice',
    initialState,
    reducers: {
        onChangeName: (state, action) => {
            state.name = action.payload;
        },
        onChangeEmail: (state, action) => {
            state.email = action.payload;
        },
        onChangePassword: (state, action) => {
            state.password = action.payload;
        },
        onToggleShowPassword: (state, action) => {
            state.showPassword = !state.showPassword;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(SignUpUserThunk.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(SignUpUserThunk.fulfilled, (state, action) => {
                state.userSinUpObj = action.payload;
                state.tokens = action.payload.tokens;
                state.isLoading = false;
            })
            .addCase(SignUpUserThunk.rejected, (state, error) => {
                state.isLoading = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            });
    },
});
const { actions, reducer } = signUpSlice;
export default reducer;
export const { onChangeName, onChangeEmail, onChangePassword, onToggleShowPassword, setLogin } =
    actions;
