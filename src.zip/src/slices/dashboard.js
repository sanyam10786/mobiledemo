/* eslint-disable prettier/prettier */
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { ReAuthenticateThunk } from '../thunk';
import Toast from 'react-native-toast-message';
const initialState = {
    refreshing: false,
    isLoading: false,
    isRememberme: false,
    isLogin: false,
    first_name: '',
    last_name: '',
    email: '',
    userObj: {},
    tokens: [],
    accessToken: {},
    refreshToken: {}
};
const dashboardSlice = createSlice({
    name: 'dashboardSlice',
    initialState,
    reducers: {
        resetState: (state, action) => {
            state.details = {};
            state.items = [];
            state.isLoading = false;
            state.refreshing = false;
            state.total = null;
        },
        setRefreshing: (state, action) => {
            state.refreshing = true;
        },
    },
    extraReducers: builder => {
        builder
        .addCase(ReAuthenticateThunk.pending, state => {
            state.refreshing = true;
        })
        .addCase(ReAuthenticateThunk.fulfilled, (state, action) => {
            state.refreshing = false;
            const data = action.payload.data;
            state.userData = [];
            state.userData = state.userData.concat(data);
            state.userData.map((obj)=> {
                state.first_name = obj.authuser ? obj.authuser.first_name : '';
                state.last_name = obj.authuser ? obj.authuser.last_name : '';
                state.email = obj.authuser ? obj.authuser.email : '';
            })
        })
        .addCase(ReAuthenticateThunk.rejected, (state, error) => {
            state.refreshing = false;
            Toast.show({
              topOffset: 45,
              visibilityTime: 4000,
              type: 'error',
              text1: error.payload.message,
            });
        })
    },
});
const { actions, reducer } = dashboardSlice;
export default reducer;
export const { resetState, setRefreshing } = actions;
