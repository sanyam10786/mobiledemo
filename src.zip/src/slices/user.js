/* eslint-disable prettier/prettier */
import { Platform } from 'react-native';
import { createSlice } from '@reduxjs/toolkit';
import Toast from 'react-native-toast-message';
import Snackbar from 'react-native-snackbar';
import { fetchAllUsers, fetchUserData, editUserProfile, fetchCatchesGallery, addReferenceImage, fetchReferenceImage, addSelectedReference, removeUserAccount, updateFirstVisitStatus } from '../thunk';
const initialState = {
    // items_loaded: false,
    details: {},
    items: [],
    catches: [],
    isLoading: false,
    refreshing: false,
    next_page_url: null,
    total: null,
    totalPages: null,
    params: {
        search: '',
        page: 1,
        property_type: 'userSlice',
    },
};
const userSlice = createSlice({
    name: 'userSlice',
    initialState,
    reducers: {
        resetState: (state, action) => {
            state.details = {};
            state.items = [];
            state.isLoading = false;
            state.refreshing = false;
            state.next_page_url = null;
            state.total = null;
            state.params = {
                search: '',
                page: 1,
                property_type: 'userSlice',
            };
        },
        setRefreshing: (state, action) => {
            state.refreshing = true;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(fetchAllUsers.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchAllUsers.fulfilled, (state, action) => {
                const data = action.payload.data;
                state.isLoading = false;
                state.refreshing = false;
                if (action.meta.arg.search || action.meta.arg.page === 1) {
                    state.items = [];
                }
                state.items = data;
                state.total = state.items.total;
            })
            .addCase(fetchAllUsers.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(fetchUserData.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchUserData.fulfilled, (state, action) => {
                const data = action.payload.data;
                state.isLoading = false;
                state.refreshing = false;
                state.details = data;
                state.total = state.items.total;
            })
            .addCase(fetchUserData.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(editUserProfile.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(editUserProfile.fulfilled, (state, action) => {
                const data = action.payload.data;
                state.isLoading = false;
                state.refreshing = false;
                state.details = data;
                state.total = state.items.total;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: action.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'success',
                        text1: action.payload.message,
                    });
                }
            })
            .addCase(editUserProfile.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(fetchCatchesGallery.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchCatchesGallery.fulfilled, (state, action) => {
                const data = action.payload.data
                const catch_gallery = data && data.catch_gallery;
                const page = data && data.page;
                const total_pages = data && data.total_pages;
                state.isLoading = false;
                state.refreshing = false;
                
                if (page === 1) {
                  state.catches = catch_gallery;
                } else {
                    state.catches = [...state.catches, ...catch_gallery];
                }
                state.params.page = page;
                state.totalPages = total_pages;
              })
              
            .addCase(fetchCatchesGallery.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(addReferenceImage.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(addReferenceImage.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(addReferenceImage.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    if(error.error.message){
                        Snackbar.show({
                            text: 'please retry upload....',
                        })
                     }else{
                        Snackbar.show({
                            text: error.payload.message,
                        })
                     }
                }else{
                    if(error.error.message){
                        Toast.show({
                            topOffset: 45,
                            visibilityTime: 4000,
                            type: 'error',
                            text1: 'please retry upload....',
                        });
                    }else{
                        Toast.show({
                            topOffset: 45,
                            visibilityTime: 4000,
                            type: 'error',
                            text1: error.payload.message,
                        });
                    }
                }
            })
            .addCase(fetchReferenceImage.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchReferenceImage.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(fetchReferenceImage.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(addSelectedReference.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(addSelectedReference.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(addSelectedReference.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(removeUserAccount.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(removeUserAccount.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload.data;
            })
            .addCase(removeUserAccount.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(updateFirstVisitStatus.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(updateFirstVisitStatus.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(updateFirstVisitStatus.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
            })
    },
});
const { actions, reducer } = userSlice;
export default reducer;
export const { resetState, setRefreshing } = actions;
