/* eslint-disable prettier/prettier */
import { createSlice } from '@reduxjs/toolkit';
import Toast from 'react-native-toast-message';
import { Platform } from 'react-native';
import Snackbar from 'react-native-snackbar';
import { mediaUploadThunk, fetchMediaDetails, chatMediaUploadThunk, updateMedia, fetchFishDetails } from '../thunk';
const initialState = {
    details: {},
    items: [],
    isLoading: false,
    refreshing: false,
    next_page_url: null,
    total: null,
};
const MediaUploadSlice = createSlice({
    name: 'MediaUploadSlice',
    initialState,
    reducers: {
        resetState: (state, action) => {
            state.details = {};
            state.items = [];
            state.isLoading = false;
            state.refreshing = false;
            state.next_page_url = null;
            state.total = null;
        },
        setRefreshing: (state, action) => {
            state.refreshing = true;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(mediaUploadThunk.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(mediaUploadThunk.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(mediaUploadThunk.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    if(error.error.message){
                        Snackbar.show({
                            text: 'please retry upload....',
                        })
                    }
                    if(error.payload.message){
                        Snackbar.show({
                            text: error.payload.message,
                        })
                    }
                } else {
                    if(error.error.message){
                        Toast.show({
                            topOffset: 45,
                            visibilityTime: 4000,
                            type: 'error',
                            text1: 'please retry upload....',
                        });
                    }
                    if(error.payload.message){
                        Toast.show({
                            topOffset: 45,
                            visibilityTime: 4000,
                            type: 'error',
                            text1: error.payload.message,
                        });
                    }
                }
            })
            .addCase(fetchMediaDetails.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchMediaDetails.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload;
            })
            .addCase(fetchMediaDetails.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })

            .addCase(fetchFishDetails.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchFishDetails.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload;
            })
            .addCase(fetchFishDetails.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })

            .addCase(chatMediaUploadThunk.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(chatMediaUploadThunk.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(chatMediaUploadThunk.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(updateMedia.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(updateMedia.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(updateMedia.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
            })
    },
});
const { actions, reducer } = MediaUploadSlice;
export default reducer;
export const { resetState, setRefreshing } = actions;
