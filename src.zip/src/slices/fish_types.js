/* eslint-disable prettier/prettier */
import { Platform } from 'react-native';
import { createSlice } from '@reduxjs/toolkit';
import Toast from 'react-native-toast-message';
import Snackbar from 'react-native-snackbar';
import { fetchFishTypes, fetchFishWeight } from '../thunk';
const initialState = {
    // items_loaded: false,
    details: {},
    items: [],
    weight: [],
    isLoading: false,
    refreshing: false,
    next_page_url: null,
    total: null,
    params: {
        search: '',
        page: 1,
        // property_type: 'fishTypesSlice',
    },
};
const fishTypesSlice = createSlice({
    name: 'fishTypesSlice',
    initialState,
    reducers: {
        resetState: (state, action) => {
            state.details = {};
            state.items = [];
            state.isLoading = false;
            state.refreshing = false;
            state.next_page_url = null;
            state.total = null;
            state.params = {
                search: '',
                page: 1,
                // property_type: 'fishTypesSlice',
            };
        },
        setRefreshing: (state, action) => {
            state.refreshing = true;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(fetchFishTypes.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchFishTypes.fulfilled, (state, action) => {
                const data = action.payload.data;
                state.isLoading = false;
                state.refreshing = false;
                if (action.meta.arg.search || action.meta.arg.page === 1) {
                    state.items = [];
                }
                state.items = data;
                state.total = state.items.total;
            })
            .addCase(fetchFishTypes.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(fetchFishWeight.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchFishWeight.fulfilled, (state, action) => {
                const data = action.payload.data;
                state.isLoading = false;
                state.refreshing = false;
                if (action.meta.arg.search || action.meta.arg.page === 1) {
                    state.weight = [];
                }
                state.weight = data;
                state.total = state.weight.total;
            })
            .addCase(fetchFishWeight.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
    },
});
const { actions, reducer } = fishTypesSlice;
export default reducer;
export const { resetState, setRefreshing } = actions;
