/* eslint-disable prettier/prettier */
import { Platform } from 'react-native';
import { createSlice } from '@reduxjs/toolkit';
import Toast from 'react-native-toast-message';
import { VerifyOtpThunk, ResendOtpThunk } from '../thunk';
import Snackbar from 'react-native-snackbar';
const initialState = {
    details: {},
    items: [],
    isLoading: false,
    refreshing: false,
    next_page_url: null,
    total: null,
};
const VerifyOtpSlice = createSlice({
    name: 'VerifyOtpSlice',
    initialState,
    reducers: {
        resetState: (state, action) => {
            state.details = {};
            state.items = [];
            state.isLoading = false;
            state.refreshing = false;
            state.next_page_url = null;
            state.total = null;
        },
        setRefreshing: (state, action) => {
            state.refreshing = true;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(VerifyOtpThunk.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(VerifyOtpThunk.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: action.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'success',
                        text1: action.payload.message,
                    });
                }
            })
            .addCase(VerifyOtpThunk.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(ResendOtpThunk.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(ResendOtpThunk.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: action.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'success',
                        text1: action.payload.message,
                    });
                }
            })
            .addCase(ResendOtpThunk.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
    },
});
const { actions, reducer } = VerifyOtpSlice;
export default reducer;
export const { resetState, setRefreshing } = actions;
