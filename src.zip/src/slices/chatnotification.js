// chatNotificationsSlice.js
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  notifications: [],
};

const chatNotificationsSlice = createSlice({
  name: 'chatNotifications',
  initialState,
  reducers: {
    updateChatNotifications: (state, action) => {
      const { _id, createdAt, receiverId, senderId, text, user } = action.payload;
      const createdAtTimestamp = new Date(createdAt).toISOString();
    
      const existingMessageIndex = state.notifications.findIndex(
        (notification) => notification._id === _id
      );
    
      if (existingMessageIndex !== -1) {
        state.notifications[existingMessageIndex] = {
          ...state.notifications[existingMessageIndex],
          text,
          user,
          unreadMessages: state.notifications[existingMessageIndex].unreadMessages + 1,
        };
      } else {
        state.notifications.unshift({
          _id,
          createdAt: createdAtTimestamp,
          receiverId,
          senderId,
          text,
          user,
          unreadMessages: 1,
        });
      }
    },
    
    markMessagesAsRead: (state, action) => {
      const unreadMessagesIds = action.payload;
      state.notifications.forEach((notification) => {
        if (unreadMessagesIds.includes(notification._id)) {
          notification.unreadMessages = 0;
        }
      });
    },
  },
});

export const { updateChatNotifications, markMessagesAsRead } = chatNotificationsSlice.actions;
export const selectChatNotifications = (state) => state.chatNotifications.notifications;

export default chatNotificationsSlice.reducer;
