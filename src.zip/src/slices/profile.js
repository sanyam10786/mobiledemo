/* eslint-disable prettier/prettier */
import { createSlice } from '@reduxjs/toolkit';
import Toast from 'react-native-toast-message';
import { profileImgUploadThunk, coverImgUploadThunk, fetchProfileImage, fetchCoverImage, removeProfileImage, removeCoverImage } from '../thunk';
const initialState = {
    details: {},
    profileData: {},
    coverData: {},
    items: [],
    isLoading: false,
    refreshing: false,
    next_page_url: null,
    total: null,
};
const ProfileSlice = createSlice({
    name: 'ProfileSlice',
    initialState,
    reducers: {
        resetState: (state, action) => {
            state.details = {};
            state.items = [];
            state.isLoading = false;
            state.refreshing = false;
            state.next_page_url = null;
            state.total = null;
        },
        setRefreshing: (state, action) => {
            state.refreshing = true;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(profileImgUploadThunk.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(profileImgUploadThunk.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(profileImgUploadThunk.rejected, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                const errorMessage = action.error.message || "An error occurred";
               
            })
            .addCase(coverImgUploadThunk.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(coverImgUploadThunk.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload;
            })
            .addCase(coverImgUploadThunk.rejected, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                const errorMessage = action.error.message || "An error occurred";
               
            })
            .addCase(fetchProfileImage.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchProfileImage.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.profileData = action.payload.data;
            })
            .addCase(fetchProfileImage.rejected, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(fetchCoverImage.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchCoverImage.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload.data;
                state.coverData = action.payload.data;
            })
            .addCase(fetchCoverImage.rejected, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                const errorMessage = action.error.message || "An error occurred";
               
            })
            .addCase(removeProfileImage.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(removeProfileImage.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(removeProfileImage.rejected, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                const errorMessage = action.error.message || "An error occurred";
              
            })
            .addCase(removeCoverImage.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(removeCoverImage.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(removeCoverImage.rejected, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                const errorMessage = action.error.message || "An error occurred";
               
            })
    },
});
const { actions, reducer } = ProfileSlice;
export default reducer;
export const { resetState, setRefreshing } = actions;
