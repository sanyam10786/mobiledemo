/* eslint-disable prettier/prettier */
import { createSlice } from '@reduxjs/toolkit';
import Toast from 'react-native-toast-message';
import Snackbar from 'react-native-snackbar';
import { Platform } from 'react-native';
import { addCatchesInfo, fetchAllCatches, removeSharedJournal, sharedJournalFriend, fetchShareJournal, fetchCatchesInfo, updateCatchesInfo, addUpdateNote, removeNote, removeJournal, shareFriendJournal } from '../thunk';
const initialState = {
    details: {},
    items: [],
    shareItem: [],
    sharedFriend: [],
    isLoading: false,
    refreshing: false,
    next_page_url: null,
    total_pages: null,
};
const CatchesInfoSlice = createSlice({
    name: 'CatchesInfoSlice',
    initialState,
    reducers: {
        resetState: (state, action) => {
            state.details = {};
            state.items = [];
            state.shareItem = [];
            state.sharedFriend = [];
            state.isLoading = false;
            state.refreshing = false;
            state.next_page_url = null;
            state.total_pages = null;
        },
        setRefreshing: (state, action) => {
            state.refreshing = true;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(addCatchesInfo.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(addCatchesInfo.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                Toast.show({
                    topOffset: 45,
                    visibilityTime: 4000,
                    type: 'success',
                    text1: action.payload.message,
                });
            })
            .addCase(addCatchesInfo.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(fetchAllCatches.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchAllCatches.fulfilled, (state, action) => {
                const data = action.payload.data;
                state.isLoading = false;
                state.refreshing = false;
                if (action.meta.arg.search || action.meta.arg.page === 1) {
                    state.items = [];
                }

                state.items = data;
                // state.items_loaded = true;
                state.total_pages = state.items.total_pages;
            })
            .addCase(fetchAllCatches.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = [];
            })
            .addCase(fetchShareJournal.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchShareJournal.fulfilled, (state, action) => {
                const data = action.payload.data;
                state.isLoading = false;
                state.refreshing = false;
                // if (action.meta.arg.search || action.meta.arg.page === 1) {
                //     state.shareItem = [];
                // }
                state.shareItem = data;
                // state.items_loaded = true;
                state.total_pages = state.shareItem.total_pages;
            })
            .addCase(fetchShareJournal.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(sharedJournalFriend.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(sharedJournalFriend.fulfilled, (state, action) => {
                const data = action.payload.data;
                state.isLoading = false;
                state.refreshing = false;
                // if (action.meta.arg.search || action.meta.arg.page === 1) {
                //     state.shareItem = [];
                // }
                state.sharedFriend = data;
                // state.items_loaded = true;
                state.total_pages = state.shareItem.total_pages;
            })
            .addCase(sharedJournalFriend.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(shareFriendJournal.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(shareFriendJournal.fulfilled, (state, action) => {
                const data = action.payload.data;
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: action.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'success',
                        text1: action.payload.message,
                    });
                }
            })
            .addCase(shareFriendJournal.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(fetchCatchesInfo.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchCatchesInfo.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.details = action.payload.data;

            })
            .addCase(fetchCatchesInfo.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                Toast.show({
                    topOffset: 45,
                    visibilityTime: 4000,
                    type: 'error',
                    text1: error.payload.message,
                });
            })
            .addCase(updateCatchesInfo.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(updateCatchesInfo.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: action.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'success',
                        text1: action.payload.message,
                    });
                }
              
            })
            .addCase(updateCatchesInfo.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
               
            })
            .addCase(addUpdateNote.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(addUpdateNote.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                Toast.show({
                    topOffset: 45,
                    visibilityTime: 4000,
                    type: 'success',
                    text1: action.payload.message,
                });
            })
            .addCase(addUpdateNote.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                Toast.show({
                    topOffset: 45,
                    visibilityTime: 4000,
                    type: 'error',
                    text1: error.payload.message,
                });
            })

            .addCase(removeNote.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(removeNote.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                Toast.show({
                    topOffset: 45,
                    visibilityTime: 4000,
                    type: 'success',
                    text1: action.payload.message,
                });
            })
            .addCase(removeNote.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                Toast.show({
                    topOffset: 45,
                    visibilityTime: 4000,
                    type: 'error',
                    text1: error.payload.message,
                });
            })

            .addCase(removeJournal.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(removeJournal.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                Toast.show({
                    topOffset: 45,
                    visibilityTime: 4000,
                    type: 'success',
                    text1: action.payload.message,
                });
            })
            .addCase(removeJournal.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                Toast.show({
                    topOffset: 45,
                    visibilityTime: 4000,
                    type: 'error',
                    text1: error.payload.message,
                });
            })
            .addCase(removeSharedJournal.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(removeSharedJournal.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(removeSharedJournal.rejected, (state, error) => {
                console.log("error",error)
                state.isLoading = false;
                state.refreshing = false;
                Toast.show({
                    topOffset: 45,
                    visibilityTime: 4000,
                    type: 'error',
                    text1: error.payload.message,
                });
            })
            
    },
});
const { actions, reducer } = CatchesInfoSlice;
export default reducer;
export const { resetState, setRefreshing } = actions;
