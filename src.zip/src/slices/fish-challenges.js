/* eslint-disable prettier/prettier */
import { Platform } from 'react-native';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { addChallenge, fetchAllChallenges, fetchChallengesRequest, acceptChallengeRequest, rejectChallengeRequest, fetchChallengesDetail, removeChallenge, updateChallenge } from '../thunk';
import Toast from 'react-native-toast-message';
import Snackbar from 'react-native-snackbar';
const initialState = {
    refreshing: false,
    isLoading: false,
    isRememberme: false,
    isLogin: false,
    userObj: {},
    items: [],
    challenge: [],
    myFriends: [],
    tokens: [],
    accessToken: {},
    refreshToken: {}
};
const fishChallengeSlice = createSlice({
    name: 'fishChallengeSlice',
    initialState,
    reducers: {
        resetState: (state, action) => {
            state.details = {};
            state.items = [];
            state.isLoading = false;
            state.refreshing = false;
            state.total = null;
        },
        setRefreshing: (state, action) => {
            state.refreshing = true;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(addChallenge.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(addChallenge.fulfilled, (state, action) => {
                state.isLoading = false;
                Toast.show({
                    topOffset: 45,
                    visibilityTime: 4000,
                    type: 'success',
                    text1: action.payload.message,
                });
            })
            .addCase(addChallenge.rejected, (state, error) => {
                state.isLoading = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                } else {
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(fetchAllChallenges.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchAllChallenges.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload.data
            })
            .addCase(fetchAllChallenges.rejected, (state, error) => {
                state.isLoading = false;
            })
            .addCase(fetchChallengesRequest.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchChallengesRequest.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.challenge = action.payload.data
            })
            .addCase(fetchChallengesRequest.rejected, (state, error) => {
                state.isLoading = false;
            })
            .addCase(acceptChallengeRequest.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(acceptChallengeRequest.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(acceptChallengeRequest.rejected, (state, error) => {
                state.isLoading = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                } else {
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(rejectChallengeRequest.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(rejectChallengeRequest.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(rejectChallengeRequest.rejected, (state, error) => {
                state.isLoading = false;
            })
            .addCase(removeChallenge.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(removeChallenge.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(removeChallenge.rejected, (state, error) => {
                state.isLoading = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                } else {
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(fetchChallengesDetail.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchChallengesDetail.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.details = action.payload.data
            })
            .addCase(fetchChallengesDetail.rejected, (state, error) => {
                state.isLoading = false;
            })
            .addCase(updateChallenge.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(updateChallenge.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(updateChallenge.rejected, (state, error) => {
                state.isLoading = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                } else {
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
    },
});
const { actions, reducer } = fishChallengeSlice;
export default reducer;
export const { resetState, setRefreshing } = actions;
