/* eslint-disable prettier/prettier */
import { configureStore } from '@reduxjs/toolkit';
import { combineReducers } from 'redux';
import loginReducer from './login';
import signUpReducer from './signup';
import forgotPassReducer from './forgot-pass';
import friendsReducer from './friends';
import fetchUserReducer from './user';
import fetchOtpVerifyReducer from './otp-verification';
import verifyOtpReducer from './email-verification';
import mediaUploadReducer from './media';
import dashboardReducer from './dashboard';
import profileReducer from './profile';
import postsReducer from './posts';
import chatNotificationReducer from'./chatnotification';
import catchesReducer from './catches';
import fishChallengeReducer from './fish-challenges';
import fetchNotification from './notification';
import fishTypesReducer from './fish_types';
import OffilneCatcheRedducer from './offline-catch';

const reducer = combineReducers({
    login: loginReducer,
    signUp: signUpReducer,
    forgotPass: forgotPassReducer,
    friends: friendsReducer,
    user: fetchUserReducer,
    otpVerify: fetchOtpVerifyReducer,
    emailVerify: verifyOtpReducer,
    mediaUpload: mediaUploadReducer,
    dashboard: dashboardReducer,
    profile: profileReducer,
    posts: postsReducer,
    chatNotifications: chatNotificationReducer,
    catches: catchesReducer,
    challenge: fishChallengeReducer,
    notification: fetchNotification,
    fishTypes: fishTypesReducer,
    offlineCatch: OffilneCatcheRedducer,
    
});

const store = configureStore({
    reducer,
    middleware: (getDefaultMiddleware) =>
      getDefaultMiddleware({
        serializableCheck: false,
      }),
  });
  
export default store;
