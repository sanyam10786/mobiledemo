/* eslint-disable prettier/prettier */
import { createSlice } from '@reduxjs/toolkit';
import Toast from 'react-native-toast-message';
import Snackbar from 'react-native-snackbar';
import { Platform } from 'react-native';
import { addOfflineCatches } from '../thunk';
const initialState = {
    details: {},
    items: [],
    isLoading: false,
    refreshing: false,
    next_page_url: null,
    total_pages: null,
};
const OffilneCatcheSlice = createSlice({
    name: 'OffilneCatcheSlice',
    initialState,
    reducers: {
        resetState: (state, action) => {
            state.details = {};
            state.items = [];
            state.isLoading = false;
            state.refreshing = false;
            state.next_page_url = null;
            state.total_pages = null;
        },
        setRefreshing: (state, action) => {
            state.refreshing = true;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(addOfflineCatches.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(addOfflineCatches.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                Toast.show({
                    topOffset: 45,
                    visibilityTime: 4000,
                    type: 'success',
                    text1: action.payload.message,
                });
            })
            .addCase(addOfflineCatches.rejected, (state, error) => {
                console.log("error",error);

                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })            
    },
});
const { actions, reducer } = OffilneCatcheSlice;
export default reducer;
export const { resetState, setRefreshing } = actions;
