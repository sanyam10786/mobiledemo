/* eslint-disable prettier/prettier */
import { Platform } from 'react-native';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { axiosClient, endpoints } from '../services';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ForgotUserPassThunk, ResetPasswordThunk } from '../thunk';
import Toast from 'react-native-toast-message';
import Snackbar from 'react-native-snackbar';
const initialState = {
    email: '',
    mailSent: '',
    showPassword: false,
    isLoading: false,
    isRememberme: false,
    eyeIcon: 'eye',
    isLogin: false,
    userObj: {},
    resetObj: {},
    tokens: [],
    accessToken: {},
    refreshToken: {}
};
const forgotSlice = createSlice({
    name: 'forgotSlice',
    initialState,
    reducers: {
        onChangeEmail: (state, action) => {
            state.email = action.payload;
        },

    },
    extraReducers: builder => {
        builder
            .addCase(ForgotUserPassThunk.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(ForgotUserPassThunk.fulfilled, (state, action) => {
                state.userObj = action.payload;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: action.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'success',
                        text1: action.payload.message,
                    });
                }
                state.isLoading = false;
            })
            .addCase(ForgotUserPassThunk.rejected, (state, error) => {
                state.isLoading = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(ResetPasswordThunk.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(ResetPasswordThunk.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: action.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'success',
                        text1: action.payload.message,
                    });
                }
            })
            .addCase(ResetPasswordThunk.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
    },
});
const { actions, reducer } = forgotSlice;
export default reducer;
export const { onChangeEmail } = actions;
