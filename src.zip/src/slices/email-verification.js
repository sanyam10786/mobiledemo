/* eslint-disable prettier/prettier */
import { Platform } from 'react-native';
import { createSlice } from '@reduxjs/toolkit';
import Toast from 'react-native-toast-message';
import Snackbar from 'react-native-snackbar';
import { EmailOtpThunk, VerifyEmailThunk } from '../thunk';
const initialState = {
    details: {},
    items: [],
    isLoading: false,
    refreshing: false,
    next_page_url: null,
    total: null,
};
const VerifyEmailSlice = createSlice({
    name: 'VerifyEmailSlice',
    initialState,
    reducers: {
        resetState: (state, action) => {
            state.details = {};
            state.items = [];
            state.isLoading = false;
            state.refreshing = false;
            state.next_page_url = null;
            state.total = null;
        },
        setRefreshing: (state, action) => {
            state.refreshing = true;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(EmailOtpThunk.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(EmailOtpThunk.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: action.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'success',
                        text1: action.payload.message,
                    });
                }
                
            })
            .addCase(EmailOtpThunk.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(VerifyEmailThunk.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(VerifyEmailThunk.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: action.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'success',
                        text1: action.payload.message,
                    });
                }
            })
            .addCase(VerifyEmailThunk.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
    },
});
const { actions, reducer } = VerifyEmailSlice;
export default reducer;
export const { resetState, setRefreshing } = actions;
