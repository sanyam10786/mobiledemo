/* eslint-disable prettier/prettier */
import { Platform } from 'react-native';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { addFriends, fetchFriends, removeFriends, acceptFriends, fetchMyFriends, removeMyFriend } from '../thunk';
import Toast from 'react-native-toast-message';
import Snackbar from 'react-native-snackbar';
const initialState = {
    refreshing: false,
    isLoading: false,
    isRememberme: false,
    isLogin: false,
    userObj: {},
    items: [],
    myFriends: [],
    tokens: [],
    accessToken: {},
    refreshToken: {}
};
const freindsSlice = createSlice({
    name: 'freindsSlice',
    initialState,
    reducers: {
        resetState: (state, action) => {
            state.details = {};
            state.items = [];
            state.isLoading = false;
            state.refreshing = false;
            state.total = null;
        },
        setRefreshing: (state, action) => {
            state.refreshing = true;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(addFriends.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(addFriends.fulfilled, (state, action) => {
                state.userObj = action.payload.data;
                state.isLoading = false;
            })
            .addCase(addFriends.rejected, (state, error) => {
                state.isLoading = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
                
            })
            .addCase(fetchFriends.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchFriends.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload.data;
            })
            .addCase(fetchFriends.rejected, (state, error) => {
                state.isLoading = false;
            })
            .addCase(removeFriends.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(removeFriends.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(removeFriends.rejected, (state, error) => {
                state.isLoading = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(removeMyFriend.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(removeMyFriend.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(removeMyFriend.rejected, (state, error) => {
                state.isLoading = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(acceptFriends.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(acceptFriends.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload.data;
            })
            .addCase(acceptFriends.rejected, (state, error) => {
                state.isLoading = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
            .addCase(fetchMyFriends.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchMyFriends.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.myFriends = action.payload.data;
            })
            .addCase(fetchMyFriends.rejected, (state, error) => {
                state.isLoading = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })
    },
});
const { actions, reducer } = freindsSlice;
export default reducer;
export const { resetState, setRefreshing } = actions;
