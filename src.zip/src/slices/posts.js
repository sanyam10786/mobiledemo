/* eslint-disable prettier/prettier */
import { Platform } from 'react-native';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { addPosts, fetchPosts, likePosts, removeLike, commentPost, fetchComments, likeComment, deleteComment, commentReply, deletePost, fetchAllLikes, fetchUserPosts, reportStoryPost } from '../thunk';
import Toast from 'react-native-toast-message';
import Snackbar from 'react-native-snackbar';
const initialState = {
    refreshing: false,
    isLoading: false,
    isRememberme: false,
    isLogin: false,
    userObj: {},
    items: [],
    id: '',
    likeUserData: [],
    myposts: {},
    tokens: [],
    accessToken: {},
    refreshToken: {}
};
const postsSlice = createSlice({
    name: 'postsSlice',
    initialState,
    reducers: {
        resetState: (state, action) => {
            state.details = {};
            state.items = [];
            state.isLoading = false;
            state.refreshing = false;
            state.total = null;
        },
        setRefreshing: (state, action) => {
            state.refreshing = true;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(addPosts.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(addPosts.fulfilled, (state, action) => {
                state.userObj = action.payload.data;
                state.isLoading = false;
            })
            .addCase(addPosts.rejected, (state, error) => {
                console.log("error",error)
                state.isLoading = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                } else {
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
               
            })
            .addCase(fetchPosts.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchPosts.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload.data;
            })
            .addCase(fetchPosts.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })

            .addCase(fetchUserPosts.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchUserPosts.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload.data;
            })
            .addCase(fetchUserPosts.rejected, (state, error) => {
                state.isLoading = false;
                state.refreshing = false;
            })

            .addCase(likePosts.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(likePosts.fulfilled, (state, action) => {
                state.userObj = action.payload.data;
                state.isLoading = false;
            })
            .addCase(likePosts.rejected, (state, error) => {
                state.isLoading = false;
            })
            .addCase(removeLike.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(removeLike.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(removeLike.rejected, (state, error) => {
                state.isLoading = false;
            })

            .addCase(commentPost.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(commentPost.fulfilled, (state, action) => {
                state.userObj = action.payload.data;
                state.isLoading = false;
            })
            .addCase(commentPost.rejected, (state, error) => {
                state.isLoading = false;
            })
            .addCase(fetchComments.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchComments.fulfilled, (state, action) => {
                state.userObj = action.payload.data;
                state.isLoading = false;
            })
            .addCase(fetchComments.rejected, (state, error) => {
                state.isLoading = false;
            })

            .addCase(likeComment.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(likeComment.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(likeComment.rejected, (state, error) => {
                state.isLoading = false;
            })

            .addCase(deleteComment.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(deleteComment.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(deleteComment.rejected, (state, error) => {
                state.isLoading = false;
            })

            .addCase(commentReply.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(commentReply.fulfilled, (state, action) => {
                state.userObj = action.payload.data;
                state.isLoading = false;
            })
            .addCase(commentReply.rejected, (state, error) => {
                state.isLoading = false;
            })

            .addCase(deletePost.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(deletePost.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(deletePost.rejected, (state, error) => {
                state.isLoading = false;
            })

            .addCase(fetchAllLikes.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchAllLikes.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                const data = action.payload.data;
                state.likeUserData = data.result;
            })
            .addCase(fetchAllLikes.rejected, (state, error) => {
                state.isLoading = false;
            })
            .addCase(reportStoryPost.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(reportStoryPost.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.myposts = action.payload.data;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: action.payload.message,
                    })
                } else {
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'success',
                        text1: action.payload.message,
                    });
                }
            })
            .addCase(reportStoryPost.rejected, (state, error) => {
                state.isLoading = false;
            })
    },
});
const { actions, reducer } = postsSlice;
export default reducer;
export const { resetState, setRefreshing } = actions;