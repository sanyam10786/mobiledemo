/* eslint-disable prettier/prettier */
import { Platform } from 'react-native';
import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { fetchNotification, notificationCount, notificationUpdate, addFcmTokenNotification, addChatNotification, tournamentRemainder } from '../thunk';
import Toast from 'react-native-toast-message';
import Snackbar from 'react-native-snackbar';
const initialState = {
    refreshing: false,
    isLoading: false,
    isRememberme: false,
    isLogin: false,
    userObj: {},
    items: [],
    myFriends: [],
    tokens: [],
    accessToken: {},
    refreshToken: {}
};
const notificationSlice = createSlice({
    name: 'notificationSlice',
    initialState,
    reducers: {
        resetState: (state, action) => {
            state.details = {};
            state.items = [];
            state.isLoading = false;
            state.refreshing = false;
            state.total = null;
        },
        setRefreshing: (state, action) => {
            state.refreshing = true;
        },
    },
    extraReducers: builder => {
        builder
            .addCase(fetchNotification.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(fetchNotification.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload.data;
            })
            .addCase(fetchNotification.rejected, (state, error) => {
                state.isLoading = false;
                if(Platform.OS === 'ios'){
                    Snackbar.show({
                        text: error.payload.message,
                    })
                }else{
                    Toast.show({
                        topOffset: 45,
                        visibilityTime: 4000,
                        type: 'error',
                        text1: error.payload.message,
                    });
                }
            })

            .addCase(notificationCount.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(notificationCount.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.userObj = action.payload;
            })
            .addCase(notificationCount.rejected, (state, error) => {
                state.isLoading = false;
            })

            .addCase(notificationUpdate.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(notificationUpdate.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
                state.items = action.payload.data;
            })
            .addCase(notificationUpdate.rejected, (state, error) => {
                state.isLoading = false;
            })
            .addCase(addFcmTokenNotification.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(addFcmTokenNotification.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(addFcmTokenNotification.rejected, (state, error) => {

                state.isLoading = false;
            })
            .addCase(addChatNotification.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(addChatNotification.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(addChatNotification.rejected, (state, error) => {
                state.isLoading = false;
            })
            .addCase(tournamentRemainder.pending, (state, action) => {
                state.isLoading = true;
            })
            .addCase(tournamentRemainder.fulfilled, (state, action) => {
                state.isLoading = false;
                state.refreshing = false;
            })
            .addCase(tournamentRemainder.rejected, (state, error) => {
                state.isLoading = false;
            })
    },
});
const { actions, reducer } = notificationSlice;
export default reducer;
export const { resetState, setRefreshing } = actions;
