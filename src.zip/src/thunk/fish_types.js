/* eslint-disable prettier/prettier */
import {createAsyncThunk} from '@reduxjs/toolkit';
import {axiosClient, endpoints} from '../services';

const fetchFishTypes = createAsyncThunk(
    'fetchFishTypes',
    async (params, thunkAPI) => {
      try {
        const response = await axiosClient.get(endpoints.fish_type.fetch, {
          params: params,
        });
        return response.data;
      } catch (error) {
        return thunkAPI.rejectWithValue(error.response.data);
      }
    },
  );
  const fetchFishWeight = createAsyncThunk(
    'fetchFishWeight',
    async (params, thunkAPI) => {
      try {
        const response = await axiosClient.get(endpoints.fish_type.weight, {
          params: params,
        });
        return response.data;
      } catch (error) {
        return thunkAPI.rejectWithValue(error.response.data);
      }
    },
  );
export {fetchFishTypes, fetchFishWeight};
