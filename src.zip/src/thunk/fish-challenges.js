/* eslint-disable prettier/prettier */
import {createAsyncThunk} from '@reduxjs/toolkit';
import {axiosClient, endpoints} from '../services';

const addChallenge = createAsyncThunk(
  'addChallenge',
  async (params, thunkAPI) => {
    try {
      const formData = new FormData();
      formData.append('media', params.media);
      formData.append('challenge_name', params.challenge_name);
      formData.append('start_date', params.start_date);
      formData.append('end_date', params.end_date);
      formData.append('user_id', params.user_id);
      const response = await axiosClient.post(
        endpoints.challenge.add,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        },
      );
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);
const fetchAllChallenges = createAsyncThunk(
    'fetchAllChallenges',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.get(`${endpoints.challenge.fetch}`, { params });
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);
const fetchChallengesRequest = createAsyncThunk(
  'fetchChallengesRequest',
  async (params, thunkAPI) => {
      try {
          const response = await axiosClient.get(`${endpoints.challenge.fetch}/` + params.user_id +'/request');
          return response.data;
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response.data);
      }
  },
);
const acceptChallengeRequest = createAsyncThunk(
  'acceptChallengeRequest',
  async (params, thunkAPI) => {
      try {
          const response = await axiosClient.put(`${endpoints.challenge.fetch}/` + params.fish_challenge_id +'/join');
          return response.data;
      } catch (error) {
          console.log('error', error);
          return thunkAPI.rejectWithValue(error.response.data);
      }
  },
);
const rejectChallengeRequest = createAsyncThunk(
  'rejectChallengeRequest',
  async (params, thunkAPI) => {
      try {
          const response = await axiosClient.delete(`${endpoints.challenge.fetch}/` + params.fish_challenge_id +'/remove-request');
          return response.data;
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response.data);
      }
  },
);

const removeChallenge = createAsyncThunk(
  'removeChallenge',
  async (params, thunkAPI) => {
      try {
          const response = await axiosClient.delete(`${endpoints.challenge.fetch}/` + params.fish_challenge_id +'/remove');
          return response.data;
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response.data);
      }
  },
);

const fetchChallengesDetail = createAsyncThunk(
  'fetchChallengesDetail',
  async (params, thunkAPI) => {
      try {
          const response = await axiosClient.get(`${endpoints.challenge.fetch}/` + params.fish_challenge_id );
          return response.data;
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response.data);
      }
  },
);

const updateChallenge = createAsyncThunk(
  'updateChallenge',
  async (params, thunkAPI) => {
      try {
        const formData = new FormData();
        formData.append('quote', params.params.quote);
        formData.append('timezone', params.params.timezone);
        formData.append("stories",params.params.stories);
        formData.append('user_id', params.params.user_id);
        formData.append('start_date', params.params.start_date);
        formData.append('end_date', params.params.end_date);
        const startTime  = new Date(params.params.start_time).toISOString();
        const endTime  = new Date(params.params.end_time).toISOString();
        let updatedStartTime = JSON.stringify(startTime);
        let updatedEndTime = JSON.stringify(endTime);
        formData.append('start_time',JSON.parse(updatedStartTime));
        formData.append('end_time', JSON.parse(updatedEndTime));
        formData.append('winning_prize', params.params.winning_prize);
        const response = await axiosClient.put(`${endpoints.challenge.fetch}/${params.fish_challenge_id}/update`,formData,{
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });
        return response.data;
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response.data);
      }
  },
);


export {addChallenge, fetchAllChallenges, fetchChallengesRequest, acceptChallengeRequest, rejectChallengeRequest, fetchChallengesDetail, removeChallenge, updateChallenge};
