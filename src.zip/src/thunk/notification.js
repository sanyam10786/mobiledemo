/* eslint-disable prettier/prettier */
import { createAsyncThunk } from '@reduxjs/toolkit';
import { axiosClient, endpoints } from '../services';

const fetchNotification = createAsyncThunk(
    'fetchNotification',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.get(endpoints.notification.fetch +'/'+ params.user_id,{params: params});
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const notificationCount = createAsyncThunk(
    'NotificationCount',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.put(endpoints.notification.fetch +'/'+ params.user_id + '/notification-count');
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const notificationUpdate = createAsyncThunk(
    'notificationUpdate',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.put(endpoints.notification.fetch +'/'+ params.notification_id);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const addFcmTokenNotification = createAsyncThunk(
    'addFcmTokenNotification',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.post(endpoints.notification.pushNotification, params);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);
const addChatNotification = createAsyncThunk(
    'addChatNotification',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.post(endpoints.notification.chat, params);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);
const tournamentRemainder = createAsyncThunk(
    'tournamentRemainder',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.post(endpoints.notification.tournament);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);
export { fetchNotification, notificationCount, notificationUpdate, addFcmTokenNotification, addChatNotification, tournamentRemainder };
