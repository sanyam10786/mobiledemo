import { createAsyncThunk } from '@reduxjs/toolkit';
import { axiosClient, endpoints } from '../services';

const profileImgUploadThunk = createAsyncThunk(
    'profileImgUploadThunk',
    async (params, thunkAPI) => {
      try {
        const formData = new FormData();
        formData.append('profile_image', params.profile_image);
        const response = await axiosClient.post(endpoints.media.profileImage, formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });
        return response.data; // Returning the response data
      } catch (error) {
        return thunkAPI.rejectWithValue(error.response.data);
      }
    }
  );
  const coverImgUploadThunk = createAsyncThunk(
    'coverImgUploadThunk',
    async (params, thunkAPI) => {
      try {
        const formData = new FormData();
        formData.append('cover_image', params.cover_image);
        const response = await axiosClient.post(endpoints.media.coverImage, formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });
        return response.data; // Returning the response data
      } catch (error) {
        return thunkAPI.rejectWithValue(error.response.data);
      }
    }
  );
  const fetchProfileImage = createAsyncThunk(
    'fetchProfileImage',
    async (params, thunkAPI) => {
      try {
        const response = await axiosClient.get(endpoints.media.profile + params.media_id);
        return response.data;
      } catch (error) {
        return thunkAPI.rejectWithValue(error.response.data);
      }
    },
  );
  const fetchCoverImage = createAsyncThunk(
    'fetchCoverImage',
    async (params, thunkAPI) => {
      try {
        const response = await axiosClient.get(endpoints.media.cover + params.mediaId);
        return response.data;
      } catch (error) {
        return thunkAPI.rejectWithValue(error.response.data);
      }
    },
  );
  const removeProfileImage = createAsyncThunk(
    'removeProfileImage',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.delete(endpoints.media.profile + params.media_id);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
  );
  const removeCoverImage = createAsyncThunk(
    'removeCoverImage',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.delete(endpoints.media.cover + params.media_id);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
  );

  export { profileImgUploadThunk, coverImgUploadThunk, fetchProfileImage, fetchCoverImage, removeProfileImage, removeCoverImage };