import { createAsyncThunk } from '@reduxjs/toolkit';
import { axiosClient, endpoints } from '../services';
const EmailOtpThunk = createAsyncThunk(
    'EmailOtpThunk',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.post(endpoints.auth.emailOtp, params);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);
const VerifyEmailThunk = createAsyncThunk(
    'VerifyEmailThunk',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.post(endpoints.auth.verifyEmail, params);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

export { EmailOtpThunk, VerifyEmailThunk };