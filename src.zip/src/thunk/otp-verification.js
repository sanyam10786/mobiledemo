/* eslint-disable prettier/prettier */
import { createAsyncThunk } from '@reduxjs/toolkit';
import { axiosClient, endpoints } from '../services';
const VerifyOtpThunk = createAsyncThunk(
    'VerifyOtpThunk',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.post(endpoints.auth.otpVerify, params);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);
const ResendOtpThunk = createAsyncThunk(
    'ResendOtpThunk',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.post(endpoints.auth.resendOtp, params);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

export { VerifyOtpThunk, ResendOtpThunk };