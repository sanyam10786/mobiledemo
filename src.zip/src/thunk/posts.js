/* eslint-disable prettier/prettier */
import { createAsyncThunk } from '@reduxjs/toolkit';
import { axiosClient, endpoints } from '../services';
import moment from 'moment';
const addPosts = createAsyncThunk(
    'addPosts',
    async (params, thunkAPI) => {
        try {
            const formData = new FormData();
            formData.append('quote', params.quote);
            formData.append('timezone', params.timezone);
            formData.append('story_type', params.story_type);
            if(params.stories.length > 0){
                params.stories.forEach((file, index) => {
                formData.append('stories', file);
            });
            }else{
                formData.append("stories",params.stories)
            }
            if(params.user_id){
                formData.append('user_id', params.user_id);
            }
            if(params.visibility){
                formData.append('visibility', params.visibility);
            }
            if(params.start_date && params.end_date && params.start_time && params.end_time){
                const startTime  = new Date(params.start_time).toISOString();
                const endTime  = new Date(params.end_time).toISOString();
                let updatedStartTime = JSON.stringify(startTime);
                let updatedEndTime = JSON.stringify(endTime);
                formData.append('start_date', params.start_date);
                formData.append('end_date', params.end_date);
                formData.append('start_time',JSON.parse(updatedStartTime));
                formData.append('end_time', JSON.parse(updatedEndTime));
            }
            if(params.fish_challenge_id){
                formData.append('fish_challenge_id', params.fish_challenge_id);
            }
            if(params.fish_weight){
                formData.append('fish_weight', params.fish_weight);
            }
            if(params.winning_prize){
                formData.append('winning_prize', params.winning_prize);
            }
            const response = await axiosClient.post(endpoints.posts.add, formData,{
                headers: {
                  'Content-Type': 'multipart/form-data',
                },
            });
            return response.data;
        } catch (error) {
            console.log("error", error)
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const fetchPosts = createAsyncThunk(
    'fetchPosts',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.get(`${endpoints.posts.fetch}`, {params});
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const fetchUserPosts = createAsyncThunk(
    'fetchUserPosts',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.get(endpoints.posts.like + params.user_id);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const likePosts = createAsyncThunk(
    'likePosts',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.post(endpoints.posts.like + params.story_id + '/like');
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const removeLike = createAsyncThunk(
    'removelike',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.delete(endpoints.posts.like + params.story_id + '/' + params.like_id + '/dislike');
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const commentPost = createAsyncThunk(
    'commentPost',
    async (params, thunkAPI) => {
        const paramsData = {comment: params.comment,}
        try {
            const response = await axiosClient.post(endpoints.posts.like + params.story_id + '/comments', paramsData);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const fetchComments = createAsyncThunk(
    'fetchComments',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.get(endpoints.posts.like + params.story_id + '/fetch-all-comments');
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const likeComment = createAsyncThunk(
    'likeComment',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.post(endpoints.posts.like + params.story_id + '/comments/' + params.comment_id + '/like-comment');
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const deleteComment = createAsyncThunk(
    'deleteComment',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.delete(endpoints.posts.like + params.story_id + '/' + params.comment_id + '/remove-comment');
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const commentReply = createAsyncThunk(
    'commentReply',
    async (params, thunkAPI) => {
        const paramsData = {text_comment: params.text_comment,}
        try {
            const response = await axiosClient.post(endpoints.posts.like + params.story_id + '/comments/' + params.comment_id + '/reply-comment', paramsData);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const deletePost = createAsyncThunk(
    'deletePost',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.delete(endpoints.posts.like + params.story_id + '/remove-story');
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const fetchAllLikes = createAsyncThunk(
    'fetchAllLikes',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.get(endpoints.posts.like + params.story_id + '/fetch-all-likes', {
                params: params,
              });
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const reportStoryPost = createAsyncThunk(
    'reportStoryPost',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.post(endpoints.report.add, params);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

export { addPosts, fetchPosts, likePosts, removeLike, commentPost, fetchComments, likeComment, deleteComment, commentReply, deletePost, fetchAllLikes, fetchUserPosts, reportStoryPost };
