/* eslint-disable prettier/prettier */
import { createAsyncThunk } from '@reduxjs/toolkit';
import { axiosClient, endpoints } from '../services';
const addFriends = createAsyncThunk(
    'addFriends',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.post(endpoints.friends.add, params);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);
const fetchFriends = createAsyncThunk(
    'fetchFriends',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.get(endpoints.friends.fetch + params.user_id);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);
const removeFriends = createAsyncThunk(
    'removeFriends',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.delete(endpoints.friends.friend + params.friend_request_id + '/remove');
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const removeMyFriend = createAsyncThunk(
    'removeMyFriend',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.delete(endpoints.friends.friend + '/' + params + '/remove-friend');
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);

const acceptFriends = createAsyncThunk(
    'acceptFriends',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.put(endpoints.friends.friend + params.friend_request_id + '/accept');
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);
const fetchMyFriends = createAsyncThunk(
    'fetchMyFriends',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.get(endpoints.users.user + params.user_id +'/friends', {
                params: params,
              });
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);
export { addFriends, fetchFriends, removeFriends, acceptFriends, fetchMyFriends, removeMyFriend };
