import { createAsyncThunk } from '@reduxjs/toolkit';
import { axiosClient, endpoints } from '../services';

const mediaUploadThunk = createAsyncThunk(
  'mediaUploadThunk',
  async (params, thunkAPI) => {
    try {
      const formData = new FormData();
      formData.append('media_file', params.media_file);
      formData.append('current_longitude', params.current_longitude);
      formData.append('current_latitude', params.current_latitude);
      formData.append('current_date', params.current_date);
      formData.append('current_time', params.current_time);
      const response = await axiosClient.post(endpoints.media.upload, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return response?.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  }
);
const fetchMediaDetails = createAsyncThunk(
  'fetchMediaDetails',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.get(endpoints.media.getMediaDetail + params.media_id);
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);
const fetchFishDetails = createAsyncThunk(
  'fetchFishDetails',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.get(endpoints.fish.getFish, {params: params});
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);

const chatMediaUploadThunk = createAsyncThunk(
  'chatMediaUploadThunk',
  async (params, thunkAPI) => {
    try {
      const formData = new FormData();
      formData.append('media_file', params.media_file);
      const response = await axiosClient.post(endpoints.media.chat, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      return response; // Returning the response data
    } catch (error) {
      console.log("errorerror",error)

      return thunkAPI.rejectWithValue(error.response.data);
    }
  }
);
const updateMedia = createAsyncThunk(
  'updateMedia',
  async (params, thunkAPI) => {
      try {
          const response = await axiosClient.put(endpoints.media.getMediaDetail + params.mediaId, params.params);
          return response.data;
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response.data);
      }
  },
);

export { mediaUploadThunk, fetchMediaDetails, chatMediaUploadThunk, updateMedia, fetchFishDetails};
