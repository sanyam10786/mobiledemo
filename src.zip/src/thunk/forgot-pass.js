/* eslint-disable prettier/prettier */
import { createAsyncThunk } from '@reduxjs/toolkit';
import { axiosClient, endpoints } from '../services';
const ForgotUserPassThunk = createAsyncThunk(
    'ForgotUserPassThunk',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.post(endpoints.auth.forgotPass, params);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);
const ResetPasswordThunk = createAsyncThunk(
    'ResetPasswordThunk',
    async (params, thunkAPI) => {
        try {
            const response = await axiosClient.post(endpoints.auth.resetPass, params);
            return response.data;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    },
);
export { ForgotUserPassThunk, ResetPasswordThunk };
