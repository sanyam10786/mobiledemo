/* eslint-disable prettier/prettier */
import {createAsyncThunk} from '@reduxjs/toolkit';
import {axiosClient, endpoints} from '../services';
import {setRefreshing} from '../slices/login';

const doLoginUserThunk = createAsyncThunk(
  'doLoginUserThunk',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.post(endpoints.auth.login, params);
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);
const doLogoutUserThunk = createAsyncThunk(
  'doLogoutUserThunk',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.post(endpoints.auth.logout, params);
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);
const fetchAPIKeys = createAsyncThunk(
  'fetchAPIKeys',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.get(endpoints.auth.apiKey, params);
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);
const fetchYearlyMoonPhase = createAsyncThunk(
  'fetchYearlyMoonPhase',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.get(endpoints.auth.moonPhase + '?year=' + params.year);
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);
export {doLoginUserThunk, doLogoutUserThunk, fetchAPIKeys, fetchYearlyMoonPhase};
