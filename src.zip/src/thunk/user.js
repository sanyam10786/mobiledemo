/* eslint-disable prettier/prettier */
import {createAsyncThunk} from '@reduxjs/toolkit';
import {axiosClient, endpoints} from '../services';

const fetchAllUsers = createAsyncThunk(
  'fetchAllUsers',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.get(endpoints.users.getAllUser, {
        params: params,
      });
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);

const fetchUserData = createAsyncThunk(
  'fetchUserData',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.get(endpoints.users.user + params.id);
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);

const editUserProfile = createAsyncThunk(
  'editUserProfile',
  async (params, thunkAPI) => {
      try {
        const formData = {
          name: params.name,
          first_name: params.first_name,
          last_name: params.last_name,
          address: params.address,
          about_us: params.about_us,
          profile_image: params.profile_image,
          cover_image: params.cover_image,
        }
          const response = await axiosClient.put(endpoints.users.user + params.user_id, formData);
          return response.data;
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response.data);
      }
  },
);

const fetchCatchesGallery = createAsyncThunk(
  'fetchCatchesGallery',
  async (params, thunkAPI) => {
    try {
      const { user_id, page, limit } = params;
      const response = await axiosClient.get(`${endpoints.users.user}${user_id}/catches`, {
        params: {
          page: page,
          limit: limit,
        },
      });
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  }
);

const addReferenceImage = createAsyncThunk(
  'addReferenceImage',
  async (params, thunkAPI) => {
      try {
          const formData = new FormData();
          formData.append('reference_obj_img', params.reference_obj_img); 
          const response = await axiosClient.post(endpoints.reference.upload, formData,{
              headers: {
                'Content-Type': 'multipart/form-data',
              },
          });
          return response;
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response.data);
      }
  },
);
const fetchReferenceImage = createAsyncThunk(
  'fetchReferenceImage',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.get(endpoints.reference.fetch + params.reference_obj_id );
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);
const addSelectedReference = createAsyncThunk(
  'addSelectedReference',
  async (params, thunkAPI) => {
    const  paramsData ={
        reference_obj_img: params.reference_obj_img,
        reference_label: params.reference_label,
        reference_width: params.reference_width,
      }
      try {
          const response = await axiosClient.put(endpoints.reference.select + params.reference_obj_id, paramsData);
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response.data);
      }
  },
);

const removeUserAccount = createAsyncThunk(
  'removeUserAccount',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.delete(endpoints.users.user + params.user_id );
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);
const updateFirstVisitStatus = createAsyncThunk(
  'updateFirstVisitStatus',
  async (params, thunkAPI) => {
      try {
          const response = await axiosClient.put(endpoints.users.firstVisit, params);
          return response;
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response.data);
      }
  },
);
export {fetchAllUsers, fetchUserData, editUserProfile, fetchCatchesGallery, addReferenceImage, fetchReferenceImage, addSelectedReference, removeUserAccount, updateFirstVisitStatus};
