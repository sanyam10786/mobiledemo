import {createAsyncThunk} from '@reduxjs/toolkit';
import {axiosClient, endpoints} from '../services';

const ReAuthenticateThunk = createAsyncThunk(
  'ReAuthenticateThunk',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.get(endpoints.auth.reAuthenticate);
      return response.data;
    } catch (error) {
      console.log('thunkcalling.error..', error);
      dispatch(doLoginUserThunk.rejected(error));
    }
  },
);

export {ReAuthenticateThunk};
