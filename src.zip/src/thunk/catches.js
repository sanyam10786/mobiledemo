/* eslint-disable prettier/prettier */
import {createAsyncThunk} from '@reduxjs/toolkit';
import {axiosClient, endpoints} from '../services';

const addCatchesInfo = createAsyncThunk(
  'addCatchesInfo',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.post(endpoints.catches.add, params);
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);
const shareFriendJournal = createAsyncThunk(
  'shareFriendJournal',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.post(endpoints.catches.share, params);
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);

const fetchShareJournal = createAsyncThunk(
  'fetchShareJournal',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.get(endpoints.catches.share, params);
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);

const sharedJournalFriend = createAsyncThunk(
  'sharedJournalFriend',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.get(endpoints.catches.share +'/' + params.fish_catch_id);
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);
const removeSharedJournal = createAsyncThunk(
  'removeSharedJournal',
  async (params, thunkAPI) => {
    try {
      console.log("params",params)
      const response = await axiosClient.delete(endpoints.catches.share +'/' + params.fish_catch_id + '/' + params.user_id);
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);
const addOfflineCatches = createAsyncThunk(
  'addOfflineCatches',
  async (params, thunkAPI) => {
    try {
      const formData = new FormData();
      formData.append('media_file', {
        uri: params.media_file.uri,
        type: params.media_file.type,
        name: params.media_file.name
      });
      formData.append('fish_name', params.fish_name);
      formData.append('height', params.height);
      formData.append('width', params.width);
      let weightValue = params.weight;
      if (typeof weightValue === 'string' && weightValue.includes('LBS')) {
        formData.append('weight', weightValue);
      } else {
          formData.append('weight', weightValue + ' LBS');
      }
      formData.append('length', params.length);
      formData.append('date', params.current_date);
      formData.append('time', params.current_time);
      formData.append('location', params.location);
      formData.append('water_temperature', params.water_temperature);
      formData.append('moon_phases', params.moon_phases);
      formData.append('weather_condition', params.weather_condition);
      formData.append('tide_period', params.tide_period);
      formData.append('bait_type', params.bait_type);
      formData.append('depth_of_water', params.depth_of_water);
      formData.append('lure_type', params.lure_type);
      formData.append('current', params.current);
      formData.append('current_latitude', params.current_latitude);
      formData.append('current_longitude', params.current_longitude);
      formData.append('sunrise', params.sunrise);
      formData.append('sunset', params.sunset);
      formData.append('moonrise', params.moonrise);
      formData.append('moonset', params.moonset);
      formData.append('notes', params.notes);
      if(params.weather_data){
        formData.append('weather_data', JSON.stringify(params.weather_data));
      }
      if (params.tide_data && params.tide_data.length > 0 && params.tide_data[0] !== "") {
        formData.append('tide_data', JSON.stringify(params.tide_data));
      }else{
        formData.append('tide_data', params.tide_data);
      }
      const response = await axiosClient.post(endpoints.catches.offline_add, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      return response.data;
    } catch (error) {
      console.log("error", error);

      // Check if error.response is defined before accessing error.response.data
      if (error.response && error.response.data) {
        return thunkAPI.rejectWithValue(error.response.data);
      } else {
        return thunkAPI.rejectWithValue({ message: 'Network Error or Configuration Issue' });
      }
    }
  },
);

const fetchAllCatches = createAsyncThunk(
  'fetchAllCatches',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.get(`${endpoints.catches.fetchAll}`, { params });
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);

const fetchCatchesInfo = createAsyncThunk(
  'fetchCatchesInfo',
  async (params, thunkAPI) => {
    try {
      const response = await axiosClient.get(
        endpoints.catches.fetch + '/' + params.catch_id,
      );
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);
const updateCatchesInfo = createAsyncThunk(
  'updateCatchesInfo',
  async ({formData, catch_id}, thunkAPI) => {
    try {
      const response = await axiosClient.put(
        `${endpoints.catches.fetch}/${catch_id}`,
        formData,
      );
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);

const addUpdateNote = createAsyncThunk(
  'addUpdateNote',
  async ({formData, catch_id, note_Id}, thunkAPI) => {
    try {
      let url = `${endpoints.catches.fetch}/${catch_id}/add-notes`;
      if (note_Id) {
        url += `?note_id=${note_Id}`;
      }

      const response = await axiosClient.put(
        url,
        formData
      );
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(error.response.data);
    }
  },
);

const removeNote = createAsyncThunk(
  'removeNote',
  async (params, thunkAPI) => {
      try {
          const response = await axiosClient.delete(endpoints.catches.fetch + '/' + params.catch_id + '/remove-notes/' + params.note_Id);
          return response.data;
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response.data);
      }
  },
);

const removeJournal = createAsyncThunk(
  'removeJournal',
  async (params, thunkAPI) => {
      try {
          const response = await axiosClient.delete(endpoints.catches.fetch + '/' + params.catch_id);
          return response.data;
      } catch (error) {
          return thunkAPI.rejectWithValue(error.response.data);
      }
  },
);

export {addCatchesInfo, sharedJournalFriend, removeSharedJournal, fetchShareJournal, addOfflineCatches, fetchCatchesInfo, updateCatchesInfo, fetchAllCatches, addUpdateNote, removeNote, removeJournal, shareFriendJournal};
