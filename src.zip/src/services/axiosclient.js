/* eslint-disable prettier/prettier */
import axios from 'axios';
import tokenService from './tokenservice';
const BASE_URL = 'https://bigfinfishingapi.exactink.in/v1';
// const BASE_URL = 'http://localhost:3000/v1/';
const axiosClient = axios.create({ baseURL: BASE_URL, timeout: 10000 });
// import { navigate } from '../navigation/Navigation';
axiosClient.interceptors.request.use(
    async config => {
        const token = await tokenService.getLocalAccessToken();
        // console.log("token",token);
        if (token) {
            config.headers.Authorization = 'Bearer ' + token; // for Spring Boot back-end
            // config.headers["x-access-token"] = token; // for Node.js Express back-end
        }
        // console.log(config);
        return config;
    },
    error => {
        return Promise.reject(error);
     } ,
);

axiosClient.interceptors.response.use(
    res => {
        return res;
    },
    async err => {
        const originalConfig = err.config;
        if (originalConfig.url !== '/auth/login' && originalConfig.url !== '/auth/verify-otp' && originalConfig.url !=='/auth/verify-email' && originalConfig.url !=='/auth/reset-password' && err.response) {
            // Access Token was expired
            if (err.response.status === 401 && !originalConfig._retry) {
                originalConfig._retry = true;
                try {
                    const refreshToken = await tokenService.getLocalRefreshToken();
                    console.log("refreshToken",refreshToken);
                    const params = {
                        refreshToken: refreshToken,
                    }
                    const rs = await axiosClient.post('/auth/refresh-tokens',params);
                    const accessToken  = rs.data.data.access.token;
                    tokenService.updateLocalAccessToken(accessToken);
                    return axiosClient(originalConfig);
                } catch (_error) {
                    return Promise.reject(_error);
                }
            }
            // if (err.response.status === 401) {
            //     await tokenService.setUser(null);
            //     await tokenService.removeUser('USER_DATA');
            //     // useDispatch(setLogin(false));
            //     setTimeout(function () {
            //         navigation.navigate('Login');
            //     }, 1000);
            // }
        }
        return Promise.reject(err);
    },
);
export default axiosClient;
