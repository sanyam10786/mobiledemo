/* eslint-disable prettier/prettier */
import Moment from 'moment';
const date = new Date().getDate(); //Current Date
const month = new Date().getMonth() + 1; //Current Month
const year = new Date().getFullYear(); //Current Year
const hours = new Date().getHours(); //Current Hours
const min = new Date().getMinutes(); //Current Minutes
const sec = new Date().getSeconds(); //Current Seconds
const currentDateTime = (string) => {
  return date + '/' + month + '/' + year + ' ' + hours + ':' + min + ':' + sec ;
}
const capitalizeFirstLetter = (string) => {
  if (string === null || string === undefined) {
    return '--';
  } else {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }
};

const timeAgo = (date, prefix = false) => {
  return Moment(date).fromNow(prefix);
};


const dateTimeFormate = (date, formatType = 'MMM DD, YYYY') => {
  let format = 'MMM DD, YYYY';
  if (formatType === 'medium') {
    format = 'MMM DD, YYYY,  h:mm:ss A';
  } else if (formatType === 'shortTime') {
    format = 'h:mm:ss A';
  } else if (formatType === 'month') {
    format = 'MMM';
  } else if (formatType === 'day') {
    format = 'DD';
  } else if (formatType === 'hoursMinute') {
    format = 'h:mm A';
  } else if (formatType === 'mediumDateTimeA') {
    format = 'DD MMM YYYY h:mm A';
  } else if (formatType === 'dateWithWeek') {
    format = 'dddd, MMMM Do';
  }
  else if (formatType === 'dayName') {
    format = 'ddd';
  }
  let dateLocal = Moment.utc(date).toDate();
  if (formatType === 'mediumDateTimeA') {
    dateLocal = Moment(date).toDate();
  }
  return Moment(dateLocal).format(format);
};
const heplerService = {
  capitalizeFirstLetter,
  dateTimeFormate,
  timeAgo,
  currentDateTime,
};

export default heplerService;
