/* eslint-disable prettier/prettier */
const endpoints = {
    auth: {
        login: '/auth/login',
        logout: '/auth/logout',
        reAuthenticate: '/auth/reauthenticate',
        signup: '/auth/register',
        forgotPass: '/auth/forgot-password',
        resetPass: '/auth/reset-password',
        otpVerify: '/auth/verify-otp',
        resendOtp: '/auth/resend-otp',
        emailOtp: '/auth/send-otpverification-email',
        verifyEmail: '/auth/verify-email',
        apiKey: '/third-party-api-keys/get',
        moonPhase: '/moon-phase-illuminated',
    },
    friends: {
        add: '/friends',
        fetch: '/friends/',
        friend: '/friends/',
    },
    users: {
        getAllUser: '/users',
        user: '/users/',
        firstVisit: '/users/first_visit_reference_update'
    },
    media:{
        upload: '/media/upload',
        getMediaDetail: '/media/',
        profileImage: '/profile-image/upload',
        coverImage: '/cover-image/upload',
        profile: '/profile-image/',
        cover: '/cover-image/',
        chat: '/chat-media/upload'
    },
    fish:{
        getFish: '/fishes'
    },
    loading: {
        load: '/admin/dashboard',
    },
    posts: {
        add: '/stories/upload',
        fetch: '/stories/fetch-all-stories',
        like: '/stories/',
    },
    report: {
        add: '/report/story',
    },
    reference: {
        upload: '/users/reference_obj/upload',
        fetch:  '/users/reference/',
        select: '/users/select-reference/'
    },
    catches: {
        add: '/fish-catch-details/upload',
        offline_add: '/fish-catch-details/upload-draft-data',
        fetch: '/fish-catch-details',
        fetchAll: '/fish-catch-details/fetch',
        update: '/fish-catch-details',
        share: '/share-fish-catch',
    },
    challenge: {
        add: '/fish-challenges/create',
        fetch: '/fish-challenges'
    },
    notification: {
        fetch: '/notifications',
        pushNotification: '/push-notifications/save-fcm-token',
        chat: '/push-notifications/chat',
        tournament: '/push-notifications/tournament-remainder'
    },
    fish_type:{
        fetch: '/fishes',
        weight: '/fish-weight'
    }


};
export default endpoints;
