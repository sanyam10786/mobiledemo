/* eslint-disable prettier/prettier */
import AsyncStorage from '@react-native-async-storage/async-storage';
const getLocalRefreshToken = async () => {
    const user = await getUser();
    return user?.data?.tokens?.refresh?.token;
};

const getLocalAccessToken = async () => {
    const user = await getUser();
    return user?.data?.tokens?.access?.token;
};

const updateLocalAccessToken = async token => {
    const user = await getUser();
    user.data.tokens.access.token = token;
    AsyncStorage.setItem('USER_DATA', JSON.stringify(user));
};

const getUser = async () => {
    const userObj = await AsyncStorage.getItem('USER_DATA');
    return JSON.parse(userObj);
};

const setUser = user => {
    AsyncStorage.setItem('USER_DATA', JSON.stringify(user));
};

const removeUser = () => {
    AsyncStorage.removeItem('USER_DATA');
};

const setEmail = email => {
    AsyncStorage.setItem('EMAIL', email);
};

const getEmail = async () => {
    const email = (await AsyncStorage.getItem('EMAIL')) || '';
    return email;
};

const removeLocalAccessToken = async () => {
    const user = await getUser();
    if (user && user.data.tokens.access) {
        user.data.tokens.access.token = null;
        await AsyncStorage.setItem('USER_DATA', JSON.stringify(user));
    }
};

const removeLocalRefreshToken = async () => {
    const user = await getUser();
    if (user && user.data.tokens.refresh) {
        user.data.tokens.refresh.token = null;
        await AsyncStorage.setItem('USER_DATA', JSON.stringify(user));
    }
};

const tokenService = {
    getLocalRefreshToken,
    getLocalAccessToken,
    updateLocalAccessToken,
    getUser,
    setUser,
    removeUser,
    setEmail,
    getEmail,
    removeLocalAccessToken,  // New Method to Remove Access Token
    removeLocalRefreshToken,
};

export default tokenService;
