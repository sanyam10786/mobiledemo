/* eslint-disable prettier/prettier */
import { Dashboard, AddFriends, StoryBoard, Journal, Challenges, RemoveAccount, CatchesDraft, Friends,} from '../screens';
import { View, Image, ScrollView, Text, BackHandler, TouchableOpacity, Linking,} from 'react-native';
import { DrawerContentScrollView, DrawerItemList, DrawerItem,} from '@react-navigation/drawer';
import {ActivityIndicator, Avatar, IconButton} from 'react-native-paper';
import {IconAsset, Styles, Icon, UiColor, Dm} from '../../theme/Index';
import {useIsFocused, useNavigation} from '@react-navigation/native';
import React, {useState, useEffect, useRef, useContext} from 'react';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import { FriendsStyle } from '../screens/add-friends/FriendsStyle';
import {createDrawerNavigator} from '@react-navigation/drawer';
import {setLogin, setRefreshing} from '../slices/login';
import {useSelector, useDispatch} from 'react-redux';
import { NetworkContext } from '../NetworkContext';
import DeviceInfo from 'react-native-device-info';
import {CameraModal, TabNav} from './Navigation';
import {tokenService} from '../services';
import {NavStyle} from './NavStyle';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Drawer = createDrawerNavigator();
const CustomDrawer = props => {
  const isFocused = useIsFocused();
  const stateVal = useSelector(state => state.login);
  const firstVisit = stateVal.first_visit;
  const [debugAppVersion, setDebugAppVersion] = useState(null); 
  const dispatch = useDispatch();

  useEffect(() => {
    const getAPKVersion = async () => {
      try {
        const apkVersion = await DeviceInfo.getVersion();
        setDebugAppVersion(apkVersion);
      } catch (error) {
        console.error('Error getting APK version:', error);
      }
    };

    getAPKVersion();
  }, []);

  const onLogout = async () => {
    await tokenService.removeUser();
    await tokenService.removeLocalAccessToken();
    await tokenService.removeLocalRefreshToken(); 
    await AsyncStorage.setItem('fcmTokenAdded', 'false');
    dispatch(setLogin(false));
    setTimeout(function () {
      props.navigation.navigate('Login');
    }, 1000);
  };

  return (
    <View style={{flex: 1, marginBottom: 12}}>
      <View style={{marginTop: 70, paddingHorizontal: 16, paddingBottom: 0}}>
        <View
          style={{display: 'flex', flexDirection: 'row', alignItems: 'center'}}>
            {!stateVal.first_name ? (
              <SkeletonPlaceholder>
                <View style={[FriendsStyle.Card, {shadowOpacity: 0,
                  shadowRadius: 0, padding: 0}]}>
                  <SkeletonPlaceholder.Item height={50} width="100%">
                    <View style={FriendsStyle.CardLeft}>
                      <SkeletonPlaceholder.Item
                        width={53}
                        height={53}
                        borderRadius={53}
                      />
                      <View>
                        <SkeletonPlaceholder.Item
                          height={16}
                          width={110}
                          marginLeft={8}
                          borderRadius={5}
                        />
                        <SkeletonPlaceholder.Item
                          height={16}
                          width={160}
                          marginLeft={8}
                          marginTop={8}
                          borderRadius={5}
                        />
                      </View>
                    </View>
                  </SkeletonPlaceholder.Item>
                </View>
              </SkeletonPlaceholder>
            ) : (
              <>
                <TouchableOpacity
                  onPress={() => props.navigation.navigate('UserProfile', isProfile = true)}>
                  <IconButton
                    size={62}
                    style={{marginLeft: -10}}
                    icon={() => (
                      <Avatar.Image
                      style={{backgroundColor: UiColor.ImageLoad}}
                        size={62}
                        source={stateVal.profile_image_path
                            ? {uri: stateVal.profile_image_path}
                            : IconAsset.BlankUser
                        }
                      />
                    )}
                  />
                </TouchableOpacity>
                <View>
                  <Text style={NavStyle.Title}>
                    {stateVal.first_name + ' ' + stateVal.last_name}
                  </Text>
                  <Text style={NavStyle.SubTitle}>{stateVal.email}</Text>
                </View>
              </>
            )}
          <TouchableOpacity
            onPress={() => {props.navigation.navigate('UserProfileEdit'), props.navigation.closeDrawer()}}
            style={{
              marginLeft: 'auto',
              width: 36,
              height: 36,
              backgroundColor: '#100F4D0A',
              borderRadius: 8,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image
              resizeMode="contain"
              style={{height: 24, width: 24, objectFit: 'contain'}}
              source={IconAsset.Edit_light}
            />
          </TouchableOpacity>
        </View>
      </View>
      <DrawerContentScrollView
        {...props}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{paddingTop: 0, paddingBottom: 20}}>
        <View>
          <DrawerItemList {...props} />
        </View>
        <DrawerItem
          onPress={() => onLogout()}
          label="Logout"
          style={{
            backgroundColor: '#100F4D08',
            height: 55,
            paddingHorizontal: 4,
            borderRadius: 9,
          }}
          labelStyle={{
            fontSize: 16,
            color: UiColor.PrimaryColor,
            marginLeft: -16,
          }}
          icon={color => (
            <Icon 
              name='logout'
              color={UiColor.PrimaryColor}
              size={22} 
              style={{ marginLeft: 10}} 
            />
          )}
        />
        <View style={{position: 'absolute', bottom: 0, right: 10,}}>
        <Text style={{fontSize: 12,
          color: UiColor.PrimaryColor,
          paddingHorizontal: 10,}}>{`Version ${debugAppVersion}`}</Text>
        </View>
      </DrawerContentScrollView>
    </View>
  );
};

export const DrawerNav = (props) => {
  const stateVal = useSelector(state => state.login);
  const firstVisit = stateVal.first_visit;
  const isConnected = useContext(NetworkContext);
  return (
    <Drawer.Navigator
      screenOptions={NavStyle.DrawerNav}
      drawerContent={props => <CustomDrawer {...props} />}>
      <Drawer.Screen
        name="Dashboard"
        component={TabNav}
        options={{
          drawerIcon: ({color}) => (
            <Icon 
              name='dashboard1'
              color={color}
              size={22} 
              style={{ marginLeft: 10,}} 
            />
          ),
        }}
      />
      <Drawer.Screen
        name="TabNav"
        component={TabNav}
        options={{headerShown: false, drawerItemStyle: {display: 'none'}}}
      />
      <Drawer.Screen
        name="Friends"
        component={Friends}
        initialParams={{ fromDrawer: true }}
        options={{
          drawerIcon: ({color}) => (
            <Icon 
              name='friends1'
              color={color}
              size={22} 
              style={{ marginLeft: 10}} 
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Capture"
        component={CameraModal}
        options={{
          drawerIcon: ({color}) => (
            <Icon 
              name='capture'
              color={color}
              size={22} 
              style={{ marginLeft: 10}} 
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Tournament"
        component={Challenges}
        initialParams={{ isDelete: false }}
        options={{
          drawerIcon: ({color}) => (
            <Icon 
            name='tournament'
            color={color}
            size={22} 
            style={{ marginLeft: 10}} 
          />
          ),
        }}
      />
      <Drawer.Screen
        name="Story Board"
        component={StoryBoard}
        options={{
          drawerIcon: ({color}) => (
            <Icon 
            name='storyboard'
            color={color}
            size={22} 
            style={{ marginLeft: 10}} 
          />
          ),
        }}
      />
      <Drawer.Screen
        name="Journal"
        component={Journal}
        options={{
          drawerIcon: ({color}) => (
            <Icon 
            name='journal'
            color={color}
            size={22} 
            style={{ marginLeft: 10}} 
          />
          ),
        }}
      />
       <Drawer.Screen
        name="Drafts"
        component={CatchesDraft}
        options={{
          drawerIcon: ({color}) => (
            <Icon 
              name='draft'
              color={color}
              size={22} 
              style={{ marginLeft: 10}} 
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Remove Account"
        component={RemoveAccount}
        onPress={() => props.navigation.navigate('RemoveAccount')}
        options={{
          drawerIcon: ({color}) => (
            <Icon 
              name='remove-account'
              color={color}
              size={22} 
              style={{ marginLeft: 10}} 
            />
          ),
        }}
      />
    </Drawer.Navigator>
  );
};
