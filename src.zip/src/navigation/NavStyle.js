import { StyleSheet, Platform } from 'react-native';
import { Dm, UiColor } from '../../theme/Index';

export const NavStyle = StyleSheet.create({

  TabNav: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  TabNavText: {
    fontSize: 12,
    textAlign: 'center',
    fontFamily: Dm.semiBold,
    marginTop: 7,
    lineHeight: 12
  },
  // TabNavIcon: {
  //   color: UiColor.SecondaryColor
  // },
  CustomTab: {
    top: -5,
    backgroundColor: UiColor.SecondaryColor,
    width: 64,
    height: 64,
    borderRadius: 64,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: UiColor.SecondaryColor,
    left: -6,
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.21,
    shadowRadius: 3.5,

    ...Platform.select({
      android: {
        elevation: 6,
      },
    }),
  },


  TabNavHead: {

    // backgroundColor: '#fff',
    backgroundColor: 'transparent',
    height: 87,
    position: 'absolute',
    // borderColor: 'transparent',
    // borderWidth:0,
    borderTopWidth: 0,
    paddingHorizontal: 6,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowOpacity: 0,
    shadowRadius: 0,
    shadowColor: '#000',

    ...Platform.select({
      ios: {
        height: 95,
        paddingBottom: 8,
      },
    }),
    ...Platform.select({
      android: {
        elevation: 0,
      },
    }),
  },
  // navbumbp: {
  //   shadowOffset: {
  //     width: 0,
  //     height: -10,
  //   },
  //   shadowOpacity: 0.25,
  //   shadowRadius: 3.5,
  //   shadowColor: '#000',
  //   elevation: 6,
  //   position: 'absolute',
  //   top: -30,
  //   left: -50,
  //   zIndex: 99,
  //   // backgroundColor: 'red',
  //   paddingTop: 20,
  //   // overflow: 'visible'
  // },

  DrawerNav: {
    drawerLabelStyle: {
      marginLeft: -16,
      fontSize: 16,
      paddingVertical: 5,
      // backgroundColor: 'blue'
    },
    drawerItemStyle: {
      marginBottom: 10,
      // height: 55,
      justifyContent: 'center',
      marginHorizontal: 16,
      borderRadius: 8,
      // paddingHorizontal: 10,
      // backgroundColor: 'blue',
      // paddingVertical: 15,
    },
    drawerStyle: {
      width: '85%',
      paddingTop: 0,
    },
    // drawerActiveBackgroundColor: 'rgba(18, 23, 71, 0.4)',
    drawerActiveBackgroundColor: UiColor.SecondaryColor,
    drawerActiveTintColor: UiColor.White,
    drawerInactiveBackgroundColor: '#100F4D08',
    // drawerInactiveBackgroundColor: 'rgba(18, 23, 71, 0.06)',
    drawerInactiveTintColor: '#100F4D',
    headerTitleAlign: 'center',
    headerShown: false,
    backgroundColor: 'red',
  },
  Title: {
    fontSize: 16,
    color: '#232323',
    fontFamily: Dm.semiBold,
    marginBottom: 3,
    width: Platform.OS === 'ios' ? 160 : 180,
    flexShrink: 1,
  },
  SubTitle: {
    fontSize: 14,
    fontFamily: Dm.regular,
    color: '#232323',
    flexShrink: 1,
    width: Platform.OS === 'ios' ? 160 : 180,
  },
  NavIcons: {
    height: 24,
    width: 24,
    objectFit: 'contain',
    marginRight: 0,
    marginLeft: 8,
  },
});