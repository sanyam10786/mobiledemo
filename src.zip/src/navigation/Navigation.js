/* eslint-disable prettier/prettier */
import { View, Image, ScrollView, Text, BackHandler, TouchableOpacity, Linking } from 'react-native';
import React, { useState, useEffect, useRef } from 'react';
import { NavigationContainer, DefaultTheme  } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { IconAsset, Styles, Icon, UiColor, Dm } from '../../theme/Index';
import { DrawerContentScrollView, DrawerItemList, DrawerItem } from '@react-navigation/drawer';
import { Splash, Login, Chat, Catches,WeatherDetail, ForgotPassword, SignUp, SignUpSuccess, ForgotSuccess, ResetPassword, ChangePassword, Dashboard, AddFriends, FriendProfile, CameraCapture, Friends, UserProfile, UserProfileEdit, CameraDetail, Notification, ChatNotification, MyFriendProfile, MyFriendFriends, StoryBoard, PostLikes, PostsUpload, EditMoreInfo, Journal, JournalList, JournalCatches, CatchHistoryMap, FriendsPosts, Challenges, ChallengesCreate, ChallengesDetail, RemoveAccount, ChallengesStoryUpload, UserPosts, EditScannedImage, OfflineDetail, CatchesDraft, JournalShare, ChallengesStory } from '../screens';
import { useSelector, useDispatch } from 'react-redux';
import { setLogin, setRefreshing } from '../slices/login';
import { tokenService } from '../services';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavStyle } from './NavStyle';
import { ActivityIndicator, Avatar, IconButton } from 'react-native-paper';
import { doLogoutUserThunk } from '../thunk';
import { useIsFocused, useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { DrawerNav } from './DrawerNavigation';

const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();
const Tab = createBottomTabNavigator();
const CameraCreate = () => <View style={{ flex: 1 }}></View>
export const CameraModal = () => <View style={{ flex: 1 }}><CameraCapture /></View>
const TestScreen = () => <View></View>
const navTheme = DefaultTheme;
navTheme.colors.background = '#fff';

export const TabNav = (props) => {
  const stateVal = useSelector(state => state.login);
  return (
    <Tab.Navigator 
    initialRouteName='Home'
    screenOptions={{
      tabBarShowLabel: false,
      tabBarStyle: NavStyle.TabNavHead,
      headerShown: false,
    }}>
      <Tab.Screen name="Home" component={Dashboard} initialParams={{ stateVal }} options={{
        tabBarIcon: ({ focused }) => (
          <View style={[NavStyle.TabNav]} >
            <Icon name="dashboard" size={22} color={focused ? UiColor.SecondaryColor : UiColor.PrimaryColor} />
            <Text style={[NavStyle.TabNavText, { color: focused ? UiColor.SecondaryColor : UiColor.PrimaryColor }]}>Dashboard </Text>
          </View>
        ),
        
      }}
      
      />
      <Tab.Screen name="Friends" component={Friends} initialParams={{ isFromTabNav: true }} options={{
        tabBarIcon: ({ focused }) => (
          <View style={NavStyle.TabNav}>
            <Icon name="friends" size={22} color={focused ? UiColor.SecondaryColor : UiColor.PrimaryColor} />
            <Text style={[NavStyle.TabNavText, { color: focused ? UiColor.SecondaryColor : UiColor.PrimaryColor }]}>Friends</Text>
          </View>
        ),
      }} />
      <Tab.Screen name="CameraCreate" component={CameraCreate} listeners={({ navigation }) => ({
        tabPress: e => {
          e.preventDefault();
          navigation.navigate("CameraModal");
        }
      })} options={{
        tabBarIcon: ({ focused }) => (
          <View style={{ position: 'relative' }}>
            <View style={[NavStyle.CustomTab]}>
              <Icon name="scan" size={26} style={{ color: '#fff' }} />
            </View>
          </View>
        ),
      }} />
      <Tab.Screen name="Catches" component={Catches} initialParams={{ isTrue: false }} options={{
        tabBarIcon: ({ focused }) => (
          <View style={NavStyle.TabNav} >
            <Icon name="gallery" size={22} color={focused ? UiColor.SecondaryColor : UiColor.PrimaryColor} />
            <Text style={[NavStyle.TabNavText, { color: focused ? UiColor.SecondaryColor : UiColor.PrimaryColor }]}>Catch Gallery </Text>
          </View>
        ),
      }} />
      <Tab.Screen name="UserProfile" component={UserProfile} options={{
        tabBarIcon: ({ focused }) => (
          <View style={NavStyle.TabNav} >
            <Icon name="profile" size={22} color={focused ? UiColor.SecondaryColor : UiColor.PrimaryColor} />
            <Text style={[NavStyle.TabNavText, { color: focused ? UiColor.SecondaryColor : UiColor.PrimaryColor }]}>Profile </Text>
          </View>
        ),
      }} />
    </Tab.Navigator>
  );
};

export const StackNav = () => {
  const login = useSelector(state => state.login);
  const isLogin = login.isLogin;
  const [initialUrlChecked, setInitialUrlChecked] = useState(false);
  const navigationRef = useRef();

  useEffect(() => {
    const handleDeepLink = (event) => {
      try {
        if (isLogin) {
          const { url } = event;
        }
      } catch (error) {
      }
    };

    const checkInitialURL = async () => {
      try {
        if (!initialUrlChecked) {
          const initialUrl = await Linking.getInitialURL();
          if (initialUrl) {
            handleDeepLink({ url: initialUrl });
          }
          setInitialUrlChecked(true);
        }
      } catch (error) {
      }
    };
    const deepLinkSubscription = Linking.addEventListener('url', handleDeepLink);
    checkInitialURL();
    if (!isLogin) {
      const backAction = () => {
        BackHandler.exitApp();
        return true;
      };
      const backHandler = BackHandler.addEventListener('hardwareBackPress', backAction);

      return () => {
        deepLinkSubscription.remove();
        backHandler.remove();
      };
    }
  }, [!isLogin, initialUrlChecked]);


  return (
    <NavigationContainer theme={navTheme} ref={navigationRef}>
      <Stack.Navigator initialRouteName="Splash"
        screenOptions={{
          headerShown: false,
          animation: 'default',
          animationTypeForReplace: 'push',
          presentation: 'fullScreenModal',
          orientation: 'portrait',
        }} >
        {isLogin ? (
          <>
            <Stack.Screen name="DrawerNav" component={DrawerNav} options={{ headerShown: false }} />
            <Stack.Screen name="CameraModal" component={CameraModal} options={{ animation: 'slide_from_left' }} />
            <Stack.Screen name="CameraCapture" component={CameraCapture} />
            <Stack.Screen name="CameraDetail" component={CameraDetail} />
            <Stack.Screen name="UserProfile" component={UserProfile} />
            <Stack.Screen name="UserPosts" component={UserPosts} />
            <Stack.Screen name="UserProfileEdit" component={UserProfileEdit} />
            <Stack.Screen name="AddFriends" component={AddFriends} />
            <Stack.Screen name="FriendProfile" component={FriendProfile} />
            <Stack.Screen name="ChangePassword" component={ChangePassword} />
            <Stack.Screen name="Notification" component={Notification} />
            <Stack.Screen name="ChatNotification" component={ChatNotification} />
            <Stack.Screen name="MyFriendProfile" component={MyFriendProfile} />
            <Stack.Screen name="MyFriendFriends" component={MyFriendFriends} />
            <Stack.Screen name="Chat" component={Chat} />
            <Stack.Screen name="Catches" component={Catches} />
            <Stack.Screen name="StoryBoard" component={StoryBoard} />
            <Stack.Screen name="PostsUpload" component={PostsUpload} options={{ animation: 'slide_from_bottom' }} />
            <Stack.Screen name="PostLikes" component={PostLikes} />
            <Stack.Screen name="EditMoreInfo" component={EditMoreInfo} />
            <Stack.Screen name="Journal" component={Journal} />
            <Stack.Screen name="JournalList" component={JournalList} />
            <Stack.Screen name="JournalShare" component={JournalShare} />
            <Stack.Screen name="JournalCatches" component={JournalCatches} options={{ animation: 'slide_from_bottom' }} />
            <Stack.Screen name="CatchHistoryMap" component={CatchHistoryMap} options={{ animation: 'slide_from_left' }} />
            <Stack.Screen name="FriendsPosts" component={FriendsPosts} />
            <Stack.Screen name="Challenges" component={Challenges} />
            <Stack.Screen name="ChallengesCreate" component={ChallengesCreate} />
            <Stack.Screen name="ChallengesDetail" component={ChallengesDetail} />
            <Stack.Screen name="ChallengesStory" component={ChallengesStory} />
            <Stack.Screen name="RemoveAccount" component={RemoveAccount} />
            <Stack.Screen name="ChallengesStoryUpload" component={ChallengesStoryUpload} />
            <Stack.Screen name="EditScannedImage" component={EditScannedImage} />
            <Stack.Screen name="OfflineDetail" component={OfflineDetail} />
            <Stack.Screen name="CatchesDraft" component={CatchesDraft} />
            <Stack.Screen name="WeatherDetail" component={WeatherDetail} />
          </>
        ) : (
          <>
            <Stack.Screen name="Splash" component={Splash} />
            <Stack.Screen name="Login" component={Login} />
            <Stack.Screen name="ForgotPassword" component={ForgotPassword} options={{ animation: 'slide_from_bottom' }} />
            <Stack.Screen name="SignUp" component={SignUp} options={{ headerShown: false, animation: 'slide_from_bottom' }} />
            <Stack.Screen name="SignUpSuccess" component={SignUpSuccess} options={{ headerShown: false, animation: 'slide_from_bottom' }} />
            <Stack.Screen name="ForgotSuccess" component={ForgotSuccess} options={{ headerShown: false }} />
            <Stack.Screen name="ResetPassword" component={ResetPassword} options={{ headerShown: false }} />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>

  );
};
export const navigationRef = React.createRef(null);


export const navigate = (name, params) => {
  if (navigationRef.current) {
    navigationRef.current.navigate(name, params);
  }
};



