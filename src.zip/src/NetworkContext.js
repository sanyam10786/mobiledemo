// src/NetworkContext.js
import React, { createContext, useState, useEffect } from 'react';
import NetInfo from '@react-native-community/netinfo';
import { useDispatch } from 'react-redux';
import { ReAuthenticateThunk } from './thunk';

export const NetworkContext = createContext();

export const NetworkProvider = ({ children }) => {
  const [isConnected, setIsConnected] = useState(false);
  const [prevIsConnected, setPrevIsConnected] = useState(false);
  const dispatch = useDispatch();

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      setIsConnected(state.isConnected);
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!prevIsConnected && isConnected) {
      dispatch(ReAuthenticateThunk());
    }
    setPrevIsConnected(isConnected);
  }, [isConnected, prevIsConnected, dispatch]);

  return (
    <NetworkContext.Provider value={isConnected}>
      {children}
    </NetworkContext.Provider>
  );
};
