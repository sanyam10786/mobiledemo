import { Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm} from '../../../theme/Index';
import {View, Text, TouchableOpacity, FlatList, SafeAreaView} from 'react-native';
import { selectChatNotifications } from '../../slices/chatnotification';
import { useIsFocused, useNavigation } from '@react-navigation/native';
import {Appbar, Avatar, ActivityIndicator} from 'react-native-paper';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import React, { useState, useEffect, useContext } from 'react';
import { FriendsStyle } from '../add-friends/FriendsStyle';
import fireStore from '@react-native-firebase/firestore';
import { useDispatch, useSelector } from 'react-redux';
import { NetworkContext } from '../../NetworkContext'; 
import { fetchUserData } from '../../thunk';
import moment from 'moment';

const ChatNotification = ({ navigation }) => {
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const stateVal = useSelector(state => state.user);
  const loginUser = useSelector(state => state.login);
  const friendRequest = useSelector(state => state.friends);
  const isConnected = useContext(NetworkContext);
  const friendData = friendRequest.items;
  const user = stateVal.details;
  const [userDataMap, setUserDataMap] = useState({});
  const [loadedData, setLoadedData] = useState([]);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const chatNotifications = useSelector(selectChatNotifications);
  const [hasReturnedFromChat, setHasReturnedFromChat] = useState(false);

  const fetchChatLists = async () => {
    setIsSearching(true);
    try {
      const chatListsSnapshot = await fireStore().collection('chatlists').get();
      const chatLists = chatListsSnapshot.docs.map(doc => {
        const data = doc.data();
        const user = {
          _id: data.senderId === loginUser.id ? data.receiverId : data.senderId,
        };
        return {
          _id: doc.id,
          createdAt: data.timestamp.toDate(),
          receiverId: data.receiverId,
          senderId: data.senderId,
          text: data.lastMessage,
          unreadMessages: data.unreadMessages || 0,
          user,
        };
      });

      const filteredChatLists = chatLists.filter(
        item =>
          item && (item.receiverId === loginUser.id || item.senderId === loginUser.id),
      );
      const sortedData = filteredChatLists.sort((a, b) => b.createdAt - a.createdAt);
      setLoadedData(sortedData);
      setIsSearching(false);
    } catch (error) {
      setIsSearching(false);
      console.error('Error fetching chat lists:', error);
    }
    setIsSearching(false);
  };


  const fetchUserDataForSender = async userId => {
    if(userId !== true){
      const params = { id: userId };
      try {
        const userData = await dispatch(fetchUserData(params));
        setUserDataMap(prevUserDataMap => ({
          ...prevUserDataMap,
          [userId]: userData.payload.data,
        }));
      } catch (error) {
        console.error('Error fetching user data for userId:', userId, error);
      }
    }
    
  };

  useEffect(() => {
    if (isConnected && loginUser.id && !loadedData.length) {
      fetchChatLists();
    }

    const senderReceiverIds = loadedData.reduce((ids, item) => {
      if (!ids.includes(item.senderId)) {
        ids.push(item.senderId);
      }
      if (!ids.includes(item.receiverId)) {
        ids.push(item.receiverId);
      }
      return ids;
    }, [isConnected]);

    const newSenderReceiverIds = senderReceiverIds.filter(
      userId => !userDataMap[userId],
    );

    newSenderReceiverIds.forEach(fetchUserDataForSender);
    if (isFocused && hasReturnedFromChat) {
      fetchChatLists();
      const sortedData = loadedData.sort((a, b) => b.createdAt - a.createdAt);
      setLoadedData(sortedData);
      setHasReturnedFromChat(false);
    }
  }, [loadedData, loginUser.id, userDataMap, isFocused, hasReturnedFromChat]);


  const uniqueUserMessages = loadedData.reduce((acc, item) => {
    const userId =
      item.receiverId === loginUser.id ? item.senderId : item.receiverId;

    if (!acc[userId] || item.createdAt > acc[userId].createdAt) {
      acc[userId] = {
        ...item,
        unreadMessages: item.unreadMessages || 0,
      };
    } else {
      acc[userId].unreadMessages += item.unreadMessages || 0;
    }

    return acc;
  }, {});


  const uniqueMessagesArray = Object.values(uniqueUserMessages);

  const navigateToChat = async (receiverId) => {
    try {
      const user = userDataMap[receiverId];
      if (user) {
        navigation.navigate('Chat', { receiverId, Name: user.first_name + ' ' + user.last_name, userProfile: user?.profile_image?.path });
        setHasReturnedFromChat(true);
      } else {
        await fetchUserDataForSender(receiverId);
        const updatedUser = userDataMap[receiverId];

        if (updatedUser) {
          navigation.navigate('Chat', { receiverId, Name: updatedUser.first_name + ' ' + updatedUser.last_name });
          setHasReturnedFromChat(true);
        } else {
          console.error('User data not available for receiverId:', receiverId);
        }
      }
    } catch (error) {
      console.error('Error updating chat notifications or navigating to chat:', error);
    }
  };



  const ListItem = ({ item, index }) => {
    const { unreadMessages, senderId } = item;
    const lastMessage = item;
    const user = item.receiverId === loginUser.id
      ? userDataMap[item.senderId]
      : userDataMap[item.receiverId];
    const userUnreadMessages = unreadMessages || 0;
    const isReceiver = item.receiverId === loginUser.id;

    return (
      <>{user && user.first_name &&
        <View style={FriendsStyle.Card}>
          <TouchableOpacity onPress={() => navigateToChat(isReceiver ? item.senderId : item.receiverId)}>
            <View style={FriendsStyle.CardLeft}>
              {user && user.profile_image && user.profile_image.path ? (
                <Avatar.Image
                  style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                  size={51}
                  source={{ uri: user.profile_image.path }}
                />
              ) : (
                <Avatar.Image
                  style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                  size={51}
                  source={IconAsset.BlankUser}
                />
              )}
              <View>
                {user && user.first_name && <Text style={FriendsStyle.CardTitle}>
                  {user.first_name} {user.last_name} {''}
                </Text>}
                <Text style={{ maxWidth: '75%' }}
                  numberOfLines={3}
                  ellipsizeMode="tail">{lastMessage && lastMessage.text}</Text>
              </View>
            </View>
          </TouchableOpacity>
          <View style={{ position: 'absolute', top: 15, right: 45, }}>
            {isReceiver && userUnreadMessages > 0 && (
              <Text
                style={{
                  color: 'white',
                  fontWeight: 'bold',
                  backgroundColor: 'blue',
                  height: 18,
                  width: 18,
                  borderRadius: 50,
                  marginLeft: 16,
                  paddingLeft: 4,
                }}>
                {userUnreadMessages}
              </Text>
            )}
          </View>
          <View style={{ flex: 1, flexDirection: 'row', position: 'absolute', top: isReceiver && userUnreadMessages > 0 ? 35 : 25, right: 10 }}>
            <Text style={{ fontWeight: 'bold', }}>
              {moment(lastMessage && lastMessage.createdAt).fromNow()}
            </Text>
          </View>
        </View>
      }
      </>

    );
  };

  return (
    <View>
      <Appbar.Header style={[Styles.AppbarHeader, Styles.AppBarShadow,]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          style={{ backgroundColor: UiColor.SecondaryColor }}
          onPress={() => navigation.goBack()}
          icon={() => (
            <Icon name="back" size={18} style={Styles.BackWhite} />
          )}
        />
        <Appbar.Content
          titleStyle={Styles.NavTitle}
          title="Chat Notification"
        />
        <Appbar.Action />
      </Appbar.Header>
      <View style={[FriendsStyle.Container, { backgroundColor: 'transparent' }]}>
        <SafeAreaView style={[FriendsStyle.CardArea, { marginBottom: 235, }]}>
        {!isConnected && loadedData && loadedData.length === 0 ? (
            <View style={[GlobalStyles.NoData, { marginTop: 80 }]}>
              <Icon name="no-connection" size={50} />
              <Text style={[GlobalStyles.NoDataMsg, { fontFamily: Dm.semiBold }]}>
                No Internet Connection
              </Text>
            </View>
          ) : (
            <>
              {isSearching ? (
                <SkeletonPlaceholder>
                  {Array.from({ length: 10 }).map((_, index) => (
                    <View style={[FriendsStyle.Card, { shadowOpacity: 0, shadowRadius: 0 }]} key={index}>
                      <SkeletonPlaceholder.Item height={50} width="100%">
                        <View style={FriendsStyle.CardLeft}>
                          <SkeletonPlaceholder.Item
                            width={51}
                            height={51}
                            borderRadius={51}
                          />
                          <View>
                            <SkeletonPlaceholder.Item
                              height={20}
                              width={120}
                              marginLeft={10}
                            />
                            <SkeletonPlaceholder.Item
                              height={20}
                              width={200}
                              marginLeft={10}
                              marginTop={8}
                            />
                          </View>
                        </View>
                      </SkeletonPlaceholder.Item>
                    </View>
                  ))}
                </SkeletonPlaceholder>
              ) : loadedData && loadedData.length === 0 ? (
                <View style={GlobalStyles.NoData}>
                  <Text style={GlobalStyles.NoDataMsg}>No Notification Found</Text>
                </View>
              ) : (
                <FlatList
                  data={uniqueMessagesArray}
                  onEndReachedThreshold={0.5}
                  showsVerticalScrollIndicator={false}
                  keyExtractor={(item, index) => index.toString()}
                  renderItem={({ item, index }) => <ListItem item={item} index={index} />}
                />
              )}
            </>
          )}
        </SafeAreaView>
      </View>
    </View>
  );

};
export default ChatNotification;
