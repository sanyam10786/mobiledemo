import {fetchMyFriends, removeFriends, acceptFriends, fetchNotification, notificationCount, notificationUpdate, acceptChallengeRequest, rejectChallengeRequest } from '../../thunk';
import {View, Text, TouchableOpacity, FlatList, SafeAreaView, Platform} from 'react-native';
import {Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm,} from '../../../theme/Index';
import {Appbar,Avatar, IconButton, ActivityIndicator} from 'react-native-paper';
import { useIsFocused, useNavigation } from '@react-navigation/native';
import { resetState, setRefreshing } from '../../slices/notification';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import React, { useState, useEffect, useContext } from 'react';
import { FriendsStyle } from '../add-friends/FriendsStyle';
import { useDispatch, useSelector } from 'react-redux';
import { NetworkContext } from '../../NetworkContext';
import moment from 'moment';

const Notification = ({ navigation }) => {
  const dispatch = useDispatch();
  const stateVal = useSelector(state => state.user);
  const loginUser = useSelector(state => state.login);
  const friendRequest = useSelector(state => state.friends);
  const friendData = friendRequest.items;
  const isConnected = useContext(NetworkContext);
  const notificationData = useSelector(state => state.notification);
  const stateNotification = notificationData.items;
  const isFocused = useIsFocused();
  const [myFriendData, setMyFriendData] = useState([]);
  const [loadedData, setLoadedData] = useState([]);
  const [isLoadingMore, setIsLoadingMore] = useState({ isLoading: false, index: -1 });
  const [isEndOfFirstPage, setIsEndOfFirstPage] = useState(false);
  const [shouldFetchNextPage, setShouldFetchNextPage] = useState(true);
  const [isSearching, setIsSearching] = useState(false);
  const [currentPage, setCurrentPage] = React.useState(1);
  const [params, setParamData] = useState({
    limit: 10,
    page: 1,
    user_id: loginUser.id
  });

  useEffect(() => {
    if (isFocused && isConnected) {
      const params = {
        page: currentPage,
        limit: 10,
        user_id: loginUser.id
      };
      fetchAllNotification(params);
      fetchNotificationCount();
      fetchFriends();
    }
    return () => {
      dispatch(resetState({}));
      setParamData({
        limit: 10,
        page: 1,
        user_id: loginUser.id
      });
      if (!isFocused) {
      }
    };
  }, [isFocused]);

  const fetchAllNotification = async (params) => {
    setIsEndOfFirstPage(true);
    try {
    const resultAction = await dispatch(fetchNotification(params));
    if (fetchNotification.fulfilled.match(resultAction)) {
      const data = resultAction.payload.data.notifications;
      if (data.length < params.limit) {
        setShouldFetchNextPage(false);
      } else {
        setShouldFetchNextPage(true);
      }
      if (params.page === 1) {
        setLoadedData(data);
      } else {
        setLoadedData(prevData => {
          const uniqueFilteredData = data.filter(item => !prevData.map(prevItem => prevItem._id).includes(item._id));
          return [...prevData, ...uniqueFilteredData];
        });
      }
    }
    setIsEndOfFirstPage(false);
  } catch (error) {
    setIsEndOfFirstPage(false);
    console.error('Error fetching users:', error);
  }
  };

  const fetchNotificationCount = async () => {
    const params = { user_id: loginUser.id };
    const resultAction = await dispatch(notificationCount(params));
    if (notificationCount.fulfilled.match(resultAction)) {
      const data = resultAction.payload.data;
    }
  };

  const NotificationStatusUpdate = async (text) => {
    const params = { notification_id: text };
    const resultAction = await dispatch(notificationUpdate(params));
    if (notificationUpdate.fulfilled.match(resultAction)) {
      const data = resultAction.payload.data;
      setLoadedData(prevData => {
        return prevData.map(item => {
            if (item._id === data._id && item.notification_type === 'share_fish_catch') {
                return {
                    ...item,
                    is_read: 'read',
                    is_seen: 'seen'
                };
            }
            return item;
        });
    });
    }
  };

  const handleLoadMore = () => {
    if (!isEndOfFirstPage && shouldFetchNextPage) {
      setIsEndOfFirstPage(true);
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      const params = {
        page: nextPage,
        limit: 10,
        user_id: loginUser.id
      };
      fetchAllNotification(params).then(() => setIsEndOfFirstPage(false));
    }
  };

  const handleRefresh = () => {
    dispatch(setRefreshing({}));
    params.page = 1;
    setCurrentPage(1);
    fetchAllNotification(params);
  };

  const acceptRequest = async (id, index) => {
    setIsLoadingMore({ isLoading: true, index });
    const paramsData = { friend_request_id: id };
    const resultAction = await dispatch(acceptFriends(paramsData));
    if (acceptFriends.fulfilled.match(resultAction)) {
        setLoadedData(prevData => {
            return prevData.map((item) => {
                if (item.notification_type === "friend_request" && item.friend_request_id && item.friend_request_id.id === id) {
                    return {
                        ...item,
                        friend_request_id: {
                            ...item.friend_request_id,
                            status: 'accepted'
                        },
                        is_read: 'read',
                        is_seen: 'seen'
                    };
                }
                return item;
            });
        });
    }
    setIsLoadingMore({ isLoading: false, index: -1 });
  };

  const removeRequest = async (id, index) => {
    setIsLoadingMore({ isLoading: true, index });
    const paramsData = { friend_request_id: id };
    const resultAction = await dispatch(removeFriends(paramsData));
    if (removeFriends.fulfilled.match(resultAction)) {
        setLoadedData(prevData => {
            return prevData.filter(item => 
                !(item.notification_type === "friend_request" && item.friend_request_id && item.friend_request_id.id === id)
            );
        });
    }
    setIsLoadingMore({ isLoading: false, index: -1 });
  };

  const acceptChallenge = async (id, index) => {
    setIsLoadingMore({ isLoading: true, index });
    const paramsData = { fish_challenge_id: id };
    const resultAction = await dispatch(acceptChallengeRequest(paramsData));
    if (acceptChallengeRequest.fulfilled.match(resultAction)) {
        setLoadedData(prevData => {
            return prevData.map((item) => {
                if (item.notification_type === "fish_challenges" && item.fish_challenge_id && item.fish_challenge_id._id === id) {
                    return {
                        ...item,
                        fish_challenge_id: {
                            ...resultAction.payload.data
                        },
                        is_read: 'read',
                        is_seen: 'seen'
                    };
                }
                return item;
            });
        });
    }
    setIsLoadingMore({ isLoading: false, index: -1 });
  };

  const removeChallenge = async (id, index) => {
    setIsLoadingMore({ isLoading: true, index });
    const paramsData = { fish_challenge_id: id };
    const resultAction = await dispatch(rejectChallengeRequest(paramsData));
    if (rejectChallengeRequest.fulfilled.match(resultAction)) {
        setLoadedData(prevData => {
            return prevData.filter((item) => {
                return !(item.notification_type === "fish_challenges" && item.fish_challenge_id && item.fish_challenge_id._id === id);
            });
        });
    }
    setIsLoadingMore({ isLoading: false, index: -1 });
  };

  const fetchFriends = async () => {
    try {
      const params = {
        user_id: loginUser.id,
        page: 1,
        limit: 30,
      };
      let allFriends = [];
      while (true) {
        const resultAction = await dispatch(fetchMyFriends(params));
        if (fetchMyFriends.fulfilled.match(resultAction)) {
          const newData = resultAction.payload.data.friends;
          allFriends = allFriends.concat(newData);
          if (newData.length < params.limit) {
            break;
          }
          params.page++;
        } else {
          break;
        }
      }
      setMyFriendData(allFriends);
    } catch (error) {
      console.error('Error in fetchFriends:', error);
    }
  };

  const navigateToProfile = text => {
    const item_id = text;
    const friendIds = myFriendData.some(item => item.id === item_id);
    if (friendIds) {
      navigation.navigate('MyFriendProfile', item_id);
    } else {
      navigation.navigate('FriendProfile', item_id);
    }
  }

  const ListItem = (item, index) => {
    const hasJoined =
      item.fish_challenge_id && item.fish_challenge_id.meta &&
      item.fish_challenge_id.meta?.fish_challenge.find(
        challenge =>
          challenge.to_id === loginUser.id && challenge.status === 'joined',
      );
    const hasAccepted =
      item.friend_request_id && item.friend_request_id.status === 'accepted';
    const challengeJoinTime = hasJoined
      ? moment(item.fish_challenge_id.created_at).fromNow()
      : null;
    const requestAcceptTime = hasAccepted
      ? moment(item.friend_request_id.created_at).fromNow()
      : null;
      const journalTime = moment(item && item.created_at).fromNow();
      const senderName = item.from_id &&
      item.from_id &&
      item.from_id.name;
    return (
      <>
        {item.notification_type === 'fish_challenges' && (
          <>
            {item.fish_challenge_id === null || item.fish_challenge_id === undefined ? '' : (
              <View style={[FriendsStyle.Card, item.is_read !== 'read' ? { backgroundColor: '#E8E8E8', flexShrink: 1 } : null]}>
                <TouchableOpacity style={{ flexShrink: 1 }} onPress={() => hasJoined ? (navigation.navigate('ChallengesDetail', item.fish_challenge_id && item.fish_challenge_id), NotificationStatusUpdate(item._id)) : []}>
                  <View style={[FriendsStyle.CardLeft, { flexShrink: 1 }]}>
                    {item.fish_challenge_id && item.fish_challenge_id.media && item.fish_challenge_id.media?.map((mediaItem, mediaIndex) =>
                      <Avatar.Image
                        style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                        size={51}
                        key={mediaIndex}
                        source={
                          mediaItem &&
                            mediaItem.media &&
                            mediaItem.media.path
                            ? { uri: mediaItem.media.path }
                            : IconAsset.BlankUser
                        }
                      />
                    )}
                    <View style={{ flexShrink: 1 }}>
                      <Text style={[FriendsStyle.CardTitle]}>
                        {item.fish_challenge_id &&
                          item.fish_challenge_id.quote
                          ? item.fish_challenge_id.quote
                          : ''}
                      </Text>
                      {hasJoined ? (
                        <Text>You joined this challenge.</Text>
                      ) : (
                        <Text
                          numberOfLines={3}
                          ellipsizeMode="tail">
                          {!hasJoined && (
                            <Text style={{ fontWeight: '600', color: UiColor.PrimaryColor, }}>{item.fish_challenge_id &&
                              item.fish_challenge_id.user &&
                              item.fish_challenge_id.user.first_name
                              ? item.fish_challenge_id.user.first_name
                              : ''} </Text>
                          )}
                          has invited you to join the Tournament.</Text>
                      )}
                    </View>
                  </View>
                </TouchableOpacity>
                {!hasJoined && (
                  <View style={{ flexDirection: 'row' }}>
                     {(isLoadingMore && isLoadingMore.index === index) ? (
                      <ActivityIndicator
                        animating={true}
                        size={28}
                        color={UiColor.BaseColor}
                        style={{ marginHorizontal: 12}}
                      />
                    ) : (
                      <>
                        <IconButton
                          style={[FriendsStyle.CardIcon, Styles.BorderSuccess]}
                          onPress={() => {
                            acceptChallenge(
                              item.fish_challenge_id && item.fish_challenge_id._id, index
                            ), NotificationStatusUpdate(item._id)
                          }
                          }
                          icon={() => <Icon name={'check'} size={16} />}
                          size={22}
                        />
                        <IconButton
                          style={[FriendsStyle.CardIcon]}
                          onPress={() =>
                            removeChallenge(
                              item.fish_challenge_id && item.fish_challenge_id._id, index
                            )
                          }
                          icon={() => <Icon name={'cross'} size={16} />}
                          size={22}
                        />
                      </>
                    )}
                  </View>
                )}
                {hasJoined && <Text style={{ position: 'absolute', top: 25, right: 10 }}>{challengeJoinTime}</Text>}
              </View>
            )}
          </>
        )}
        {item.notification_type === 'friend_request' && (
          <>
            {item.friend_request_id === null || item.friend_request_id === undefined ? '' : (
              <View style={[FriendsStyle.Card, item.is_read !== 'read' ? { backgroundColor: '#E8E8E8' } : null]}>
                <TouchableOpacity onPress={() => { navigateToProfile(item.friend_request_id && item.friend_request_id.from_id.id), NotificationStatusUpdate(item._id) }}>
                  <View style={FriendsStyle.CardLeft}>
                    {item.friend_request_id && item.friend_request_id.from_id && (
                      <Avatar.Image
                        style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                        size={51}
                        source={
                          item.friend_request_id.from_id &&
                            item.friend_request_id.from_id.profile_image &&
                            item.friend_request_id.from_id.profile_image.path
                            ? {
                              uri: item.friend_request_id.from_id.profile_image
                                .path,
                            }
                            : IconAsset.BlankUser
                        }
                      />
                    )}
                    <View>
                      <Text style={FriendsStyle.CardTitle}>
                        {item.friend_request_id &&
                          item.friend_request_id.from_id &&
                          item.friend_request_id.from_id.first_name
                          ? item.friend_request_id.from_id.first_name
                          : ''}{' '}
                        {item.friend_request_id &&
                          item.friend_request_id.from_id &&
                          item.friend_request_id.from_id.last_name
                          ? item.friend_request_id.from_id.last_name
                          : ''}
                      </Text>
                      {hasAccepted ? (
                        <Text>now you are friends.</Text>
                      ) : (
                        <Text style={{ maxWidth: '75%' }}
                          numberOfLines={3}
                          ellipsizeMode="tail">has sent you friend request.</Text>
                      )}
                    </View>
                  </View>
                </TouchableOpacity>
                {!hasAccepted && (
                  <View style={{ flexDirection: 'row', }}>
                     {(isLoadingMore && isLoadingMore.isLoading && isLoadingMore.index === index) ? (
                      <ActivityIndicator
                        animating={true}
                        size={28}
                        color={UiColor.BaseColor}
                        style={{ marginHorizontal: 12}}
                      />
                    ) : (
                      <>
                        <IconButton
                          style={[FriendsStyle.CardIcon, Styles.BorderSuccess]}
                          onPress={() => {
                            acceptRequest(
                              item.friend_request_id && item.friend_request_id.id, index
                            ), NotificationStatusUpdate(item._id)
                          }
                          }
                          icon={() => <Icon name={'check'} size={16} />}
                          size={22}
                        />
                        <IconButton
                          style={[FriendsStyle.CardIcon]}
                          onPress={() =>
                            removeRequest(
                              item.friend_request_id && item.friend_request_id.id, index
                            )
                          }
                          icon={() => <Icon name={'cross'} size={16} />}
                          size={22}
                        />
                      </>
                    )}
                  </View>
                )}
                {hasAccepted && <Text style={{ position: 'absolute', top: 25, right: 10, flexShrink: 1 }}>{requestAcceptTime}</Text>}
              </View>
            )}
          </>
        )}
        {item.notification_type === 'share_fish_catch' && (
          <>
            <View style={[FriendsStyle.Card, item.is_read !== 'read' ? { backgroundColor: '#E8E8E8' } : null]}>
              <TouchableOpacity onPress={() => { navigation.navigate('JournalCatches', { catch_id: item && item.share_fish_catch_id && item.share_fish_catch_id.fish_catch && item.share_fish_catch_id.fish_catch._id, sender_name: senderName ? senderName : '', isJournalUser: false}), NotificationStatusUpdate(item._id) }}>
                <View style={FriendsStyle.CardLeft}>
                  {item && item.share_fish_catch_id && item.share_fish_catch_id.fish_catch && item.share_fish_catch_id.fish_catch.media && (
                    <Avatar.Image
                      style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                      size={51}
                      source={{
                        uri: item && item.share_fish_catch_id && item.share_fish_catch_id.fish_catch && item.share_fish_catch_id.fish_catch.media && item.share_fish_catch_id.fish_catch.media.path,
                      }}
                    />
                  )}
                  <View>
                  <Text style={FriendsStyle.CardTitle}>
                  {item.share_fish_catch_id &&
                   item.share_fish_catch_id.fish_catch &&
                   item.share_fish_catch_id.fish_catch.fish_name}
                    </Text>
                      <Text style={{width: '75%'}}
                        numberOfLines={3}
                        ellipsizeMode="tail"><Text style={{ fontWeight: '500', color: UiColor.PrimaryColor, }}>{senderName ? senderName : ''}</Text> has sent you a journal.</Text>
                  </View>
                </View>
              </TouchableOpacity>
              <Text style={{ position: 'absolute', top: 10, right: 10, flexShrink: 1 }}>{journalTime}</Text>
            </View>
          </>
        )}
      </>
    );
  };

  return (
    <View>
      <Appbar.Header style={[Styles.AppbarHeader, Styles.AppBarShadow,]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{ backgroundColor: UiColor.SecondaryColor }}
          icon={() => (
            <Icon name="back" size={18} style={Styles.BackWhite} />
          )}
        />
        <Appbar.Content titleStyle={Styles.NavTitle} title="Notification" />
        <Appbar.Action />
      </Appbar.Header>
      <View style={[FriendsStyle.Container, { marginTop: 10, backgroundColor: 'transparent' }]}>
        <SafeAreaView style={[FriendsStyle.CardArea, { marginBottom: Platform.OS === 'ios' ? 260 : 300, }]}>
        {!isConnected && loadedData && loadedData.length === 0 ?
          <View style={[GlobalStyles.NoData, {marginTop: 80}]}>
            <Icon name="no-connection" size={50} />
            <Text style={[GlobalStyles.NoDataMsg, {fontFamily: Dm.semiBold}]}>
              No Internet Connection
            </Text>
          </View> 
          :
          <>
          {Object.keys(loadedData).length === 0 && isEndOfFirstPage ? (
            <SkeletonPlaceholder>
              {Array.from({ length: 10 }).map((_, index) => (
                <View style={[FriendsStyle.Card, {shadowOpacity: 0,
                  shadowRadius: 0,}]} key={index}>
                  <SkeletonPlaceholder.Item height={50} width="100%">
                    <View style={FriendsStyle.CardLeft}>
                      <SkeletonPlaceholder.Item
                        width={51}
                        height={51}
                        borderRadius={51}
                      />
                      <View>
                        <SkeletonPlaceholder.Item
                          height={20}
                          width={120}
                          marginLeft={10}
                        />
                        <SkeletonPlaceholder.Item
                          height={20}
                          width={200}
                          marginLeft={10}
                          marginTop={8}
                        />
                      </View>
                    </View>
                  </SkeletonPlaceholder.Item>
                </View>
              ))}
            </SkeletonPlaceholder>
          ) : (
            <>
              <FlatList
                data={loadedData}
                onEndReachedThreshold={0.1}
                onEndReached={handleLoadMore}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item, index }) => ListItem(item, index)}
                refreshing={notificationData.refreshing}
                onRefresh={handleRefresh}
                showsVerticalScrollIndicator={false}
                ListFooterComponent={() => {
                  return isEndOfFirstPage ? (
                    <ActivityIndicator
                      animating={true}
                      size={32}
                      color={UiColor.BaseColor}
                    />
                  ) : null;
                }}
              />
              {!isSearching && !isEndOfFirstPage &&
                loadedData &&
                loadedData?.length === 0 && (
                  <View style={GlobalStyles.NoData}>
                    <Text style={GlobalStyles.NoDataMsg}>
                      No Notification Found
                    </Text>
                  </View>
                )}
            </>
            )}
          </>
        }
        </SafeAreaView>
      </View>
    </View>
  );
};
export default Notification;
