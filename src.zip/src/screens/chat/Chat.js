import { View, Text, TextInput, ActivityIndicator, Platform, TouchableOpacity, Modal, StyleSheet, Image, Keyboard, TouchableWithoutFeedback, } from 'react-native';
import { chatMediaUploadThunk, addChatNotification, fetchMyFriends } from '../../thunk';
import { Bubble, GiftedChat, InputToolbar, Send } from 'react-native-gifted-chat';
import { useIsFocused, useNavigation, useRoute } from '@react-navigation/native';
import { getStorage, ref, deleteObject } from '@react-native-firebase/storage';
import { Styles, UiColor, IconAsset, Icon, Dm } from '../../../theme/Index';
import React, { useState, useCallback, useEffect, useRef } from 'react';
import { RemoveStyle } from '../auth/remove-account/RemoveStyle';
import { Appbar, Avatar, IconButton } from 'react-native-paper';
import cameraPicker from 'react-native-image-crop-picker';
import fireStore from '@react-native-firebase/firestore';
import { useDispatch, useSelector } from 'react-redux';
import { ChatStyle } from './ChatStyle';

const Chat = ({ navigation }) => {
  const ImagePicker = require('react-native-image-picker');
  const [selectedMessages, setSelectedMessages] = useState([]);
  const [messageDocs, setMessageDocs] = useState({});
  const giftedChatRef = useRef();
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(true);
  const [isTyping, setIsTyping] = useState(false);
  const [select, setSelect] = useState(false);
  const [isAlertVisible, setAlertVisible] = useState(false);
  const [pickImagePath, setPickImagePath] = useState('');
  const [isMoreTyping, setIsMoreTyping] = useState(false);
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const [userChatStatus, setUserChatStatus] = useState(null);
  const stateVal = useSelector(state => state.login);
  const userStatus = stateVal.isOnline;
  const [myFriendData, setMyFriendData] = useState([]);
  const route = useRoute();
  const routeData = route?.params;
  const receiverId = routeData.receiverId;

  const generateChatRoomId = (userId1, userId2) => {
    const sortedIds = [userId1, userId2].sort();
    return sortedIds.join('_');
  };

  const [chatRoomId, setChatRoomId] = useState(
    generateChatRoomId(stateVal.id, receiverId),
  );
  

  useEffect(() => {
    const chatListRef = fireStore().collection('chatlists').doc(stateVal.id);
    const updateUnreadMessagesToZero = async () => {
      try {
        await chatListRef.update({
          unreadMessages: 0,
        });
      } catch (error) { }
    };
    updateUnreadMessagesToZero();
    fetchFriends()
    const chatRoomRef = fireStore().collection('chats').doc(chatRoomId);
    const messagesRef = chatRoomRef
      .collection('messages')
      .orderBy('createdAt', 'desc');

    const unsubscribe = messagesRef.onSnapshot(snapShot => {
      const allMessages = snapShot.docs.map(snap => {
        const data = snap.data();
        const createdAt = data.createdAt ? data.createdAt.toDate() : new Date();
        return { ...data, createdAt };
      });
      const chatMessages = allMessages.filter(
        message => !message.system || message.system === false,
      );
      setMessages(chatMessages);
      setLoading(false);
    });
    const typingStatusInterval = setInterval(() => {
      if (isFocused) {
        const typingStatusRef = fireStore()
          .collection('typing')
          .doc(stateVal.id);
        typingStatusRef.get().then(doc => {
          if (doc.exists) {
            const isTyping = doc.data();
            setIsMoreTyping(isTyping.isTyping);
          }
        });
      }
    }, 2000);

    const unsubscribeChat = fireStore()
      .collection('userStatus')
      .doc(receiverId)
      .onSnapshot(doc => {
        if (doc.exists) {
          setUserChatStatus(doc.data());
        }
      });
    return () => {
      updateTypingStatus(false);
      unsubscribe();
      unsubscribeChat();
    };
  }, [chatRoomId, isTyping, receiverId]);

  const onSend = async (messageArray = []) => {
    setInputText('');
    const trimmedText = messageArray[0].text.trim();
    if (trimmedText.length > 0 || pickImagePath) {
      const myMsgs = messageArray.map(msg => ({
        ...msg,
        _id: `${msg.user._id}_${Date.now()}`,
        senderId: stateVal.id,
        receiverId: receiverId,
        unreadId: `${stateVal.id}_${receiverId}_${Date.now()}`,
        messagesSentCount: 1,
        image: pickImagePath,
        avatar:
          stateVal.id === msg.user._id
            ? stateVal.profile_image_path
            : routeData.userProfile,
        createdAt: new Date(),
      }));
      setMessages(previousMessages =>
        GiftedChat.append(previousMessages, myMsgs),
      );
      try {
        const chatRoomRef = fireStore().collection('chats').doc(chatRoomId);
        const messagesRef = chatRoomRef.collection('messages');
        const batch = fireStore().batch();

        myMsgs.forEach(async myMsg => {
          const docRef = messagesRef.doc();
          batch.set(docRef, {
            ...myMsg,
            createdAt: fireStore.FieldValue.serverTimestamp(),
          });
        });

        await batch.commit();
        setPickImagePath('');
        setInputText('');
        updateTypingStatus(false);
        setPickImagePath('');
        setInputText('');
        const senderChatListRef = fireStore()
          .collection('chatlists')
          .doc(receiverId);
        await senderChatListRef.set(
          {
            chatRoomId,
            lastMessage: myMsgs[0].text,
            timestamp: fireStore.FieldValue.serverTimestamp(),
            unreadMessages: fireStore.FieldValue.increment(myMsgs.length),
            senderId: stateVal.id,
            receiverId: receiverId,
          },
          { merge: true },
        );

        const receiverChatListRef = fireStore()
          .collection('chatlists')
          .doc(receiverId);
        const receiverChatListDoc = await receiverChatListRef.get();

        if (receiverChatListDoc.exists) {
          const data = receiverChatListDoc.data();
          const unreadMessages = data.unreadMessages || 0;

          if (data.unreadId === myMsgs[0].unreadId) {
            receiverChatListRef.update({
              lastMessage: myMsgs[0].text,
              timestamp: fireStore.FieldValue.serverTimestamp(),
              unreadMessages: fireStore.FieldValue.increment(
                myMsgs.length - unreadMessages,
              ),
              senderId: stateVal.id,
              receiverId: receiverId,
            });
          }
        } else {
          receiverChatListRef.set(
            {
              chatRoomId,
              lastMessage: myMsgs[0].text,
              timestamp: fireStore.FieldValue.serverTimestamp(),
              unreadMessages: fireStore.FieldValue.increment(myMsgs.length),
              unreadId: myMsgs[0].unreadId,
              senderId: stateVal.id,
              receiverId: receiverId,
            },
            { merge: true },
          );
        }
        if (giftedChatRef.current) {
          giftedChatRef.current?.scrollToOffset({
            offset: 0,
            animated: true,
          });
        }
        sendPushNotification(receiverId, messageArray[0].text);
      } catch (error) { }
      updateTypingStatus(false);
      setPickImagePath('');
      setInputText('');
    }
  };

  const sendPushNotification = async (receiverId, messageText) => {
    try {
      const params = {
        user_id: receiverId,
        messaging_body: 'send you a message.',
      };
      const resultAction = await dispatch(addChatNotification(params));
    } catch (error) {
      console.error('Error sending push notification:', error);
    }
  };

  const onInputTextChanged = async text => {
    setInputText(text);
    const shouldUpdateTypingStatus = text.length > 1 || text === '';
    if (shouldUpdateTypingStatus) {
      updateTypingStatus(text.length > 1);
    }
  };

  const updateTypingStatus = async isTyping => {
    try {
      const typingRef = fireStore().collection('typing').doc(receiverId);
      await typingRef.delete();
      await typingRef.set({
        typerId: stateVal.id,
        isTyping,
        timestamp: fireStore.FieldValue.serverTimestamp(),
      });
    } catch (error) { }
  };

  const renderMessage = props => {
    const { currentMessage } = props;
    const isSelected = selectedMessages.includes(currentMessage._id);
    const isReceiverMessage = currentMessage.user._id === receiverId;
// console.log('currentMessage', currentMessage);
    return (
      <TouchableOpacity style={{ width: '100%', backgroundColor: isSelected ? '#d3d3d3' : 'transparent'}}>
        <Bubble
          {...props}
          onLongPress={() => toggleMessageSelection(currentMessage)}
          renderAvatar={() => {
            return <></>;
          }}
          wrapperStyle={{
            right: {
              marginBottom: Platform.OS === 'ios' ? 18 : currentMessage._id === messages[0]._id ? 70 : 18, // Adjust the margin for the last message
            },
            left: {
              marginBottom: Platform.OS === 'ios' ? 19 : currentMessage._id === messages[0]._id ? 70 : 19, // Adjust the margin for the last message
            },
          }}
        />
      </TouchableOpacity>
    );
  };

  const openCamera = async () => {
    setPickImagePath('');
    closeAlert();
    setSelect(true);
    try {
      const image = await cameraPicker.openCamera({
        cropping: false,
        cropperCircleOverlay: false,
        compressImageQuality: 0.8,
        width: 300,
        height: 300,
      });
      if (!image.didCancel) {
        uploadImage([image], 'camera');
      }
    } catch (error) {
      setSelect(false);
    } finally {
    }
  };

  const handleImagePicker = async () => {
    setPickImagePath('');
    setSelect(true);
    try {
      const options = {
        mediaType: 'photo',
      };
      ImagePicker.launchImageLibrary(options, async response => {
        if (response.didCancel) {
          console.log('Image picking canceled');
        } else if (response.error) {
          console.error('Image picker error:', response.error);
        } else {
          const ImageData = response.assets;
          uploadImage(ImageData);
          closeAlert();
        }
      });
    } catch (err) {
      console.error('Error in handleImagePicker:', err);
    }
    setSelect(false);
  };

  const uploadImage = async (imageData, source) => {
    setSelect(true);
    const imageUri = imageData[0].uri;
    const fileName = imageData[0].fileName;
    if (source === 'camera') {
      const fileName = imageData[0].path.split('/').pop();
      const params = {
        media_file: {
          fileCopyUri: null,
          name: fileName,
          size: imageData[0].size?.toString(),
          type: imageData[0].mime,
          uri: imageData[0].path,
        },
      };
      const resultAction = await dispatch(chatMediaUploadThunk(params));
      const uploadedUri =
        resultAction.payload.data && resultAction.payload.data.data
          ? resultAction.payload.data.data
          : imageUri;
      setSelect(false);
      setPickImagePath(uploadedUri);
    } else {
      const params = {
        media_file: {
          fileCopyUri: null,
          name: fileName,
          size: imageData[0].fileSize?.toString(),
          type: imageData[0].type,
          uri: imageData[0].uri,
        },
      };
      const resultAction = await dispatch(chatMediaUploadThunk(params));
      const uploadedUri =
        resultAction.payload.data && resultAction.payload.data.data
          ? resultAction.payload.data.data
          : imageUri;
      setPickImagePath(uploadedUri);
      setSelect(false);
    }
  };

  const showAlert = () => {
    setAlertVisible(true);
  };

  const closeAlert = () => {
    setAlertVisible(false);
  };

  const CustomAlert = ({ visible, onClose }) => {
    return (
      <Modal
        visible={visible}
        transparent
        animationType="slide"
        onRequestClose={onClose}>
        <View style={[styles.modalContainer, { marginTop: 450 }]}>
          <View style={[styles.modalContent, { flexDirection: 'row' }]}>
            <TouchableOpacity onPress={() => openCamera()}>
              <Icon
                name="camera"
                style={[Styles.Backbtn, { marginRight: 20, top: 5 }]}
              />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => handleImagePicker()}>
              <Icon
                name="gallery"
                style={[Styles.Backbtn, { marginRight: 20, top: 5 }]}
              />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={onClose}
              style={[styles.closeButton, { left: 50, bottom: 20 }]}>
              <Text style={[styles.closeButtonText]}>X</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    );
  };

  const renderSend = (props, inputText) => {
    return (
      <View style={{ flexDirection: 'row', alignItems: 'center', height: 60 }}>
        {pickImagePath && (
          <View
            style={{
              right: Platform.OS === 'ios' ? 85 : 95,
              top: 5,
              bottom: 5,
              width: 0,
            }}>
            <IconButton
              style={{ bottom: 5, position: 'absolute' }}
              onPress={() => setPickImagePath('')}
              icon={() => (
                <Icon name={'cross'} color={UiColor.Danger} size={18} />
              )}
              size={28}
            />
            <Image
              source={{ uri: pickImagePath }}
              style={{ width: 30, height: 30, borderRadius: 10 }}
            />
          </View>
        )}
        {select && (
          <ActivityIndicator
            style={ChatStyle.ActivityIndicator}
          />
        )}
        <CustomAlert visible={isAlertVisible} onClose={closeAlert} />
        <Send {...props}>
          <TouchableOpacity
            onPress={() =>
              onSend([{ text: inputText, user: { _id: stateVal.id } }])
            }>
            <Image
              source={IconAsset.Share}
              style={[
                {
                  position: Platform.OS === 'ios' ? undefined : 'absolute',
                  bottom: 7,
                  top: Platform.OS === 'ios' ? 18 : -32,
                  right: Platform.OS === 'ios' ? 45 : 12,
                },
              ]}
            />
          </TouchableOpacity>
        </Send>
      </View>
    );
  };

  const fetchFriends = async () => {
    try {
      const params = {
        user_id: stateVal.id,
        page: 1,
        limit: 30,
      };

      let allFriends = [];
      while (true) {
        const resultAction = await dispatch(fetchMyFriends(params));
        if (fetchMyFriends.fulfilled.match(resultAction)) {
          const newData = resultAction.payload.data.friends;
          allFriends = allFriends.concat(newData);
          if (newData.length < params.limit) {
            break;
          }
          params.page++;
        } else {
          break;
        }
      }
      setMyFriendData(allFriends);
    } catch (error) {
      console.error('Error in fetchFriends:', error);
    }
  };

  function navigateToProfile(text) {
    console.log('text', text);
    const item_id = text.user_id;
      const hasFriend = myFriendData.some(item => item.id === item_id);
      if (hasFriend) {
        navigation.navigate('MyFriendProfile', item_id);
      } else {
        navigation.navigate('FriendProfile', item_id);
      }
  }

  const renderInputToolbar = props => {
    return (
      <InputToolbar
        {...props}
        containerStyle={{
          // borderRadius: -20,
          width: '100%',
          height: 55,
          position: Platform.OS === 'ios' ? undefined : 'absolute',
          bottom: Platform.OS === 'ios' ? 22 : 12,
          // backgroundColor: '#FFFFFF',
          borderTopWidth: 0,
        }}
        renderComposer={composerProps => (
          <View
            style={ChatStyle.MessageInputBox}>
            <TouchableOpacity onPress={() => handleImagePicker()}>
              <Icon name="media" size={28} color={UiColor.GrayLight} />
            </TouchableOpacity>
            <View
              style={ChatStyle.MessageInput}>
              <TextInput
                {...composerProps}
                style={{
                  paddingTop: Platform.OS === 'ios' ? 12 : 10,
                  width: 230,
                }}
                placeholder="Type a message ..."
                multiline
                value={inputText}
                onChangeText={text => onInputTextChanged(text)}
              />
            </View>
          </View>
        )}
      />
    );
  };

  const handleTouchOutsideInput = () => {
    Keyboard.dismiss();
  };
  
  const toggleMessageSelection = async (message) => {
    console.log('message', message);
    const messageId = message._id;
  
    if (selectedMessages.includes(messageId)) {
      setSelectedMessages((prevSelected) =>
        prevSelected.filter((id) => id !== messageId)
      );
    } else {
      setSelectedMessages((prevSelected) => [...prevSelected, messageId]);
    }
  
    await getMessageDocId(); // Fetch document IDs whenever a message is selected
  };
  
  const getMessageDocId = async () => {
    try {
      const chatRoomRef = fireStore().collection('chats').doc(chatRoomId);
      const messagesSnapshot = await chatRoomRef.collection('messages').get();
      const messageDocsMapping = {};
  
      messagesSnapshot.forEach((doc) => {
        const messageData = doc.data();
        messageDocsMapping[messageData._id] = doc.id;
      });
  
      setMessageDocs(messageDocsMapping);
    } catch (error) {
      console.error("Error fetching message document IDs: ", error);
    }
  };

  const deleteSelectedMessages = async () => {
    if (selectedMessages.length === 0) {
      console.log("No messages selected for deletion");
      return;
    }

    try {
      const chatRoomRef = fireStore().collection('chats').doc(chatRoomId);
      const batch = fireStore().batch();

      for (const messageId of selectedMessages) {
        const docId = messageDocs[messageId];
        if (docId) {
          const messageRef = chatRoomRef.collection('messages').doc(docId);

          const messageData = await messageRef.get();
          if (messageData.exists) {
            const { image } = messageData.data();

            if (image) {
              const storage = getStorage();
            const desertRef = ref(storage, `images/${image}`);
            deleteObject(desertRef).then(() => {
            }).catch((error) => {
              console.log('error', error);
            });
            }
          }
          // Delete the message document from Firestore
          batch.delete(messageRef);
        }
      }

      await batch.commit();
      console.log("Messages successfully deleted from Firestore");
      deleteChatListIfValid(receiverId, chatRoomId);

      // Verify deletion
      const remainingMessages = await chatRoomRef.collection('messages').get();
      if (remainingMessages.empty) {
        console.log("No messages remaining.");
      } else {
        remainingMessages.forEach((doc) => {
          console.log("Remaining message after deletion:", doc.id);
        });
      }

      // Update local state
      setMessages((prevMessages) =>
        prevMessages.filter((message) => !selectedMessages.includes(message._id))
      );
      setSelectedMessages([]); // Clear selected messages
    } catch (error) {
      console.error("Error deleting messages: ", error);
    }
  };



  
  const deleteChatListIfValid = async (receiverId, currentChatRoomId) => {
    const receiverChatListRef = fireStore().collection('chatlists').doc(receiverId);
    const receiverChatListDoc = await receiverChatListRef.get();
  
    if (receiverChatListDoc.exists) {
      const data = receiverChatListDoc.data();
  
      // Verify current chatRoomId
      if (data.chatRoomId === currentChatRoomId) {
        const batch = fireStore().batch();
        
        // Update the lastMessage field to null
        batch.update(receiverChatListRef, { lastMessage: null });
        
        // Commit the batch
        await batch.commit();
        console.log(`Last message for receiver ${receiverId} updated to null successfully.`);
      } else {
        console.log(`Current chatRoomId does not match. Expected: ${data.chatRoomId}, but got: ${currentChatRoomId}`);
      }
    } else {
      console.log(`Chat list for receiver ${receiverId} does not exist.`);
    }
  };

  return (
    <TouchableWithoutFeedback
      onPress={handleTouchOutsideInput}
      accessible={false}>
      <View style={{ flex: 1, marginBottom: Platform.OS === 'ios' ? 12 : 0 }}>
        <Appbar.Header
          style={[
            Styles.AppbarHeader,
            Styles.SubHeader,
            Styles.AppBarShadow,
            { justifyContent: 'unset', alignItems: 'center' },
          ]}>
          <Appbar.Action
            animated={false}
            size={20}
            rippleColor="#00000008"
            onPress={() => navigation.goBack()}
            style={{ backgroundColor: UiColor.SecondaryColor }}
            icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
          />
          <TouchableOpacity onPress={() => navigateToProfile({user_id: receiverId})} style={{ flexDirection: 'row', marginRight: 5 }}>
            <Avatar.Image
              size={42}
              style={{backgroundColor: UiColor.ImageLoad}}
              source={
                routeData.userProfile
                  ? {
                    uri: routeData.userProfile,
                  }
                  : IconAsset.BlankUser
              }
            />
            <View style={{ marginLeft: 12 }}>
              <Text
                style={ChatStyle.userName}>
                {routeData.Name ? routeData.Name : ''}
              </Text>
              <Text
                style={ChatStyle.userChatStatus}>
                {userChatStatus && userChatStatus.user_id === receiverId && userChatStatus.status}
              </Text>
            </View>
          </TouchableOpacity>
          {selectedMessages.length !== 0 &&
            <TouchableOpacity
              style={[RemoveStyle.DeleteBtn,{ paddingHorizontal: 20,  paddingVertical: 7,  marginLeft: 'auto' 
               }]}
              onPress={() => {
                deleteSelectedMessages();
              }}>
              <Text
                style={{
                  color: UiColor.White,
                  fontSize: 14,
                  fontFamily: Dm.bold,
                }}>Delete
              </Text>
           </TouchableOpacity>
          }
        </Appbar.Header>

        <View style={{ flex: 1, paddingHorizontal: 12, paddingTop: 10 }}>
          {loading ? (
            <ActivityIndicator
              size="large"
              color="#0000ff"
              style={{ flex: 1, justifyContent: 'center' }}
            />
          ) : (
            <>
              <GiftedChat
                messages={messages}
                messageContainerRef={giftedChatRef}
                onSend={messages => onSend(messages)}
                renderMessage={renderMessage}
                alwaysShowSend
                // scrollToBottom
                renderSend={props => renderSend(props, inputText)}
                renderInputToolbar={renderInputToolbar}
                onInputTextChanged={text => onInputTextChanged(text)}
                user={{
                  _id: stateVal.id,
                  avatar: stateVal.profile_image_path,
                }}
                renderBubble={props => {
                  return (
                    <Bubble
                      {...props}
                      messagesContainerStyle={{
                        paddingHorizontal: 0,
                        marginLeft: 0,
                      }}
                      wrapperStyle={{
                        right: {
                          backgroundColor: 'transparent',
                          borderWidth: 1,
                          borderColor: '#00000014',
                          paddingHorizontal: 5,
                          paddingVertical: 5,
                          minWidth: 146,
                          maxWidth: '80%',
                          borderRadius: 15,
                          borderTopEndRadius: 0,
                          marginBottom: 8,
                        },
                        left: {
                          backgroundColor: '#F0F0F0',
                          borderWidth: 1,
                          borderColor: '#00000014',
                          paddingHorizontal: 5,
                          paddingVertical: 5,
                          minWidth: 146,
                          maxWidth: '80%',
                          borderRadius: 15,
                          borderBottomLeftRadius: 0,
                          marginLeft: 0,
                          marginBottom: 20,
                        },
                      }}
                      textStyle={{
                        right: {
                          color: UiColor.PrimaryColor,
                          fontSize: 14,
                          fontFamily: Dm.regular,
                          lineHeight: 18,
                        },
                        left: {
                          color: UiColor.PrimaryColor,
                          fontSize: 14,
                          fontFamily: Dm.regular,
                          lineHeight: 18,
                        },
                      }}
                      timeTextStyle={{
                        right: {
                          color: '#7F7F7F',
                          fontSize: 10,
                          fontFamily: Dm.regular,
                          lineHeight: 13,
                          marginTop: 5,
                        },
                        left: {
                          color: '#7F7F7F',
                          fontSize: 10,
                          fontFamily: Dm.regular,
                          lineHeight: 13,
                          marginTop: 5,
                        },
                      }}
                    />
                  );
                }}
              />
              <View
                style={{
                  position: 'absolute',
                  bottom: 10,
                  left: 10,
                }}>
                <Text
                  style={{
                    color: '#000000',
                    fontWeight: 'bold',
                    marginBottom: 50,
                  }}>
                  {isMoreTyping === true && 'Typing...'}
                </Text>
              </View>
            </>
          )}
        </View>
      </View>
    </TouchableWithoutFeedback>
  );
};
const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    alignItems: 'center',
  },
  alertText: {
    fontSize: 18,
    marginBottom: 10,
  },
  closeButton: {
    backgroundColor: '#3498db',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
  },
  closeButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  InputBorder: {
    position: 'absolute',
    top: -10,
    // transform: [{ rotate: '180deg' }],
    transform: 'rotate(180deg)',
    left: -20,
    width: '150%',
    height: '120%',
    // backgroundColor: '#00000014',
    // filter: 'blur(10)',
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: -20,
    },
    shadowOpacity: 0.9,
    shadowRadius: 0,
    ...Platform.select({
      android: {
        elevation: 20,
      },
    }),
  },
});
export default Chat;
