/* eslint-disable prettier/prettier */
import { StyleSheet, Platform } from 'react-native';
import { UiColor, Poppins, Inter } from '../../../theme/Index';
import { Dm } from '../../../theme/FontFamily';

export const ChatStyle = StyleSheet.create({
    MessageInputBox: {
        flexDirection: 'row',
        alignItems: 'center',
        position: 'relative',
        marginRight: 10,
    },
    ActivityIndicator: {
        marginRight: 10,
        right: 75,
        top: 5,
        bottom: 5,
        color: '#000000',
        position: 'absolute',
    },
    userChatStatus: {
        fontSize: 14,
        fontFamily: Dm.regular,
        color: '#2E3660',
        marginTop: 2,
    },
    userName: {
        fontSize: 16,
        fontFamily: Dm.medium,
        color: UiColor.PrimaryColor,
    },
    MessageInput: {
        flex: 1,
        width: 300,
        height: 50,
        top: 0,
        bottom: 10,
        left: 10,
        borderRadius: 101,
        paddingLeft: 15,
        fontSize: 16,
        backgroundColor: '#E9E9E9',
        borderWidth: 1,
        borderColor: '#00000014',
        textAlignVertical: 'bottom',
    },
});


