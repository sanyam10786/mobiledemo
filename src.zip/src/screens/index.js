import Splash from './auth/splash/Splash';
import Login from './auth/login/Login';
import ReAuthenticate from './auth/login/ReAuthenticate';
import SignUp from './auth/sign-up/SignUp';
import SignUpSuccess from './auth/sign-up/SignUpSuccess';
import ForgotPassword from './auth/forgot-pass/ForgotPass';
import ForgotSuccess from './auth/forgot-pass/ForgotSuccess';
import ResetPassword from './auth/reset-pass/ResetPass';
import ChangePassword from './auth/reset-pass/ChangePassword';
import Dashboard from './dashboard/Dashboard';
import AddFriends from './add-friends/AddFriends';
import FriendProfile from './add-friends/FriendProfile';
import CameraCapture from './camera/Camera';
import CameraDetail from './camera/CameraDetail';
import EditMoreInfo from './camera/EditMoreInfo';
import Friends from './friends/Friends';
import MyFriendProfile from './friends/MyFriendProfile';
import MyFriendFriends from './friends/MyFriendFriends';
import UserProfile from './user-profile/UserProfile';
import UserProfileEdit from './user-profile/UserProfileEdit';
import Notification from './notifications/Notification';
import ChatNotification from './notifications/ChatNotification';
import Chat from './chat/Chat';
import Catches from './catches/Catches';
import StoryBoard from './story-board/StoryBoard';
import FriendsPosts from './story-board/FriendsPosts';
import PostsUpload from './story-board/PostsUpload';
import PostLikes from './story-board/PostLikes';
import Journal from './journal/Journal';
import JournalList from './journal/JournalList';
import JournalShare from './journal/JournalShare';
import JournalCatches from './journal/JournalCatches';
import CatchHistoryMap from './journal/CatchHistoryMap';
import Challenges from './fish-challenges/Challenges';
import ChallengesCreate from './fish-challenges/ChallengesCreate';
import ChallengesDetail from './fish-challenges/ChallengesDetail';
import RemoveAccount from './auth/remove-account/RemoveAccount';
import ChallengesStoryUpload from './fish-challenges/ChallengesStoryUpload';
import UserPosts from './user-profile/UserPosts';
import EditScannedImage from './camera/EditScannedImage';
import OfflineDetail from './camera/OfflineDetail';
import CatchesDraft from './catches/CatchesDraft';
import ChallengesStory from './fish-challenges/ChallengesStory';
import WeatherDetail from './dashboard/WeatherDetail';

export {
  Splash,
  Login,
  SignUp,
  SignUpSuccess,
  ForgotPassword,
  ForgotSuccess,
  ResetPassword,
  ChangePassword,
  Dashboard,
  AddFriends,
  FriendProfile,
  CameraCapture,
  Friends,
  UserProfile,
  UserProfileEdit,
  CameraDetail,
  ReAuthenticate,
  Notification,
  MyFriendProfile,
  MyFriendFriends,
  Chat,
  Catches,
  StoryBoard,
  PostLikes,
  PostsUpload,
  ChatNotification,
  EditMoreInfo,
  Journal,
  JournalList,
  JournalCatches,
  CatchHistoryMap,
  FriendsPosts,
  Challenges,
  ChallengesCreate,
  ChallengesDetail,
  RemoveAccount,
  ChallengesStoryUpload,
  UserPosts,
  EditScannedImage,
  OfflineDetail,
  CatchesDraft,
  JournalShare,
  ChallengesStory,
  WeatherDetail,
  
};
