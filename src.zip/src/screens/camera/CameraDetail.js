import {View, Text, Image, StatusBar, TouchableOpacity, ScrollView, Alert, BackHandler } from 'react-native';
import { IconAsset, Icon, Styles, UiColor, GlobalStyles } from '../../../theme/Index';
import {useRoute, useIsFocused, useFocusEffect} from '@react-navigation/native';
import {ActivityIndicator, Appbar, Avatar} from 'react-native-paper';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import { RemoveStyle } from '../auth/remove-account/RemoveStyle';
import {fetchMediaDetails, addCatchesInfo} from '../../thunk';
import LinearGradient from 'react-native-linear-gradient';
import {ProfileStyle} from '../user-profile/ProfileStyle';
import {FriendsStyle} from '../add-friends/FriendsStyle';
import React, {useState, useEffect, useRef, useMemo} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import RBSheet from 'react-native-raw-bottom-sheet';
import { heplerService } from '../../services';
import {CameraStyle} from './CameraStyle';
import Share from 'react-native-share';
import RNFS from 'react-native-fs';
import moment from 'moment';
import axios from 'axios';

const CameraDetail = ({navigation}) => {
  const keysData = useSelector(state => state.login.third_party_keys);
  const route = useRoute();
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const refSheet = useRef();
  const mediaId = route.params && route.params.id;
  const updatedRoute = route.params && route.params.updated;
  const routeData = route.params && route.params.data;
  const measured = routeData && routeData.measured;
  const [saved, setSaved] = useState(false);
  const [routeFulfill, setRouteFulFill] = useState(false);
  const [catchId, setCatchId] = useState('');
  const [mediaDetail, setMediaDetail] = useState('');
  const originalDate = mediaDetail.current_date;
  const formattedDate = moment(originalDate, 'YYYY-MM-DD').format('MM-DD-YYYY');
  const getCurrentDate = () => {
    const date = new Date();
    const options = {
      timeZone: 'America/Los_Angeles',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    };
    const formatter = new Intl.DateTimeFormat('en-US', options);
    const [{value: month}, , {value: day}, , {value: year}] =
      formatter.formatToParts(date);
    return `${year}-${month}-${day}`;
  };
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const [weatherData, setWeatherData] = useState(null);
  const [astroData, setAstroData] = useState(null);
  const [waterTemp, setWaterTemp] = useState('');
  const [tideWave, setTideWave] = useState('');
  const [tideData, setTideData] = useState([]);
  const [formLayoutIndex, setFormLayoutIndex] = useState(0);
  const [state, setState] = React.useState({open: false});
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [IsLoading, setIsLoading] = useState(false);
  const onStateChange = ({open}) => setState({open});
  const {open} = state;
  const [formErrors, setFormErrors] = useState({});
  const [formData, setFormData] = useState({
    media: '',
    fish_name: '',
    height: '',
    width: '',
    weight: '',
    length: '',
    date: '',
    time: '',
    location: '',
    water_temperature: '',
    moon_phases: '',
    weather_condition: '',
    tide_period: '',
    bait_type: '',
    depth_of_water: '',
    lure_type: '',
    current: '',
    current_latitude: '',
    current_longitude: '',
    sunrise: '',
    sunset: '',
    moonrise: '',
    moonset: '',
    tide_data: [''],
    weather_data: '',
  });

  useEffect(() => {
    if (isFocused && mediaId !== undefined && !mediaDetail) {
      fetchMediaData();
    }
    const fetchData = async () => {
      if (
        isFocused &&
        mediaDetail?.current_latitude &&
        !astroData &&
        !weatherData
      ) {
        fetchOpenWeatherMap();
      }

      if (
        isFocused &&
        weatherData !== '' &&
        astroData !== '' &&
        mediaDetail !== '' &&
        formData.current_latitude === ''
      ) {
        setAllData();
      }
    };
    fetchData();
  }, [
    mediaId,
    isFocused,
    mediaDetail,
    weatherData,
    astroData,
    formData,
  ]);

  useEffect(() => {
    if (isFocused && astroData !== '' && formData.current_latitude !== '') {
      setAllData();
    }
  }, [astroData, isFocused]);

  useFocusEffect(
    React.useCallback(() => {
      if (updatedRoute !== undefined) {
        console.log('calling');
        fetchMediaData();
      }
      const backHandler = BackHandler.addEventListener(
        'hardwareBackPress',
        handleBackPress,
      );
      return () => {
        backHandler.remove();
      };
    }, [updatedRoute]),
  );
  const handleBackPress = () => {
    navigation.navigate('DrawerNav');
    return true;
  };

  const fetchMediaData = async () => {
    try {
      const params = {
        media_id: mediaId,
      };
      const resultAction = await dispatch(fetchMediaDetails(params));
      if (fetchMediaDetails.fulfilled.match(resultAction)) {
        setRouteFulFill(true);
        const data = resultAction.payload.media;
        setLatitude(data?.current_latitude);
        setLongitude(data?.current_longitude);
        setMediaDetail(data);
      }
    } catch (error) {
      console.error('Error in fetchMediaData1:', error);
    }
  };

  const hasErrors = () => {
    const errors = {};
    const fishNames = formData.fish_name.split(',').map(name => name.trim());
    if (fishNames.length === 0) {
      errors.fish_name = 'Fish name is required';
    } else if (fishNames.length > 1) {
      errors.fish_name = 'Please select only one fish name';
    }
    setFormErrors(errors);
    return Object.keys(errors).length > 0;
  };

  const addCatchesData = async () => {
    refSheet.current.close();
    setIsLoadingMore(true);
    if (hasErrors()) {
      return;
    }
    setFormErrors({});
    try {
      const resultAction = await dispatch(addCatchesInfo(formData));
      if (addCatchesInfo.fulfilled.match(resultAction)) {
        setSaved(true);
        setCatchId(
          resultAction.payload.data ? resultAction.payload.data._id : '',
        );
      }
      setIsLoadingMore(false);
    } catch (error) {
      console.error('Error in fetchMediaData1:', error);
    }
    setIsLoadingMore(false);
  };

  const setAllData = async () => {
    setFormData({
      ...formData,
      media: mediaId,
      weather_condition: `${
        weatherData.weather[0].description
      }, ${convertCelsiusToFahrenheit(weatherData.main.temp).toFixed(
        2,
      )} °F, wind: ${convertMetersPerSecondToMilesPerHour(
        weatherData.wind.speed,
      ).toFixed(2)} miles/hour, ${getWindDirection(weatherData.wind.deg)}`,
      water_temperature: `${waterTemp}`,
      moon_phases: `${
        astroData &&
        astroData.astronomy?.astro?.moon_phase +
          ' ' +
          astroData.astronomy.astro.moon_illumination +
          '%'
      }`,
      date: `${mediaDetail.current_date}`,
      time: `${mediaDetail.current_time}`,
      current_latitude: mediaDetail.current_latitude,
      current_longitude: mediaDetail.current_longitude,
      height: measured && measured[0].height ? measured[0].height : '',
      width: measured && measured[0].width ? measured[0].width : '',
      weight:
        measured && measured[0].fish_weight ? measured[0].fish_weight : '',
      length:
        measured && measured[0].fish_length ? measured[0].fish_length : '',
      fish_name: measured && measured[0].fish_name ? measured[0].fish_name : '',
      tide_period: tideWave && tideWave.type + ' Tide',
      sunrise: `${astroData && astroData.astronomy?.astro?.sunrise}`,
      sunset: `${astroData && astroData.astronomy?.astro?.sunset}`,
      moonrise: `${astroData && astroData.astronomy?.astro?.moonrise}`,
      moonset: `${astroData && astroData.astronomy?.astro?.moonset}`,
      tide_data: tideData ? tideData : '',
    });
  };

  const fetchOpenWeatherMap = async () => {
    const ApiKey = keysData.weather;
    try {
      const response = await axios.get(
        'https://api.openweathermap.org/data/2.5/weather',
        {
          params: {
            lat: latitude,
            lon: longitude,
            appid: ApiKey,
            units: 'metric',
          },
        },
      );
      fetchAstroApi();
      fetchSeaSurfaceTemperature();
      setWeatherData(response.data);
      fetchTideData();
      fetchLocationName();
      fetchOceanDepth();
      fetchOpenWeatherWeekly();
    } catch (error) {
      console.log('error', error);
    } finally {
    }
  };

  const fetchAstroApi = async () => {
    const apiKey = keysData && keysData.astro_weather;
    const lat = latitude;
    const long = longitude;
    const currentDate = getCurrentDate();
    const apiUrl = `https://api.weatherapi.com/v1/astronomy.json?key=${apiKey}&q=${lat},${long}&dt=${currentDate}`;
    fetch(apiUrl)
      .then(response => response.json())
      .then(data => {
        setAstroData(data);
        setFormData(prevState => ({
          ...prevState,
          moon_phases: `${
            data &&
            data.astronomy &&
            data.astronomy?.astro?.moon_phase +
              ' ' +
              data.astronomy.astro.moon_illumination +
              '%'
          }`,
        }));
      })
      .catch(error => console.error('Error fetching Moon Phase:', error));
  };

  const fetchSeaSurfaceTemperature = async () => {
    try {
      const ApiKey = keysData && keysData.sea_surface_weather;
      const lat = latitude;
      const long = longitude;
      const baseURL = `http://api.worldweatheronline.com/premium/v1/marine.ashx?key=${ApiKey}&q=${lat},${long}&format=json`;
      const response = await axios.get(baseURL);
      const seaTemperatureF =
        response.data?.data?.weather[0].hourly[0].waterTemp_F;
      const temperature = `${seaTemperatureF} Degree`;
      setWaterTemp(temperature);
      setFormData(prevState => ({
        ...prevState,
        water_temperature: temperature,
      }));
    } catch (error) {
      console.error('Error fetchSeaSurfaceTemperature:', error);
    }
  };

  const fetchTideData = async () => {
    const lat = latitude;
    const lon = longitude;
    const apiKey = keysData && keysData.tide_weather;
    const apiUrl = `https://www.worldtides.info/api/v3?datum=CD&extremes&lat=${lat}&lon=${lon}&key=${apiKey}`;
    try {
      const response = await fetch(apiUrl);
      if (!response.ok) {
        throw new Error('Failed to fetch tide data');
      }
      const jsonData = await response.json();
      setTideWave(jsonData && jsonData.extremes[0]);
      setFormData(prevState => ({
        ...prevState,
        tide_period:
          jsonData &&
          jsonData.extremes &&
          jsonData.extremes[0] &&
          jsonData.extremes[0].type + ' Tide',
        tide_data: jsonData && jsonData.extremes,
      }));
      setTideData(jsonData && jsonData.extremes);
    } catch (error) {
      console.error('Error fetching tide data:', error);
    }
  };

  const fetchLocationName = async () => {
    const apiKey = keysData && keysData.google_map;
    const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${apiKey}`;
    try {
      const response = await axios.get(url);
      if (response.data.status === 'OK') {
        const locationName = response.data.results[0].formatted_address;
        setFormData(prevState => ({
          ...prevState,
          location: locationName,
        }));
      } else {
        console.error('Error fetching location name:', response.data.status);
      }
    } catch (error) {
      console.error('Error fetching location name:', error);
    }
  };

  const fetchOceanDepth = async () => {
    const apiKey = keysData.google_map;
    const url = `https://maps.googleapis.com/maps/api/elevation/json?locations=${latitude},${longitude}&key=${apiKey}`;
    try {
      const response = await axios.get(url);
      if (response.data.status === 'OK') {
        const elevationData = response.data.results[0];
        const elevationInMeters = elevationData.elevation;
        const elevationInFeet = elevationInMeters * 3.28084;
        const depthInFeet =
          elevationInMeters < 0 ? Math.abs(elevationInFeet) : 0;
        setFormData(prevFormData => ({
          ...prevFormData,
          depth_of_water: `${depthInFeet.toFixed(2)} Feet`,
        }));
      } else {
        console.error('Error fetching elevation data:', response.data.status);
      }
    } catch (error) {
      console.error('Error fetching elevation data:', error);
    }
  };

  const fetchOpenWeatherWeekly = async () => {
    const apiKey = keysData && keysData.weather;
    try {
      const response = await axios.get(
        'https://api.openweathermap.org/data/2.5/forecast',
        {
          params: {
            lat: latitude,
            lon: longitude,
            appid: apiKey,
            units: 'metric',
          },
        },
      );
      organizeWeatherData(response.data);
    } catch (error) {
      console.log('Error fetching weather data', error);
    }
  };

  const organizeWeatherData = data => {
    const filteredData = {
      city: {
        country: data.city.country,
        name: data.city.name,
      },
      list: data.list.map(item => ({
        dt_txt: item.dt_txt,
        main: {
          temp: item.main.temp,
          temp_max: item.main.temp_max,
          temp_min: item.main.temp_min,
        },
        weather: item.weather.map(weatherItem => ({
          description: weatherItem.description,
          main: weatherItem.main,
        })),
      })),
    };
    setFormData(prevState => ({
      ...prevState,
      weather_data: filteredData,
    }));
  };

  const backToCamera = () => {
    if (updatedRoute === true) {
      navigation.navigate('Dashboard');
    } else {
      navigation.goBack();
    }
    setMediaDetail('');
  };

  const convertCelsiusToFahrenheit = celsius => {
    return (celsius * 9) / 5 + 32;
  };

  const convertMetersPerSecondToMilesPerHour = mps => {
    return mps * 2.23694;
  };

  const getWindDirection = degrees => {
    if (degrees >= 0 && degrees < 90) {
      return 'North';
    } else if (degrees >= 90 && degrees < 180) {
      return 'East';
    } else if (degrees >= 180 && degrees < 270) {
      return 'South';
    } else if (degrees >= 270 && degrees < 360) {
      return 'West';
    } else {
      return '';
    }
  };

  const navigateToEditMoreInfo = catchId => {
    setIsLoading(true);
    setTimeout(() => {
      if (catchId) {
        navigation.navigate('EditMoreInfo', {catch_id: catchId});
      }
    }, 2000);
    setIsLoading(false);
  };

  const shareCatchData = async () => {
    try {
      const imageUrl =
        mediaDetail.measured && mediaDetail.measured[0].detected_path;
      const downloadDest = `${RNFS.CachesDirectoryPath}/catchImage.jpg`;
      const options = {
        fromUrl: imageUrl,
        toFile: downloadDest,
      };
      await RNFS.downloadFile(options).promise;
      const shareOptions = {
        title: 'Check out my catch!',
        url: `file://${downloadDest}`,
        type: 'image/jpeg',
        failOnCancel: false,
      };
      await Share.open(shareOptions);
    } catch (error) {
      alert(error.message);
    }
  };

  const ImageComponent = useMemo(() => {
    return (
      <>
        {mediaDetail?.measured &&
          mediaDetail?.measured.map((item, index) => (
            <View
              style={{ marginBottom: 10, marginHorizontal: 10 }}
              key={index}>
              {item.detected_path ? (
                <Image
                source={{
                  uri: `${
                    item.detected_path
                  }?timestamp=${new Date().getTime()}`,
                }}
                  style={{
                    width: '100%',
                    height: 300,
                    resizeMode: 'contain',
                  }}
                />
              ) : (
                console.log('No detected_path found for item:', item)
              )}
            </View>
          ))}
      </>
    );
  }, [mediaDetail?.measured]);

  return (
    <LinearGradient
      colors={['rgba(230, 236, 244, 0.00)', '#F6FAFF']}
      useAngle={true}
      angle={192}
      style={{flex: 1}}>
      <StatusBar barStyle="light-content" />
      <Appbar.Header style={[Styles.AppbarHeader, ProfileStyle.UserProfileBar]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => backToCamera()}
          style={{backgroundColor: UiColor.SecondaryColor}}
          icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
        />
        {updatedRoute && (
          <TouchableOpacity
            style={[RemoveStyle.DeleteBtn,{ paddingHorizontal: 12,  paddingVertical: 7,
              alignItems: 'center'}]}
              onPress={() => refSheet.current.open()}>
              <Text
                style={RemoveStyle.DoneBtnText}>
                  Save/Edit
              </Text>
          </TouchableOpacity>
        )}
      </Appbar.Header>

      {mediaDetail?.measured?.length === 0 ? (
        <Text style={[CameraStyle.CardTitle, {marginLeft: 20, marginTop: 50}]}>
          There is no clear object in your image, please use another image.
        </Text>
      ) : (
        ''
      )}
      <View style={[Styles.Container]}>
        {!formData.length ? (
            <SkeletonPlaceholder>
            <SkeletonPlaceholder.Item height={250} width="100%" />
            <SkeletonPlaceholder.Item paddingTop={20} marginLeft={20}>
              <View style={CameraStyle.UploadImgDetail}>
              <View style={[CameraStyle.UploadDetailCardHead]}>
                <SkeletonPlaceholder.Item borderRadius={12} style={CameraStyle.UploadDetailCard}>
                  <SkeletonPlaceholder.Item width={80} height={20} />
                  <SkeletonPlaceholder.Item width={100} height={20} marginTop={10} />
                </SkeletonPlaceholder.Item>
              </View>
              <View style={[CameraStyle.UploadDetailCardHead]}>
                <SkeletonPlaceholder.Item borderRadius={12} style={CameraStyle.UploadDetailCard}>
                  <SkeletonPlaceholder.Item width={80} height={20} />
                  <SkeletonPlaceholder.Item width={100} height={20} marginTop={10} />
                </SkeletonPlaceholder.Item>
              </View>
            </View>
            <View style={CameraStyle.UploadImgDetail}>
              <View style={[CameraStyle.UploadDetailCardHead]}>
                <SkeletonPlaceholder.Item borderRadius={12} style={CameraStyle.UploadDetailCard}>
                  <SkeletonPlaceholder.Item width={80} height={20} />
                  <SkeletonPlaceholder.Item width={100} height={20} marginTop={10} />
                </SkeletonPlaceholder.Item>
              </View>
              <View style={[CameraStyle.UploadDetailCardHead]}>
                <SkeletonPlaceholder.Item borderRadius={12} style={CameraStyle.UploadDetailCard}>
                  <SkeletonPlaceholder.Item width={80} height={20} />
                  <SkeletonPlaceholder.Item width={100} height={20} marginTop={10} />
                </SkeletonPlaceholder.Item>
              </View>
            </View>
            </SkeletonPlaceholder.Item>
            {Array.from({ length: 3 }).map((_, index) => (
              <View style={[FriendsStyle.Card, {shadowOpacity: 0,
                shadowRadius: 0,}]} key={index}>
                <SkeletonPlaceholder.Item height={50} width="100%">
                  <View style={FriendsStyle.CardLeft}>
                    <SkeletonPlaceholder.Item
                      width={51}
                      height={51}
                      borderRadius={51}
                    />
                    <View>
                      <SkeletonPlaceholder.Item
                        height={30}
                        width={130}
                        marginLeft={10}
                      />
                      <SkeletonPlaceholder.Item
                        height={20}
                        width={90}
                        marginLeft={10}
                        marginTop={8}
                      />
                    </View>
                  </View>
                </SkeletonPlaceholder.Item>
              </View>
            ))}
          </SkeletonPlaceholder>
        ) : (
          <>
             <>
                {ImageComponent}
              </>
            {updatedRoute && (
              <ScrollView showsVerticalScrollIndicator={false}>
                <View style={CameraStyle.UploadImgDetail}>
                  <View style={[CameraStyle.UploadDetailCardHead]}>
                    <View style={CameraStyle.UploadDetailCard}>
                      <Text style={CameraStyle.CardLabel}>Length</Text>
                      <Text style={CameraStyle.CardTitle}>
                        {formData.length ? formData.length : '--'}
                      </Text>
                    </View>
                  </View>
                  <View style={[CameraStyle.UploadDetailCardHead]}>
                    <View style={CameraStyle.UploadDetailCard}>
                      <Text style={CameraStyle.CardLabel}>Weight</Text>
                      <Text style={CameraStyle.CardTitle}>
                        {formData.weight ? formData.weight : '--'}
                      </Text>
                    </View>
                  </View>
                </View>
                <View style={CameraStyle.UploadImgDetail}>
                  <View style={[CameraStyle.UploadDetailCardHead]}>
                    <View style={CameraStyle.UploadDetailCard}>
                      <Text style={CameraStyle.CardLabel}>Date</Text>
                      <Text style={CameraStyle.CardTitle}>
                        {mediaDetail ? formattedDate : '--'}
                      </Text>
                    </View>
                  </View>
                  <View style={[CameraStyle.UploadDetailCardHead]}>
                    <View style={CameraStyle.UploadDetailCard}>
                      <Text style={CameraStyle.CardLabel}>Time</Text>
                      <Text style={CameraStyle.CardTitle}>
                        {mediaDetail ? mediaDetail.current_time : '--'}
                      </Text>
                    </View>
                  </View>
                </View>
                <View
                  style={[
                    GlobalStyles.alignStart,
                    {marginHorizontal: 10, marginBottom: 180},
                  ]}>
                  <>
                    <View
                      style={[
                        FriendsStyle.Container,
                        {backgroundColor: 'transparent'},
                      ]}>
                      <View style={FriendsStyle.Card}>
                        <View style={[FriendsStyle.CardLeft, {width: 250}]}>
                          <Icon name="location" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                          <View>
                            <Text
                              style={[
                                FriendsStyle.CardTitle,
                                {position: 'relative'},
                              ]}>
                              {heplerService.capitalizeFirstLetter(formData.location ? formData.location : '--')}
                            </Text>
                            <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>
                              Location
                            </Text>
                          </View>
                        </View>
                      </View>
                      <View style={FriendsStyle.Card}>
                        <View style={[FriendsStyle.CardLeft, {width: 250}]}>
                          <Icon name="water-temp" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                          <View>
                            <Text
                              style={[
                                FriendsStyle.CardTitle,
                                {position: 'relative'},
                              ]}>
                              {heplerService.capitalizeFirstLetter(formData.water_temperature ? formData.water_temperature : '--')}
                            </Text>
                            <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>
                              Water Temperature
                            </Text>
                          </View>
                        </View>
                      </View>
                      <View style={FriendsStyle.Card}>
                        <View style={[FriendsStyle.CardLeft, {width: 320}]}>
                          <Icon name="moon" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                          <View>
                            <Text
                              style={[
                                FriendsStyle.CardTitle,
                                {position: 'relative'},
                              ]}>
                              {heplerService.capitalizeFirstLetter(formData.moon_phases ? formData.moon_phases : '--')}
                            </Text>
                            <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>
                              Moon Phase
                            </Text>
                          </View>
                        </View>
                      </View>
                      <View style={FriendsStyle.Card}>
                        <View style={[FriendsStyle.CardLeft, {width: 280}]}>
                          <Icon name="weather" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                          <View>
                            <Text
                              style={[
                                FriendsStyle.CardTitle,
                                {position: 'relative'},
                              ]}>
                              {heplerService.capitalizeFirstLetter(formData.weather_condition ? formData.weather_condition : '--')}
                            </Text>
                            <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>
                              Weather Condition
                            </Text>
                          </View>
                        </View>
                      </View>
                      <View style={FriendsStyle.Card}>
                        <View style={[FriendsStyle.CardLeft, {width: 300}]}>
                          <Icon name="tide" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                          <View>
                            <Text
                              style={[
                                FriendsStyle.CardTitle,
                                {position: 'relative'},
                              ]}>
                              {heplerService.capitalizeFirstLetter(formData.tide_period ? formData.tide_period : '--')}
                            </Text>
                            <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>
                              Tide Period
                            </Text>
                          </View>
                        </View>
                      </View>
                      <View style={FriendsStyle.Card}>
                        <View style={[FriendsStyle.CardLeft, {width: 300}]}>
                          {/* <Icon name="bait" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} /> */}
                          <View style={FriendsStyle.CardImageIcon}>
                            <Icon name="bait" color={UiColor.White} size={16} />
                          </View>
                          <View>
                            <Text
                              style={[
                                FriendsStyle.CardTitle,
                                {position: 'relative'},
                              ]}>
                              {heplerService.capitalizeFirstLetter(formData.bait_type ? formData.bait_type : '--')}
                            </Text>
                            <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>
                              Bait Type
                            </Text>
                          </View>
                        </View>
                      </View>
                      <View style={FriendsStyle.Card}>
                        <View style={[FriendsStyle.CardLeft, {width: 300}]}>
                          <Icon name="depth" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                          <View>
                            <Text
                              style={[
                                FriendsStyle.CardTitle,
                                {position: 'relative'},
                              ]}>
                              {heplerService.capitalizeFirstLetter(formData.depth_of_water ? formData.depth_of_water : '--')}
                            </Text>
                            <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>
                              Depth of Water
                            </Text>
                          </View>
                        </View>
                      </View>
                      <View style={FriendsStyle.Card}>
                        <View style={[FriendsStyle.CardLeft, {width: 300}]}>
                          <View style={FriendsStyle.CardImageIcon}>
                            <Icon name="lure" color={UiColor.White} size={14} />
                          </View>
                          <View>
                            <Text
                              style={[
                                FriendsStyle.CardTitle,
                                {position: 'relative'},
                              ]}>
                              {heplerService.capitalizeFirstLetter(formData.lure_type ? formData.lure_type : '--')}
                            </Text>
                            <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>
                              Lure Type
                            </Text>
                          </View>
                        </View>
                      </View>
                      <View style={FriendsStyle.Card}>
                        <View style={[FriendsStyle.CardLeft, {width: 300}]}>
                          <Icon name="current" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                          <View>
                            <Text
                              style={[
                                FriendsStyle.CardTitle,
                                {position: 'relative'},
                              ]}>
                              {heplerService.capitalizeFirstLetter(formData.current ? formData.current : '--')}
                            </Text>
                            <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>
                              Current
                            </Text>
                          </View>
                        </View>
                      </View>
                    </View>
                  </>
                </View>
              </ScrollView>
            )}
          </>
        )}
      </View>
      <RBSheet
        ref={refSheet}
        closeOnDragDown={true}
        closeOnPressMask={true}
        customStyles={{
          wrapper: {
            backgroundColor: '#100f4d3d',
          },
          draggableIcon: {
            backgroundColor: '#E3E3E3',
            marginTop: 10,
          },
          container: {
            backgroundColor: '#fff',
            borderTopLeftRadius: 30,
            borderTopRightRadius: 30,
          },
        }}>
        <>
          <View style={{paddingHorizontal: 20, marginTop: 20}}>
            <View style={{marginBottom: 10, top: 10}}>
              {isLoadingMore ? (
                <ActivityIndicator style={{marginBottom: 30}} />
              ) : (
                <TouchableOpacity
                  style={[ProfileStyle.BtnFileUpload]}
                  onPress={() => addCatchesData()}>
                  <Text style={ProfileStyle.BtnFileUploadText}>Save</Text>
                </TouchableOpacity>
              )}
            </View>
            <TouchableOpacity
              style={[ProfileStyle.BtnFileUpload]}
              onPress={() => {
                if (catchId) {
                  [refSheet.current.close(), shareCatchData()];
                } else {
                  Alert.alert(
                    'Please save your changes',
                    'You must save your changes before sharing.',
                    [{text: 'OK', onPress: () => console.log('OK Pressed')}],
                  );
                }
              }}>
              <Text style={ProfileStyle.BtnFileUploadText}>Share</Text>
            </TouchableOpacity>
            <View style={{marginBottom: 20}}>
              <TouchableOpacity
                style={[ProfileStyle.BtnFileUpload]}
                onPress={() => {
                  if (catchId) {
                    [refSheet.current.close(), navigateToEditMoreInfo(catchId)];
                  } else {
                    Alert.alert(
                      'Please save your changes',
                      'You must save your changes before editing.',
                      [{text: 'OK', onPress: () => console.log('OK Pressed')}],
                    );
                  }
                }}>
                {IsLoading ? (
                  <ActivityIndicator />
                ) : (
                  <Text style={[ProfileStyle.BtnFileUploadText]}>Edit</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </>
      </RBSheet>
    </LinearGradient>
  );
  
};
export default CameraDetail;
