/* eslint-disable prettier/prettier */
import { StyleSheet, Platform, useColorScheme } from 'react-native';
import { UiColor, Dm } from '../../../theme/Index';

export const CameraStyle = StyleSheet.create({
  UploadImgDetail: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -8,
  },
  UploadDetailCardHead: {
    paddingHorizontal: 8,
    width: '50%',
  },
  UploadDetailCard: {
    backgroundColor: UiColor.White,
    padding: 20,
    borderWidth: 1,
    borderColor: UiColor.labelColor,
    borderRadius: 10,
    marginBottom: 14
  },
  CardLabel: {
    fontSize: 14,
    color: '#757575',
    fontFamily: Dm.regular,
  },
  CardTitle: {
    fontSize: 16,
    color: UiColor.PrimaryColor,
    fontFamily: Dm.medium,
  },

  TabTextHead: {
    flexDirection: 'row',
    // justifyContent: 'space-between',
    marginBottom: 10,
    backgroundColor: 'pink',
    Width: '100%'
  },
  TabLeftText: {
    marginRight: 0,
    fontSize: 14,
    fontWeight: 'bold',
    // maxWidth: '50%',
  },
  TabRightText: {
    // maxWidth: '50%',
    fontWeight: 'bold',
  },
});