import {View, Text, TouchableOpacity, ScrollView, KeyboardAvoidingView, Platform} from 'react-native';
import {Appbar, TextInput, ActivityIndicator, HelperText} from 'react-native-paper';
import {useIsFocused, useNavigation, useRoute} from '@react-navigation/native';
import { RemoveStyle } from '../auth/remove-account/RemoveStyle';
import {fetchCatchesInfo, updateCatchesInfo} from '../../thunk';
import {Styles, UiColor, Icon} from '../../../theme/Index';
import {useDispatch, useSelector} from 'react-redux';
import {LoginStyle} from '../auth/login/LoginStyle';
import React, {useState, useEffect} from 'react';

const EditMoreInfo = ({navigation}) => {
  const dispatch = useDispatch();
  const route = useRoute();
  const catchId = route.params;
  const isFocused = useIsFocused();
  const [formErrors, setFormErrors] = useState({});
  const [inProcess, setInProcess] = useState(false);
  const [formData, setFormData] = useState({
    fish_name: '',
    height: '',
    width: '',
    weight: '',
    date: '',
    time: '',
    location: '',
    water_temperature: '',
    moon_phases: '',
    weather_condition: '',
    tide_period: '',
    bait_type: '',
    depth_of_water: '',
    lure_type: '',
    current: '',
    weather_data: '',
  });

  useEffect(() => {
    if (catchId.catch_id !== undefined) {
      fetchCatchedData();
    }
  }, [catchId.catch_id, isFocused]);

  const fetchCatchedData = async () => {
    try {
      const params = {catch_id: catchId.catch_id};
      const resultAction = await dispatch(fetchCatchesInfo(params));
      if (fetchCatchesInfo.fulfilled.match(resultAction)) {
        const data = resultAction.payload.data;
        setFormData({
          ...formData,
          fish_name: data.fish_name,
          length: data.length,
          // width: data.width,
          weight: data.weight,
          date: data.date,
          time: data.time,
          location: data.location,
          water_temperature: data.water_temperature,
          moon_phases: data.moon_phases,
          weather_condition: data.weather_condition,
          tide_period: data.tide_period,
          bait_type: data.bait_type,
          depth_of_water: data.depth_of_water,
          lure_type: data.lure_type,
          current: data.current,
          current_latitude: data.current_latitude,
          current_longitude: data.current_longitude,
          sunrise: data.sunrise,
          sunset: data.sunset,
          moonrise: data.moonrise,
          moonset: data.moonset,
          tide_data: data.tide_data,
          weather_data: data.weather_data,
        });
      }
    } catch (error) {
      console.error('Error in fetchCatchData:', error);
    }
  };
  const updateCatchesData = async () => {
    if (hasErrors()) {
      return;
    }
    setFormErrors({});
    setInProcess(true);
    try {
      const resultAction = await dispatch(
        updateCatchesInfo({
          formData: formData,
          catch_id: catchId.catch_id,
        }),
      );
      if (updateCatchesInfo.fulfilled.match(resultAction)) {
        if (catchId.isEditfishName === true) {
          navigation.goBack();
        } else {
          navigation.navigate('Dashboard');
        }
      }
    } catch (error) {
      setInProcess(false);
      console.error('Error in fetchCatchData:', error);
    }
    setInProcess(false);
  };

  const hasErrors = () => {
    const errors = {};
    if (!formData.fish_name) {
      errors.fish_name = 'Fish name is required';
    }
    setFormErrors(errors);
    return Object.keys(errors).length > 0;
  };

  return (
    <View style={{flex: 1}}>
      <Appbar.Header style={[Styles.AppbarHeader, Styles.AppBarShadow]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{backgroundColor: UiColor.SecondaryColor}}
          icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
        />
        <Appbar.Content titleStyle={Styles.NavTitle} title="Edit Journal" />
        <TouchableOpacity
          style={[RemoveStyle.DeleteBtn,{ paddingHorizontal: 20,  paddingVertical: 7,
            alignItems: 'center'}]}
          onPress={() => {
            updateCatchesData();
          }}>
            <Text
              style={RemoveStyle.DoneBtnText}>
              {inProcess ? (
                <ActivityIndicator size={24} color={UiColor.White} />
              ) : (
                'Done'
              )}
            </Text>
        </TouchableOpacity>
      </Appbar.Header>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <ScrollView
          contentContainerStyle={{paddingBottom: 120}}
          showsVerticalScrollIndicator={false}>
          <View
            style={[
              Styles.Container,
              {
                backgroundColor: 'transparent',
                paddingHorizontal: 30,
                paddingBottom: 10,
                marginTop: 12
              },
            ]}>
            <View>
              <View style={[LoginStyle.FormControl]}>
                <Text style={{marginLeft: 5, marginTop: 5, marginBottom: 5}}>
                  Fish Name
                </Text>
                <TextInput
                  placeholder="Fish Name"
                  value={formData.fish_name}
                  onChangeText={text => {
                    setFormErrors({...formErrors, fish_name: ''}),
                      setFormData({...formData, fish_name: text});
                  }}
                  theme={LoginStyle.TextInput}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.fish_name
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  editable={false}
                  autoCapitalize="none"
                  keyboardType="default"
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.fish_name !== undefined}>
                  {formErrors.fish_name}
                </HelperText>
              </View>
              <View style={LoginStyle.FormControl}>
                <Text style={{marginLeft: 5, marginTop: 5, marginBottom: 5}}>
                  Length
                </Text>
                <TextInput
                  placeholder="Length"
                  value={formData.length}
                  onChangeText={text => {
                    setFormErrors({...formErrors, length: ''}),
                      setFormData({...formData, length: text});
                  }}
                  theme={LoginStyle.TextInput}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.length
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  editable={false}
                  autoCapitalize="none"
                  keyboardType="default"
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.length !== undefined}>
                  {formErrors.length}
                </HelperText>
              </View>
              <View style={LoginStyle.FormControl}>
                <Text style={{marginLeft: 5, marginTop: 5, marginBottom: 5}}>
                  Weight
                </Text>
                <TextInput
                  placeholder="Weight"
                  value={formData.weight}
                  onChangeText={text => {
                    setFormErrors({...formErrors, weight: ''}),
                      setFormData({...formData, weight: text});
                  }}
                  theme={LoginStyle.TextInput}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.weight
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  editable={false}
                  autoCapitalize="none"
                  keyboardType="default"
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.weight !== undefined}>
                  {formErrors.weight}
                </HelperText>
              </View>
              <View style={LoginStyle.FormControl}>
                <Text style={{marginLeft: 5, marginTop: 5, marginBottom: 5}}>
                  Location
                </Text>
                <TextInput
                  placeholder="Location"
                  value={formData.location}
                  onChangeText={text => {
                    setFormErrors({...formErrors, location: ''}),
                      setFormData({...formData, location: text});
                  }}
                  theme={LoginStyle.TextInput}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.location
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  multiline
                  autoCapitalize="none"
                  keyboardType="default"
                  editable={false}
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.location !== undefined}>
                  {formErrors.location}
                </HelperText>
              </View>
              <View style={LoginStyle.FormControl}>
                <Text style={{marginLeft: 5, marginTop: 5, marginBottom: 5}}>
                  Water Temperature
                </Text>
                <TextInput
                  placeholder="Water Temperature"
                  value={formData.water_temperature}
                  onChangeText={text => {
                    setFormErrors({...formErrors, water_temperature: ''}),
                      setFormData({...formData, water_temperature: text});
                  }}
                  theme={LoginStyle.TextInput}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.water_temperature
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  autoCapitalize="none"
                  keyboardType="default"
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.water_temperature !== undefined}>
                  {formErrors.water_temperature}
                </HelperText>
              </View>
              <View style={LoginStyle.FormControl}>
                <Text style={{marginLeft: 5, marginTop: 5, marginBottom: 5}}>
                  Moon Phase
                </Text>
                <TextInput
                  placeholder="Moon Phase"
                  value={formData.moon_phases}
                  onChangeText={text => {
                    setFormErrors({...formErrors, moon_phases: ''}),
                      setFormData({...formData, moon_phases: text});
                  }}
                  theme={LoginStyle.TextInput}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.moon_phases
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  autoCapitalize="none"
                  keyboardType="default"
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.moon_phases !== undefined}>
                  {formErrors.moon_phases}
                </HelperText>
              </View>
              <View style={LoginStyle.FormControl}>
                <Text style={{marginLeft: 5, marginTop: 5, marginBottom: 5}}>
                  Weather Condition
                </Text>
                <TextInput
                  placeholder="Weather Condition"
                  value={formData.weather_condition}
                  onChangeText={text => {
                    setFormErrors({...formErrors, weather_condition: ''}),
                      setFormData({...formData, weather_condition: text});
                  }}
                  theme={LoginStyle.TextInput}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.weather_condition
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  autoCapitalize="none"
                  keyboardType="default"
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.weather_condition !== undefined}>
                  {formErrors.weather_condition}
                </HelperText>
              </View>
              <View style={LoginStyle.FormControl}>
                <Text style={{marginLeft: 5, marginTop: 5, marginBottom: 5}}>
                  Tide Period
                </Text>
                <TextInput
                  placeholder="Tide Period"
                  value={formData.tide_period}
                  onChangeText={text => {
                    setFormErrors({...formErrors, tide_period: ''}),
                      setFormData({...formData, tide_period: text});
                  }}
                  theme={LoginStyle.TextInput}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.tide_period
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  autoCapitalize="none"
                  keyboardType="default"
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.tide_period !== undefined}>
                  {formErrors.tide_period}
                </HelperText>
              </View>
              <View style={LoginStyle.FormControl}>
                <Text style={{marginLeft: 5, marginTop: 5, marginBottom: 5}}>
                  Bait Type
                </Text>
                <TextInput
                  placeholder="Bait Type"
                  value={formData.bait_type}
                  onChangeText={text => {
                    setFormErrors({...formErrors, bait_type: ''}),
                      setFormData({...formData, bait_type: text});
                  }}
                  theme={LoginStyle.TextInput}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.bait_type
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  autoCapitalize="none"
                  keyboardType="default"
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.bait_type !== undefined}>
                  {formErrors.bait_type}
                </HelperText>
              </View>
              <View style={LoginStyle.FormControl}>
                <Text style={{marginLeft: 5, marginTop: 5, marginBottom: 5}}>
                  Depth of Water
                </Text>
                <TextInput
                  placeholder="Depth of Water"
                  value={formData.depth_of_water}
                  onChangeText={text => {
                    setFormErrors({...formErrors, depth_of_water: ''}),
                      setFormData({...formData, depth_of_water: text});
                  }}
                  theme={LoginStyle.TextInput}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.depth_of_water
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  autoCapitalize="none"
                  keyboardType="default"
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.depth_of_water !== undefined}>
                  {formErrors.depth_of_water}
                </HelperText>
              </View>
              <View style={LoginStyle.FormControl}>
                <Text style={{marginLeft: 5, marginTop: 5, marginBottom: 5}}>
                  Lure Type
                </Text>
                <TextInput
                  placeholder="Lure Type"
                  value={formData.lure_type}
                  onChangeText={text => {
                    setFormErrors({...formErrors, lure_type: ''}),
                      setFormData({...formData, lure_type: text});
                  }}
                  theme={LoginStyle.TextInput}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.lure_type
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  autoCapitalize="none"
                  keyboardType="default"
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.lure_type !== undefined}>
                  {formErrors.lure_type}
                </HelperText>
              </View>
              <View style={LoginStyle.FormControl}>
                <Text style={{marginLeft: 5, marginTop: 5, marginBottom: 5}}>
                  Current
                </Text>
                <TextInput
                  placeholder="Current"
                  value={formData.current}
                  onChangeText={text => {
                    setFormErrors({...formErrors, current: ''}),
                      setFormData({...formData, current: text});
                  }}
                  theme={LoginStyle.TextInput}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.current
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  autoCapitalize="none"
                  keyboardType="default"
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.current !== undefined}>
                  {formErrors.current}
                </HelperText>
              </View>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
};
export default EditMoreInfo;
