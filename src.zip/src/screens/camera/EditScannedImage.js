import {ActivityIndicator, Appbar, TextInput, HelperText} from 'react-native-paper';
import {useRoute, useIsFocused, useNavigation} from '@react-navigation/native';
import {View, Text, Image, TouchableOpacity, StyleSheet} from 'react-native';
import { RemoveStyle } from '../auth/remove-account/RemoveStyle';
import {Icon, Styles, UiColor, Dm} from '../../../theme/Index';
import {ProfileStyle} from '../user-profile/ProfileStyle';
import React, {useState, useEffect, useRef} from 'react';
import {resetState} from '../../slices/fish-challenges';
import {updateMedia, fetchFishTypes} from '../../thunk';
import {Dropdown} from 'react-native-element-dropdown';
import {useDispatch, useSelector} from 'react-redux';
import {LoginStyle} from '../auth/login/LoginStyle';
import {CameraStyle} from './CameraStyle';

const EditScannedImage = ({navigation}) => {
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const route = useRoute();
  const stateVal = useSelector(state => state.fishTypes);
  const fishTypes = stateVal.items;
  const mediaId = route.params && route.params._id;
  const [inProcess, setInProcess] = useState(false);
  const {detected_path, height, width, _id} =
    route.params && route.params.measured[0];
  const [formErrors, setFormErrors] = useState({});
  const [otherInput, setOtherInput] = useState(false);
  const [formData, setFormData] = useState({
    fish_name: '',
    fish_length: '',
    fish_weight: '',
    other_fish_length: '',
  });
  const [params, setParams] = useState({
    search: '',
    page: 1,
    limit: 30,
  });
  const [fishName, setFishName] = useState('');
  const [selectedFish, setSelectedFish] = useState(null);
  const [selectedOtherFish, setSelectedOtherFish] = useState();
  const [selectedOtherLength, setSelectedOtherLength] = useState();
  const [selectedOtherWeight, setSelectedOtherWeight] = useState();
  const [selectedLength, setSelectedLength] = useState(null);
  const [fishValue, setFishValue] = useState({
    label: '',
    value: '',
  });

  useEffect(() => {
    if (isFocused) {
      fetchFishData();
    }
    return () => {
      dispatch(resetState({}));
      if (!isFocused) {
      }
    };
  }, [isFocused]);

  const fetchFishData = async () => {
    try {
      const resultAction = await dispatch(fetchFishTypes(params));
      if (fetchFishTypes.fulfilled.match(resultAction)) {
        dispatch(resetState({}));
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const validateForm = () => {
    let isValid = true;
    const errors = {};

    if (otherInput === true) {
      if (!selectedOtherLength) {
        errors.other_fish_length = 'Fish length is required';
        isValid = false;
      }

      if (!selectedOtherFish) {
        errors.fish_name = 'Fish name is required';
        isValid = false;
      }

      if (!selectedOtherWeight) {
        errors.fish_weight = 'Fish weight is required';
        isValid = false;
      }
    } else {
      if (!selectedFish) {
        errors.fish_type = 'Fish type is required';
        isValid = false;
      }

      if (!selectedLength) {
        errors.fish_length = 'Fish length is required';
        isValid = false;
      }
    }
    setFormErrors(errors);
    return isValid;
  };

  const submitData = async () => {
    if (!validateForm()) {
      return;
    }
    setInProcess(true);
    const params = {
      measured_obj_id: _id,
      fish_name: otherInput === false ? fishName : selectedOtherFish,
      fish_length:
        otherInput === false
          ? selectedLength
          : selectedOtherLength + ' Inches',
      fish_weight:
        otherInput === false
          ? formData.fish_weight
          : selectedOtherWeight + ' LBS',
    };
    const resultAction = await dispatch(updateMedia({mediaId, params}));
    if (updateMedia.fulfilled.match(resultAction)) {
      navigation.navigate('CameraDetail', {
        id: mediaId,
        updated: true,
        data: resultAction.payload.updated_media,
      });
    }
    setInProcess(false);
  };

  const handleFishSelection = fish => {
    if (fish.value) {
      setFishValue({...fishValue, label: fish.label, value: fish.value});
      setSelectedFish(fish.value);
      setFishName(fish.label);
    }
  };

  const handleLengthSelection = length => {
    setSelectedLength(length.value);
    const fishIndex =
      selectedFish && selectedFish.fish_length
        ? selectedFish.fish_length.indexOf(length.value)
        : -1;
    const selectedWeight = selectedFish.fish_weight[fishIndex];
    setFormData(prevState => ({
      ...prevState,
      fish_name: fishName,
      fish_length: length.value,
      fish_weight: selectedWeight,
    }));
  };

  return (
    <>
      <Appbar.Header
        style={[
          Styles.AppbarHeader,
          ProfileStyle.UserProfileBar,
          Styles.AppBarShadow,
        ]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{backgroundColor: UiColor.SecondaryColor}}
          icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
        />
        <Appbar.Content
          titleStyle={Styles.NavTitle}
          title="Edit Media"
        />
        <TouchableOpacity
          style={[RemoveStyle.DeleteBtn,{ paddingHorizontal: 20,  paddingVertical: 7,
            alignItems: 'center'}]}
          onPress={() => {
            submitData();
          }}>
            <Text
              style={RemoveStyle.DoneBtnText}>
              {inProcess ? (
                <ActivityIndicator size={24} color={UiColor.White} />
              ) : (
                'Done'
              )}
            </Text>
        </TouchableOpacity>
      </Appbar.Header>

      <TouchableOpacity
        onPress={() => setOtherInput(!otherInput)}
        style={{width: 65, marginLeft: 30}}>
        <View
          style={{
            marginTop: 10,
            backgroundColor: UiColor.SecondaryColor,
            borderRadius: 5,
            padding: 6,
            width: 65,
            alignItems: 'center',
          }}>
          <Text
            style={{
              fontFamily: Dm.semiBold,
              fontSize: 14,
              color: UiColor.White,
            }}>
            Other
          </Text>
        </View>
      </TouchableOpacity>

      {otherInput === false ? (
        <View style={{flexDirection: 'row', marginHorizontal: 10}}>
          <View>
            <Dropdown
              style={[styles.dropdown, {width: 150}]}
              placeholderStyle={styles.placeholderStyle}
              selectedTextStyle={styles.selectedTextStyle}
              inputSearchStyle={styles.inputSearchStyle}
              iconStyle={styles.iconStyle}
              data={
                fishTypes && fishTypes.result
                  ? fishTypes.result.map(fish => ({
                      label: fish.fish_name,
                      value: fish,
                    }))
                  : []
              }
              search
              maxHeight={300}
              labelField="label"
              valueField="value"
              placeholder="Fish Type"
              searchPlaceholder="Search..."
              value={fishValue}
              onChange={fish => handleFishSelection(fish)}
            />
            <HelperText
              type="error"
              style={[
                Styles.ErrorMsg,
                {left: 10, bottom: -10, position: 'absolute', width: 200},
              ]}
              visible={formErrors.fish_type !== undefined}>
              {formErrors.fish_type}
            </HelperText>
          </View>
          <View>
            <Dropdown
              style={[styles.dropdown, {width: 150}]}
              placeholderStyle={styles.placeholderStyle}
              selectedTextStyle={styles.selectedTextStyle}
              inputSearchStyle={styles.inputSearchStyle}
              iconStyle={styles.iconStyle}
              data={
                selectedFish && selectedFish.fish_length
                  ? selectedFish.fish_length.map(length => ({
                      label: length,
                      value: length,
                    }))
                  : []
              }
              maxHeight={300}
              labelField="label"
              valueField="value"
              placeholder="Length"
              value={selectedLength}
              onChange={length => handleLengthSelection(length)}
            />
            <HelperText
              type="error"
              style={[
                Styles.ErrorMsg,
                {left: 10, bottom: -10, position: 'absolute', width: 200},
              ]}
              visible={formErrors.fish_length !== undefined}>
              {formErrors.fish_length}
            </HelperText>
          </View>
        </View>
      ) : (
        <View
          style={[
            CameraStyle.UploadImgDetail,
            {marginHorizontal: 20, marginBottom: 10},
          ]}>
          <View
            style={[
              CameraStyle.UploadDetailCardHead,
              {width: '100%', marginBottom: 20, marginTop: 10},
            ]}>
            <TextInput
              label="Fish Name"
              value={selectedOtherFish}
              onChangeText={text => {
                const capitalizedText =
                  text.charAt(0).toUpperCase() + text.slice(1);
                setFormErrors({...formErrors, fish_name: ''}),
                  setFormData({...formData, fish_name: capitalizedText}),
                  setSelectedOtherFish(capitalizedText);
              }}
              theme={LoginStyle.TextInput}
              style={[
                LoginStyle.FormInput,
                {
                  borderColor: formErrors.fish_name
                    ? UiColor.SecondaryColor
                    : UiColor.GrayLight,
                },
              ]}
              textColor={UiColor.PrimaryColor}
              underlineStyle={{backgroundColor: 'transparent'}}
              autoCapitalize="none"
              keyboardType="default"
            />
            <HelperText
              type="error"
              style={Styles.ErrorMsg}
              visible={formErrors.fish_name !== undefined}>
              {formErrors.fish_name}
            </HelperText>
          </View>
          <View style={[CameraStyle.UploadDetailCardHead]}>
            <TextInput
              label="Length"
              style={[
                LoginStyle.FormInput,
                {
                  borderColor: formErrors.fish_name
                    ? UiColor.SecondaryColor
                    : UiColor.GrayLight,
                },
              ]}
              value={selectedOtherLength}
              onChangeText={text => {
                setFormErrors({...formErrors, other_fish_length: ''}),
                  setFormData({...formData, fish_length: text}),
                  setSelectedOtherLength(text);
              }}
              keyboardType="numeric"
              theme={LoginStyle.TextInput}
              textColor={UiColor.PrimaryColor}
              underlineStyle={{backgroundColor: 'transparent'}}
            />
            <HelperText
              type="error"
              style={[Styles.ErrorMsg, {bottom: -25}]}
              visible={formErrors.other_fish_length !== undefined}>
              {formErrors.other_fish_length}
            </HelperText>
          </View>
          <View style={[CameraStyle.UploadDetailCardHead]}>
            <TextInput
              label="Weight"
              style={[
                LoginStyle.FormInput,
                {
                  borderColor: formErrors.fish_name
                    ? UiColor.SecondaryColor
                    : UiColor.GrayLight,
                },
              ]}
              value={selectedOtherWeight}
              onChangeText={text => {
                setFormErrors({...formErrors, fish_weight: ''}),
                  setFormData({...formData, fish_weight: text}),
                  setSelectedOtherWeight(text);
              }}
              keyboardType="numeric"
              theme={LoginStyle.TextInput}
              textColor={UiColor.PrimaryColor}
              underlineStyle={{backgroundColor: 'transparent'}}
            />
            <HelperText
              type="error"
              style={[Styles.ErrorMsg, {bottom: -25}]}
              visible={formErrors.fish_weight !== undefined}>
              {formErrors.fish_weight}
            </HelperText>
          </View>
        </View>
      )}

      <View style={{alignItems: 'center', marginTop: 20}}>
        <Image
          source={{uri: detected_path}}
          style={{
            width: '100%',
            height: 320,
            resizeMode: 'contain',
          }}
        />
      </View>
    </>
  );
};
const styles = StyleSheet.create({
  heightLine: {
    position: 'absolute',
    width: 1,
    height: 320,
    backgroundColor: '#000000',
    right: 10,
    bottom: -19,
    borderWidth: 1,
    borderColor: '#000000',
  },
  widthLine: {
    position: 'absolute',
    width: 320,
    height: 1,
    backgroundColor: '#000000',
    left: 0,
    top: 35,
  },
  dropdown: {
    margin: 16,
    height: 50,
    borderBottomColor: 'gray',
    borderBottomWidth: 0.5,
  },
  icon: {
    marginRight: 5,
  },
  placeholderStyle: {
    fontSize: 16,
  },
  selectedTextStyle: {
    fontSize: 16,
  },
  iconStyle: {
    width: 20,
    height: 20,
  },
  inputSearchStyle: {
    height: 40,
    fontSize: 16,
  },
});
export default EditScannedImage;
