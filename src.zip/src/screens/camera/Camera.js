import { View, Text, Image, BackHandler, TouchableOpacity, PermissionsAndroid, Platform, StyleSheet} from 'react-native';
import {useIsFocused, useFocusEffect,useNavigation,} from '@react-navigation/native';
import React, {useState, useEffect, useRef, useContext} from 'react';
import {Camera, useCameraDevices} from 'react-native-vision-camera';
import { RemoveStyle } from '../auth/remove-account/RemoveStyle';
import Geolocation from '@react-native-community/geolocation';
import {ActivityIndicator, Appbar} from 'react-native-paper';
import {Icon, Styles, UiColor} from '../../../theme/Index';
import ImagePicker from 'react-native-image-crop-picker';
import {useDispatch, useSelector} from 'react-redux';
import {NetworkContext} from '../../NetworkContext';
import * as Localize from 'react-native-localize';
import {mediaUploadThunk} from '../../thunk';
import moment from 'moment-timezone';

const CameraCapture = () => {
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const camera = useRef(null);
  const devices = useCameraDevices();
  // const currentDevice = Platform.OS === 'ios'
  // ? devices?.back
  // : devices?.find(device => device.position === 'back')
  const currentDevice = devices && devices?.find(device => device.position === 'back');
  const device = currentDevice;
  const navigation = useNavigation();
  const [enableFlashlight, setEnableFlashLight] = useState(false);
  const [imagePath, setImagePath] = useState('');
  const [pickImagePath, setPickImagePath] = useState('');
  const [takePhotoClicked, setTakePhotoClicked] = useState(false);
  const [allPermission, setAllPermission] = useState(false);
  const [backToCamera, setBackToCamera] = useState(false);
  const [PhotoClickedParams, setPhotoClickedParams] = useState('');
  const isConnected = useContext(NetworkContext);
  const [isSubmit, setIsSubmit] = useState(false);
  const [formData, setFormData] = useState({
    current_latitude: '',
    current_longitude: '',
    locationStatus: '',
    enableFlashlight: '',
    imageUrl: '',
    takePhotoClicked: '',
    current_date: '',
    current_time: '',
  });
  const deviceTimeZoneLocalize = Localize.getTimeZone();

  const getCurrentDate = () => {
    return moment.tz(deviceTimeZoneLocalize).format('YYYY-MM-DD');
  };

  const getCurrentTime = () => {
    return moment.tz(deviceTimeZoneLocalize).format('hh:mm:ss A'); // 12-hour format with AM/PM
  };

  const currentDate = getCurrentDate();
  const currentTime = getCurrentTime();
  
  useFocusEffect(
    React.useCallback(() => {
      setBackToCamera(false);
      const backHandler = BackHandler.addEventListener(
        'hardwareBackPress',
        handleBackPress,
      );
      return () => {
        backHandler.remove();
      };
    }, []),
  );

  useEffect(() => {
    setIsSubmit(false);
    setEnableFlashLight(false);
    checkAndRequestPermissions();
    const requestLocationPermission = async () => {
      if (Platform.OS === 'ios') {
        getOneTimeLocation();
      } else {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.CAMERA,
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          getDevices();
        } else {
          console.log('not permisseds');
        }
      }
    };
    if (isFocused) {
      checkAndRequestPermissions();
      requestLocationPermission();
      getDevices();
    }
    const unsubscribeFocus = navigation.addListener('focus', () => {
      setBackToCamera(false);
      getOneTimeLocation();
      requestLocationPermission();
      checkAndRequestPermissions();
      getDevices();
    });
    return () => {
      unsubscribeFocus();
    };
  }, [navigation, isFocused]);

  const checkAndRequestPermissions = async () => {
    try {
      const granted = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
        PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        PermissionsAndroid.PERMISSIONS.CAMERA,
      ]);
      if (
        granted['android.permission.CAMERA'] ===
          PermissionsAndroid.RESULTS.GRANTED &&
        granted['android.permission.RECORD_AUDIO'] ===
          PermissionsAndroid.RESULTS.GRANTED &&
        granted['android.permission.READ_EXTERNAL_STORAGE'] ===
          PermissionsAndroid.RESULTS.GRANTED &&
        granted['android.permission.WRITE_EXTERNAL_STORAGE'] ===
          PermissionsAndroid.RESULTS.GRANTED &&
        granted['android.permission.ACCESS_FINE_LOCATION'] ===
          PermissionsAndroid.RESULTS.GRANTED
      ) {
        if (!allPermission) {
          getOneTimeLocation();
        }
      } else {
        // Handle permissions denied accordingly.
      }
    } catch (err) {
      console.warn(err);
    }
  };

  const getOneTimeLocation = async () => {
    try {
      console.log('Geolocation');
      const position = await new Promise((resolve, reject) => {
        Geolocation.getCurrentPosition(resolve, reject);
      });
      console.log('position');
      const currentLongitude = JSON.stringify(position.coords.longitude);
      const currentLatitude = JSON.stringify(position.coords.latitude);
      if (currentLongitude !== undefined) {
        setAllPermission(true);
      }
      setFormData({
        ...formData,
        current_longitude: currentLongitude,
        current_latitude: currentLatitude,
      });
    } catch (error) {
      getOneTimeLocation();
      if (error.code === 1) {
        console.log('Permission denied');
      } else if (error.code === 2) {
        console.log('Position unavailable');
      } else if (error.code === 3) {
        console.log('Timeout');
      } else {
        console.log('Other error', error);
      }
    }
  };

  const getDevices = async () => {
    const cameraPermission = await Camera.getCameraPermissionStatus();
    const microphonePermission = await Camera.getMicrophonePermissionStatus();
    if (cameraPermission === 'denied' || microphonePermission === 'denied') {
      checkAndRequestPermissions();
    }
  };

  const takePicture = async () => {
    getOneTimeLocation();
    setImagePath('');
    setPickImagePath('');
    try {
      if (camera && camera.current) {
        const photo = await camera.current.takePhoto({
          flash: enableFlashlight ? 'on' : 'off',
        });

        if (photo.path != null) {
          const path = 'file://' + photo.path;
          setImagePath(path);
          setTakePhotoClicked(true);
          let photoSize = 'Unknown';
          try {
            const absolutePath = path;
            const response = await fetch(absolutePath);
            const fileBlob = await response.blob();
            photoSize = fileBlob.size;
          } catch (error) {
            setTakePhotoClicked(false);
            console.log('Error retrieving photo size:', error);
          }
          
          const croppedImage = await ImagePicker.openCropper({
            path: path,
            compressImageQuality: 0.8,
            cropperCircleOverlay: false,
            freeStyleCropEnabled: true,
            showCropGuidelines: true,
            hideBottomControls: false,
            enableRotationGesture: true,
            avoidEmptySpaceAroundImage: true,
          });  

          if (croppedImage) {
            setImagePath(croppedImage.path);
            const takePictureParams = {
              media_file: {
                fileCopyUri: null,
                name: 'photo.jpg',
                size: croppedImage.size.toString(),
                type: 'image/jpeg',
                uri: croppedImage.path,
              },
              current_longitude: formData.current_longitude,
              current_latitude: formData.current_latitude,
              current_date: currentDate,
              current_time: currentTime,
            };
            setPhotoClickedParams(takePictureParams);
          }
        }
      } else {
        setTakePhotoClicked(false);
        console.log('Camera reference not found or is invalid:', camera);
      }
    } catch (err) {
      setTakePhotoClicked(false);
      console.log('Error capturing photo:', err);
    }
  };

  const submitData = async () => {
    setIsSubmit(true);
    if (isConnected === true) {
      if (PhotoClickedParams) {
        try {
          const resultAction = await dispatch(
            mediaUploadThunk(PhotoClickedParams),
          );
          if (mediaUploadThunk.fulfilled.match(resultAction)) {
            navigation.navigate('EditScannedImage', resultAction.payload.data);
            setIsSubmit(false);
            setTakePhotoClicked(false);
          }
          setIsSubmit(false);
          return resultAction.payload.data;
        } catch (error) {
          console.log('onsubmit', error);
        }
      }
    } else {
      navigation.navigate('OfflineDetail', PhotoClickedParams);
    }
    setIsSubmit(false);
    setTakePhotoClicked(false);
    setBackToCamera(true);
  };

  const handleImagePicker = async () => {
    getOneTimeLocation();
    setImagePath('');
    setTakePhotoClicked(true);
    try {
      const image = await ImagePicker.openPicker({
        cropping: true,
        compressImageQuality: 0.8,
        cropperCircleOverlay: false,
        freeStyleCropEnabled: true,
        showCropGuidelines: true,
        hideBottomControls: false,
        enableRotationGesture: true,
        avoidEmptySpaceAroundImage: true,
        mediaType: 'photo',
      });
      setPickImagePath(image.path);
      setTakePhotoClicked(true);
      if (image) {
        const params = {
          media_file: {
            fileCopyUri: null,
            name: 'galleryObject.jpg',
            size: image.size,
            type: image.mime,
            uri: image.path,
          },
          current_longitude: formData.current_longitude,
          current_latitude: formData.current_latitude,
          current_date: currentDate,
          current_time: currentTime,
        };
        setPhotoClickedParams(params);
      }
      setTakePhotoClicked(true);
    } catch (err) {
      navigation.navigate('DrawerNav');
      setTakePhotoClicked(false);
      console.log('File picking error:', err);
      setBackToCamera(true);
      if (err) {
        setTakePhotoClicked(false);
      }
    }
  };

  const handleBackPress = () => {
    navigation.goBack();
    if (takePhotoClicked) {
      setTakePhotoClicked(false);
      setPickImagePath('');
      setImagePath('');
    } else {
      navigation.navigate('DrawerNav');
    }
    return true;
  };

  const closePreview = async () => {
    setTakePhotoClicked(false);
    setPickImagePath(''), setImagePath('');
  };

  if (device == null) {
    return <ActivityIndicator size={30} style={{marginTop: 100}} />;
  }
  const handleCameraError = e => {
    console.log('error', e);
  };

  return (
    <View style={{flex: 1}}>
      {takePhotoClicked ? (
        <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
          {imagePath !== '' && (
            <Image
              source={{uri: imagePath}}
              style={{flex: 1, width: '100%', resizeMode: 'contain'}}
            />
          )}
          {pickImagePath !== '' && (
            <Image
              source={{uri: pickImagePath}}
              style={{flex: 1, width: '100%', resizeMode: 'contain'}}
            />
          )}
          <View
            style={{
              position: 'absolute',
              left: 20,
              top: 60,
              backgroundColor: '#D2283D',
              borderRadius: 50,
              width: 35,
              height: 35,
              justifyContent: 'center',
              alignItems: 'center',
              zIndex: 999,
            }}>
            <Icon
              name="back"
              size={25}
              style={Styles.BackWhite}
              onPress={() => {
                closePreview();
              }}
            />
          </View>
          <View
            style={{
              position: 'absolute',
              right: 12,
              top: 61,
            }}>
          <TouchableOpacity
            style={[RemoveStyle.DeleteBtn,{ paddingHorizontal: 20,  paddingVertical: 7,
              alignItems: 'center'}]}
            onPress={() => {
              submitData();
            }}>
              <Text
                style={RemoveStyle.DoneBtnText}>
                {isSubmit ? (
                  <ActivityIndicator size={22} color={UiColor.White} />
                ) : (
                  'Done'
                )}
              </Text>
          </TouchableOpacity>
          </View>
        </View>
      ) : (
        <View style={{flex: 1}}>
          {allPermission ? (
            <Camera
              ref={camera}
              style={[StyleSheet.absoluteFillObject]}
              device={device}
              isActive={isFocused}
              photo={true}
              captured={true}
              onError={handleCameraError}
              zoom={0}
              orientation={'portrait'}
            />
          ) : (
            <View
              style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: '#000000',
              }}>
              <ActivityIndicator style={{backgroundColor: '#000000'}} />
            </View>
          )}
          {backToCamera && allPermission ? (
            <Camera
              ref={camera}
              style={[StyleSheet.absoluteFillObject]}
              device={device}
              isActive={isFocused}
              photo={true}
              captured={true}
              onError={handleCameraError}
              zoom={0}
              orientation={'portrait'}
            />
          ) : (
            ''
          )}
          <TouchableOpacity
            style={Styles.CameraClick}
            disabled={!allPermission}
            onPress={() => takePicture()}></TouchableOpacity>
          <View style={Styles.CameraIcons}>
            <TouchableOpacity
              disabled={!allPermission}
              style={Styles.CameraBtn}
              onPress={() => {
                handleImagePicker();
              }}>
              <Icon name="gallery" size={26} color={UiColor.White} />
            </TouchableOpacity>
          </View>
          <View style={[Styles.CameraIcons, Styles.CameraFlash]}>
            <TouchableOpacity
              disabled={!allPermission}
              style={Styles.CameraBtn}
              onPress={() => {
                setEnableFlashLight(!enableFlashlight);
              }}>
              <Icon
                name="flash"
                size={26}
                color={enableFlashlight ? UiColor.White : UiColor.GrayLight}
              />
            </TouchableOpacity>
          </View>
          <TouchableOpacity
            style={{
              position: 'absolute',
              left: 20,
              top: 60,
              backgroundColor: 'transparent',
            }}
            onPress={() => {
              navigation.goBack();
            }}>
            <View
              style={{
                position: 'absolute',
                backgroundColor: '#D2283D',
                borderRadius: 50,
                width: 36,
                height: 36,
                justifyContent: 'center',
                alignItems: 'center',
                zIndex: 999,
              }}>
              <Icon name="back" size={18} style={Styles.BackWhite} />
            </View>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
};
export default CameraCapture;
