import {View, Text, Image, StatusBar, TouchableOpacity, KeyboardAvoidingView, TouchableWithoutFeedback, Keyboard, StyleSheet, ScrollView} from 'react-native';
import {ActivityIndicator, Appbar, TextInput, Avatar, HelperText} from 'react-native-paper';
import {IconAsset, Icon, Styles, UiColor, GlobalStyles, Dm} from '../../../theme/Index';
import {useRoute, useIsFocused, useNavigation} from '@react-navigation/native';
import {addOfflineCatches, fetchFishTypes, fetchAPIKeys} from '../../thunk';
import React, {useState, useEffect, useRef, useContext} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { RemoveStyle } from '../auth/remove-account/RemoveStyle';
import {ProfileStyle} from '../user-profile/ProfileStyle';
import LinearGradient from 'react-native-linear-gradient';
import {FriendsStyle} from '../add-friends/FriendsStyle';
import {Dropdown} from 'react-native-element-dropdown';
import {useDispatch, useSelector} from 'react-redux';
import {LoginStyle} from '../auth/login/LoginStyle';
import {NetworkContext} from '../../NetworkContext';
import Toast from 'react-native-toast-message';
import moment from 'moment';
import axios from 'axios';

const OfflineDetail = () => {
  const route = useRoute();
  const routeData = route.params;
  const isConnected = useContext(NetworkContext);
  const [isSaved, setIsSaved] = useState(false);
  const stateVal = useSelector(state => state.fishTypes);
  const keysData = useSelector(state => state.login.third_party_keys);
  const fishTypes = stateVal.items;
  const [storedFishData, setStoredFishData] = useState(null);
  const [fishNames, setFishNames] = useState([]);
  const [selectedFishName, setSelectedFishName] = useState(null);
  const [otherInput, setOtherInput] = useState(false);
  const [offlineUserId, setOfflineUserId] = useState('');
  const [selectedLength, setSelectedLength] = useState('');
  const [fishLength, setFishLengths] = useState('');
  const [formErrors, setFormErrors] = useState({});
  const [selectedOtherFish, setSelectedOtherFish] = useState();
  const [selectedOtherLength, setSelectedOtherLength] = useState();
  const [selectedOtherWeight, setSelectedOtherWeight] = useState();
  const navigation = useNavigation();
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const [inProcess, setInProcess] = useState(false);
  const [formData, setFormData] = useState({
    user_id: '',
    id: '',
    media_file: '',
    fish_name: '',
    height: '',
    width: '',
    weight: '',
    length: '',
    current_date: '',
    current_time: '',
    location: '',
    water_temperature: '',
    moon_phases: '',
    weather_condition: '',
    tide_period: '',
    bait_type: '',
    depth_of_water: '',
    lure_type: '',
    current: '',
    current_latitude: '',
    current_longitude: '',
    sunrise: '',
    sunset: '',
    moonrise: '',
    moonset: '',
    tide_data: [''],
    notes: '',
    weather_data: '',
  });
  const [params, setParams] = useState({
    search: '',
    page: 1,
    limit: 30,
  });

  useEffect(() => {
    if (routeData) {
      if (routeData.id) {
        setIsSaved(true);
      }
      const uniqueId = generateUniqueId();
      setFormData({
        ...formData,
        user_id: offlineUserId,
        id: uniqueId,
        ...routeData,
        media_file: routeData && routeData.media_file,
        fish_name: routeData && routeData.fish_name ? routeData.fish_name : '',
        height: routeData && routeData.height ? routeData.height : '',
        width: routeData && routeData.width ? routeData.width : '',
        weight: routeData && routeData.weight ? routeData.weight : '',
        length: routeData && routeData.length ? routeData.length : '',
        current_date:
          routeData && routeData.current_date ? routeData.current_date : '',
        current_time:
          routeData && routeData.current_time ? routeData.current_time : '',
        location: routeData && routeData.location ? routeData.location : '',
        water_temperature:
          routeData && routeData.water_temperature
            ? routeData.water_temperature
            : '',
        moon_phases:
          routeData && routeData.moon_phases ? routeData.moon_phases : '',
        weather_condition:
          routeData && routeData.weather_condition
            ? routeData.weather_condition
            : '',
        tide_period:
          routeData && routeData.tide_period ? routeData.tide_period : '',
        bait_type: routeData && routeData.bait_type ? routeData.bait_type : '',
        depth_of_water:
          routeData && routeData.depth_of_water ? routeData.depth_of_water : '',
        lure_type: routeData && routeData.lure_type ? routeData.lure_type : '',
        current: routeData && routeData.current ? routeData.current : '',
        current_latitude:
          routeData && routeData.current_latitude
            ? routeData.current_latitude
            : '',
        current_longitude:
          routeData && routeData.current_longitude
            ? routeData.current_longitude
            : '',
      });
      setSelectedFishName(
        routeData && routeData.fish_name ? routeData.fish_name : '',
      );
      setSelectedLength(routeData && routeData.length ? routeData.length : '');
      setSelectedOtherFish(
        routeData && routeData.fish_name ? routeData.fish_name : '',
      );
      setSelectedOtherLength(
        routeData && routeData.length ? routeData.length : '',
      );
      setSelectedOtherWeight(
        routeData && routeData.weight ? routeData.weight : '',
      );
      if (isConnected) {
        fetchFishData();
      }
    }
    fetchLoginUserId();
    retrieveFishDataFromStorage();
  }, []);

  useEffect(() => {
    if (isFocused && isConnected && keysData !== undefined) {
      const latititude = routeData.current_latitude;
      const longitude = routeData.current_longitude;
      if (latititude && longitude) {
        fetchLocationName(latititude, longitude);
        fetchAstroApi(latititude, longitude);
        fetchSeaSurfaceTemperature(latititude, longitude);
        fetchOpenWeatherMap(latititude, longitude);
        fetchTideData(latititude, longitude);
        fetchOceanDepth(latititude, longitude);
        fetchOpenWeatherWeekly(latititude, longitude);
      }
    }
    if (formData.fish_name && fishTypes.result && isConnected === true) {
      const fish = fishTypes.result.find(
        fish => fish.fish_name === formData.fish_name,
      );
      if (fish) {
        const lengths = fish.fish_length.map(length => ({
          label: `${length}`,
          value: length,
        }));
        setFishLengths(lengths);
        if (formData.length) {
          const lengthIndex = fish.fish_length.indexOf(formData.length);
          const weight = fish.fish_weight[lengthIndex];
          setFormData(prevData => ({
            ...prevData,
            weight,
          }));
        }
      }
    }
  }, [isFocused, formData.fish_name, fishTypes.result, isConnected]);

  const getCurrentDate = () => {
    const date = new Date();
    const options = {
      timeZone: 'America/Los_Angeles',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    };
    const formatter = new Intl.DateTimeFormat('en-US', options);
    const [{value: month}, , {value: day}, , {value: year}] =
      formatter.formatToParts(date);

    return `${year}-${month}-${day}`;
  };
  const validateForm = () => {
    let isValid = true;
    const errors = {};

    if (otherInput === true) {
      if (!selectedOtherLength) {
        errors.otherfish_length = 'Fish length is required';
        isValid = false;
      }

      if (!selectedOtherFish) {
        errors.fish_name = 'Fish name is required';
        isValid = false;
      }

      if (!selectedOtherWeight) {
        errors.fish_weight = 'Fish weight is required';
        isValid = false;
      }
    } else {
      if (!selectedFishName) {
        errors.fish_type = 'Fish type is required';
        isValid = false;
      }

      if (!selectedLength) {
        errors.fish_length = 'Fish length is required';
        isValid = false;
      }
    }

    setFormErrors(errors);
    return isValid;
  };

  const fetchLoginUserId = async () => {
    const userObjString = await AsyncStorage.getItem('USER_DATA');
    if (userObjString) {
      const userObj = JSON.parse(userObjString);
      const userId = userObj?.data?.user?._id;
      setOfflineUserId(userId);
      setFormData(prevState => ({
        ...prevState,
        user_id: userId,
      }));
    }
  };

  const retrieveFishDataFromStorage = async () => {
    try {
      const jsonValueData = await AsyncStorage.getItem('@fish_data');
      const storedFishData =
        jsonValueData != null ? JSON.parse(jsonValueData) : [];
      setStoredFishData(storedFishData);
      setFishNames(
        storedFishData.map(name => ({
          label: name.fish_name,
          value: name.fish_name,
        })),
      );
    } catch (e) {
      console.error('Error retrieving fish names from storage:', e);
    }
  };

  const fetchOpenWeatherMap = async (latitude, longitude) => {
    const ApiKey = keysData.weather;
    try {
      const response = await axios.get(
        'https://api.openweathermap.org/data/2.5/weather',
        {
          params: {
            lat: latitude,
            lon: longitude,
            appid: ApiKey,
            units: 'metric',
          },
        },
      );
      const weatherData = response.data;
      setFormData(prevState => ({
        ...prevState,
        weather_condition: `${
          weatherData.weather[0].description
        }, ${convertCelsiusToFahrenheit(weatherData.main.temp).toFixed(
          2,
        )} °F, wind: ${convertMetersPerSecondToMilesPerHour(
          weatherData.wind.speed,
        ).toFixed(2)} miles/hour, ${getWindDirection(weatherData.wind.deg)}`,
      }));
    } catch (error) {
      console.log('error', error);
    } finally {
    }
  };

  const convertCelsiusToFahrenheit = celsius => {
    return (celsius * 9) / 5 + 32;
  };

  const convertMetersPerSecondToMilesPerHour = mps => {
    return mps * 2.23694;
  };

  const getWindDirection = degrees => {
    if (degrees >= 0 && degrees < 90) {
      return 'North';
    } else if (degrees >= 90 && degrees < 180) {
      return 'East';
    } else if (degrees >= 180 && degrees < 270) {
      return 'South';
    } else if (degrees >= 270 && degrees < 360) {
      return 'West';
    } else {
      return '';
    }
  };

  const fetchAstroApi = async (latitude, longitude) => {
    const apiKey = keysData.astro_weather;
    const lat = latitude;
    const long = longitude;
    const currentDate = getCurrentDate();
    const apiUrl = `https://api.weatherapi.com/v1/astronomy.json?key=${apiKey}&q=${lat},${long}&dt=${currentDate}`;
    fetch(apiUrl)
      .then(response => response.json())
      .then(data => {
        setFormData(prevState => ({
          ...prevState,
          moon_phases: `${
            data &&
            data.astronomy &&
            data.astronomy?.astro?.moon_phase +
              ' ' +
              data.astronomy.astro.moon_illumination +
              '%'
          }`,
          sunrise: `${data && data.astronomy?.astro?.sunrise}`,
          sunset: `${data && data.astronomy?.astro?.sunset}`,
          moonrise: `${data && data.astronomy?.astro?.moonrise}`,
          moonset: `${data && data.astronomy?.astro?.moonset}`,
        }));
      })
      .catch(error => console.error('Error fetching Moon Phase:', error));
  };

  const fetchTideData = async (latitude, longitude) => {
    const lat = latitude;
    const lon = longitude;
    const apiKey = keysData.tide_weather;
    const apiUrl = `https://www.worldtides.info/api/v3?datum=CD&extremes&lat=${lat}&lon=${lon}&key=${apiKey}`;
    try {
      const response = await fetch(apiUrl);
      if (!response.ok) {
        throw new Error('Failed to fetch tide data');
      }
      const jsonData = await response.json();
      if (jsonData && jsonData.extremes && jsonData.extremes.length > 0) {
        setFormData(prevState => ({
          ...prevState,
          tide_period: `${
            jsonData &&
            jsonData.extremes &&
            jsonData.extremes[0] &&
            jsonData.extremes[0].type + ' '
          }Tide`,
          tide_data: jsonData && jsonData.extremes,
        }));
      }
    } catch (error) {
      console.error('Error fetching tide data:', error);
    }
  };

  const fetchSeaSurfaceTemperature = async (latitude, longitude) => {
    try {
      const ApiKey = keysData.sea_surface_weather;
      const lat = latitude;
      const long = longitude;
      const baseURL = `http://api.worldweatheronline.com/premium/v1/marine.ashx?key=${ApiKey}&q=${lat},${long}&format=json`;
      const response = await axios.get(baseURL);
      const seaSurfaceTemperature =
        response.data?.data?.weather[0].hourly[0].waterTemp_F;
      setFormData(prevState => ({
        ...prevState,
        water_temperature: `${seaSurfaceTemperature} Degrees`,
      }));
    } catch (error) {
      console.error('Error fetchSeaSurfaceTemperature:', error);
    }
  };

  const fetchLocationName = async (latitude, longitude) => {
    const apiKey = keysData.google_map;
    const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${apiKey}`;
    try {
      const response = await axios.get(url);
      if (response.data.status === 'OK') {
        const locationName = response.data.results[0].formatted_address;
        setFormData(prevState => ({
          ...prevState,
          location: locationName,
        }));
      } else {
        console.error('Error fetching location name:', response.data.status);
      }
    } catch (error) {
      console.error('Error fetching location name:', error);
    }
  };

  const fetchOceanDepth = async (latitude, longitude) => {
    const apiKey = keysData.google_map;
    const url = `https://maps.googleapis.com/maps/api/elevation/json?locations=${latitude},${longitude}&key=${apiKey}`;
    try {
      const response = await axios.get(url);
      if (response.data.status === 'OK') {
        const elevationData = response.data.results[0];
        console.log('elevationInMeters', elevationInMeters);
        const elevationInMeters = elevationData.elevation;
        const elevationInFeet = elevationInMeters * 3.28084;
        const depthInFeet =
          elevationInMeters < 0 ? Math.abs(elevationInFeet) : 0;
        setFormData(prevFormData => ({
          ...prevFormData,
          depth_of_water: `${depthInFeet.toFixed(2)} Feet`,
        }));
      } else {
        console.error('Error fetching elevation data:', response.data.status);
      }
    } catch (error) {
      console.error('Error fetching elevation data:', error);
    }
  };

  const fetchOpenWeatherWeekly = async (latitude, longitude) => {
    const apiKey = keysData && keysData.weather;
    if (!apiKey) {
      console.log('API key is missing');
      return;
    }
    try {
      const response = await axios.get(
        'https://api.openweathermap.org/data/2.5/forecast',
        {
          params: {
            lat: latitude,
            lon: longitude,
            appid: apiKey,
            units: 'metric',
          },
        },
      );
      organizeWeatherData(response.data);
    } catch (error) {
      console.log('error', error);
    }
  };

  const organizeWeatherData = data => {
    const filteredData = {
      city: {
        country: data.city.country,
        name: data.city.name,
      },
      list: data.list.map(item => ({
        dt_txt: item.dt_txt,
        main: {
          temp: item.main.temp,
          temp_max: item.main.temp_max,
          temp_min: item.main.temp_min,
        },
        weather: item.weather.map(weatherItem => ({
          description: weatherItem.description,
          main: weatherItem.main,
        })),
      })),
    };
    setFormData(prevState => ({
      ...prevState,
      weather_data: filteredData,
    }));
  };

  const generateUniqueId = () => {
    const timestamp = Date.now().toString(36);
    const randomNum = Math.random().toString(36).substr(2, 5);
    return `${timestamp}-${randomNum}`;
  };

  const saveDraft = async () => {
    if (!validateForm()) {
      return;
    }
    setInProcess(true);
    if (isConnected === true && isSaved === true) {
      const resultAction = await dispatch(addOfflineCatches(formData));
      if (addOfflineCatches.fulfilled.match(resultAction)) {
        try {
          const drafts = await AsyncStorage.getItem('catch_drafts');
          let draftArray = drafts ? JSON.parse(drafts) : [];
          draftArray = draftArray.filter(item => item.id !== formData.id);
          await AsyncStorage.setItem(
            'catch_drafts',
            JSON.stringify(draftArray),
          );
          navigation.goBack();
        } catch (err) {
          console.error('Error removing uploaded item from AsyncStorage:', err);
        }
      }
      setInProcess(false);
    } else {
      try {
        const drafts = await AsyncStorage.getItem('catch_drafts');
        let draftArray = drafts ? JSON.parse(drafts) : [];
        const index = draftArray.findIndex(item => item.id === formData.id);
        if (index >= 0) {
          draftArray[index] = formData;
        } else {
          draftArray.unshift(formData);
        }
        await AsyncStorage.setItem('catch_drafts', JSON.stringify(draftArray));
        Toast.show({
          topOffset: 45,
          visibilityTime: 4000,
          type: 'success',
          text1: 'Draft Saved.',
        });
        setInProcess(false);
        if (routeData && routeData.fish_name !== '' && isSaved) {
          navigation.goBack();
        } else {
          navigation.navigate('Dashboard');
        }
      } catch (err) {
        console.error('Error saving draft:', err);
        setInProcess(false);
      }
    }
  };

  const onTabChange = async () => {
    if (otherInput === true) {
      setFormData({
        ...formData,
        fish_name: selectedFishName,
        length: selectedLength ? `${selectedLength}` : '',
        weight: '',
      });
    } else {
      setFormData({
        ...formData,
        fish_name: selectedOtherFish,
        length: selectedOtherLength ? `${selectedOtherLength + ' Inches'}` : '',
        weight: selectedOtherWeight
          ? `${selectedOtherWeight} LBS`
          : `${formData.weight} LBS`,
      });
    }
  };

  const fetchFishData = async () => {
    try {
      const resultAction = await dispatch(fetchFishTypes(params));
      if (fetchFishTypes.fulfilled.match(resultAction)) {
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const handleLengthSelection = length => {
    setSelectedLength(length.value);
    const fishName = selectedFishName?.value || formData.fish_name; // Use the formData fish name if selectedFishName is null
    setFormData(prevData => ({
      ...prevData,
      length: length.value,
      fish_name: fishName,
    }));
  };

  const handleFishSelection = fish => {
    const fishName = fish.value;
    setSelectedFishName(fishName);
    setFormData(prevData => ({
      ...prevData,
      fish_name: fishName,
    }));
    if (storedFishData && fishName) {
      const selectedFish = storedFishData.find(
        fish => fish.fish_name === fishName,
      );
      if (selectedFish) {
        setFishLengths(
          selectedFish.fish_length.map(length => ({
            label: `${length}`,
            value: length,
          })),
        );
      }
    }
  };

  return (
    <LinearGradient
      colors={['rgba(230, 236, 244, 0.00)', '#F6FAFF']}
      useAngle={true}
      angle={192}
      style={{flex: 1}}>
      <StatusBar barStyle="light-content" />
      <Appbar.Header style={[Styles.AppbarHeader, Styles.AppBarShadow, {justifyContent: 'space-between'}]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{backgroundColor: UiColor.SecondaryColor}}
          icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
        />
        <TouchableOpacity
          style={[RemoveStyle.DeleteBtn,{ paddingHorizontal: 20,  paddingVertical: 7,
            alignItems: 'center'}]}
          onPress={() => {
            saveDraft();
          }}>
            <Text
              style={{
                color: UiColor.White,
                fontSize: 14,
                fontFamily: Dm.bold,
              }}>
              {inProcess ? (
                <ActivityIndicator size={24} color="#fff" />
              ) : (
                <>
                {isConnected === true && isSaved === true
                  ? 'Upload'
                  : 'Save Draft'}
                  </>
              )}
            </Text>
        </TouchableOpacity>
      </Appbar.Header>
      <KeyboardAvoidingView>
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <View style={[Styles.Container]}>
            <>
              <ScrollView showsVerticalScrollIndicator={false}>
                <TouchableOpacity activeOpacity={1}>
                  <View style={{marginBottom: 10, marginHorizontal: 10}}>
                    <Image
                      source={
                        routeData &&
                        routeData.media_file &&
                        routeData.media_file
                          ? routeData.media_file
                          : ''
                      }
                      style={{
                        width: '100%',
                        height: 300,
                        resizeMode: 'contain',
                      }}
                    />
                  </View>
                  {routeData && !routeData.fish_name && (
                    <TouchableOpacity
                      onPress={() => {
                        setOtherInput(!otherInput),
                          setTimeout(() => {
                            onTabChange();
                          }, 1500);
                      }}
                      style={{width: 65, marginLeft: 20}}>
                      <View
                        style={{
                          marginTop: 10,
                          backgroundColor: UiColor.SecondaryColor,
                          borderRadius: 5,
                          padding: 6,
                          width: 65,
                          alignItems: 'center',
                        }}>
                        <Text
                          style={{
                            fontFamily: Dm.semiBold,
                            fontSize: 14,
                            color: UiColor.White,
                          }}>
                          Other
                        </Text>
                      </View>
                    </TouchableOpacity>
                  )}
                  <View style={[GlobalStyles.alignStart, {marginBottom: 180}]}>
                    <View
                      style={[
                        FriendsStyle.Container,
                        {backgroundColor: 'transparent'},
                      ]}>
                      <View
                        style={[ {flexDirection: 'column'}]}>
                        {otherInput === false ? (
                          <>
                            <Text style={FriendsStyle.TitleText}>Fish Name</Text>
                            {routeData.fish_name ? (
                              <View
                                style={[
                                  FriendsStyle.CardLeft,
                                  {marginBottom: 18},
                                ]}>
                                <TextInput
                                  value={formData.fish_name}
                                  placeholder="Fish Name"
                                  theme={LoginStyle.TextInput}
                                  style={[
                                    LoginStyle.FormInput,
                                    {
                                      borderColor: UiColor.GrayLight,
                                    },
                                  ]}
                                  textColor={UiColor.PrimaryColor}
                                  underlineStyle={{
                                    backgroundColor: 'transparent',
                                  }}
                                  autoCapitalize="none"
                                  keyboardType="default"
                                  editable={false}
                                  left={
                                    <TextInput.Icon
                                      style={LoginStyle.RightBorder}
                                      icon={() => (
                                        // <Icon name="fish" style={FriendsStyle.CardInputIcon} color={"#09193D"} size={36} />
                                        <View style={[FriendsStyle.CardImageIcon, {width: 35, height: 35, borderRadius: 35, marginRight: 3}]}>
                                          <Icon name="fish" color={UiColor.White} size={14} />
                                        </View>
                                      )}
                                    />
                                  }
                                />
                              </View>
                            ) : (
                              <View
                                style={[
                                  FriendsStyle.CardLeft,
                                  {marginBottom: 18},
                                ]}>
                                <View
                                  style={[
                                    LoginStyle.FormInput,
                                    {
                                      flexDirection: 'row',
                                      height: 55,
                                      paddingVertical: 8,
                                      alignItems: 'center',
                                    },
                                  ]}>
                                  <View
                                    style={{
                                      borderRightColor: '#737680',
                                      borderRightWidth: 1,
                                      borderRadius: 0,
                                      marginLeft: 8,
                                      marginRight: 8,
                                      height: '100%',
                                      justifyContent: 'center',
                                    }}>
                                      {/* <Icon name="fish" style={{marginRight: 2}} color={"#09193D"} size={36} /> */}
                                      <View style={[FriendsStyle.CardImageIcon, {width: 35, height: 35, borderRadius: 35, marginRight: 3}]}>
                                        <Icon name="fish" color={UiColor.White} size={12} />
                                      </View>
                                  </View>
                                  <Dropdown
                                    style={[{width: '70%'}]}
                                    placeholderStyle={[styles.placeholderStyle, {color: UiColor.GrayLight}]}
                                    selectedTextStyle={styles.selectedTextStyle}
                                    inputSearchStyle={styles.inputSearchStyle}
                                    iconStyle={styles.iconStyle}
                                    data={fishNames}
                                    maxHeight={300}
                                    labelField="label"
                                    valueField="value"
                                    placeholder="Fish Name"
                                    value={selectedFishName}
                                    onChange={fish => handleFishSelection(fish)}
                                  />
                                  <HelperText
                                    type="error"
                                    style={[
                                      Styles.ErrorMsg,
                                      {
                                        marginRight: -50,
                                        marginTop: 10,
                                        position: 'absolute',
                                        width: 200,
                                      },
                                    ]}
                                    visible={
                                      formErrors.fish_type !== undefined
                                    }>
                                    {formErrors.fish_type}
                                  </HelperText>
                                </View>
                              </View>
                            )}
                            <Text style={FriendsStyle.TitleText}>Length</Text>
                            {routeData.length ? (
                              <View
                                style={[
                                  FriendsStyle.CardLeft,
                                  {marginBottom: 18},
                                ]}>
                                <TextInput
                                  value={formData.length}
                                  placeholder="Length"
                                  theme={LoginStyle.TextInput}
                                  style={[
                                    LoginStyle.FormInput,
                                    {
                                      borderColor: UiColor.GrayLight,
                                    },
                                  ]}
                                  textColor={UiColor.PrimaryColor}
                                  underlineStyle={{
                                    backgroundColor: 'transparent',
                                  }}
                                  autoCapitalize="none"
                                  keyboardType="default"
                                  editable={false}
                                  left={
                                    <TextInput.Icon
                                      style={LoginStyle.RightBorder}
                                      icon={() => (
                                        <Icon name="length" style={FriendsStyle.CardInputIcon} color={"#09193D"} size={36} />
                                      )}
                                    />
                                  }
                                />
                              </View>
                            ) : (
                              <View
                                style={[
                                  FriendsStyle.CardLeft,
                                  {marginBottom: 18},
                                ]}>
                                <View
                                  style={[
                                    LoginStyle.FormInput,
                                    {
                                      flexDirection: 'row',
                                      height: 55,
                                      paddingVertical: 8,
                                      alignItems: 'center',
                                    },
                                  ]}>
                                  <View
                                    style={{
                                      borderRightColor: '#737680',
                                      borderRightWidth: 1,
                                      borderRadius: 0,
                                      marginLeft: 8,
                                      marginRight: 8,
                                      height: '100%',
                                      justifyContent: 'center',
                                    }}>
                                    <Icon name="length" style={{marginRight: 2}} color={"#09193D"} size={36} />
                                  </View>
                                  <Dropdown
                                    style={[{width: '70%'}]}
                                    placeholderStyle={[styles.placeholderStyle, {color: UiColor.GrayLight}]}
                                    selectedTextStyle={styles.selectedTextStyle}
                                    inputSearchStyle={styles.inputSearchStyle}
                                    iconStyle={styles.iconStyle}
                                    data={
                                      fishLength && fishLength ? fishLength : []
                                    }
                                    maxHeight={300}
                                    labelField="label"
                                    valueField="value"
                                    placeholder="Length"
                                    value={selectedLength}
                                    onChange={length =>
                                      handleLengthSelection(length)
                                    }
                                  />
                                  <HelperText
                                    type="error"
                                    style={[
                                      Styles.ErrorMsg,
                                      {
                                        marginRight: -50,
                                        marginTop: 10,
                                        position: 'absolute',
                                        width: 200,
                                      },
                                    ]}
                                    visible={
                                      formErrors.fish_length !== undefined
                                    }>
                                    {formErrors.fish_length}
                                  </HelperText>
                                </View>
                              </View>
                            )}
                            <Text style={FriendsStyle.TitleText}>Weight</Text>
                            {routeData.weight ? (
                              <View
                                style={[
                                  FriendsStyle.CardLeft,
                                  {marginBottom: 18},
                                ]}>
                                <TextInput
                                  value={
                                    routeData.weight
                                      ? routeData.weight + ' LBS'
                                      : formData.weight
                                  }
                                  placeholder="Weight"
                                  onChangeText={text => {
                                    setFormData({...formData, weight: text});
                                  }}
                                  theme={LoginStyle.TextInput}
                                  style={[
                                    LoginStyle.FormInput,
                                    {
                                      borderColor: UiColor.GrayLight,
                                    },
                                  ]}
                                  textColor={UiColor.PrimaryColor}
                                  underlineStyle={{
                                    backgroundColor: 'transparent',
                                  }}
                                  autoCapitalize="none"
                                  keyboardType="default"
                                  editable={false}
                                  left={
                                    <TextInput.Icon
                                      style={LoginStyle.RightBorder}
                                      icon={() => (
                                        // <Icon name="weight" style={{marginRight: 5}} color={"#09193D"} size={36} />
                                        <View style={[FriendsStyle.CardImageIcon, {width: 35, height: 35, borderRadius: 35, marginRight: 3}]}>
                                          <Icon name="weight" color={UiColor.White} size={12} />
                                        </View>
                                      )}
                                    />
                                  }
                                />
                              </View>
                            ) : (
                              <View
                                style={[
                                  FriendsStyle.CardLeft,
                                  {marginBottom: 18},
                                ]}>
                                <TextInput
                                  value={formData.weight}
                                  placeholder="Weight"
                                  onChangeText={text => {
                                    setFormData({...formData, weight: text});
                                  }}
                                  theme={LoginStyle.TextInput}
                                  style={[
                                    LoginStyle.FormInput,
                                    {
                                      borderColor: UiColor.GrayLight,
                                    },
                                  ]}
                                  textColor={UiColor.PrimaryColor}
                                  underlineStyle={{
                                    backgroundColor: 'transparent',
                                  }}
                                  autoCapitalize="none"
                                  keyboardType="default"
                                  editable={false}
                                  left={
                                    <TextInput.Icon
                                      style={[LoginStyle.RightBorder, ]}
                                      icon={() => (
                                        // <Icon name="weight" style={FriendsStyle.CardInputIcon} color={"#09193D"} size={36} />
                                        <View style={[FriendsStyle.CardImageIcon, {width: 35, height: 35, borderRadius: 35, marginRight: 3}]}>
                                          <Icon name="weight" color={UiColor.White} size={22} />
                                        </View>
                                      )}
                                    />
                                  }
                                />
                              </View>
                            )}
                          </>
                        ) : (
                          <>
                            <Text style={FriendsStyle.TitleText}>Fish Name</Text>
                            <View
                              style={[
                                FriendsStyle.CardLeft,
                                {marginBottom: 18},
                              ]}>
                              <TextInput
                                value={selectedOtherFish}
                                placeholder="Fish Name"
                                theme={LoginStyle.TextInput}
                                onChangeText={text => {
                                  const capitalizedText =
                                    text.charAt(0).toUpperCase() +
                                    text.slice(1);
                                  setFormData({
                                    ...formData,
                                    fish_name: capitalizedText,
                                  }),
                                    setSelectedOtherFish(capitalizedText);
                                }}
                                style={[
                                  LoginStyle.FormInput,
                                  {
                                    borderColor: UiColor.GrayLight,
                                  },
                                ]}
                                textColor={UiColor.PrimaryColor}
                                underlineStyle={{
                                  backgroundColor: 'transparent',
                                }}
                                autoCapitalize="none"
                                keyboardType="default"
                                editable={true}
                                left={
                                  <TextInput.Icon
                                  style={LoginStyle.RightBorder}
                                    icon={() => (
                                      // <Icon name="fish" style={FriendsStyle.CardInputIcon} color={"#09193D"} size={36} />
                                      <View style={[FriendsStyle.CardImageIcon, {width: 35, height: 35, borderRadius: 35, marginRight: 3}]}>
                                        <Icon name="fish" color={UiColor.White} size={12} />
                                      </View>
                                    )}
                                  />
                                }
                              />
                              <HelperText
                                type="error"
                                style={[
                                  Styles.ErrorMsg,
                                  {
                                    marginRight: -50,
                                    marginTop: 10,
                                    position: 'absolute',
                                    width: 200,
                                  },
                                ]}
                                visible={formErrors.fish_name !== undefined}>
                                {formErrors.fish_name}
                              </HelperText>
                            </View>
                            <Text style={FriendsStyle.TitleText}>Length</Text>
                            <View
                              style={[
                                FriendsStyle.CardLeft,
                                {marginBottom: 18},
                              ]}>
                              <TextInput
                                value={selectedOtherLength}
                                placeholder="Length"
                                onChangeText={text => {
                                  setFormData({...formData, length: text + ' Inches'}),
                                    setSelectedOtherLength(text);
                                }}
                                theme={LoginStyle.TextInput}
                                style={[
                                  LoginStyle.FormInput,
                                  {
                                    borderColor: UiColor.GrayLight,
                                  },
                                ]}
                                textColor={UiColor.PrimaryColor}
                                underlineStyle={{
                                  backgroundColor: 'transparent',
                                }}
                                autoCapitalize="none"
                                keyboardType="numeric"
                                editable={true}
                                left={
                                  <TextInput.Icon
                                    style={LoginStyle.RightBorder}
                                    icon={() => (
                                      <Icon name="length" style={FriendsStyle.CardInputIcon} color={"#09193D"} size={36} />
                                    )}
                                  />
                                }
                                right={<TextInput.Affix text="Inches" />}
                              />
                              <HelperText
                                type="error"
                                style={[
                                  Styles.ErrorMsg,
                                  {
                                    marginRight: -50,
                                    marginTop: 10,
                                    position: 'absolute',
                                    width: 200,
                                  },
                                ]}
                                visible={
                                  formErrors.otherfish_length !== undefined
                                }>
                                {formErrors.otherfish_length}
                              </HelperText>
                            </View>
                            <Text style={FriendsStyle.TitleText}>Weight</Text>
                            <View
                              style={[
                                FriendsStyle.CardLeft,
                                {marginBottom: 18},
                              ]}>
                              <TextInput
                                value={selectedOtherWeight}
                                placeholder="Weight"
                                onChangeText={text => {
                                  setFormData({...formData, weight: text}),
                                    setSelectedOtherWeight(text);
                                }}
                                theme={LoginStyle.TextInput}
                                style={[
                                  LoginStyle.FormInput,
                                  {
                                    borderColor: UiColor.GrayLight,
                                  },
                                ]}
                                textColor={UiColor.PrimaryColor}
                                underlineStyle={{
                                  backgroundColor: 'transparent',
                                }}
                                autoCapitalize="none"
                                keyboardType="numeric"
                                editable={true}
                                left={
                                  <TextInput.Icon
                                    style={LoginStyle.RightBorder}
                                    icon={() => (
                                      // <Icon name="weight" style={FriendsStyle.CardInputIcon}  color={"#09193D"} size={36} />
                                      <View style={[FriendsStyle.CardImageIcon, {width: 35, height: 35, borderRadius: 35, marginRight: 3}]}>
                                        <Icon name="weight" color={UiColor.White} size={22} />
                                      </View>
                                    )}
                                  />
                                }
                                right={<TextInput.Affix text="LBS" />}
                              />
                              <HelperText
                                type="error"
                                style={[
                                  Styles.ErrorMsg,
                                  {
                                    marginRight: -50,
                                    marginTop: 10,
                                    position: 'absolute',
                                    width: 200,
                                  },
                                ]}
                                visible={formErrors.fish_weight !== undefined}>
                                {formErrors.fish_weight}
                              </HelperText>
                            </View>
                          </>
                        )}
                        <Text style={FriendsStyle.TitleText}>Date</Text>
                        <View
                          style={[FriendsStyle.CardLeft, {marginBottom: 18}]}>
                          <TextInput
                            value={moment(formData.current_date).format(
                              'MM-DD-YYYY',
                            )}
                            placeholder="Date"
                            onChangeText={text => {
                              setFormData({...formData, current_date: text});
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{backgroundColor: 'transparent'}}
                            autoCapitalize="none"
                            keyboardType="default"
                            editable={false}
                            left={
                              <TextInput.Icon
                                style={LoginStyle.RightBorder}
                                icon={() => (
                                  // <Icon name="date" style={FriendsStyle.CardInputIcon} color={"#09193D"} size={36} />
                                  <View style={[FriendsStyle.CardImageIcon, {width: 35, height: 35, borderRadius: 35, marginRight: 3}]}>
                                    <Icon name="date" color={UiColor.White} size={20} />
                                  </View>
                                )}
                              />
                            }
                          />
                        </View>
                        <Text style={FriendsStyle.TitleText}>Time</Text>
                        <View
                          style={[FriendsStyle.CardLeft, {marginBottom: 18}]}>
                          <TextInput
                            value={formData.current_time}
                            placeholder="Time"
                            onChangeText={text => {
                              setFormData({...formData, time: text});
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{backgroundColor: 'transparent'}}
                            autoCapitalize="none"
                            keyboardType="default"
                            editable={false}
                            left={
                              <TextInput.Icon
                                style={LoginStyle.RightBorder}
                                icon={() => (
                                  <Icon name="time" style={[FriendsStyle.CardInputIcon]} color={"#09193D"} size={36} />
                                )}
                              />
                            }
                          />
                        </View>
                        <Text style={FriendsStyle.TitleText}>Location</Text>
                        <View
                          style={[FriendsStyle.CardLeft, {marginBottom: 18}]}>
                          <TextInput
                            value={formData.location}
                            placeholder="Location"
                            onChangeText={text => {
                              setFormData({...formData, location: text});
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{backgroundColor: 'transparent'}}
                            autoCapitalize="none"
                            keyboardType="default"
                            editable={false}
                            multiline={true}
                            left={
                              <TextInput.Icon
                                style={LoginStyle.RightBorder}
                                icon={() => (
                                  <Icon name="location" style={[FriendsStyle.CardInputIcon]} color={"#09193D"} size={36} />
                                )}
                              />
                            }
                          />
                        </View>
                        <Text style={FriendsStyle.TitleText}>Latitide</Text>
                        <View
                          style={[FriendsStyle.CardLeft, {marginBottom: 18}]}>
                          <TextInput
                            value={formData.current_latitude}
                            placeholder="Latitide"
                            onChangeText={text => {
                              setFormData({
                                ...formData,
                                current_latitude: text,
                              });
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{backgroundColor: 'transparent'}}
                            autoCapitalize="none"
                            keyboardType="default"
                            editable={false}
                            left={
                              <TextInput.Icon
                                style={LoginStyle.RightBorder}
                                icon={() => (
                                  <Icon name="location" style={[FriendsStyle.CardInputIcon]} color={"#09193D"} size={36} />
                                )}
                              />
                            }
                          />
                        </View>
                        <Text style={FriendsStyle.TitleText}>Longitude</Text>
                        <View
                          style={[FriendsStyle.CardLeft, {marginBottom: 18}]}>
                          <TextInput
                            value={formData.current_longitude}
                            placeholder="Longitude"
                            onChangeText={text => {
                              setFormData({
                                ...formData,
                                current_longitude: text,
                              });
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{backgroundColor: 'transparent'}}
                            autoCapitalize="none"
                            keyboardType="default"
                            editable={false}
                            left={
                              <TextInput.Icon
                                style={LoginStyle.RightBorder}
                                icon={() => (
                                  <Icon name="location" style={[FriendsStyle.CardInputIcon]} color={"#09193D"} size={36} />
                                )}
                              />
                            }
                          />
                        </View>
                        <Text style={FriendsStyle.TitleText}>
                          Water Temperature
                        </Text>
                        <View
                          style={[FriendsStyle.CardLeft, {marginBottom: 18}]}>
                          <TextInput
                            value={formData.water_temperature}
                            placeholder="Water Temperature"
                            onChangeText={text => {
                              setFormData({
                                ...formData,
                                water_temperature: text,
                              });
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{backgroundColor: 'transparent'}}
                            autoCapitalize="none"
                            keyboardType="default"
                            multiline={true}
                            left={
                              <TextInput.Icon
                                style={LoginStyle.RightBorder}
                                icon={() => (
                                  <Icon name="water-temp" style={[FriendsStyle.CardInputIcon]} color={"#09193D"} size={36} />
                                )}
                              />
                            }
                          />
                        </View>
                        <Text style={FriendsStyle.TitleText}>Moon Phase</Text>
                        <View
                          style={[FriendsStyle.CardLeft, {marginBottom: 18}]}>
                          <TextInput
                            value={formData.moon_phases}
                            placeholder="Moon Phase"
                            onChangeText={text => {
                              setFormData({...formData, moon_phases: text});
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{backgroundColor: 'transparent'}}
                            autoCapitalize="none"
                            keyboardType="default"
                            left={
                              <TextInput.Icon
                                style={LoginStyle.RightBorder}
                                icon={() => (
                                  <Icon name="moon" style={[FriendsStyle.CardInputIcon]} color={"#09193D"} size={36} />
                                )}
                              />
                            }
                          />
                        </View>
                        <Text style={FriendsStyle.TitleText}>
                          Weather Condition
                        </Text>
                        <View
                          style={[FriendsStyle.CardLeft, {marginBottom: 18}]}>
                          <TextInput
                            value={formData.weather_condition}
                            placeholder="Weather Condition"
                            onChangeText={text => {
                              setFormData({
                                ...formData,
                                weather_condition: text,
                              });
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{backgroundColor: 'transparent'}}
                            autoCapitalize="none"
                            keyboardType="default"
                            editable={false}
                            multiline={true}
                            left={
                              <TextInput.Icon
                                style={LoginStyle.RightBorder}
                                icon={() => (
                                  <Icon name="weather" style={[FriendsStyle.CardInputIcon]} color={"#09193D"} size={36} />
                                )}
                              />
                            }
                          />
                        </View>
                        <Text style={FriendsStyle.TitleText}>Tide Period</Text>
                        <View
                          style={[FriendsStyle.CardLeft, {marginBottom: 18}]}>
                          <TextInput
                            value={formData.tide_period}
                            placeholder="Tide Period"
                            onChangeText={text => {
                              setFormData({...formData, tide_period: text});
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{backgroundColor: 'transparent'}}
                            autoCapitalize="none"
                            keyboardType="default"
                            left={
                              <TextInput.Icon
                                style={LoginStyle.RightBorder}
                                icon={() => (
                                  <Icon name="tide" style={[FriendsStyle.CardInputIcon]} color={"#09193D"} size={36} />
                                )}
                              />
                            }
                          />
                        </View>
                        <Text style={FriendsStyle.TitleText}>Bait Type</Text>
                        <View
                          style={[FriendsStyle.CardLeft, {marginBottom: 18}]}>
                          <TextInput
                            value={formData.bait_type}
                            placeholder="Bait Type"
                            onChangeText={text => {
                              setFormData({...formData, bait_type: text});
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{backgroundColor: 'transparent'}}
                            autoCapitalize="none"
                            keyboardType="default"
                            left={
                              <TextInput.Icon
                                style={LoginStyle.RightBorder}
                                icon={() => (
                                  // <Icon name="bait" style={[FriendsStyle.CardInputIcon]} color={"#09193D"} size={36} />
                                  <View style={[FriendsStyle.CardImageIcon, {width: 35, height: 35, borderRadius: 35, marginRight: 3}]}>
                                    <Icon name="bait" color={UiColor.White} size={16} />
                                  </View>
                                )}
                              />
                            }
                          />
                        </View>
                        <Text style={FriendsStyle.TitleText}>Water Depth</Text>
                        <View
                          style={[FriendsStyle.CardLeft, {marginBottom: 18}]}>
                          <TextInput
                            value={formData.depth_of_water}
                            placeholder="Water Depth"
                            onChangeText={text => {
                              setFormData({...formData, depth_of_water: text});
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{backgroundColor: 'transparent'}}
                            autoCapitalize="none"
                            keyboardType="default"
                            left={
                              <TextInput.Icon
                                style={LoginStyle.RightBorder}
                                icon={() => (
                                  <Icon name="depth" style={[FriendsStyle.CardInputIcon]} color={"#09193D"} size={36} />
                                )}
                              />
                            }
                          />
                        </View>
                        <Text style={FriendsStyle.TitleText}>Lure Type</Text>
                        <View
                          style={[FriendsStyle.CardLeft, {marginBottom: 18}]}>
                          <TextInput
                            value={formData.lure_type}
                            placeholder="Lure Type"
                            onChangeText={text => {
                              setFormData({...formData, lure_type: text});
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{backgroundColor: 'transparent'}}
                            autoCapitalize="none"
                            keyboardType="default"
                            left={
                              <TextInput.Icon
                                style={LoginStyle.RightBorder}
                                icon={() => (
                                  // <Icon name="lure" style={[FriendsStyle.CardInputIcon]} color={"#09193D"} size={36} />
                                  <View style={[FriendsStyle.CardImageIcon, {width: 35, height: 35, borderRadius: 35, marginRight: 3}]}>
                                    <Icon name="lure" color={UiColor.White} size={13} />
                                  </View>
                                )}
                              />
                            }
                          />
                        </View>
                        <Text style={FriendsStyle.TitleText}>Current</Text>
                        <View
                          style={[FriendsStyle.CardLeft, {marginBottom: 18}]}>
                          <TextInput
                            value={formData.current}
                            placeholder="Current"
                            onChangeText={text => {
                              setFormData({...formData, current: text});
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{backgroundColor: 'transparent'}}
                            autoCapitalize="none"
                            keyboardType="default"
                            multiline={true}
                            left={
                              <TextInput.Icon
                                style={LoginStyle.RightBorder}
                                icon={() => (
                                  <Icon name="current" style={[FriendsStyle.CardInputIcon]} color={"#09193D"} size={36} />
                                )}
                              />
                            }
                          />
                        </View>
                      </View>
                    </View>
                  </View>
                </TouchableOpacity>
              </ScrollView>
            </>
          </View>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
};
const styles = StyleSheet.create({
  heightLine: {
    position: 'absolute',
    width: 1,
    height: 320,
    backgroundColor: '#000000',
    right: 10,
    bottom: -19,
    borderWidth: 1,
    borderColor: '#000000',
  },
  widthLine: {
    position: 'absolute',
    width: 'auto',
    height: 1,
    backgroundColor: '#000000',
    left: 0,
    top: 35,
  },
  dropdown: {
    margin: 16,
    height: 50,
    borderBottomColor: 'gray',
    borderBottomWidth: 0.5,
  },
  icon: {
    marginRight: 5,
  },
  placeholderStyle: {
    fontSize: 14,
  },
  selectedTextStyle: {
    fontSize: 14,
    marginHorizontal: 5,
  },
  iconStyle: {
    width: 20,
    height: 20,
  },
  inputSearchStyle: {
    height: 40,
    fontSize: 16,
  },
});
export default OfflineDetail;
