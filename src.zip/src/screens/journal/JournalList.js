import { View, Text, Modal, TouchableOpacity, ScrollView, Image, SafeAreaView, FlatList, useWindowDimensions } from 'react-native';
import { fetchAllCatches, fetchCatchesGallery, fetchShareJournal, sharedJournalFriend, removeSharedJournal } from '../../thunk';
import { Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm } from '../../../theme/Index';
import { Appbar, Avatar, IconButton, ActivityIndicator } from 'react-native-paper';
import { useIsFocused, useNavigation, useRoute } from '@react-navigation/native';
import SegmentedControlTab from 'react-native-segmented-control-tab';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import { resetState, setRefreshing } from '../../slices/catches';
import React, { useEffect, useState, useContext } from 'react';
import { FriendsStyle } from '../add-friends/FriendsStyle';
import { useDispatch, useSelector } from 'react-redux';
import { NetworkContext } from '../../NetworkContext';

const JournalList = ({ navigation }) => {
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const route = useRoute();
  const isConnected = useContext(NetworkContext);
  const routeDate = route.params;
  const stateVal = useSelector(state => state.login);
  const catchesData = useSelector(state => state.catches);
  const sharedFriends = catchesData.sharedFriend;
  const shareData = catchesData.shareItem;
  const filterData = shareData && shareData.filter(item => item.created_at.startsWith(routeDate));
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [loadingUnshare, setLoadingUnshare] = useState({});
  const stateValue = catchesData.items;
  const [currentPage, setCurrentPage] = React.useState(1);
  const [journalData, setJournalData] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const { height, width } = useWindowDimensions();
  const [selectedCatchId, setSelectedCatchId] = useState(null);
  const [shouldFetchNextPage, setShouldFetchNextPage] = useState(true);
  const [formLayoutIndex, setFormLayoutIndex] = useState(0);
  const [search, setSearch] = useState('');
  const [params, setParamData] = useState({
    date: route.params,
    page: 1,
    search: search,
    limit: 10
  });
  const [isSearching, setIsSearching] = useState(false);
  useEffect(() => {
    if (isConnected && isFocused) {
      const params = {
        date: route.params,
        page: 1,
        search: '',
        limit: 10
      };
      fetchCatchedData(currentPage, params);
      dispatch(fetchShareJournal());
    }
  }, [isConnected, isFocused, params]);

  const fetchCatchedData = async (page, params) => {
    setIsLoadingMore(true);
    const resultAction = await dispatch(fetchAllCatches(params));
    if (fetchAllCatches.fulfilled.match(resultAction)) {
      const newData = resultAction.payload.data.result;
      if (params.page === 1) {
        setJournalData(newData);
      } else {
        setJournalData(prevData => {
          const uniqueFilteredData = newData.filter(item => !prevData.map(prevItem => prevItem._id).includes(item._id));
          return [...prevData, ...uniqueFilteredData];
        });
      }
      if (newData.length < params.limit) {
        setShouldFetchNextPage(false);
      } else {
        setShouldFetchNextPage(true);
      }
    }
    setIsLoadingMore(false);
  };

  const handleLoadMore = () => {
    if (!isLoadingMore && shouldFetchNextPage) {
      setIsLoadingMore(true);
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      const params = {
        page: nextPage,
        search: '',
        date: route.params,
        limit: 10
      };
      fetchCatchedData(nextPage, params).then(() => setIsLoadingMore(false));
    }
  };

  const formatDate = (dateString) => {
    const [year, month, day] = dateString.split('-');
    return `${month}-${day}-${year}`;
  };

  const handleRefresh = () => {
    dispatch(setRefreshing({}));
    params.page = 1;
    fetchCatchedData(currentPage, params);
  };
  const handleFormLayout = index => {
    setFormLayoutIndex(index);
  };
  const showSharedData = async (id) => {
    const params = {
      fish_catch_id: id
    }
    const resultAction = await dispatch(sharedJournalFriend(params));
    if (sharedJournalFriend.fulfilled.match(resultAction)) {
      setSelectedCatchId(id);
      setModalVisible(true)
    };
  }
  const closeModal = async () => {
    handleRefresh();
    setModalVisible(false)
  }
  const removeJournal = async (item) => {
    setLoadingUnshare(prevState => ({ ...prevState, [item.user_id]: true }));
    const params = {
      fish_catch_id: item.catch_id,
      user_id: item.user_id
    }
    const resultAction = await dispatch(removeSharedJournal(params));
    if (removeSharedJournal.fulfilled.match(resultAction)) {
      const refreshParams = {
        fish_catch_id: selectedCatchId
      }
      await dispatch(sharedJournalFriend(refreshParams));
    }
    setLoadingUnshare(prevState => ({ ...prevState, [item.user_id]: false }));
  }

  const ListItem = (item, index) => {
    const catchedFish = item.media && item.media.path;
    const isJournalUser = item.user === stateVal.id ? true : false;
    return (
      <View style={FriendsStyle.Card}>
        <TouchableOpacity style={{ flexShrink: 1 }} onPress={() => navigation.navigate("JournalCatches", { catch_id: item._id, date: item.date, isJournalUser }, setCurrentPage(1))}>
          <View style={FriendsStyle.CardLeft}>
            {catchedFish ? (
              <Avatar.Image
                style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                size={51}
                source={{
                  uri: catchedFish ? `${catchedFish}?timestamp=${new Date().getTime()}` : IconAsset.BlankUser,
                }}
              />
            ) : (
              <Avatar.Image
              style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                size={51}
                source={IconAsset.BlankUser}
              />
            )}
            <View style={{ flexShrink: 1 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <Text style={[FriendsStyle.CardTitle, { paddingRight: 28 }]}>{item.fish_name}</Text>
                {item.share_status === 'shared' && <IconButton
                  onPress={() => showSharedData(item._id)}
                  style={{ position: 'absolute', right: 0, top: -8 }}
                  icon={() => <Icon name={'connection'} size={10} />}
                  size={10}
                />}
              </View>
              <Text style={FriendsStyle.CardDisc}>
                {'' + item.length + ', ' + '' + item.weight}
              </Text>
            </View>
          </View>
        </TouchableOpacity>
        <IconButton
          onPress={() => navigation.navigate("JournalCatches", { catch_id: item._id, date: item.date, isJournalUser }, setCurrentPage(1))}
          style={[FriendsStyle.CardIcon, {borderWidth: 0}]}
          icon={() => <Icon name={'arrow'} size={14} />}
          size={28}
        />
        <Modal
          animationType="slide"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => setModalVisible(false)}
        >
          <View
            style={{
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
              backgroundColor: 'rgba(0, 0, 0, 0.5)',
              paddingHorizontal: 15,
            }}
          >

            <View
              style={{
                backgroundColor: UiColor.White,
                // backgroundColor: UiColor.PrimaryColor,
                padding: 20,
                width: '100%',
                borderRadius: 10,
              }}
            >
              <IconButton
                style={{
                  width: 25,
                  height: 25,
                  position: 'absolute',
                  top: -14,
                  right: -10,
                  backgroundColor: '#D2283D',
                }}
                onPress={() => closeModal()}
                icon={() => (
                  <Icon name="cross" size={14} color={UiColor.White} />
                )}
                size={28}
              />
              <View
                style={{
                  marginTop: 10,
                }}
              >
                <Text
                  style={{
                    color: UiColor.PrimaryColor,
                    // color: UiColor.SecondaryColor,
                    fontSize: 16,
                    paddingLeft: 0,
                    fontFamily: Dm.semiBold,
                    textAlign: 'center'
                  }}
                >
                  Shared With
                </Text>

                <ScrollView style={{ width: '100%', maxHeight: height - 200 }} showsVerticalScrollIndicator={false}>
                  {sharedFriends?.map((obj, index) => (
                    <View
                      key={index}
                      style={{
                        paddingHorizontal: 0,
                        paddingVertical: 8,
                        width: '100%',
                        flexDirection: 'row',
                        // justifyContent: 'space-between',
                      }}
                    >
                      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
                        <View style={{ flexDirection: 'row', alignItems: 'center', flexShrink: 1, marginRight: 10 }}>
                          <Image
                            source={obj.to_id && obj.to_id.profile_image ? { uri: obj.to_id.profile_image.path } : IconAsset.BlankUser}
                            style={{ borderRadius: 45, width: 45, height: 45 }}
                          />
                          <Text
                            style={{
                              marginLeft: 10,
                              color: UiColor.Black,
                              fontSize: 14,
                              fontFamily: Dm.semiBold,
                              flexShrink: 1
                            }}
                          >
                            {obj.to_id && obj.to_id.name}
                          </Text>
                        </View>
                        <View
                          style={{
                            backgroundColor: '#D2283D',
                            // backgroundColor: '#000',
                            borderRadius: 6,
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'center',
                            width: 100,
                          }}>
                          <TouchableOpacity
                            onPress={() => {
                              removeJournal({ catch_id: selectedCatchId, user_id: obj.to_id && obj.to_id.id })
                            }} style={{ paddingHorizontal: 12, paddingVertical: 5, }}>
                            <Text style={{ color: 'white', fontSize: 16, fontFamily: Dm.semiBold }}>{loadingUnshare[obj.to_id && obj.to_id.id] ? (
                              <ActivityIndicator size={24} color="#fff" />
                            ) : (
                              'Unshare'
                            )}</Text>
                          </TouchableOpacity>
                        </View>
                      </View>
                    </View>
                  ))}
                  {sharedFriends.length === 0 &&
                    <Text
                      style={{
                        color: UiColor.Black,
                        marginTop: 10,
                        fontSize: 14,
                        paddingLeft: 8,
                        textAlign: 'center'
                      }}>Not Found !</Text>
                  }
                </ScrollView>

              </View>
            </View>
          </View>
        </Modal>
      </View>
    );
  };
  const ListShareItem = (item, index) => {
    const catchedFish = item.fish_catch && item.fish_catch.media && item.fish_catch.media.path;
    const isJournalUser = item && item.from_id.id === stateVal.id ? true : false;
    return (
      <View style={FriendsStyle.Card}>
        <TouchableOpacity
          onPress={() => navigation.navigate("JournalCatches", { catch_id: item && item.fish_catch && item.fish_catch._id, isJournalUser }, setCurrentPage(1))}
        >
          <View style={FriendsStyle.CardLeft}>
            {catchedFish ? (
              <Avatar.Image
                style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                size={51}
                source={{
                  uri: catchedFish ? `${catchedFish}?timestamp=${new Date().getTime()}` : IconAsset.BlankUser,
                }}
              />
            ) : (
              <Avatar.Image
                style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                size={51}
                source={IconAsset.BlankUser}
              />
            )}
            <View>
              <Text style={FriendsStyle.CardTitle}>{item.fish_catch && item.fish_catch.fish_name}</Text>
              <Text>
                Shared by <Text style={{ color: UiColor.Black, fontFamily: Dm.semiBold }}>{item.from_id.name}</Text>
              </Text>
            </View>
          </View>
        </TouchableOpacity>
        <IconButton
          onPress={() => navigation.navigate("JournalCatches", { catch_id: item && item.fish_catch && item.fish_catch._id, isJournalUser }, setCurrentPage(1))}
          style={[FriendsStyle.CardIcon, {borderWidth: 0}]}
          icon={() => <Icon name={'arrow'} size={14} />}
          size={28}
        />
      </View>
    );
  };
  return (
    <>
      <Appbar.Header
        style={[
          Styles.AppbarHeader,
          Styles.AppBarShadow,
          { justifyContent: 'space-between' },
        ]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{ backgroundColor: UiColor.SecondaryColor }}
          icon={() => (
            <Icon name="back" size={18} style={Styles.BackWhite} />
          )}
        />
        <Appbar.Content titleStyle={Styles.NavTitle} title="Journals" />
        <Text style={Styles.NavTitle}>{routeDate ? formatDate(routeDate) : ''}</Text>
      </Appbar.Header>
      <View>
        <SegmentedControlTab
          values={[
            'My Journals',
            'Shared With Me',
          ]}
          selectedIndex={formLayoutIndex}
          onTabPress={handleFormLayout}
          borderRadius={18}
          tabsContainerStyle={[Styles.TabContainer]}
          tabStyle={Styles.TabStyle}
          activeTabStyle={Styles.ActiveTab}
          tabTextStyle={Styles.TabText}
          activeTabTextStyle={Styles.ActiveTabText}
        />
        {formLayoutIndex === 0 && (
          <SafeAreaView style={[FriendsStyle.FullCardArea, { marginTop: 15 }]}>
            {!isConnected && journalData && journalData.length === 0 ?
              <View style={[GlobalStyles.NoData, { marginTop: 80 }]}>
                <Icon name="no-connection" size={50} />
                <Text style={[GlobalStyles.NoDataMsg, { fontFamily: Dm.semiBold, fontWeight: '600' }]}>
                  No Internet Connection
                </Text>
              </View>
              :
              <>
                {Object.keys(journalData).length === 0 && isLoadingMore ? (
                  <SkeletonPlaceholder>
                    {Array.from({ length: 10 }).map((_, index) => (
                      <View style={[FriendsStyle.Card, {
                        shadowOpacity: 0,
                        shadowRadius: 0,
                      }]} key={index}>
                        <SkeletonPlaceholder.Item height={50} width="100%">
                          <View style={FriendsStyle.CardLeft}>
                            <SkeletonPlaceholder.Item
                              width={51}
                              height={51}
                              borderRadius={51}
                            />
                            <View>
                              <SkeletonPlaceholder.Item
                                height={20}
                                width={120}
                                marginLeft={10}
                              />
                              <SkeletonPlaceholder.Item
                                height={20}
                                width={180}
                                marginLeft={10}
                                marginTop={8}
                              />
                            </View>
                          </View>
                        </SkeletonPlaceholder.Item>
                      </View>
                    ))}
                  </SkeletonPlaceholder>
                ) : (
                  <>
                  {!isLoadingMore && !catchesData.isLoading && journalData && journalData?.length === 0 ? (
                  <View style={GlobalStyles.NoData}>
                    <Text style={GlobalStyles.NoDataMsg}>No Journals Found</Text>
                  </View>
                ) : (
                  <View style={{marginBottom: 110}}>
                    <FlatList
                      data={journalData}
                      onEndReachedThreshold={0.5}
                      onEndReached={handleLoadMore}
                      showsVerticalScrollIndicator={false}
                      keyExtractor={(item, index) => index.toString()}
                      renderItem={({ item, index }) => ListItem(item, index)}
                      refreshing={handleRefresh}
                    />
                  </View>
                  )}
                  </>
                )}
              </>
            }
          </SafeAreaView>
        )}
        {formLayoutIndex === 1 && (
          <SafeAreaView style={[FriendsStyle.FullCardArea, { marginTop: 15 }]}>
            {!isConnected && filterData && filterData.length === 0 ?
              <View style={[GlobalStyles.NoData, { marginTop: 80 }]}>
                <Icon name="no-connection" size={50} />
                <Text style={[GlobalStyles.NoDataMsg, { fontFamily: Dm.semiBold }]}>
                  No Internet Connection
                </Text>
              </View>
              :
              <>
                {Object.keys(filterData).length === 0 && isLoadingMore ? (
                  <SkeletonPlaceholder>
                    {Array.from({ length: 10 }).map((_, index) => (
                      <View style={[FriendsStyle.Card, {
                        shadowOpacity: 0,
                        shadowRadius: 0,
                      }]} key={index}>
                        <SkeletonPlaceholder.Item height={50} width="100%">
                          <View style={FriendsStyle.CardLeft}>
                            <SkeletonPlaceholder.Item
                              width={51}
                              height={51}
                              borderRadius={51}
                            />
                            <View>
                              <SkeletonPlaceholder.Item
                                height={20}
                                width={120}
                                marginLeft={10}
                              />
                              <SkeletonPlaceholder.Item
                                height={20}
                                width={180}
                                marginLeft={10}
                                marginTop={8}
                              />
                            </View>
                          </View>
                        </SkeletonPlaceholder.Item>
                      </View>
                    ))}
                  </SkeletonPlaceholder>
                ) : (
                  <FlatList
                    data={filterData}
                    onEndReachedThreshold={0.5}
                    onEndReached={handleLoadMore}
                    showsVerticalScrollIndicator={false}
                    keyExtractor={(item, index) => index.toString()}
                    renderItem={({ item, index }) => ListShareItem(item, index)}
                    refreshing={handleRefresh}
                  />
                )}
                {!isLoadingMore && !catchesData.isLoading && filterData && filterData?.length === 0 && (
                  <View style={GlobalStyles.NoData}>
                    <Text style={GlobalStyles.NoDataMsg}>No Journals Found</Text>
                  </View>
                )}
              </>
            }
          </SafeAreaView>
        )}
      </View>
    </>
  );
};
export default JournalList;
