import { fetchAllCatches, fetchCatchesInfo, addUpdateNote, removeNote, removeJournal, fetchMyFriends, shareFriendJournal } from '../../thunk';
import { View, Text, Modal, TouchableOpacity, ScrollView, Image, ImageBackground, StyleSheet, Alert, Platform, Animated, Linking } from 'react-native';
import { Appbar, Avatar, IconButton, ActivityIndicator, TextInput, HelperText } from 'react-native-paper';
import { Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm } from '../../../theme/Index';
import { useIsFocused, useNavigation, useRoute } from '@react-navigation/native';
import SegmentedControlTab from 'react-native-segmented-control-tab';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import { RemoveStyle } from '../auth/remove-account/RemoveStyle';
import { useEffect, useState, useRef, useMemo } from 'react';
import { ProfileStyle } from '../user-profile/ProfileStyle';
import { FriendsStyle } from '../add-friends/FriendsStyle';
import { useDispatch, useSelector } from 'react-redux';
import { LineChart } from 'react-native-gifted-charts';
import { LoginStyle } from '../auth/login/LoginStyle';
import { FriendStyle } from '../friends/FriendStyle';
import RBSheet from 'react-native-raw-bottom-sheet';
import ImageView from 'react-native-image-viewing';
import * as Localize from 'react-native-localize';
import { resetState } from '../../slices/catches';
import FastImage from 'react-native-fast-image';
import WeatherCalendar from './WeatherCalendar';
import { heplerService } from '../../services';
import { WebView } from 'react-native-webview';
import { JournalStyle } from './JournalStyle';
import MoonCalendar from './MoonCalendar';
import Share from 'react-native-share';
import MapboxGL from '@rnmapbox/maps';
import moment from 'moment-timezone';
import RNFS from 'react-native-fs';

const JournalCatches = ({ navigation }) => {
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const refSheet = useRef({});
  const friendSheet = useRef({});
  const noteCreateSheet = useRef({});
  const noteViewSheet = useRef({});
  const noteUpdateSheet = useRef({});
  const route = useRoute();
  const catchedId = route.params;
  const senderName = catchedId.sender_name;
  const [formLayoutIndex, setFormLayoutIndex] = useState(0);
  const stateVal = useSelector(state => state.login);
  const catchesData = useSelector(state => state.catches);
  const [inProcess, setInProcess] = useState(false);
  const [isSubmit, setIsSubmit] = useState(false);
  const stateValue = catchesData.details;
  const originalDate = stateValue.date;
  const formattedDate = moment(originalDate, 'YYYY-MM-DD').format('MM-DD-YYYY');
  const stateData = catchesData.items;
  const [formErrors, setFormErrors] = useState({});
  const [friendsData, setFriendsData] = useState([]);
  const [selectedFriendIds, setSelectedFriendIds] = useState([]);
  const [isVisible, setIsVisible] = useState(false);
  const slideAnim = useRef(new Animated.Value(0)).current;
  const [imageVisible, setImageVisible] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [backGroundImage, setBackGroundImage] = useState('');
  const timeZones = ['PST', 'CST', 'EST'];
  const [selectedTimezoneIndex, setSelectedTimezoneIndex] = useState(0);
  const selectedTimezone = timeZones[selectedTimezoneIndex];
  const [lineChartData, setLineChartData] = useState([]);
  const deviceTimeZoneLocalize = Localize.getTimeZone();
  const timeZoneMap = {
    PST: 'America/Los_Angeles',
    CST: 'America/Chicago',
    EST: 'America/New_York',
  };
  const [stateValueData, setStateValueData] = useState({
    moonrise: '',
    moonset: '',
    sunrise: '',
    sunset: '',
  });
  const [selectedNote, setSelectedNote] = useState({
    note: '',
    date: '',
  });
  const [formData, setFormData] = useState({
    notes: '',
  });
  const [formDataUser, setFormDataUser] = useState({
    user_id: '',
    fish_catch: '',
  });
  const formatTimeLabel = (date) => {
    if (!date) return '';
    const options = { hour: 'numeric', minute: 'numeric', hour12: true, timeZone: timeZoneMap[selectedTimezone] };
    return new Date(date).toLocaleTimeString('en-US', options);
  };
  const convertMetersToFeet = (meters) => {
    return (meters * 3.28084).toFixed(2);
  };
  const lineChartFirstData = stateValue?.tide_data?.map(obj => ({
    value: parseFloat(convertMetersToFeet(obj.height)),
    label: formatTimeLabel(obj.date),
  })) || [];

  const maxValue = Math.ceil(Math.max(...lineChartData.map(item => item.value))) + 1;
  const minValue = Math.floor(Math.min(...lineChartData.map(item => item.value))) - 1;
  const yAxisRange = maxValue - minValue;
  const noOfSections = 8;
  let stepValue;
  if (yAxisRange > noOfSections) {
    stepValue = Math.ceil(yAxisRange / noOfSections);
  } else {
    stepValue = 1;
  }
  const dataPointCount = lineChartData.length;
  const spacing = 65;
  const initialSpacing = 35;
  const additionalSpacing = 50;
  const LineChartWidth = Math.max((dataPointCount - 1) * spacing + initialSpacing + additionalSpacing, 450);

  useEffect(() => {
    if (isFocused && catchedId.catch_id !== '') {
      fetchCatchedData();
      fetchAllCatchedData();
    }
    return () => {
      dispatch(resetState({}));
      if (!isFocused) {
      }
    };
  }, [isFocused]);

  if (Platform.OS === 'ios') {
    MapboxGL.setWellKnownTileServer('mapbox');
  } else {
    MapboxGL.setWellKnownTileServer('Mapbox');
  }
  MapboxGL.setAccessToken(
    'pk.eyJ1IjoiZXhhY3RpbmsiLCJhIjoiY2x3enpzejFpMGMzejJqc2RrNjR4ZWs4dCJ9.8Xuj0V6TUuh3T8Bzt7QIHw',
  );

  const fetchCatchedData = async () => {
    const params = { catch_id: catchedId.catch_id };
    const resultAction = await dispatch(fetchCatchesInfo(params));
    const imagePath = resultAction.payload.data.media.path;
    if (backGroundImage !== imagePath) {
      setBackGroundImage(imagePath);
    }
    fetchAllCatchedData();
  };

  const fetchAllCatchedData = async () => {
    const params = {
      date: catchedId.date,
      page: 1,
      search: '',
      limit: 10,
    };
    const resultAction = await dispatch(fetchAllCatches(params));
  };

  const addNotes = async text => {
    if (hasErrors()) {
      return;
    }
    setFormErrors({});
    const params =
      text.isNoteUpdate === true
        ? {
          formData,
          catch_id: catchedId.catch_id,
          note_Id: selectedNote.note_Id,
        }
        : { formData, catch_id: catchedId.catch_id };
    try {
      setInProcess(true);
      const resultAction = await dispatch(addUpdateNote(params));
      if (addUpdateNote.fulfilled.match(resultAction)) {
        fetchCatchedData();
        setFormData('');
      }
      setInProcess(false);
      noteCreateSheet.current.close();
      noteUpdateSheet.current.close();
    } catch (error) {
      setInProcess(false);
      console.error('Error in fetchCatchData:', error);
    }
  };

  const hasErrors = () => {
    const errors = {};
    if (!formData.notes || formData.notes.length === 0) {
      errors.notes = 'Note is required';
    }
    setFormErrors(errors);
    return Object.keys(errors).length > 0;
  };

  const handleFormLayout = index => {
    setFormLayoutIndex(index);
  };

  useEffect(() => {
    if (stateValue) {
      const formatTime = (time) => {
        const timeZoneConvert = moment.tz(time, "hh:mm A", "America/New_York").tz("America/Los_Angeles").format("hh:mm A");
        return timeZoneConvert;
      };
  
      setStateValueData({
        moonrise: formatTime(stateValue.moonrise),
        moonset: formatTime(stateValue.moonset),
        sunrise: formatTime(stateValue.sunrise),
        sunset: formatTime(stateValue.sunset),
      });
      setLineChartData(lineChartFirstData);
    }
  }, [stateValue]);

  const handleCardClick = (note, date, id) => {
    setSelectedNote({
      note: note,
      date: date.substring(0, 10),
      note_Id: id,
    });
    const selectedNote = stateValue.notes.find(note => note._id === id);
    if (selectedNote) {
      setFormData({
        ...formData,
        notes: selectedNote.notes,
      });
    }
  };

  const deleteItem = async text => {
    const params = {
      catch_id: catchedId.catch_id,
      note_Id: selectedNote.note_Id,
    };
    try {
      const resultAction = await dispatch(
        text.isJournal === true ? removeJournal(params) : removeNote(params),
      );
      if (removeJournal.fulfilled.match(resultAction)) {
        if (catchedId.isCatchGallery === false) {
          navigation.goBack();
        } else {
          if (text.isJournal === true) {
            refSheet.current.close();
            navigation.goBack();
          } else {
            fetchCatchedData();
          }
        }
      } else {
        fetchCatchedData();
      }
    } catch (error) {
      console.error('Error in deleteItem:', error);
    }
  };

  const handleDeletePress = text => {
    // refSheet.current?.close();
    Alert.alert(
      'Delete', // Alert Title
      text.isJournal === true
        ? 'Are you sure you want to remove this journal?'
        : 'Are you sure you want to remove this note?',
      [
        {
          text: 'Cancel',
          onPress: () => {
            console.log('Cancel Pressed'), refSheet.current.close();
          },
          style: 'cancel',
        },
        {
          text: 'Remove',
          onPress: () => deleteItem(text),
          style: 'destructive',
        },
      ],
    );
    noteViewSheet.current.close();

  };

  const shareJournalImg = async () => {
    try {
      const imageUrl = stateValue && stateValue.media && stateValue.media.path;
      const downloadDest = `${RNFS.CachesDirectoryPath}/catchImage.jpg`;
      const options = {
        fromUrl: imageUrl,
        toFile: downloadDest,
      };
      await RNFS.downloadFile(options).promise;
      const shareOptions = {
        title: 'Check out my catch!',
        url: `file://${downloadDest}`,
        type: 'image/jpeg',
        failOnCancel: false,
      };
      setTimeout(() => {
        Share.open(shareOptions);
      }, 1000);

    } catch (error) {
      alert(error.message);
    }
  };
  const openNoteSheet = async () => {
    noteCreateSheet.current.open();
  }

  const openUpdateNoteSheet = async () => {
    noteViewSheet.current.close();
    setTimeout( () => {
     noteUpdateSheet.current.open();
    }, 1000)
  }
  const fetchMyFriendsData = async () => {
    try {
      const params = {
        user_id: stateVal.id,
        page: 1,
        limit: 20,
        search: '',
      };
      let allFriends = [];
      while (true) {
        const resultAction = await dispatch(fetchMyFriends(params));
        if (fetchMyFriends.fulfilled.match(resultAction)) {
          const newData = resultAction.payload.data.friends;
          allFriends = allFriends.concat(newData);
          if (newData.length < params.limit) {
            break;
          }
          params.page++;
        } else {
          break;
        }
      }
      setFriendsData(allFriends);
    } catch (error) {
      console.error('Error in fetchFriends:', error);
    }
  };

  const handleFriendSelection = friendId => {
    const isSelected = selectedFriendIds.includes(friendId);
    if (isSelected) {
      const updatedIds = selectedFriendIds.filter(id => id !== friendId);
      setSelectedFriendIds(updatedIds);
    } else {
      setSelectedFriendIds([...selectedFriendIds, friendId]);
    }

    setFormDataUser({
      ...formDataUser,
      user_id: isSelected
        ? selectedFriendIds.filter(id => id !== friendId)
        : [...selectedFriendIds, friendId],
    });
  };

  const formatNoteDate = (dateString) => {
    return moment(dateString).tz(deviceTimeZoneLocalize).format('MM-DD-YYYY');
  };

  const shareJournalInfo = async () => {
    setIsSubmit(true)
    const params = {
      user_id: formDataUser.user_id,
      fish_catch: catchedId.catch_id,
    }
    const resultAction = await dispatch(shareFriendJournal(params));
    friendSheet.current.close();
    setSelectedFriendIds('');
    setIsSubmit(false)
  }
  
  const openShareSheet = async () => {
    refSheet.current?.close();
    fetchMyFriendsData();
    setTimeout(() => {
      friendSheet.current.open();
    }, 1000);
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      timeZone: timeZoneMap[selectedTimezone],
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    }).replace(/\//g, '-');
  };

  const handleImagePress = (index) => {
    setSelectedIndex(index);
    setImageVisible(true);
  };

  const convertTimeToTimezone = (time, timezone) => {
    return moment.tz(time, "hh:mm A", timeZoneMap[selectedTimezone]).tz(timezone).format("hh:mm A");
  };

  const handleNextTimezone = () => {
    const newIndex = (selectedTimezoneIndex + 1) % timeZones.length;
    const newTimezone = timeZones[newIndex];

    const convertedTimes = {
      sunrise: convertTimeToTimezone(stateValue.sunrise, timeZoneMap[newTimezone]),
      sunset: convertTimeToTimezone(stateValue.sunset, timeZoneMap[newTimezone]),
      moonrise: convertTimeToTimezone(stateValue.moonrise, timeZoneMap[newTimezone]),
      moonset: convertTimeToTimezone(stateValue.moonset, timeZoneMap[newTimezone]),
    };

    const updatedLineChartData = stateValue?.tide_data?.map(obj => ({
      value: parseFloat(convertMetersToFeet(obj.height)),
      label: new Date(obj.date).toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: 'numeric',
        hour12: true,
        timeZone: timeZoneMap[newTimezone],
      }),
    })) || [];

    setStateValueData((prevState) => ({
      ...prevState,
      ...convertedTimes,
    }));
    
    setLineChartData(updatedLineChartData);
    setSelectedTimezoneIndex(newIndex);
  };

  const slideUp = () => {
    setIsVisible(true);
    Animated.timing(slideAnim, {
      toValue: 1,
      duration: 200,
      useNativeDriver: true,
    }).start();
  };

  const slideDown = () => {
    Animated.timing(slideAnim, {
      toValue: 0,
      duration: 300,
      useNativeDriver: true,
    }).start(() => setIsVisible(false));
  };

  const handleDotPress = (pressedDataPoint) => {
    const matchedDataPoint = lineChartData.find(
      dataPoint => dataPoint.label === pressedDataPoint.label
    );

    if (matchedDataPoint) {
      const { value, label } = matchedDataPoint;
  
      Alert.alert(
        'Data Point Details',
        `Height: ${value.toFixed(3)} ft\nTime: ${label}`,
        [
          {
            text: 'OK',
            onPress: () => console.log('OK Pressed'),
          },
        ],
        { cancelable: true }
      );
    } else {
      Alert.alert(
        'Error', 
        'Data point not found', 
        [
          {
            text: 'OK',
            onPress: () => console.log('OK Pressed'),
          },
        ],
        { cancelable: true }
      );
    }
  };

  const BackgroundImage = useMemo(() => {
    return backGroundImage && backGroundImage !== '' ? (
      <TouchableOpacity onPress={slideUp} style={{ position: 'absolute', top: 0, width: '100%', height: 385, backgroundColor: '#000' }}>
        <ImageBackground
          source={{ uri: `${backGroundImage}?timestamp=${new Date().getTime()}` }}
          resizeMode="cover"
          style={[ProfileStyle.UserProfileBg, { height: '100%' }]}>
          <View style={Styles.BannerOverlay}></View>
        </ImageBackground>
      </TouchableOpacity>
    ) : (
      <ImageBackground
        source={IconAsset.Splash}
        resizeMode="cover"
        style={[
          ProfileStyle.UserProfileBg,
          { height: 356, justifyContent: 'flex-end' },
        ]}>
        <View style={Styles.BannerOverlay}></View>
      </ImageBackground>
    );
  }, [backGroundImage]);

  const memoizedImages = useMemo(() => {
    if (catchedId && catchedId.isJournalUser === false) {
      return (
        <View style={ProfileStyle.ProfileImgList}>
          <View style={ProfileStyle.ProfileImgHead}>
            <TouchableOpacity onPress={() => handleImagePress(0)}>
              <Image
                style={ProfileStyle.ProfileImg}
                source={
                  stateValue.media
                    ? { uri: `${stateValue.media.path}?timestamp=${new Date().getTime()}` }
                    : IconAsset.User
                }
              />
            </TouchableOpacity>
          </View>
        </View>
      );
    } else if (stateData) {
      return (
        <View style={ProfileStyle.ProfileImgList}>
          {stateData.result?.map((obj, index) => (
            <View style={ProfileStyle.ProfileImgHead} key={index}>
              <TouchableOpacity onPress={() => handleImagePress(index)}>
                <Image
                  style={ProfileStyle.ProfileImg}
                  source={
                    obj.media
                      ? { uri: `${obj.media.path}?timestamp=${new Date().getTime()}` }
                      : IconAsset.BlankUser
                  }
                />
              </TouchableOpacity>
            </View>
          ))}
        </View>
      );
    }
    return null;
  }, [catchedId, stateData, stateValue.media, IconAsset, ProfileStyle]);

  const memoizedPreviewImages = useMemo(() => {
    return stateData?.result
      ?.filter(item => item && item.media && item.media.path) // Filter out any invalid entries
      .map(item => ({ uri: `${item.media.path}?timestamp=${new Date().getTime()}` })) || [];
  }, [stateData]);
  
  const openInBrowser = () => {
    // Open the URL in the device's default browser
    Linking.openURL('https://tempbreak.com/');
  };

  return (
    <>
      <Appbar.Header
        style={[Styles.AppbarHeader, ProfileStyle.UserProfileBar]}>
        {(imageVisible || isVisible) && <View style={Styles.VisibleBox}>
          <Text></Text>
        </View>}
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{ backgroundColor: UiColor.SecondaryColor }}
          icon={() => (
            <Icon name="back" size={18} style={Styles.BackWhite} />
          )}
        />
        {catchedId.isJournalUser === true ? (
          <Appbar.Action
            animated={false}
            size={30}
            rippleColor="#00000008"
            icon={() => (
              <Icon
                name="more"
                style={[Styles.Backbtn, Styles.More]}
                onPress={() => {
                  refSheet.current?.open();
                }}
              />
            )}
          />
        ) : (
          ''
        )}
        {senderName && (
          <Text style={[JournalStyle.SenderName]}>By: {senderName ? ' ' + senderName : ''}</Text>
        )}
      </Appbar.Header>
      <RBSheet
        ref={ref => (refSheet.current = ref)}
        closeOnDragDown={true}
        closeOnPressMask={true}
        openDuration={800}
        height={250}
        customStyles={{
          wrapper: {
            backgroundColor: '#00000024',
          },
          draggableIcon: {
            backgroundColor: '#E3E3E3',
          },
          container: {
            borderTopLeftRadius: 30,
            borderTopRightRadius: 30,
          },
        }}>
        <View style={Styles.PostCardEdit}>
        <TouchableOpacity
          style={[Styles.PostActionBtn, {marginTop: 10}]}
          onPress={() => {
            refSheet.current.close();
            setTimeout(() => {
              navigation.navigate('EditMoreInfo', {
                catch_id: stateValue._id,
                isEditfishName: true,
              });
            }, 3000);
          }}>
          {/* <Icon name="edit2" style={Styles.PostActionIcon} size={20} /> */}
          <Text style={Styles.PostActionText}>Edit</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => [refSheet.current.close(), shareJournalImg()]}
          style={[Styles.PostActionBtn, {marginTop: 10}]}>
          {/* <Icon name="share" style={Styles.PostActionIcon} size={20} /> */}
          <Text style={Styles.PostActionText}>Share</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => {
            handleDeletePress({
              isJournal: true,
            });
          }}
          style={[Styles.PostActionBtn, {marginTop: 10}]}>
          {/* <Icon name="trash" style={Styles.PostActionIcon} size={20} /> */}
          <Text style={Styles.PostActionText}>Delete</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => openShareSheet()}
          style={[Styles.PostActionBtn, {marginTop: 10, maxWidth: 150}]}>
          {/* <Icon name="journal_share-1" style={Styles.PostActionIcon} size={20} /> */}
          <Text style={Styles.PostActionText}>Share to friends</Text>
        </TouchableOpacity>
        </View>
      </RBSheet>
      <RBSheet
        ref={ref => (friendSheet.current = ref)}
        closeOnDragDown={true}
        closeOnPressMask={true}
        openDuration={800}
        height={450}
        customStyles={{
          wrapper: {
            backgroundColor: '#00000024',
          },
          draggableIcon: {
            backgroundColor: '#E3E3E3',
          },
          container: {
            borderTopLeftRadius: 30,
            borderTopRightRadius: 30,
          },
        }}>
        <View style={{ marginTop: 8 }}>
          <Text style={[FriendStyle.FriendText, { fontSize: 20, fontFamily: Dm.bold, marginBottom: 10 }]} >Share with</Text>
          <View
            style={JournalStyle.ShareBox}>
            {isSubmit ? (
              <ActivityIndicator size={24} color={UiColor.White} style={{ paddingHorizontal: 12, paddingVertical: 5, }} />
            ) : (
              <TouchableOpacity
                onPress={() => {
                  shareJournalInfo()
                }} style={{ paddingHorizontal: 12, paddingVertical: 5, }}>
                <Text style={JournalStyle.ShareBoxText}>Share</Text>
              </TouchableOpacity>
            )}
          </View>
          <ScrollView showsVerticalScrollIndicator={false} style={{ marginBottom: 50 }}>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginTop: 20, marginBottom: 30 }}>
              {friendsData &&
                friendsData?.map((friend, index) => (
                  <View style={[FriendStyle.FriendList]} key={index}>
                    <TouchableOpacity
                      onPress={() => handleFriendSelection(friend.id)}>
                      {selectedFriendIds && selectedFriendIds?.includes(friend.id) && (
                        <View style={JournalStyle.selectedFriendIds}>
                          <Icon
                            name="check"
                            size={18}
                            color={UiColor.Success}
                          />
                        </View>
                      )}
                      <Avatar.Image
                        style={{backgroundColor: UiColor.ImageLoad}}
                        size={72}
                        source={
                          friend.profile_image &&
                            friend.profile_image.path
                            ? {
                              uri: friend.profile_image.path,
                            }
                            : IconAsset.BlankUser
                        }
                      />
                      <Text style={FriendStyle.FriendText}>
                        {friend.first_name} {friend.last_name}
                      </Text>
                    </TouchableOpacity>
                  </View>
                ))}
            </View>
          </ScrollView>
        </View>
      </RBSheet>
      {Object.keys(backGroundImage).length === 0 ? (
        <SkeletonPlaceholder>
          <SkeletonPlaceholder.Item height={300} width="100%" />
          <SkeletonPlaceholder.Item flexDirection="row" alignItems="center" marginTop={20} marginLeft={20}>
            <SkeletonPlaceholder.Item width={100} height={35} borderRadius={15} />
            <SkeletonPlaceholder.Item width={120} height={35} borderRadius={15} marginLeft={22} />
            <SkeletonPlaceholder.Item width={120} height={35} borderRadius={15} marginLeft={22} />
          </SkeletonPlaceholder.Item>
          <SkeletonPlaceholder.Item paddingTop={20} marginLeft={20}>
            {Array.from({ length: 6 }).map((_, index) => (
              <SkeletonPlaceholder.Item key={index} flexDirection="row" alignItems="center" marginBottom={20}>
                <SkeletonPlaceholder.Item width={50} height={45} borderRadius={4} />
                <SkeletonPlaceholder.Item marginLeft={10}>
                  <SkeletonPlaceholder.Item width={120} height={20} borderRadius={4} />
                  <SkeletonPlaceholder.Item marginTop={6} width={80} height={20} borderRadius={4} />
                </SkeletonPlaceholder.Item>
              </SkeletonPlaceholder.Item>
            ))}
          </SkeletonPlaceholder.Item>
        </SkeletonPlaceholder>
      ) : (
        <>
          {BackgroundImage}
          <Modal
            visible={isVisible}
            transparent={true}
            animationType="fade"
            onRequestClose={slideDown}>
            <Animated.View
              style={{
                flex: 1,
                backgroundColor: 'black',
                transform: [
                  {
                    translateY: slideAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [750, 0],
                    }),
                  },
                ],
              }}>
                <FastImage
                    style={{ flex: 1 }}
                    source={{
                      uri: `${backGroundImage}`,
                      priority: FastImage.priority.normal,
                    }}
                  resizeMode={FastImage.resizeMode.contain}
                />
                <TouchableOpacity
                  style={[
                    JournalStyle.ModalBoxClose,
                    {
                      position: 'absolute',
                      width: 34,
                      height: 34,
                      top: 70,
                      right: 10,
                      borderRadius: 34,
                      justifyContent: 'center',
                      alignItems: 'center',
                      zIndex: 1,
                    },
                  ]}
                  onPress={slideDown}
                >
                  <Icon name="cross" size={18} color={UiColor.White} />
                </TouchableOpacity>
            </Animated.View>
          </Modal>
          <View style={[Styles.Container, { marginTop: 260 }]}>
            <View>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <SegmentedControlTab
                  values={[
                    'Details',
                    'Daily Fish Picture',
                    'Catch Location',
                    'Tide Chart',
                    'Sea Surface Temperature',
                    'Moon Phase',
                    'Weather Conditions',
                    'Notes',
                  ]}
                  selectedIndex={formLayoutIndex}
                  onTabPress={handleFormLayout}
                  borderRadius={18}
                  tabsContainerStyle={[Styles.TabContainer]}
                  tabStyle={Styles.TabStyle}
                  activeTabStyle={Styles.ActiveTab}
                  tabTextStyle={Styles.TabText}
                  activeTabTextStyle={Styles.ActiveTabText}
                />
              </ScrollView>
            </View>
            <ScrollView
              showsVerticalScrollIndicator={false}
              style={{ marginBottom: 400 }}>
              {formLayoutIndex === 0 && (
                <View
                  style={[
                    FriendsStyle.Container,
                    { backgroundColor: 'transparent' },
                  ]}>
                  <View style={FriendsStyle.Card}>
                    <View style={[FriendsStyle.CardLeft, { width: 250 }]}>
                      <View style={FriendsStyle.CardImageIcon}>
                        <Icon name="fish" color={UiColor.White} size={15} />
                      </View>
                      <View>
                        <Text
                          style={[
                            FriendsStyle.CardTitle,
                            { position: 'relative' },
                          ]}>
                          {heplerService.capitalizeFirstLetter(stateValue.fish_name ? stateValue.fish_name : '--' )}
                        </Text>
                        <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>Fish Type</Text>
                      </View>
                    </View>
                  </View>
                  <View style={FriendsStyle.Card}>
                    <View style={[FriendsStyle.CardLeft, { width: 250 }]}>
                      <Icon name="length" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                      <View>
                        <Text
                          style={[
                            FriendsStyle.CardTitle,
                            { position: 'relative' },
                          ]}>
                          {stateValue.length ? stateValue.length : '--' }
                        </Text>
                        <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>Length</Text>
                      </View>
                    </View>
                  </View>
                  <View style={FriendsStyle.Card}>
                    <View style={[FriendsStyle.CardLeft, { width: 250 }]}>
                      {/* <Icon name="weight" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} /> */}
                      <View style={FriendsStyle.CardImageIcon}>
                        <Icon name="weight" color={UiColor.White} size={26} />
                      </View>
                      <View>
                        <Text
                          style={[
                            FriendsStyle.CardTitle,
                            { position: 'relative' },
                          ]}>
                          {stateValue.weight ? stateValue.weight : '--' }
                        </Text>
                        <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>Weight</Text>
                      </View>
                    </View>
                  </View>
                  <View style={FriendsStyle.Card}>
                    <View style={[FriendsStyle.CardLeft,]}>
                      {/* <Icon name="date" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} /> */}
                      <View style={FriendsStyle.CardImageIcon}>
                        <Icon name="date" color={UiColor.White} size={20} />
                      </View>
                      <View>
                        <Text
                          style={[
                            FriendsStyle.CardTitle,
                            { position: 'relative' },
                          ]}>
                          {formattedDate ? formattedDate : '--'}
                        </Text>
                        <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>Date</Text>
                      </View>
                    </View>
                  </View>
                  <View style={FriendsStyle.Card}>
                    <View style={[FriendsStyle.CardLeft, { width: 250 }]}>
                      <Icon name="time" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                      <View>
                        <Text
                          style={[
                            FriendsStyle.CardTitle,
                            { position: 'relative' },
                          ]}>
                          {stateValue.time ? stateValue.time : '--' }
                        </Text>
                        <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>Time</Text>
                      </View>
                    </View>
                  </View>
                  <View style={FriendsStyle.Card}>
                    <TouchableOpacity onPress={() => handleFormLayout(2)}>
                      <View style={[FriendsStyle.CardLeft, { width: 250 }]}>
                        <Icon name="location" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                        <View>
                          <Text
                            style={[
                              FriendsStyle.CardTitle,
                              { position: 'relative' },
                            ]}>
                            {stateValue.location ? stateValue.location : '--'}
                          </Text>
                          <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>Location</Text>
                        </View>
                      </View>
                    </TouchableOpacity>
                  </View>
                  <View style={FriendsStyle.Card}>
                    <View style={[FriendsStyle.CardLeft, { width: 250 }]}>
                      <Icon name="water-temp" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                      <View>
                        <Text
                          style={[
                            FriendsStyle.CardTitle,
                            { position: 'relative' },
                          ]}>
                          {stateValue.water_temperature ? stateValue.water_temperature : '--'}
                        </Text>
                        <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>
                          Water Temperature
                        </Text>
                      </View>
                    </View>
                  </View>
                  <View style={FriendsStyle.Card}>
                    <View style={[FriendsStyle.CardLeft, { width: 320 }]}>
                      <Icon name="moon" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                      <View>
                        <Text
                          style={[
                            FriendsStyle.CardTitle,
                            { position: 'relative' },
                          ]}>
                          {stateValue.moon_phases ? stateValue.moon_phases : '--'}
                        </Text>
                        <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>Moon Phase</Text>
                      </View>
                    </View>
                  </View>
                  <View style={FriendsStyle.Card}>
                    <View style={[FriendsStyle.CardLeft, { width: 280 }]}>
                      <Icon name="weather" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                      <View>
                        <Text
                          style={[
                            FriendsStyle.CardTitle,
                            { position: 'relative' },
                          ]}>
                          {heplerService.capitalizeFirstLetter(stateValue.weather_condition ? stateValue.weather_condition : '--')}
                        </Text>
                        <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>
                          Weather Condition
                        </Text>
                      </View>
                    </View>
                  </View>
                  <View style={FriendsStyle.Card}>
                    <View style={[FriendsStyle.CardLeft, { width: 300 }]}>
                      <Icon name="tide" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                      <View>
                        <Text
                          style={[
                            FriendsStyle.CardTitle,
                            { position: 'relative' },
                          ]}>
                          {stateValue.tide_period ? stateValue.tide_period : '--'}
                        </Text>
                        <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>Tide Period</Text>
                      </View>
                    </View>
                  </View>
                  <View style={FriendsStyle.Card}>
                    <View style={[FriendsStyle.CardLeft, { width: 300 }]}>
                      {/* <Icon name="bait" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} /> */}
                      <View style={FriendsStyle.CardImageIcon}>
                        <Icon name="bait" color={UiColor.White} size={16} />
                      </View>
                      <View>
                        <Text
                          style={[
                            FriendsStyle.CardTitle,
                            { position: 'relative' },
                          ]}>
                          {heplerService.capitalizeFirstLetter(stateValue.bait_type ? stateValue.bait_type : '--')}
                        </Text>
                        <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>Bait Type</Text>
                      </View>
                    </View>
                  </View>
                  <View style={FriendsStyle.Card}>
                    <View style={[FriendsStyle.CardLeft, { width: 300 }]}>
                      <Icon name="depth" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                      <View>
                        <Text
                          style={[
                            FriendsStyle.CardTitle,
                            { position: 'relative' },
                          ]}>
                          {stateValue.depth_of_water ? stateValue.depth_of_water : '--'}
                        </Text>
                        <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>
                          Depth of Water
                        </Text>
                      </View>
                    </View>
                  </View>
                  <View style={FriendsStyle.Card}>
                    <View style={[FriendsStyle.CardLeft, { width: 300 }]}>
                      {/* <Icon name="lure" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} /> */}
                      <View style={FriendsStyle.CardImageIcon}>
                        <Icon name="lure" color={UiColor.White} size={14} />
                      </View>
                      <View>
                        <Text
                          style={[
                            FriendsStyle.CardTitle,
                            { position: 'relative' },
                          ]}>
                          {heplerService.capitalizeFirstLetter(stateValue.lure_type ? stateValue.lure_type : '--')}
                        </Text>
                        <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>Lure Type</Text>
                      </View>
                    </View>
                  </View>
                  <View style={FriendsStyle.Card}>
                    <View style={[FriendsStyle.CardLeft, { width: 300 }]}>
                      <Icon name="current" style={[FriendsStyle.CardImg]} color={"#09193D"} size={41} />
                      <View>
                        <Text
                          style={[
                            FriendsStyle.CardTitle,
                            { position: 'relative' },
                          ]}>
                          {heplerService.capitalizeFirstLetter(stateValue.current ? stateValue.current : '--')}
                        </Text>
                        <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>Current</Text>
                      </View>
                    </View>
                  </View>
                </View>
              )}
              {formLayoutIndex === 1 && (
                <>
                  {memoizedImages}
                  <Modal
                    visible={imageVisible}
                    transparent={true}
                    animationType="fade"
                    onRequestClose={() => setImageVisible(false)}
                  >
                    <ImageView
                      images={memoizedPreviewImages}
                      visible={imageVisible}
                      imageIndex={selectedIndex}
                      onRequestClose={() => setImageVisible(false)}
                    />
                  </Modal>
                </>
              )}
              {formLayoutIndex === 2 && (
                <>
                  <View>
                    {stateValue.current_latitude ? (
                      <View
                        style={{
                          flex: 1,
                          height: 500,
                          marginBottom: 10,
                          marginTop: 10,
                        }}>
                        {stateValue.current_latitude ? (
                          <MapboxGL.MapView
                            style={{ flex: 1 }}
                            styleURL='mapbox://styles/exactink/clx1vdour003b01qs7fej67yk'>
                            <MapboxGL.Camera
                              zoomLevel={10}
                              centerCoordinate={[
                                stateValue.current_longitude,
                                stateValue.current_latitude,
                              ]} // San Francisco coordinates
                            />
                            <MapboxGL.PointAnnotation
                              id={`marker-${stateValue.id}`}
                              coordinate={[
                                stateValue.current_longitude,
                                stateValue.current_latitude,
                              ]}
                              onSelected={() => { }}>
                              <>
                                <Icon
                                  color={UiColor.SecondaryColor}
                                  name={'noun-fish'}
                                  size={15}
                                />
                                <MapboxGL.Callout
                                  title={stateValue.fish_name}
                                  style={styles.callout}>
                                  <Text
                                    style={
                                      styles.calloutText
                                    }>{`Fish: ${stateValue.fish_name}`}</Text>
                                  <Text
                                    style={
                                      styles.calloutText
                                    }>{`Weight: ${stateValue.weight}`}</Text>
                                </MapboxGL.Callout>
                              </>
                            </MapboxGL.PointAnnotation>
                            <MapboxGL.SymbolLayer
                              id="place-labels"
                              sourceID="composite"
                              sourceLayerID="place_label"
                              style={{
                                textField: ['get', 'name'],
                                textFont: ['DIN Pro Medium', 'Arial Unicode MS Bold'],
                                textSize: 12,
                                textColor: 'white',
                              }}
                            />
                          </MapboxGL.MapView>
                        ) : (
                          <ActivityIndicator />
                        )}
                      </View>
                    ) : (
                      <ActivityIndicator />
                    )}
                  </View>
                </>
              )}
              {formLayoutIndex === 3 && (
                <View style={[styles.tideChart]}>
                  {stateValue && stateValue.tide_data && stateValue.tide_data.length > 0 && (
                  <>
                    <View> 
                      <View style={{flexDirection: 'column', justifyContent: 'center', alignItems: 'center', backgroundColor: '#1E3A8A', paddingVertical: 15, borderRadius: 5}}>
                        <Text style={{ fontSize: 18, fontFamily: Dm.semiBold, color: UiColor.White}}>{stateValue ? moment(stateValue.date).format('MMM D, YYYY') : '---'}</Text>
                      </View>
                      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginTop: 12, marginBottom: 20}} >
                      <LineChart
                        data={lineChartData}
                        width={LineChartWidth}
                        height={200}
                        xAxisLabelTextStyle={{ fontSize: 12, fontFamily: Dm.medium, }}
                        yAxisLabelTextStyle={{ fontSize: 12, fontFamily: Dm.medium }}
                        yAxisTextStyle={{ color: UiColor.PrimaryColor }}
                        xAxisTextStyle={{ color: UiColor.PrimaryColor }}
                        noOfSections={noOfSections}
                        formatYLabel={(value) => `${value} ft`}
                        dataPointsColor={UiColor.SecondaryColor}
                        xAxisColor={UiColor.PrimaryColor}
                        yAxisColor={UiColor.PrimaryColor}
                        color="#1E3A8A"
                        showValuesAsTopLabel={true}
                        yAxisMaxValue={maxValue}
                        onPress={handleDotPress}
                        yAxisOffset={minValue}
                        hideDataPoints={false}
                        adjustToWidth={false}
                        yAxisLabelWidth={35}
                        dataPointsHeight={6}
                        dataPointsRadius={6}
                        dataPointsWidth={6}
                        initialSpacing={35}
                        rulesType="solid"
                        endSpacing={40}
                        stepValue={stepValue}
                        spacing={65}
                        curved
                      />
                      </ScrollView>
                    </View>
                    <View>
                      <View style={styles.tideHeader}>
                        <Text style={styles.tideColumn}>Tide</Text>
                        <Text style={styles.tideColumn}>Time & Date</Text>
                        <View style={styles.timeContainer}>
                          <Text style={styles.timezoneText}>{selectedTimezone}</Text>
                          <View style={styles.arrowContainer}>
                            <TouchableOpacity onPress={handleNextTimezone} style={styles.bottomArrowButton}>
                              <Text style={styles.arrowText}>{'>'}</Text>
                            </TouchableOpacity>
                          </View>
                        </View>
                        <Text style={[styles.tideColumn]}>Height</Text>
                      </View>
                      {stateValue &&
                        stateValue.tide_data?.map(obj => {
                        return (
                          <View
                            key={obj._id}
                            style={[
                              styles.tideData,
                              {
                                backgroundColor: '#1E3A8A',
                                marginTop: 8,
                              },
                            ]}>
                            <View style={{}}>
                              <Text
                                style={{ fontSize: 14, fontFamily: Dm.medium, color: UiColor.White }}>
                                {obj.type ? obj.type + ' Tide' : '--'} 
                              </Text>
                            </View>
                            <View style={{ width: 160 }}>
                              <Text
                                style={{ fontSize: 14, fontFamily: Dm.medium, color: UiColor.White }}>
                                {obj.date ? formatDate(obj.date) : '--'}
                              </Text>
                            </View>
                            <View style={{ width: 60 }}>
                              <Text
                                style={{
                                  fontSize: 14,
                                  fontFamily: Dm.medium,
                                  textAlign: 'right',
                                  color: UiColor.White
                                }}>
                                {obj.height ? convertMetersToFeet(obj.height) + ' ft' : '--' } 
                              </Text>
                            </View>
                          </View>
                        );
                      })}
                    </View>
                  </>
                  )}
                  <View
                    style={[
                      styles.additionalInfo,
                      { flexDirection: 'row', marginTop: 10, justifyContent: 'space-between' },
                    ]}>
                    <View style={[styles.infoRow, { width: '25%', alignItems: 'center' }]}>
                      <Icon
                        name={'Sunrise'}
                        size={24}
                      />
                      <Text style={styles.infoLabel}>Sunrise</Text>
                      <Text style={styles.infoValue}>
                        {stateValue && stateValue.sunrise ? stateValueData.sunrise : '--'}
                      </Text>
                    </View>
                    <View style={styles.infoRow}>
                      <Icon
                        name={'Sunset'}
                        size={24}
                      />
                      <Text style={styles.infoLabel}>Sunset</Text>
                      <Text style={styles.infoValue}>
                        {stateValue && stateValue.sunset ? stateValueData.sunset : '--'}
                      </Text>
                    </View>
                    <View style={styles.infoRow}>
                      <Icon
                        name={'moonrise'}
                        size={24}
                      />
                      <Text style={styles.infoLabel}>Moonrise</Text>
                      <Text style={styles.infoValue}>
                        {stateValue && stateValue.moonrise ? stateValueData.moonrise : '--'}
                      </Text>
                    </View>
                    <View style={[styles.infoRow, { borderRightWidth: 0 }]}>
                      <Icon
                        name={'moonset'}
                        size={24}
                      />
                      <Text style={styles.infoLabel}>Moonset</Text>
                      <Text style={styles.infoValue}>
                        {stateValue && stateValue.moonset ? stateValueData.moonset : '--'}
                      </Text>
                    </View>
                  </View>
                </View>
              )}
              {formLayoutIndex === 4 && (
                <View
                  style={JournalStyle.formLayoutIndex}>
                  <View
                    style={JournalStyle.locationBox}>
                    <Text
                      style={JournalStyle.locationBoxText}>
                      {stateValue.location ? stateValue.location : '--'}
                    </Text>
                  </View>
                  <View
                    style={JournalStyle.locationDetailBox}>
                    <View
                      style={JournalStyle.locationDetail}>
                      <Text style={JournalStyle.locationDetailText}>
                        Latitude
                      </Text>
                      <Text style={{ fontSize: 14, }}>
                        {stateValue.current_latitude ? stateValue.current_latitude : '--'}
                      </Text>
                    </View>
                    <View
                      style={JournalStyle.BlankBox}></View>
                    <View
                      style={JournalStyle.locationDetail}>
                      <Text style={JournalStyle.locationDetailText}>
                        Longitude
                      </Text>
                      <Text style={{ fontSize: 14 }}>
                        {stateValue.current_longitude ? stateValue.current_longitude : '--'}
                      </Text>
                    </View>
                    <View
                      style={JournalStyle.BlankBox}></View>
                    <View
                      style={JournalStyle.locationDetail}>
                      <Text style={JournalStyle.locationDetailText}>
                        Temp
                      </Text>
                      <Text style={{ fontSize: 14 }}>
                        {stateValue.water_temperature ? stateValue.water_temperature : '--'}
                      </Text>
                    </View>
                    <View
                      style={JournalStyle.BlankBox}></View>
                    <View
                      style={JournalStyle.locationDetail}>
                      <Text style={JournalStyle.locationDetailText}>
                        Depth
                      </Text>
                      <Text style={{ fontSize: 14 }}>{stateValue.depth_of_water ? stateValue.depth_of_water : '--'}</Text>
                    </View>
                  </View>
                  {/* <View
                    style={{
                      flex: 1,
                      height: 300,
                      marginTop: 0,
                      marginBottom: 100,
                    }}>
                    {stateValue.current_latitude ? (
                      <MapboxGL.MapView
                        style={{ flex: 1 }}
                        styleURL='mapbox://styles/exactink/clx1vdour003b01qs7fej67yk'
                      >
                        <MapboxGL.Camera
                          zoomLevel={10}
                          centerCoordinate={
                            stateValue.current_latitude && stateValue.current_longitude
                              ? [stateValue.current_longitude, stateValue.current_latitude]
                              : [-122.431297, 37.773972]
                          }
                        />
                        <MapboxGL.PointAnnotation
                          id={`marker-${stateValue.id}`}
                          coordinate={[
                            stateValue.current_longitude,
                            stateValue.current_latitude,
                          ]}
                          onSelected={() => { }}>
                          <>
                            <Icon
                              color={UiColor.SecondaryColor}
                              name={'noun-fish'}
                              size={15}
                            />
                            <MapboxGL.Callout
                              title={stateValue.fish_name ? stateValue.fish_name : '--'}
                              style={styles.callout}>
                              <Text
                                style={
                                  styles.calloutText
                                }>{`Fish: ${stateValue.fish_name ? stateValue.fish_name : '--'}`}</Text>
                              <Text
                                style={
                                  styles.calloutText
                                }>{`Weight: ${stateValue.weight ? stateValue.weight : '--'}`}</Text>
                            </MapboxGL.Callout>
                          </>
                        </MapboxGL.PointAnnotation>
                        <MapboxGL.SymbolLayer
                          id="place-labels"
                          sourceID="composite"
                          sourceLayerID="place_label"
                          style={{
                            textField: ['get', 'name'],
                            textFont: ['DIN Pro Medium', 'Arial Unicode MS Bold'],
                            textSize: 12,
                            textColor: 'white',
                          }}
                        />
                      </MapboxGL.MapView>
                    ) : (
                      <ActivityIndicator />
                    )}
                  </View> */}
              
              <View style={styles.container}>
                {stateValue.current_latitude ? (
                  <>
                    <View style={styles.webViewContainer}>
                      {/* WebView */}
                      <WebView
                        source={{ uri: 'https://tempbreak.com/' }}
                        style={styles.webView}
                      />
                      
                    </View>
                      <TouchableOpacity style={styles.overlay} onPress={openInBrowser}>
                        <Text style={styles.overlayText}>Open in Browser</Text>
                      </TouchableOpacity>
                  </>
                ) : (
                  <ActivityIndicator size="large" color="#0000ff" />
                )}
              </View>
                </View>
              )}
              {formLayoutIndex === 5 && (
                <>
                  <MoonCalendar />
                </>
              )}
              {formLayoutIndex === 6 && (
                <>
                  <WeatherCalendar
                    weather_data={stateValue.weather_data}
                  />
                </>
              )}
              {formLayoutIndex === 7 && (
                <>
                  <View
                    style={[
                      FriendsStyle.Container,
                      { backgroundColor: 'transparent' },
                    ]}>
                    {stateValue.notes?.map((obj, index) => {
                      if (obj.notes) {
                        const words = obj.notes.split(' ');
                        const maxWordsToShow = 4;
                        const truncatedNotes =
                          words.length > maxWordsToShow
                            ? words.slice(0, maxWordsToShow).join(' ') + ' ...'
                            : obj.notes;
                        const date = obj.date.substring(0, 10);
                        return (
                          <View style={FriendsStyle.Card} key={index}>
                            <TouchableOpacity
                              onPress={() => {
                                handleCardClick(
                                  obj.notes,
                                  obj.date.substring(0, 10),
                                  obj._id,
                                ), noteViewSheet.current.open();
                              }
                              }>
                              <View style={FriendsStyle.CardLeft}>
                                <View>
                                  <Text style={FriendsStyle.CardTitle}>
                                    {truncatedNotes ? truncatedNotes : '--'}
                                  </Text>
                                  <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>
                                    {formatNoteDate(date)}
                                  </Text>
                                </View>
                              </View>
                            </TouchableOpacity>
                            <IconButton
                              onPress={() => {
                                handleCardClick(
                                  obj.notes,
                                  obj.date.substring(0, 10),
                                  obj._id,
                                ),  noteViewSheet.current.open();
                              }
                              }
                              style={[FriendsStyle.CardIcon, {borderWidth: 0}]}
                              icon={() => <Icon name={'arrow'} size={14} />}
                              size={28}
                            />
                          </View>
                        );
                      }
                    })}
                    {stateValue && stateValue.notes && stateValue.notes?.length === 0 && (
                      <View style={[GlobalStyles.NoData, { marginTop: 30 }]}>
                        <Text style={GlobalStyles.NoDataMsg}>No Notes Found</Text>
                      </View>
                    )}
                  </View>
                  <RBSheet
                    ref={ref => (noteCreateSheet.current = ref)}
                    closeOnDragDown={true}
                    closeOnPressMask={true}
                    openDuration={800}
                    height={400}
                    customStyles={{
                      wrapper: {
                        backgroundColor: '#00000024',
                      },
                      draggableIcon: {
                        backgroundColor: '#E3E3E3',
                      },
                      container: {
                        borderTopLeftRadius: 30,
                        borderTopRightRadius: 30,
                      },
                    }}>
                       <View
                          style={{
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                            marginTop: 2,
                            marginLeft: 290
                          }}>
                          <TouchableOpacity
                            style={[
                              RemoveStyle.DeleteBtn,
                              { backgroundColor: UiColor.SecondaryColor, paddingHorizontal: 20 },
                            ]}
                            onPress={() => addNotes({ isNoteUpdate: false })}>
                            {inProcess ? (
                              <ActivityIndicator
                                style={{
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                }}
                                size={24}
                                color="#fff"
                              />
                            ) : (
                              <Text
                                style={JournalStyle.ModalBoxTxt}>
                                Add
                              </Text>
                            )}
                          </TouchableOpacity>
                        </View>
                      <View
                        style={Styles.ModalBoxBody}>
                         <View style={[LoginStyle.FormControl, {marginHorizontal: 15}]}>
                          <Text
                            style={{
                              marginLeft: 5,
                              marginTop: 5,
                              marginBottom: 5,
                            }}>
                            Note
                          </Text>
                          <TextInput
                            placeholder="Note"
                            value={formData.notes}
                            onChangeText={text => {
                              if (text.length <= 250) {
                                setFormErrors({ ...formErrors, notes: '' }),
                                  setFormData({ ...formData, notes: text });
                              } else {
                                setFormErrors({
                                  notes: 'note must be 250 characters or less',
                                });
                              }
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: formErrors.notes
                                  ? UiColor.SecondaryColor
                                  : UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{ backgroundColor: 'transparent' }}
                            autoCapitalize="none"
                            keyboardType="default"
                            multiline
                            numberOfLines={4}
                          />
                          <HelperText
                            type="error"
                            style={Styles.ErrorMsg}
                            visible={formErrors.notes !== undefined}>
                            {formErrors.notes}
                          </HelperText>
                        </View>
                      </View>
                  </RBSheet>
                  <RBSheet
                    ref={ref => (noteViewSheet.current = ref)}
                    closeOnDragDown={true}
                    closeOnPressMask={true}
                    openDuration={800}
                    height={400}
                    customStyles={{
                      wrapper: {
                        backgroundColor: '#00000024',
                      },
                      draggableIcon: {
                        backgroundColor: '#E3E3E3',
                      },
                      container: {
                        borderTopLeftRadius: 30,
                        borderTopRightRadius: 30,
                      },
                    }}>
                      <View
                        style={JournalStyle.ModalBoxBody}>
                           {catchedId && catchedId.isJournalUser === true && (
                            <View
                              style={{
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                                paddingTop: 12,
                              }}>
                              <TouchableOpacity
                                onPress={() =>
                                  handleDeletePress({ isJournal: false })
                                }>
                                <View style={[RemoveStyle.DeleteBtn, { paddingHorizontal: 25 }]}>
                                  <Text
                                    style={JournalStyle.ModalBoxTxt}>
                                    Delete
                                  </Text>
                                </View>
                              </TouchableOpacity>
                              <TouchableOpacity onPress={() => openUpdateNoteSheet()}>
                                <View
                                  style={[
                                    RemoveStyle.DeleteBtn,
                                    { backgroundColor: UiColor.PrimaryColor, paddingHorizontal: 30 },
                                  ]}>
                                  <Text
                                    style={JournalStyle.ModalBoxTxt}>
                                    Edit
                                  </Text>
                                </View>
                              </TouchableOpacity>
                            </View>
                            )}
                        <View style={{marginTop: 20}}>
                          <Text style={[FriendsStyle.CardTitle, { width: 300 }]}>
                            {selectedNote.note}
                          </Text>
                          <Text style={[FriendsStyle.CardDisc, {color: UiColor.GrayLight,}]}>
                              {formatNoteDate(selectedNote.date)}
                          </Text>
                        </View>
                      </View>
                  </RBSheet>
                  <RBSheet
                    ref={ref => (noteUpdateSheet.current = ref)}
                    closeOnDragDown={true}
                    closeOnPressMask={true}
                    openDuration={800}
                    height={400}
                    customStyles={{
                      wrapper: {
                        backgroundColor: '#00000024',
                      },
                      draggableIcon: {
                        backgroundColor: '#E3E3E3',
                      },
                      container: {
                        borderTopLeftRadius: 30,
                        borderTopRightRadius: 30,
                      },
                    }}>
                       <View
                          style={{
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                            marginTop: 2,
                            marginLeft: 260
                          }}>
                          <TouchableOpacity
                            style={[
                              RemoveStyle.DeleteBtn,
                              { backgroundColor: UiColor.SecondaryColor, paddingHorizontal: 20 },
                            ]}
                            onPress={() => addNotes({ isNoteUpdate: true })}>
                            {inProcess ? (
                              <ActivityIndicator
                                style={{
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                }}
                                size={24}
                                color="#fff"
                              />
                            ) : (
                              <Text
                                style={JournalStyle.ModalBoxTxt}>
                                Update
                              </Text>
                            )}
                          </TouchableOpacity>
                        </View>
                      <View
                        style={Styles.ModalBoxBody}>
                         <View style={[LoginStyle.FormControl, {marginHorizontal: 15}]}>
                          <Text
                            style={{
                              marginLeft: 5,
                              marginTop: 5,
                              marginBottom: 5,
                            }}>
                            Note
                          </Text>
                          <TextInput
                            placeholder="Note"
                            value={formData.notes}
                            onChangeText={text => {
                              if (text.length <= 250) {
                                setFormErrors({ ...formErrors, notes: '' }),
                                  setFormData({ ...formData, notes: text });
                              } else {
                                setFormErrors({
                                  notes: 'note must be 250 characters or less',
                                });
                              }
                            }}
                            theme={LoginStyle.TextInput}
                            style={[
                              LoginStyle.FormInput,
                              {
                                borderColor: formErrors.notes
                                  ? UiColor.SecondaryColor
                                  : UiColor.GrayLight,
                              },
                            ]}
                            textColor={UiColor.PrimaryColor}
                            underlineStyle={{ backgroundColor: 'transparent' }}
                            autoCapitalize="none"
                            keyboardType="default"
                            multiline
                            numberOfLines={4}
                          />
                          <HelperText
                            type="error"
                            style={Styles.ErrorMsg}
                            visible={formErrors.notes !== undefined}>
                            {formErrors.notes}
                          </HelperText>
                        </View>
                      </View>
                  </RBSheet>
                </>
              )}
            </ScrollView>
          </View>
        </>
      )}
      {formLayoutIndex &&
        formLayoutIndex === 7 &&
        catchedId.isJournalUser === true ? (
        <TouchableOpacity
          onPress={() => {
            openNoteSheet();
            setFormData('');
          }}
          style={[Styles.AddBtn]}>
          <Icon name="plus" size={18} color={UiColor.White} />
        </TouchableOpacity>
      ) : (
        ''
      )}
    </>
  );
};

const styles = StyleSheet.create({
  tideChart: {
    marginTop: 10,
    backgroundColor: '#fff',
    borderRadius: 14,
    overflow: 'hidden',
    borderColor: 'grey',
    marginBottom: 100,
  },
  tideHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#D2283D',
  },
  tideColumn: {
    padding: 20,
    color: '#fff',
  },
  timeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: -30
  },
  arrowContainer: {
    flexDirection: 'column',
    marginTop: 0
  },
  arrowButton: {
    marginTop: 10,
  },
  bottomArrowButton: {
    marginBottom: 2,
  },
  arrowText: {
    fontSize: 22,
    color: UiColor.White,
  },
  timezoneDisplay: {
    alignItems: 'center',
  },
  timezoneText: {
    fontSize: 14,
    fontFamily: Dm.medium,
    color: '#fff',
    paddingRight: 8,  // Add some space between timezone text and arrows
  },
  tideData: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 8,
    textAlign: 'center',
    backgroundColor: '#fafafa',
  },
  additionalInfo: {},
  infoRow: {
    padding: 14,
    borderRightWidth: 1,
    borderRightColor: UiColor.BaseColorLight,
    width: '25%',
    alignItems: 'center',
  },
  Border0: {
    borderWidth: 0,
  },
  callout: {
    backgroundColor: 'white',
    padding: 10,
    width: 190,
    marginBottom: Platform.OS === 'ios' ? 50 : 10,
  },
  calloutText: {
    fontSize: 16,
    color: 'black',
  },
  container: {
    flex: 1,
  },
  webViewContainer: {
    flex: 1,
    height: 300,
    marginTop: 0,
    marginBottom: 100,
    position: 'relative', // Required for absolute positioning
  },
  webView: {
    flex: 1,
  },
  overlay: {
    position: 'absolute', // Position overlay on top of WebView
    top: 250,
    left: 0,
    height: 50,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)', // Semi-transparent background
  },
  overlayText: {
    color: 'white',
    fontSize: 16,
  },
});

export default JournalCatches;
