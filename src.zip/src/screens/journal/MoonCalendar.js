import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useDispatch, useSelector } from 'react-redux';
import React, { useState, useEffect } from 'react';
import { fetchYearlyMoonPhase } from '../../thunk';
import { Dm } from '../../../theme/FontFamily';
import moment from 'moment';

const MoonCalendar = () => {
  const dispatch = useDispatch();
  const stateVal = useSelector(state => state.login.moonPhase);
  const [selectedMonth, setSelectedMonth] = useState(moment().month() + 1);
  const [selectedYear, setSelectedYear] = useState(moment().year());
  const currentDate = moment();

  useEffect(() => {
    fetchMoonData(selectedYear);
  }, [selectedYear]);

  const fetchMoonData = async (year) => {
    const params = { year: year };
    await dispatch(fetchYearlyMoonPhase(params));
  };

  const moonPhaseLegend = [
    { iconName: 'moon-new', color: '#000000', label: 'New Moon' },
    { iconName: 'moon-waxing-crescent', color: '#b3cde0', label: 'Waxing Crescent' },
    { iconName: 'moon-first-quarter', color: '#6497b1', label: 'First Quarter' },
    { iconName: 'moon-waxing-gibbous', color: '#005b96', label: 'Waxing Gibbous' },
    { iconName: 'moon-full', color: '#ffcc00', label: 'Full Moon' },
    { iconName: 'moon-waning-gibbous', color: '#e6b800', label: 'Waning Gibbous' },
    { iconName: 'moon-last-quarter', color: '#e67300', label: 'Last Quarter' },
    { iconName: 'moon-waning-crescent', color: '#cc3300', label: 'Waning Crescent' },
  ];

  const renderLegendItem = ({ iconName, color, label }) => (
    <View key={iconName} style={styles.legendItem}>
      <Icon name={iconName} size={20} color={color} />
      <Text style={styles.legendText}>{label}</Text>
    </View>
  );

  const getMoonPhaseIcon = (illumination) => {
    if (illumination < 0.03 || illumination > 0.97) {
      return { iconName: 'moon-new', color: '#000000' };
    } else if (illumination < 0.25) {
      return { iconName: 'moon-waxing-crescent', color: '#b3cde0' };
    } else if (illumination < 0.28) {
      return { iconName: 'moon-first-quarter', color: '#6497b1' };
    } else if (illumination < 0.50) {
      return { iconName: 'moon-waxing-gibbous', color: '#005b96' };
    } else if (illumination < 0.53) {
      return { iconName: 'moon-full', color: '#ffcc00' };
    } else if (illumination < 0.75) {
      return { iconName: 'moon-waning-gibbous', color: '#e6b800' };
    } else if (illumination < 0.78) {
      return { iconName: 'moon-last-quarter', color: '#e67300' };
    } else {
      return { iconName: 'moon-waning-crescent', color: '#cc3300' };
    }
  };

  const generateDates = (year, month) => {
    const daysInMonth = moment(`${year}-${month}`, 'YYYY-MM').daysInMonth();
    const dates = [];
    const monthName = moment(`${year}-${month}`, 'YYYY-MM').format('MMM');
    for (let i = 1; i <= daysInMonth; i++) {
      const day = i < 10 ? `0${i}` : `${i}`;
      const illumination = stateVal[monthName]?.[day] || '--';
      dates.push({
        date: moment(`${year}-${month}-${i}`, 'YYYY-MM-DD'),
        illumination: illumination === '--' ? 0 : parseFloat(illumination)
      });
    }
    return dates;
  };

  const renderDay = (item, index) => {
    const isCurrentDate = item.date.isSame(currentDate, 'day');
    const { iconName, color } = getMoonPhaseIcon(item.illumination);
    return (
      <View key={index} style={[styles.dayContainer, isCurrentDate && styles.currentDayContainer]}>
        <Text style={styles.dateText}>{item.date.format('D')}</Text>
        <Icon name={iconName} size={30} color={color} />
        <Text style={{ fontSize: 10, marginLeft: 8, fontWeight: '400' }}>{`${(item.illumination * 100).toFixed(0)}%`}</Text>
        {isCurrentDate && <View style={styles.currentDateMarker} />}
      </View>
    );
  };

  const renderEmptyDay = (index) => (
    <View key={index} style={styles.emptyDayContainer} />
  );

  const updateMonth = (direction) => {
    let newMonth = selectedMonth + direction;
    let newYear = selectedYear;

    if (newMonth < 1) {
      newMonth = 12;
      newYear -= 1;
    } else if (newMonth > 12) {
      newMonth = 1;
      newYear += 1;
    }

    setSelectedMonth(newMonth);
    setSelectedYear(newYear);
    fetchMoonData(newYear);
  };

  const dates = generateDates(selectedYear, selectedMonth);
  const firstDayOfMonth = moment(`${selectedYear}-${selectedMonth}-01`, 'YYYY-MM-DD').day();
  const calendarData = Array.from({ length: firstDayOfMonth }, () => null).concat(dates);

  // Calculate the number of empty days to fill the last row
  const lastRowEmptyDays = (7 - (calendarData.length % 7)) % 7;
  const calendarDataWithEmptyDays = calendarData.concat(Array.from({ length: lastRowEmptyDays }, () => null));

  // Group dates into weeks
  const weeks = [];
  for (let i = 0; i < calendarDataWithEmptyDays.length; i += 7) {
    weeks.push(calendarDataWithEmptyDays.slice(i, i + 7));
  }

  return (
    <View style={{ backgroundColor: '#f2f2f2', marginTop: 10, borderRadius: 15 }}>
      <View>
        <Text style={{ textAlign: 'center', marginTop: 10, fontFamily: Dm.semiBold, fontSize: 18 }}>Moon Illumination At Midnight</Text>
      </View>
      <View style={styles.headerContainer}>
        <TouchableOpacity onPress={() => updateMonth(-1)} style={styles.arrowButton}>
          <Icon name="chevron-left" size={30} />
        </TouchableOpacity>
        <Text style={styles.headerText}>{moment(`${selectedYear}-${selectedMonth}`, 'YYYY-MM').format('MMMM YYYY')}</Text>
        <TouchableOpacity onPress={() => updateMonth(1)} style={styles.arrowButton}>
          <Icon name="chevron-right" size={30} />
        </TouchableOpacity>
      </View>
      <View style={styles.daysOfWeekContainer}>
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day, index) => (
          <Text key={index} style={styles.dayOfWeekText}>{day}</Text>
        ))}
      </View>
      <View style={styles.calendarContainer}>
        {weeks.map((week, weekIndex) => (
          <View key={weekIndex} style={styles.weekContainer}>
            {week.map((day, dayIndex) => (day ? renderDay(day, dayIndex) : renderEmptyDay(dayIndex)))}
          </View>
        ))}
      </View>
      <View style={styles.legendContainer}>
        <View style={{ marginRight: 20 }}>
          {moonPhaseLegend.slice(0, 4).map((phase) => renderLegendItem(phase))}
        </View>
        <View>
          {moonPhaseLegend.slice(4, 8).map((phase) => renderLegendItem(phase))}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 10,
  },
  headerText: {
    fontSize: 18,
    fontWeight: 'bold',
    fontFamily: Dm.semiBold,
  },
  arrowButton: {
    padding: 5,
  },
  daysOfWeekContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 10,
    backgroundColor: '#e6e6e6',
  },
  dayOfWeekText: {
    width: '14%',
    textAlign: 'center',
    fontWeight: 'bold',
    fontFamily: Dm.semiBold,
  },
  calendarContainer: {
    paddingHorizontal: 5,
    backgroundColor: '#f2f2f2',
  },
  weekContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  dayContainer: {
    width: '14%',
    alignItems: 'center',
    marginVertical: 10,
  },
  dateText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
  },

  currentDateMarker: {
    width: 5,
    height: 5,
    backgroundColor: 'red',
    borderRadius: 2.5,
  },
  emptyDayContainer: {
    width: '14%',
    marginVertical: 10,
  },
  legendContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
    marginBottom: 10,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  legendText: {
    marginLeft: 5,
  },
});

export default MoonCalendar;
