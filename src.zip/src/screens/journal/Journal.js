import { View, Text, TextInput, TouchableOpacity, ScrollView, Image } from 'react-native';
import { Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm } from '../../../theme/Index';
import { Appbar, IconButton, ActivityIndicator } from 'react-native-paper';
import { useIsFocused, useNavigation } from '@react-navigation/native';
import React, { useEffect, useState, useRef, useContext } from 'react';
import { NetworkContext } from '../../NetworkContext';
import { useDispatch, useSelector } from 'react-redux';
import RBSheet from 'react-native-raw-bottom-sheet';
import { Calendar } from 'react-native-calendars';
import fireStore from '@react-native-firebase/firestore';
import { fetchAllCatches } from '../../thunk';
import moment from 'moment';
import { JournalStyle } from './JournalStyle';

const Journal = ({ navigation }) => {
  const isFocused = useIsFocused();
  const dispatch = useDispatch();
  const refSheet = useRef();
  const isConnected = useContext(NetworkContext);
  const [selectedDate, setSelectedDate] = useState(moment().format('YYYY-MM-DD'));
  const stateVal = useSelector(state => state.login);
  const notification = stateVal.notification_count;
  const [unreadCount, setUnreadCount] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [params, setParams] = useState({
    search: '',
    page: 1,
    limit: 60,
  });
  const [markedDates, setMarkedDates] = useState({});

  useEffect(() => {
    if (isConnected && isFocused) {
      fetchFishData();
      ChatNotification();
    }
    return () => { };
  }, [isConnected, isFocused]);

  const fetchFishData = async () => {
    const resultAction = await dispatch(fetchAllCatches(params));
    if (fetchAllCatches.fulfilled.match(resultAction)) {
      const data = resultAction.payload.data;
      const newMarkedDates = getMarkedDates(data.result);
      setMarkedDates(prevMarkedDates => ({
        ...prevMarkedDates,
        ...newMarkedDates,
      }));
    }
  };

  const getMarkedDates = catches => {
    const markedDates = {};
    catches.forEach(catchItem => {
      const catchDate = moment(catchItem.date, 'YYYY MM DD').format('YYYY-MM-DD');
      markedDates[catchDate] = {
        marked: true,
        dotColor: 'red',
      };
    });
    return markedDates;
  };

  const handleMonthChange = month => {
    const nextPage = params.page + 1;
    if (nextPage > currentPage) {
      setParams(prevParams => ({
        ...prevParams,
        page: nextPage,
      }));
      setCurrentPage(nextPage);
      fetchFishData();
    }
  };

  const ChatNotification = async () => {
    try {
      const loggedInUserId = stateVal.id;
      const chatListSnapshot = await fireStore()
        .collection('chatlists')
        .where('receiverId', '==', loggedInUserId)
        .get();
      const chatListData = chatListSnapshot.docs.map(doc => doc.data());
      chatListData.map((obj, index) => {
        setUnreadCount(obj.unreadMessages);
      });
    } catch (error) {
      console.error('Error fetching chat list:', error);
    }
  };

  const handleDayPress = day => {
    const formattedDate = moment(day.dateString).format('YYYY-MM-DD');
    setSelectedDate(formattedDate);
  };

  const handleContinue = () => {
    refSheet.current.close();
    setTimeout(goToNextScreen, 600);
  };
  const goToNextScreen = () => {
    setTimeout(() => {
      navigation.navigate('JournalList', selectedDate);
    }, 100);
  };

  return (
    <View style={Styles.WhiteBg}>
      <Appbar.Header
        style={[Styles.AppbarHeader, Styles.AppBarShadow, { justifyContent: 'space-between' }]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{ backgroundColor: UiColor.SecondaryColor }}
          icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
        />
        <Appbar.Content titleStyle={Styles.NavTitle} title="Journal" />
        <Appbar.Action />
      </Appbar.Header>
      <View style={MainStyles.Container}>
        <View
          style={{
            flexDirection: 'row',
            marginHorizontal: -8,
            flexWrap: 'wrap',
          }}>
          <View style={{ paddingHorizontal: 8, width: '50%' }}>
            <TouchableOpacity
              style={{ textAlign: 'center' }}
              onPress={() => refSheet.current.open()}>
              <View
                style={JournalStyle.CalenderBox}>
                <Image
                  style={JournalStyle.CalenderBoxImg}
                  source={IconAsset.CalenderOld}
                />
                <Text
                  style={JournalStyle.CalenderBoxText} numberOfLines={2} ellipsizeMode='tail'>
                  Daily Journal
                </Text>
              </View>
            </TouchableOpacity>
          </View>
          <View style={{ paddingHorizontal: 8, width: '50%' }}>
            <TouchableOpacity
              style={{ textAlign: 'center' }}
              onPress={() => navigation.navigate('CatchHistoryMap')}>
              <View
                style={JournalStyle.HistoryMap}>
                <Image
                  style={JournalStyle.HistoryMapImg}
                  source={IconAsset.Destination}
                />
                <Text
                  style={JournalStyle.CalenderBoxText} numberOfLines={2} ellipsizeMode='tail'>
                  Catch History Map
                </Text>
              </View>
            </TouchableOpacity>
          </View>
          <View style={{ paddingHorizontal: 8, width: '50%' }}>
            <TouchableOpacity
              style={{ textAlign: 'center' }}
              onPress={() => navigation.navigate('JournalShare')}>
              <View
                style={JournalStyle.CalenderBox}>
                <Image
                  style={JournalStyle.CalenderBoxImg}
                  source={IconAsset.ShareWithMe}
                />
                <Text
                  style={JournalStyle.CalenderBoxText} numberOfLines={2} ellipsizeMode='tail'>
                  Shared With Me
                </Text>
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <RBSheet
        ref={refSheet}
        closeOnDragDown={true}
        closeOnPressMask={true}
        height={460}
        onOpen={() => {
          fetchFishData();
        }}
        onClose={() => {
          setParams(prevParams => ({
            ...prevParams,
            page: 1,
          }));
          setCurrentPage(1);
        }}
        customStyles={{
          wrapper: {
            backgroundColor: '#100f4d3d',
          },
          draggableIcon: {
            backgroundColor: '#E3E3E3',
            // marginTop: 10,
          },
          container: {
            backgroundColor: '#fff',
            borderTopLeftRadius: 30,
            borderTopRightRadius: 30,
          },
        }}>
        <>
          <View style={{ justifyContent: 'center', flex: 1 }}>
            <Calendar
              onDayPress={handleDayPress}
              onMonthChange={handleMonthChange}
              markedDates={{
                ...markedDates,
                [selectedDate]: {
                  selected: true,
                  disableTouchEvent: true,
                  selectedDotColor: 'red',
                },
              }}
              theme={{
                selectedDayBackgroundColor: UiColor.DarkBlue,
                todayTextColor: UiColor.SecondaryColor,
                arrowColor: UiColor.DarkBlue,
              }}
            />
            <View
              style={JournalStyle.CalendarCtaBox}>
              <TouchableOpacity
                style={JournalStyle.CalendarCta}
                onPress={handleContinue}>
                <Text style={{ color: '#fff', fontSize: 21 }}>Continue</Text>
              </TouchableOpacity>
            </View>
          </View>
        </>
      </RBSheet>
    </View>
  );
};
const MainStyles = {
  WhiteBg: {
    flex: 1,
    backgroundColor: '#DDE8F3',
  },
  Container: {
    padding: 16,
  },
  CardContainer: {
    width: 170,
    height: 133.93,
    margin: 8,
    overflow: 'hidden',
    borderRadius: 10,
  },
  HighlightCard: {
    backgroundColor: '#DDE8F3',
    borderRadius: 10,
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  CardContent: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingBottom: 10,
  },

  CardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#100F4D',
  },
  CardImage: {
    width: 50,
    height: 50,
    marginBottom: 10,
  },
};

export default Journal;
