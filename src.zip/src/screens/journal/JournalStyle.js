/* eslint-disable prettier/prettier */
import { StyleSheet, Platform } from 'react-native';
import { UiColor, Dm } from '../../../theme/Index';


export const JournalStyle = StyleSheet.create({
    CalenderBox: {
        paddingHorizontal: 16,
        paddingVertical: 30,
        marginBottom: 14,
        backgroundColor: '#09193D',
        borderWidth: 1,
        borderColor: '#DDE8F3',
        borderRadius: 10,
        width: '100%',
        alignItems: 'center',
        height: 150
    },
    CalenderBoxImg: {
        width: 60,
        height: 60,
        objectFit: 'contain',
        marginBottom: 8,
    },
    CalenderBoxText: {
        fontSize: 14,
        fontFamily: Dm.semiBold,
        color: '#fff',
        textAlign: 'center',
    },
    HistoryMap: {
        paddingHorizontal: 16,
        paddingVertical: 30,
        marginBottom: 14,
        backgroundColor: '#09193D',
        borderWidth: 1,
        borderColor: '#DDE8F3',
        borderRadius: 10,
        width: '100%',
        alignItems: 'center',
        height: 150
    },
    HistoryMapImg: {
        width: 60,
        height: 60,
        objectFit: 'contain',
        marginBottom: 8,
    },
    JournalShare: {
        width: 60,
        height: 60,
        objectFit: 'contain',
        marginBottom: 8,
    },
    CalendarCtaBox: {
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 10,
        marginBottom: 10,
        paddingHorizontal: 35,
    },
    CalendarCta: {
        backgroundColor: '#D2283D',
        width: '100%',
        height: 45,
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center',
    },
    SenderName: {
        fontFamily: Dm.medium,
        backgroundColor: 'grey',
        opacity: 0.5,
        position: 'absolute',
        fontSize: 16,
        color: 'white',
        alignItems: 'baseline',
        marginLeft: 220,
        width: 160
    },
    ShareBox: {
        position: 'absolute',
        right: 15,
        backgroundColor: 'transparent',
        backgroundColor: '#D2283D',
        borderRadius: 6,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 10
    },
    ShareBoxText: {
        color: 'white',
        fontSize: 16,
        fontFamily: Dm.semiBold,
    },
    selectedFriendIds: {
        position: 'absolute',
        zIndex: 1,
        top: 0,
        right: 0,
        backgroundColor: '#fff',
        width: 28,
        height: 28,
        borderRadius: 28,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    ViewIcon: {
        position: 'absolute',
        alignContent: 'center',
        alignItems: 'center',
        bottom: 400,
        right: 15,
        width: 30,
        height: 30,
    },
    formLayoutIndex: {
        marginTop: 10,
        backgroundColor: '#fff',
        borderRadius: 14,
        overflow: 'hidden',
    },
    locationBox: {
        paddingVertical: 15,
        alignItems: 'center',
        paddingHorizontal: 15,
        backgroundColor: UiColor.SecondaryColor,
    },
    locationBoxText: {
        fontFamily: Dm.semiBold,
        color: UiColor.White,
        fontSize: 18,
        flexShrink: 1,
        textAlign: 'center',
    },
    locationDetailBox: {
        paddingVertical: 10,
        flex: 1,
        flexDirection: 'row',
        width: '100%',
        justifyContent: 'space-between',
        borderColor: UiColor.BaseColorLight,
        borderWidth: 1,
        backgroundColor: '#EBF5FB',
    },
    locationDetail: {
        width: '25%',
        paddingHorizontal: 6,
        alignItems: 'center'
    },
    locationDetailText: {
        fontWeight: '600',
        fontFamily: Dm.semiBold,
        fontSize: 12
    },
    BlankBox: {
        width: 1,
        height: 35,
        borderColor: UiColor.BaseColorLight,
        borderWidth: 1,
        marginTop: 2,
    },
    ModalBox: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        paddingHorizontal: 15,
    },
    ModalBoxBody: {
        backgroundColor: UiColor.White,
        padding: 20,
        width: '100%',
        height: 'auto',
        borderRadius: 10,
    },
    ModalBoxClose: {
        position: 'absolute',
        top: -14,
        right: -8,
        backgroundColor: UiColor.SecondaryColor,
        borderRadius: 16,
    },
    ModalBoxTxt: {
        color: UiColor.White,
        fontSize: 16,
        fontFamily: Dm.bold,
        textAlign: 'center',
    },
});


