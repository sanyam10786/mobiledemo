import {Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm} from '../../../theme/Index';
import { fetchAllCatches, fetchShareJournal } from '../../thunk';
import {View, Text, TouchableOpacity, SafeAreaView, FlatList} from 'react-native';
import {Appbar, Avatar, IconButton, ActivityIndicator} from 'react-native-paper';
import { useIsFocused, useNavigation, useRoute } from '@react-navigation/native';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import { resetState, setRefreshing } from '../../slices/catches';
import React, { useEffect, useState, useContext } from 'react';
import { FriendsStyle } from '../add-friends/FriendsStyle';
import { useDispatch, useSelector } from 'react-redux';
import { NetworkContext } from '../../NetworkContext'; 

const JournalShare = ({ navigation }) => {
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const route = useRoute();
  const stateVal = useSelector(state => state.login);
  const isConnected = useContext(NetworkContext);
  const catchesData = useSelector(state => state.catches);
  const shareData = catchesData.shareItem;
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const stateValue = catchesData.items;
  const [currentPage, setCurrentPage] = React.useState(1);
  const [search, setSearch] = useState('');
  const [params, setParamData] = useState({
    date: route.params,
    page: 1,
    search: search,
    limit: 10
  });
  const [isSearching, setIsSearching] = useState(false);
  useEffect(() => {
    if (isFocused) {
      dispatch(fetchShareJournal());
    }
  }, [isFocused, params]);

  const handleRefresh = () => {
    dispatch(resetState({}));
    params.page = 1;
    fetchShareJournal(currentPage, params);
  };

  const ListShareItem = (item, index) => {
    const senderName = item.from_id.name
    const catchedFish = item.fish_catch && item.fish_catch.media && item.fish_catch.media.path;
    const isJournalUser = item && item.from_id.id === stateVal.id ? true : false;
    return (
      <View style={FriendsStyle.Card}>
        <TouchableOpacity
          onPress={() => navigation.navigate("JournalCatches", {catch_id: item && item.fish_catch && item.fish_catch._id, isJournalUser, sender_name: senderName}, setCurrentPage(1))}
          >
          <View style={FriendsStyle.CardLeft}>
            {catchedFish ? (
              <Avatar.Image
                style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                size={51}
                source={{
                  uri: catchedFish ? catchedFish : IconAsset.BlankUser,
                }}
              />
            ) : (
              <Avatar.Image
                style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                size={51}
                source={IconAsset.BlankUser}
              />
            )}
            <View>
              <Text style={FriendsStyle.CardTitle}>{item.fish_catch && item.fish_catch.fish_name}</Text>
              <Text>
              Shared by <Text style={{ color: UiColor.Black, fontFamily: Dm.semiBold}}>{item.from_id.name}</Text>
              </Text>
            </View>
          </View>
        </TouchableOpacity>
        <IconButton
          onPress={() => navigation.navigate("JournalCatches", {catch_id: item && item.fish_catch && item.fish_catch._id, isJournalUser, sender_name: senderName}, setCurrentPage(1))}
          style={[FriendsStyle.CardIcon, {borderWidth: 0}]}
          icon={() => <Icon name={'arrow'} size={14} />}
          size={28}
        />
      </View>
    );
  };
  return (
    <>
      <Appbar.Header
        style={[
          Styles.AppbarHeader,
          Styles.AppBarShadow,
          {justifyContent: 'space-between'},
        ]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{ backgroundColor: UiColor.SecondaryColor }}
          icon={() => (
            <Icon name="back" size={18} style={Styles.BackWhite} />
          )}
        />
        <Appbar.Content titleStyle={Styles.NavTitle} title="Shared Journals" />
        <Appbar.Action animated={false} size={30} rippleColor="#00000008" />
      </Appbar.Header>
      <View>
          <SafeAreaView style={[FriendsStyle.FullCardArea, {marginTop: 15}]}>
          {!isConnected && shareData &&
              shareData.length === 0 ?
            <View style={[GlobalStyles.NoData, {marginTop: 80}]}>
              <Icon name="no-connection" size={50} />
              <Text style={[GlobalStyles.NoDataMsg, {fontFamily: Dm.semiBold}]}>
                No Internet Connection
              </Text>
            </View> 
          : 
            <>
            {Object.keys(shareData).length === 0 && isLoadingMore ? (
              <SkeletonPlaceholder>
                {Array.from({ length: 10 }).map((_, index) => (
                  <View style={[FriendsStyle.Card, {shadowOpacity: 0,
                    shadowRadius: 0,}]} key={index}>
                    <SkeletonPlaceholder.Item height={50} width="100%">
                      <View style={FriendsStyle.CardLeft}>
                        <SkeletonPlaceholder.Item
                          width={51}
                          height={51}
                          borderRadius={51}
                        />
                        <View>
                          <SkeletonPlaceholder.Item
                            height={20}
                            width={120}
                            marginLeft={10}
                          />
                          <SkeletonPlaceholder.Item
                            height={20}
                            width={180}
                            marginLeft={10}
                            marginTop={8}
                          />
                        </View>
                      </View>
                    </SkeletonPlaceholder.Item>
                  </View>
                ))}
              </SkeletonPlaceholder>
            ) : (
              <FlatList
                  data={shareData}
                  onEndReachedThreshold={0.5}
                  showsVerticalScrollIndicator={false}
                  keyExtractor={(item, index) => index.toString()}
                  renderItem={({ item, index }) => ListShareItem(item, index)}
                  refreshing={handleRefresh}
              />
              )}
              {!isLoadingMore && !catchesData.isLoading && shareData && shareData?.length === 0 && (
                  <View style={GlobalStyles.NoData}>
                  <Text style={GlobalStyles.NoDataMsg}>No Journals Found</Text>
                  </View>
              )}
          </>}
          </SafeAreaView>
      </View>
    </>
  );
};
export default JournalShare;
