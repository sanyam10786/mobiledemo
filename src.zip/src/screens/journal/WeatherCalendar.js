import {View, Text, StyleSheet, Image, ScrollView} from 'react-native';
import {Icon, IconAsset} from '../../../theme/IconsAssets';
import React, {useState, useEffect} from 'react';
import {UiColor} from '../../../theme/UiColors';
import moment from 'moment';

const WeatherCalendar = ({weather_data}) => {
  const [weatherData, setWeatherData] = useState(null);
  const [cityInfo, setCityInfo] = useState(null);

  useEffect(() => {
    if (weather_data) {
      organizeWeatherData(weather_data);
      setCityInfo(weather_data.city);
    }
  }, [weather_data, weather_data.city]);

  const organizeWeatherData = data => {
    const groupedData = {};
    data.list.forEach(item => {
      const date = item.dt_txt.split(' ')[0];
      if (!groupedData[date]) {
        groupedData[date] = [];
      }
      groupedData[date].push(item);
    });

    const days = Object.keys(groupedData).map(date => ({
      date,
      data: groupedData[date],
    }));
    setWeatherData(days);
  };

  const convertCelsiusToFahrenheit = celsius => {
    return (celsius * 9) / 5 + 32;
  };

  const getWeatherImage = weatherType => {
    switch (weatherType) {
      case 'Clear':
        return IconAsset.Sunny;
      case 'Clouds':
        return IconAsset.Clouds;
      case 'Rain':
        return IconAsset.Rain;
      default:
        return IconAsset.PartlySunny;
    }
  };

  const todayDate = moment().format('YYYY-MM-DD');
  const todayWeather = weatherData
    ? weatherData.find(day => day.date === todayDate)
    : null;

  return (
    <View style={styles.container}>
      {todayWeather && todayWeather.data.length > 0 && (
        <View style={[styles.todayWeatherContainer, {flexDirection: 'row'}]}>
          <View style={{marginHorizontal: 20}}>
            <Text style={styles.todayTempText}>
              {convertCelsiusToFahrenheit(
                todayWeather.data[0].main.temp,
              ).toFixed(2)}
              °
            </Text>
            <Text style={styles.dateText}>
              {moment(todayWeather.data[0].dt_txt).format('ddd, MMM DD, YYYY')}
            </Text>
            {cityInfo && (
              <View style={{flexDirection: 'row'}}>
                <Icon
                  name="location"
                  size={14}
                  color={UiColor.White}
                  style={{marginRight: 8, marginTop: 3}}
                />
                <Text style={[styles.cityName]}>
                  {cityInfo.name}, {cityInfo.country}
                </Text>
              </View>
            )}
          </View>
          <View>
            <Image
              source={getWeatherImage(todayWeather.data[0].weather[0].main)}
              style={{width: 100, height: 100}}
            />
            <Text style={[styles.descriptionText, {marginLeft: 10}]}>
              {todayWeather.data[0].weather[0].description}
            </Text>
          </View>
        </View>
      )}
      {todayWeather && <Text style={styles.sectionTitle}>Today</Text>}
      <View style={{alignItems: 'center'}}>
        {todayWeather && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {todayWeather.data.map((item, index) => (
              <View key={index} style={styles.hourlyItem}>
                <Text style={styles.hourText}>
                  {moment(item.dt_txt).format('h A')}
                </Text>
                <Image
                  source={getWeatherImage(item.weather[0].main)}
                  style={styles.weatherImage}
                />
                <Text style={styles.hourTempText}>
                  {convertCelsiusToFahrenheit(item.main.temp).toFixed(0)}°
                </Text>
              </View>
            ))}
          </ScrollView>
        )}
      </View>

      {todayWeather ? (
        <Text style={styles.sectionTitle}>6 days forecast</Text>
      ) : (
        <Text style={[styles.sectionTitle, {textAlign: 'center'}]}>
          No forecast record found
        </Text>
      )}
      <View style={{marginBottom: 10}}>
        {weatherData &&
          weatherData.map((item, index) => (
            <View key={index} style={styles.dailyItem}>
              <Text style={styles.dailyText}>
                {moment(item.date).format('ddd')}
              </Text>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  position: 'absolute',
                  marginLeft: 80,
                }}>
                <Image
                  source={getWeatherImage(item.data[0].weather[0].main)}
                  style={styles.weatherImage}
                />
                <Text style={[styles.dailyText]}>
                  {item.data[0].weather[0].main}
                </Text>
              </View>
              <Text style={styles.dailyTempText}>
                {convertCelsiusToFahrenheit(item.data[0].main.temp_max).toFixed(
                  0,
                )}
                ° /{' '}
                {convertCelsiusToFahrenheit(item.data[0].main.temp_min).toFixed(
                  0,
                )}
                °
              </Text>
            </View>
          ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 10,
    backgroundColor: '#1E3A8A',
    borderRadius: 10,
    margin: 20,
  },
  cityName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  todayWeatherContainer: {
    alignItems: 'center',
    marginVertical: 20,
  },
  todayTempText: {
    fontSize: 48,
    fontWeight: 'bold',
    color: 'white',
  },
  dateText: {
    fontSize: 16,
    color: 'white',
  },
  descriptionText: {
    fontSize: 14,
    color: 'white',
  },
  sectionTitle: {
    fontSize: 16,
    color: 'white',
    marginVertical: 10,
    marginLeft: 10,
  },
  hourlyItem: {
    alignItems: 'center',
    marginHorizontal: 5,
  },
  hourText: {
    fontSize: 14,
    color: 'white',
  },
  hourTempText: {
    fontSize: 14,
    color: 'white',
  },
  dailyItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    paddingHorizontal: 15,
    backgroundColor: '#fff',
    borderRadius: 10,
    marginVertical: 5,
  },
  dailyText: {
    fontSize: 16,
    color: '#000000',
    flex: 1,
  },
  dailyTempText: {
    fontSize: 16,
    color: '#000000',
  },
  weatherImage: {
    width: 30,
    height: 30,
    marginHorizontal: 10,
  },
});

export default WeatherCalendar;
