import { View, Text, TouchableOpacity, TextInput, Image, ScrollView, StyleSheet, Platform } from 'react-native';
import { Styles, Icon, IconAsset, UiColor } from '../../../theme/Index';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { fetchAllCatches, fetchShareJournal } from '../../thunk';
import { ActivityIndicator, Appbar } from 'react-native-paper';
import { ProfileStyle } from '../user-profile/ProfileStyle';
import React, { useEffect, useState, useRef } from 'react';
import { useIsFocused } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import MapboxGL from '@rnmapbox/maps';
import moment from 'moment';

const CustomDatePicker = ({ value, onChange, show, setShow, placeholder }) => {
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleConfirm = date => {
    hideDatePicker();
    onChange(date);
  };

  return (
    <>
      <TouchableOpacity
        onPress={showDatePicker}
        style={styles.datePickerContainer}>
        <Image source={IconAsset.Calender} style={styles.calendarIcon} />
        <TextInput
          style={styles.datePickerText}
          placeholder={placeholder}
          value={moment(value).format('MM-DD-YYYY')}
          onPressIn={showDatePicker}
          editable={false}
        />
      </TouchableOpacity>
      <DateTimePickerModal
        isVisible={isDatePickerVisible}
        mode="date"
        date={value}
        onConfirm={handleConfirm}
        onCancel={hideDatePicker}
      />
    </>
  );
};

const FrameCard = ({ catchItem }) => (
  <View style={styles.frameCardContainer}>
    <Image
      source={
        catchItem.media && catchItem.media.path
          ? { uri: catchItem.media.path }
          : IconAsset.BlankUser
      }
      style={styles.frameCardImage}
    />
    <View style={styles.frameCardTextContainer}>
      <Text style={styles.frameCardTitle}>{catchItem.fish_name}</Text>
      <View style={styles.frameCardSubtitleContainer}>
        <Text style={styles.frameCardSubtitle}>
          {catchItem.weight}
        </Text>
      </View>
    </View>
  </View>
);

const CatchHistoryMap = ({ navigation }) => {
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const mapViewRef = useRef(null);
  const stateVal = useSelector(state => state.login);
  const userData = useSelector(state => state.catches);
  const catches = userData.items;
  const sharedCatches = userData && userData.shareItem;
  const [firstMarkerLatitude, setFirstMarkerLatitide] = useState('');
  const [firstMarkerLongitude, setFirstMarkerLongitude] = useState('');
  const [inProcess, setInProcess] = useState(false);
  const [userLocation, setUserLocation] = useState({
    latitude: null,
    longitude: null,
  });
  const [fromDate, setFromDate] = useState(() => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), 1);
  });
  const [toDate, setToDate] = useState(new Date());
  const formatDate = date => {
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${year}-${month}-${day}`;
  };
  const formattedFromDate = formatDate(fromDate);
  const formattedToDate = formatDate(toDate);
  const [showFromDatePicker, setShowFromDatePicker] = useState(false);
  const [showToDatePicker, setShowToDatePicker] = useState(false);
  if (Platform.OS === 'ios') {
    MapboxGL.setWellKnownTileServer('mapbox');
  } else {
    MapboxGL.setWellKnownTileServer('Mapbox');
  }
  MapboxGL.setAccessToken(
    'pk.eyJ1IjoiZXhhY3RpbmsiLCJhIjoiY2x3enpzejFpMGMzejJqc2RrNjR4ZWs4dCJ9.8Xuj0V6TUuh3T8Bzt7QIHw',
  );
  useEffect(() => {
    if (isFocused) {
      fetchCatch();
      dispatch(fetchShareJournal());
    }
  }, [isFocused]);

  const fetchCatch = async () => {
    setInProcess(true);
    const params = {
      start_date: formattedFromDate,
      end_date: formattedToDate,
      page: 1,
    };
    try {
      const resultAction = await dispatch(fetchAllCatches(params));
      if (fetchAllCatches.fulfilled.match(resultAction)) {
        const firstCatch =
          resultAction.payload.data && resultAction.payload.data.result[0];
        if (firstCatch) {
          setFirstMarkerLatitide(Number(firstCatch.current_latitude));
          setFirstMarkerLongitude(Number(firstCatch.current_longitude));
          setInProcess(false);
        }
      }
    } catch (error) {
      console.error('Failed to fetch catches:', error);
    } finally {
      setInProcess(false);
    }
  };
  
  return (
    <>
      <Appbar.Header
        style={[
          Styles.AppbarHeader,
          ProfileStyle.UserProfileBar,
          Styles.AppBarShadow,
        ]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{ backgroundColor: UiColor.SecondaryColor }}
          icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
        />
        <Appbar.Content
          titleStyle={Styles.NavTitle}
          title="Catch History Map"
        />
        <Appbar.Action animated={false} size={30} rippleColor="#00000008" />
      </Appbar.Header>
      <View style={{ flex: 1, marginBottom: 10 }}>
          <>
          <MapboxGL.MapView
              style={{ flex: 1 }}
              styleURL='mapbox://styles/exactink/clx1vdour003b01qs7fej67yk'
              ref={mapViewRef}
            >
              <MapboxGL.Camera
                zoomLevel={10}
                centerCoordinate={firstMarkerLongitude ? [
                  firstMarkerLongitude,
                  firstMarkerLatitude,
                ] : [-122.431297, 37.773972]}
              />
              {catches?.result?.map((catchItem, index) => {
                const longitude = Number(catchItem.current_longitude);
                const latitude = Number(catchItem.current_latitude);

                if (isNaN(longitude) || isNaN(latitude) || latitude < -90 || latitude > 90) {
                  console.error(`Invalid coordinates for marker ${index}:`, { latitude, longitude });
                  return null;
                }

                return (
                  <MapboxGL.PointAnnotation
                    key={index}
                    id={`marker-${index}`}
                    coordinate={[longitude, latitude]}
                    onSelected={() => {
                      console.log(`Marker ${index} selected`);
                    }}
                  >
                    <>
                      <Icon
                        color={UiColor.SecondaryColor}
                        name={'noun-fish'}
                        size={15}
                      />
                      <MapboxGL.Callout title={catchItem.fish_name} style={styles.callout}>
                        <Text style={styles.calloutText}>{`Fish: ${catchItem.fish_name}`}</Text>
                        <Text style={styles.calloutText}>{`Weight: ${catchItem.weight}`}</Text>
                      </MapboxGL.Callout>
                    </>
                  </MapboxGL.PointAnnotation>
                );
              })}
              {sharedCatches && sharedCatches?.map((sharedItem, index) => {
                if (!sharedItem.fish_catch) return null;
                const longitude = Number(sharedItem.fish_catch.current_longitude);
                const latitude = Number(sharedItem.fish_catch.current_latitude);

                if (isNaN(longitude) || isNaN(latitude) || latitude < -90 || latitude > 90) {
                  console.error(`Invalid coordinates for shared marker ${index}:`, { latitude, longitude });
                  return null;
                }

                return (
                  <MapboxGL.PointAnnotation
                    key={`shared-${index}`}
                    id={`shared-marker-${index}`}
                    coordinate={[longitude, latitude]}
                    onSelected={() => {
                      console.log(`Second marker ${index} selected`);
                    }}
                  >
                    <>
                      <Icon
                        color={'#FFFF00'}
                        name={'noun-fish'}
                        size={15}
                      />
                      <MapboxGL.Callout title={sharedItem.fish_catch.fish_name} style={[styles.callout, { marginBottom: Platform.OS === 'ios' ? 80 : 10,}]}>
                        <Text style={styles.calloutText}>{`By: ${sharedItem.from_id ? sharedItem.from_id.name : ''}`}</Text>
                        <Text style={styles.calloutText}>{`Fish: ${sharedItem.fish_catch.fish_name}`}</Text>
                        <Text style={styles.calloutText}>{`Weight: ${sharedItem.fish_catch.weight}`}</Text>
                      </MapboxGL.Callout>
                    </>
                  </MapboxGL.PointAnnotation>
                );
              })}

              {/* Ensure that the symbol layer for labels is added correctly */}
              <MapboxGL.SymbolLayer
                id="place-labels"
                sourceID="composite"
                sourceLayerID="place_label"
                style={{
                  textField: ['get', 'name'],
                  textFont: ['DIN Pro Medium', 'Arial Unicode MS Bold'],
                  textSize: 12,
                  textColor: 'white',
                }}
              />
            </MapboxGL.MapView>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={{
                position: 'absolute',
                marginHorizontal: 10,
                bottom: 230,
              }}>
              {catches?.result?.map((catchItem, index) => (
                <TouchableOpacity
                  key={index}
                  onPress={() =>
                    navigation.navigate('JournalCatches', {
                      catch_id: catchItem._id,
                      date: catchItem.date,
                      isJournalUser: true,
                    })
                  }>
                  <FrameCard key={index} catchItem={catchItem} />
                </TouchableOpacity>
              ))}
            </ScrollView>
          </>
        <View style={{paddingHorizontal: 15}}>
          <View style={{marginBottom: 8}}>
            <CustomDatePicker
              value={fromDate}
              onChange={setFromDate}
              show={showFromDatePicker}
              setShow={setShowFromDatePicker}
              placeholder="From Date"
            />
          </View>
          <View style={{marginBottom: 8}}>
            <CustomDatePicker
              value={toDate}
              onChange={setToDate}
              show={showToDatePicker}
              setShow={setShowToDatePicker}
              placeholder="To Date"
            />
          </View>
          <View style={styles.searchButtonContainer}>
            <TouchableOpacity
              style={styles.searchButton}
              onPress={() => fetchCatch()}>
              <Text style={{color: '#FFFFFF'}}>
                {inProcess ? (
                  <ActivityIndicator size={24} color="#fff" />
                ) : (
                  'Search'
                )}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  datePickerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 15,
    borderRadius: 12,
    borderColor: '#0A141B',
    borderWidth: 1,
    height: 50,
  },
  calendarIcon: {
    width: 24,
    height: 24,
    marginLeft: 12, // Adjust this as needed
  },
  datePickerText: {
    flex: 1,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0F0F18',
    paddingLeft: 12, // Adjust this as needed
  },
  frameCardContainer: {
    width: 181,
    height: 'auto',
    paddingVertical: 5,
    borderRadius: 10,
    flexDirection: 'row',
    padding: 5.74,
    backgroundColor: '#FFFFFF',
    marginRight: 10,
  },
  frameCardImage: {
    width: 70,
    height: 70,
    borderRadius: 10,
  },
  frameCardTextContainer: {
    marginLeft: 10,
  },
  frameCardTitle: {
    width: 150,
    height: 'auto',
    top: 10,
    color: '#100F4D',
    fontSize: 16,
    flexShrink: 1,
  },
  frameCardSubtitleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    top: 16,
  },
  frameCardSubtitle: {
    flexWrap: 'wrap',
    width: 170,
    color: '#100F4D',
    fontSize: 14,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  searchButtonContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 5,
  },
  searchButton: {
    width: '100%',
    height: 45,
    borderRadius: 12,
    backgroundColor: '#D2283D',
    justifyContent: 'center',
    alignItems: 'center',
  },
  callout: {
    backgroundColor: 'white',
    padding: 10,
    width: 190,
    marginBottom: Platform.OS === 'ios' ? 70 : 10,
  },
  calloutText: {
    fontSize: 16,
    color: 'black',
  },
});

export default CatchHistoryMap;
