import React, {useState, useEffect} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useDispatch, useSelector} from 'react-redux';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  KeyboardAvoidingView,
  TouchableWithoutFeedback,
  Platform,
  Keyboard,
  ImageBackground,
  StatusBar,
} from 'react-native';
import {
  Appbar,
  TextInput,
  HelperText,
  ActivityIndicator,
} from 'react-native-paper';
import CheckBox from '@react-native-community/checkbox';
import Toast from 'react-native-toast-message';
import {
  GlobalStyles,
  Icon,
  IconAsset,
  Styles,
  UiColor,
} from '../../../../theme/Index';
import {
  doLoginUserThunk,
  EmailOtpThunk,
  addFcmTokenNotification,
} from '../../../thunk';
import {tokenService} from '../../../services';
import {setLogin} from '../../../slices/login';
import {LoginStyle} from './LoginStyle';

const Login = ({navigation}) => {
  const dispatch = useDispatch();
  const stateVal = useSelector(state => state.login);
  const [formErrors, setFormErrors] = useState({});
  const [checked, setChecked] = useState(false);
  const [passwordVisible, setPasswordVisible] = useState(true);
  const [inProcess, setInProcess] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const hasErrors = () => {
    const errors = {};
    if (!formData.email || formData.email.length === 0) {
      errors.email = 'Email is required';
    } else if (formData.email.length && !formData.email.includes('@')) {
      errors.email = 'Invalid email';
    }
    if (!formData.password || formData.password.length === 0) {
      errors.password = 'Password is required';
    }
    setFormErrors(errors);
    return Object.keys(errors).length > 0;
  };

  useEffect(() => {
    const retrieveStoredCredentials = async () => {
      const storedEmail = await AsyncStorage.getItem('storedEmail');
      const storedPassword = await AsyncStorage.getItem('storedPassword');
      if (storedEmail && storedPassword) {
        setFormData({
          email: storedEmail,
          password: storedPassword,
        });
        setChecked(true);
      }
    };
    retrieveStoredCredentials();
  }, []);

  const doLogin = async () => {
    if (hasErrors()) {
      return;
    }
    setFormErrors({});
    setInProcess(true);
    if (checked) {
      await AsyncStorage.setItem('storedEmail', formData.email);
      await AsyncStorage.setItem('storedPassword', formData.password);
    } else {
      await AsyncStorage.removeItem('storedEmail');
      await AsyncStorage.removeItem('storedPassword');
    }
    const params = {
      email: formData.email,
      password: formData.password,
    };
    const resultAction = await dispatch(doLoginUserThunk(params));
    if (doLoginUserThunk.fulfilled.match(resultAction)) {
      const userMailVerify =
        resultAction.payload.data && resultAction.payload.data.user
          ? resultAction.payload.data.user
          : {};
      const isEmailVerified = userMailVerify.is_email_verified;
      const userId = userMailVerify._id;
      if (isEmailVerified === false) {
        Toast.show({
          topOffset: 45,
          visibilityTime: 4000,
          type: 'error',
          text1: 'Email is not verified, please verify your email.',
        });
        const paramsMail = {
          email: formData.email,
        };
        const resultAction = await dispatch(EmailOtpThunk(paramsMail));
        if (EmailOtpThunk.fulfilled.match(resultAction)) {
          const params = {
            email: formData.email,
            password: formData.password,
            comeFrom: 'LoginScreen',
          };
          navigation.navigate('SignUpSuccess', params);
          setInProcess(false);
        }
      }
      if (isEmailVerified !== false) {
        dispatch(setLogin(true));
        tokenService.setUser(resultAction.payload);
        setInProcess(false);
        const fcmtoken = await AsyncStorage.getItem('fcmtoken');
        const data = {
          user_id: userId,
          fcm_device_token: fcmtoken,
        };
        const tokenData = await dispatch(addFcmTokenNotification(data));
        console.log('tokenData', tokenData.payload);
      }
    } else {
      setInProcess(false);
    }
    setInProcess(false);
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={Styles.WhiteBg}>
      <StatusBar barStyle="light-content" />
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={LoginStyle.Container}>
          <View style={LoginStyle.LoginBg}>
            <ImageBackground
              source={IconAsset.Splash}
              resizeMode="cover"
              style={LoginStyle.BgImage}>
              <Image style={LoginStyle.Logo} source={IconAsset.SplashLogo} />
            </ImageBackground>
          </View>
          <View style={LoginStyle.LoginForm}>
            <Text style={LoginStyle.Title}>Login with Email</Text>
            <View style={LoginStyle.FormControl}>
              <TextInput
                label="Email"
                value={formData.email}
                style={[
                  LoginStyle.FormInput,
                  {
                    borderColor: formErrors.email
                      ? UiColor.SecondaryColor
                      : UiColor.GrayLight,
                  },
                ]}
                textColor={UiColor.PrimaryColor}
                theme={LoginStyle.TextInput}
                onChangeText={text => {
                  setFormErrors({...formErrors, email: ''});
                  setFormData({...formData, email: text});
                }}
                underlineStyle={{backgroundColor: 'transparent'}}
                autoCapitalize="none"
                keyboardType="email-address"
                left={
                  <TextInput.Icon
                    style={LoginStyle.RightBorder}
                    icon={() => (
                      <Icon
                        name="sms"
                        color={
                          formErrors.email
                            ? UiColor.SecondaryColor
                            : UiColor.GrayLight
                        }
                        size={20}
                      />
                    )}
                  />
                }
              />
              <HelperText
                type="error"
                style={Styles.ErrorMsg}
                visible={formErrors.email !== undefined}>
                {formErrors.email}
              </HelperText>
            </View>
            <View style={LoginStyle.FormControl}>
              <TextInput
                label="Password"
                value={formData.password}
                style={[
                  LoginStyle.FormInput,
                  {
                    borderColor: formErrors.password
                      ? UiColor.SecondaryColor
                      : UiColor.GrayLight,
                  },
                ]}
                textColor={UiColor.PrimaryColor}
                theme={LoginStyle.TextInput}
                onChangeText={text => {
                  setFormErrors({...formErrors, password: ''});
                  setFormData({...formData, password: text});
                }}
                underlineStyle={{backgroundColor: 'transparent'}}
                autoCapitalize="none"
                secureTextEntry={passwordVisible}
                right={
                  <TextInput.Icon
                    icon={() => (
                      <Icon
                        name={passwordVisible ? 'eye-slash' : 'eye'}
                        style={LoginStyle.TextInputIcon}
                        size={20}
                      />
                    )}
                    onPress={() => setPasswordVisible(!passwordVisible)}
                  />
                }
                left={
                  <TextInput.Icon
                    style={LoginStyle.RightBorder}
                    icon={() => (
                      <Icon
                        name="lock"
                        // style={LoginStyle.TextInputIcon}
                        color={
                          formErrors.password
                            ? UiColor.SecondaryColor
                            : UiColor.GrayLight
                        }
                        size={18}
                      />
                    )}
                  />
                }
              />
              <HelperText
                type="error"
                style={Styles.ErrorMsg}
                visible={formErrors.password !== undefined}>
                {formErrors.password}
              </HelperText>
            </View>
            <View style={LoginStyle.RememberHead}>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <CheckBox
                  tintColors={LoginStyle.CheckBoxColor}
                  onFillColor={UiColor.SecondaryColor}
                  onTintColor={UiColor.SecondaryColor}
                  onCheckColor={UiColor.White}
                  style={[LoginStyle.CheckBox]}
                  value={checked}
                  onValueChange={setChecked}
                  boxType="square"
                  lineWidth={2}
                />
                <Text style={LoginStyle.RememberText}>Remember Me</Text>
              </View>
              <View>
                <TouchableOpacity
                  onPress={() => navigation.navigate('ForgotPassword')}>
                  <Text style={LoginStyle.ForgotPass}>Forgot Password?</Text>
                </TouchableOpacity>
              </View>
            </View>
            <View>
              <TouchableOpacity style={LoginStyle.Btn} onPress={doLogin}>
                <Text style={LoginStyle.BtnText}>
                  {inProcess ? (
                    <ActivityIndicator
                      style={Styles.Loader}
                      size={24}
                      color="#fff"
                    />
                  ) : (
                    'Login'
                  )}
                </Text>
              </TouchableOpacity>
            </View>
            <View style={LoginStyle.SignUp}>
              <Text style={LoginStyle.SignUpText}>Don't have an account? </Text>
              <TouchableOpacity onPress={() => navigation.navigate('SignUp')}>
                <Text style={LoginStyle.SignUpTextLink}>Sign Up</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </KeyboardAvoidingView>
  );
};

export default Login;
