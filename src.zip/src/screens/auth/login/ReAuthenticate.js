import React, { useEffect, useRef } from 'react';
import { View, AppState } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ReAuthenticateThunk, fetchFriends, fetchFishTypes } from '../../../thunk';
import { NotificationListener, requestUserPermission } from '../../../utils/pushnotification_helper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { setOnlineStatus } from '../../../slices/login';
import firestore from '@react-native-firebase/firestore';

export const ReAuthenticate = ({ navigation }) => {
  const stateVal = useSelector(state => state.login);
  const isUserLoggedIn = useSelector(state => state.login.isLogin);
  const availableData = useSelector(state => state.login.first_name);
  const appState = useRef(AppState.currentState);
  const dispatch = useDispatch();

  const fetchFriendsData = async () => {
    const params = { user_id: stateVal.id };
    await dispatch(fetchFriends(params));
  };

  useEffect(() => {
    if (isUserLoggedIn && availableData === '') {
      try {
        dispatch(ReAuthenticateThunk());
      } catch (error) {
        console.error('Error in reauthenticate:', error);
      }
    }
    if (stateVal.id) {
      fetchFriendsData();
      fetchAndSaveFishData();
      NotificationListener(stateVal.id);
      requestUserPermission();
    }

    const handleAppStateChange = (nextAppState) => {
      if (appState.current.match(/inactive|background/) && nextAppState === 'active') {
        console.log('App has come to the foreground!');
        updateFirestoreStatus('Online');
      } else if (nextAppState.match(/inactive|background/)) {
        updateFirestoreStatus('Offline');
        console.log('App has gone to the background!');
        dispatch(setOnlineStatus(false));
      }
      appState.current = nextAppState;
    };

    const subscription = AppState.addEventListener('change', handleAppStateChange);

    return () => {
      if (subscription && subscription.remove) {
        subscription.remove();
      }
    };
  }, [isUserLoggedIn, availableData]);

  const saveFishDataToStorage = async (fishData) => {
    try {
      const jsonValue = JSON.stringify(fishData);
      await AsyncStorage.setItem('@fish_data', jsonValue);
      console.log("Fish data saved");
    } catch (e) {
      console.error('Error saving fish data to storage:', e);
    }
  };

  const fetchAndSaveFishData = async () => {
    try {
      const params = {
        search: '',
        page: 1,
        limit: 50,
      };
      const resultAction = await dispatch(fetchFishTypes(params));
      if (fetchFishTypes.fulfilled.match(resultAction)) {
        const data = resultAction.payload.data;
        const fishData = data.result.map(obj => ({
          fish_name: obj.fish_name,
          fish_length: obj.fish_length,
        }));
        await saveFishDataToStorage(fishData);
      }
    } catch (error) {
      console.error('Error fetching fish data:', error);
    }
  };

  const updateFirestoreStatus = async (status) => {
    if (stateVal.id) {
      const userStatusRef = firestore().collection('userStatus').doc(stateVal.id);
      await userStatusRef.set({
        status: status,
        user_id: stateVal.id,
        [status === 'Online' ? 'onlineTime' : 'offlineTime']: firestore.FieldValue.serverTimestamp(),
      }, { merge: true });
    }
  };

  useEffect(() => {
    return () => {
      // App is being closed
      console.log('App is being closed!');
      updateFirestoreStatus('Offline');
    };
  }, []);

  return <View />;
};

export default ReAuthenticate;
