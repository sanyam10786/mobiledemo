/* eslint-disable prettier/prettier */
import { StyleSheet, Platform } from 'react-native';
import { UiColor, Poppins, Inter, Dm } from '../../../../theme/Index';

export const LoginStyle = StyleSheet.create({

    LoginBg: {
        height: '45%',
    },
    LoginForm: {
        backgroundColor: UiColor.White,
        height: '55%',
        borderTopEndRadius: 40,
        borderTopStartRadius: 40,
        paddingHorizontal: 18,
        paddingVertical: 27,
    },
    Logo: {
        height: 100,
        objectFit: 'contain',
    },
    BgImage: {
        width: '100%',
        height: '106%',
        objectFit: 'cover',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        bottom: -10,
    },
    Container: {
        position: 'relative',
    },
    Title: {
        fontSize: 20,
        color: UiColor.PrimaryColor,
        textAlign: 'center',
        fontFamily: Dm.bold,
        marginBottom: 30,
    },

    FormControl: {
        marginBottom: 20,
    },

    FormInput: {
        color: UiColor.GrayLight,
        backgroundColor: '#fff',
        fontSize: 14,
        fontFamily: Dm.regular,
        width: '100%',
        marginBottom: 0,
        borderColor: UiColor.PrimaryColor,
        borderWidth: 1,
        borderRadius: 10,
        ...Platform.select({
            ios: {
                height: 62,
            },
        }),
    },

    TextInput: {
        colors: {
            primary: UiColor.GrayLight,
            underlineColor: 'transparent',
            text: UiColor.PrimaryColor,
            placeholder: UiColor.PrimaryColor,
            onSurfaceVariant: UiColor.GrayLight,
            fontFamily: Dm.regular,
        },
        roundness: 10,
    },
    CheckBox: {
        borderRadius: 10,
        width: 20,
        height: 20,
        marginRight: 6,
        ...Platform.select({
            android: {
                marginRight: 10,
            },
        }),
    },

    RememberHead: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
    },
    CheckBoxColor: {
        true: UiColor.SecondaryColor,
        false: UiColor.PrimaryColor,
    },
    ForgotPass: {
        fontSize: 14,
        fontFamily: Dm.regular,
        color: UiColor.PrimaryColor,
    },

    Btn: {
        width: '100%',
        backgroundColor: UiColor.SecondaryColor,
        textAlign: 'center',
        borderRadius: 8,
        textTransform: 'capitalize',
        marginTop: 30,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        ...Platform.select({
            ios: {
                height: 45,
            },
            android: {
                height: 45,
            },
        }),
    },

    BtnText: {
        fontFamily: Dm.bold,
        fontSize: 16,
        lineHeight: 22,
        color: UiColor.White,
        textAlign: 'center',
    },
    SignUp: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 30,
        // position: 'absolute',
        // bottom: 30,
        // left: 0,
        // right: 0,
    },
    SignUpText: {
        fontSize: 14,
        color: UiColor.GrayLight,
        fontFamily: Dm.medium,
    },
    SignUpTextLink: {
        fontSize: 14,
        color: UiColor.PrimaryColor,
        fontFamily: Dm.medium,
        textAlign: 'center',
    },
    TextInputIcon: {
        color: UiColor.PrimaryColor,
    },
    RightBorder: {
        borderRightColor: '#D9D9D9',
        borderRightWidth: 1,
        borderRadius: 0,
    },
    MsgBoxHead: {
        paddingTop: 91,
        textAlign: 'center',
        justifyContent: 'center',
        flexDirection: 'row',
        alignItems: 'center',
    },
    MsgBoxImg: {
        width: 192,
        height: 186,
        objectFit: 'contain',
    },
    OtpResend: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 22,
    },
    OtpResendText: {
        color: UiColor.Gray,
        fontSize: 18,
        fontFamily: Dm.medium,
        backgroundColor: 'transparent',
        paddingVertical: 0,
    },

    ForgotTitle: {
        fontSize: 20,
        fontFamily: Dm.semiBold,
        color: UiColor.PrimaryColor,
        marginBottom: 12,
        textAlign: 'center',
    },
    ForgotDisc: {
        fontSize: 14,
        fontFamily: Dm.regular,
        color: UiColor.Gray,
        marginBottom: 12,
        textAlign: 'center',
        marginBottom: 44,
    },
    ForgotTitleHead: {
        paddingTop: 55,
    },

    OtpInputHead: {
        width: '100%',
    },
    OtpInput: {
        width: '14%',
        borderWidth: 1,
        borderColor: 'red,',
        borderRadius: 8,
        borderBottomWidth: 1,
    },
    OtpDisc: {
        marginBottom: 36,
    },
    OtpDiscLink: {
        fontSize: 14,
        fontFamily: Dm.medium,
        color: UiColor.PrimaryColor,
        verticalAlign: 'bottom'
    },

    SignUpHead: {
        flexDirection: 'row',
        justifyContent: 'center',
        paddingBottom: 26,
        textAlign: 'center',
    },

    SignUpUser: {
        width: 120,
        height: 120,
        borderRadius: 100,
        backgroundColor: '#F7F6FF',
    },
    CameraImg: {
        position: 'absolute',
        bottom: 0,
        right: 0,
        backgroundColor: UiColor.PrimaryColor,
        borderRadius: 50,
        width: 45,
        height: 45,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    CameraIcon: {
        width: 25,
        height: 25,
        objectFit: 'contain',
    },

    LoginBannerHead: {
        alignItems: 'center',
    },


    LoginFromBody: {
        paddingTop: 86,
        backgroundColor: UiColor.White,
        width: '100%',
        height: '100%',
    },

    LoginTitle: {
        fontSize: 32,
        lineHeight: 44,
        color: UiColor.BaseColor,
        marginBottom: 20,
        fontFamily: Poppins.medium,
    },

    LoginDisc: {
        fontSize: 14,
        lineHeight: 20,
        color: UiColor.Black,
        marginBottom: 20,
        fontFamily: Poppins.regular,
    },

    FromIcons: {
        color: UiColor.BaseColor,
        fontSize: 18,
    },

    Signuplabel: {
        marginTop: 200,
        paddingLeft: 100,
        flexDirection: 'row',
        textAlign: 'center'

    },

    Form: {
        color: UiColor.Grey,
    },

    IconColor: {
        color: UiColor.BaseColor,
    },

    Remember: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 12,
    },

    RememberText: {
        fontSize: 14,
        fontFamily: Poppins.regular,
        color: UiColor.Gray,
    },
    FormLabel: {
        fontSize: 14,
        marginBottom: 2,
        fontFamily: Inter.regular,
        color: UiColor.PrimaryColor,
    }
});


