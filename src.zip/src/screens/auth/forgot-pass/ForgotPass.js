import { View, Text, TouchableOpacity, KeyboardAvoidingView, TouchableWithoutFeedback, Keyboard} from 'react-native';
import {TextInput, HelperText, Appbar, ActivityIndicator} from 'react-native-paper';
import {Icon, Styles, UiColor, GlobalStyles} from '../../../../theme/Index';
import {useDispatch, useSelector} from 'react-redux';
import {ForgotUserPassThunk} from '../../../thunk';
import React, {useState, useEffect} from 'react';
import {LoginStyle} from '../login/LoginStyle';
import { useFocusEffect } from '@react-navigation/native';
import { BackHandler } from 'react-native';

const ForgotPassword = ({navigation}) => {
  const stateVal = useSelector(state => state.forgotPass);
  const dispatch = useDispatch();
  const [formErrors, setFormErrors] = useState({});
  const [inProcess, setInProcess] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
  });

  const hasErrors = () => {
    const errors = {};
    if (!formData.email || formData.email.length === 0) {
      errors.email = 'Email is required';
    } else if (formData.email.length && !formData.email.includes('@')) {
      errors.email = 'Invalid email';
    }
    setFormErrors(errors);
    return Object.keys(errors).length > 0;
  };

  const ForgotPass = async () => {
    if (hasErrors()) {
      return;
    }
    setFormErrors({});
    setInProcess(true);
    const params = {
      email: formData.email,
    };
    const resultAction = await dispatch(ForgotUserPassThunk(params));
    if (ForgotUserPassThunk.fulfilled.match(resultAction)) {
      navigation.navigate('ForgotSuccess', params);
      setInProcess(false);
    } else {
      setInProcess(false);
    }
  };

  useFocusEffect(
    React.useCallback(() => {
      const backHandler = BackHandler.addEventListener(
        'hardwareBackPress',
        handleBackPress,
      );
      return () => {
        backHandler.remove();
      };
    }, []),
  );

  const handleBackPress = () => {
    navigation.goBack();
    return true;
  };
  const GoBackAction = React.memo(({navigation}) => (
    <Appbar.Action
      animated={false}
      size={20}
      rippleColor="#00000008"
      onPress={() => navigation.goBack()}
      style={{backgroundColor: UiColor.SecondaryColor}}
      icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
    />
  ));

  return (
    <View style={Styles.WhiteBg}>
      <Appbar.Header
        style={[
          Styles.AppbarHeader,
          Styles.AppBarShadow,
          {justifyContent: 'space-between'},
        ]}
      >
         <GoBackAction navigation={navigation} />
        <Appbar.Content titleStyle={Styles.NavTitle} title="Forgot Password" />
        <Appbar.Action />
      </Appbar.Header>
      <KeyboardAvoidingView>
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <View style={Styles.Container}>
            <View>
              <View style={LoginStyle.ForgotTitleHead}>
                {/* <Text style={LoginStyle.ForgotTitle}>Forgot Password</Text> */}
                <Text style={LoginStyle.ForgotDisc}>
                  Enter your registered email address. We will send you a
                  password reset instruction code.
                </Text>
              </View>
              <View style={[LoginStyle.FormControl, GlobalStyles.mb0]}>
                <TextInput
                  value={formData.email}
                  placeholder="Enter Registered Email"
                  onChangeText={text => setFormData({...formData, email: text})}
                  theme={LoginStyle.TextInput}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.email
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  placeholderTextColor={UiColor.GrayLight}
                  textColor={UiColor.PrimaryColor}
                  autoCapitalize="none"
                  keyboardType="email-address"
                  underlineStyle={{backgroundColor: 'transparent'}}
                  left={
                    <TextInput.Icon
                      style={LoginStyle.RightBorder}
                      color={UiColor.SecondaryColor}
                      icon={() => (
                        <Icon
                          name="sms"
                          color={
                            formErrors.email
                              ? UiColor.SecondaryColor
                              : UiColor.GrayLight
                          }
                          size={20}
                        />
                      )}
                    />
                  }
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.email !== undefined}>
                  {formErrors.email}
                </HelperText>
              </View>
              <TouchableOpacity
                disabled={inProcess}
                style={LoginStyle.Btn}
                onPress={ForgotPass}
                loading={inProcess}>
                <Text style={LoginStyle.BtnText}>
                  {inProcess ? (
                    <ActivityIndicator
                      style={Styles.Loader}
                      size={24}
                      color="#fff"
                    />
                  ) : (
                    'Send'
                  )}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    </View>
  );
};

export default ForgotPassword;
