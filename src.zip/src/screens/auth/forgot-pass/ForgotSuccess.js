import {View, Text, TouchableOpacity, KeyboardAvoidingView, TouchableWithoutFeedback, Platform, Keyboard, Image, ImageBackground} from 'react-native';
import {IconAsset, Icon, Styles, UiColor} from '../../../../theme/Index';
import {Appbar, ActivityIndicator, Button} from 'react-native-paper';
import {VerifyOtpThunk, ResendOtpThunk} from '../../../thunk';
import {ProfileStyle} from '../../user-profile/ProfileStyle';
import React, {useState, useEffect, useRef} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import OTPTextView from 'react-native-otp-textinput';
import {useRoute} from '@react-navigation/native';
import {LoginStyle} from '../login/LoginStyle';

const ForgotSuccess = ({navigation}) => {
  const route = useRoute();
  const dispatch = useDispatch();
  const registerEmail = route.params.email;
  const [inProcess, setInProcess] = useState(false);
  const [formErrors, setFormErrors] = useState({});
  const [otpValue, setOtpValue] = useState('');
  const otpRef = useRef(otpValue);

  const handleOtpChange = text => {
    if (text.length === 6) {
      otpRef.current = text;
      setOtpValue(text);
      handleSubmit();
    } else {
    }
  };

  const handleSubmit = async () => {
    setFormErrors({});
    setInProcess(true);
    const params = {
      otp: otpRef.current,
    };
    const resultAction = await dispatch(VerifyOtpThunk(params));
    if (VerifyOtpThunk.fulfilled.match(resultAction)) {
      navigation.navigate('ResetPassword', registerEmail);
      setInProcess(false);
    } else {
      setInProcess(false);
      otpRef.current = '';
      setOtpValue('');
    }
  };

  const ResendOtp = async () => {
    setInProcess(true);
    const params = {
      email: registerEmail,
    };
    const resultAction = await dispatch(ResendOtpThunk(params));
    if (ResendOtpThunk.fulfilled.match(resultAction)) {
      setInProcess(false);
    } else {
      setInProcess(false);
    }
  };

  return (
    <View>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <View style={LoginStyle.Container}>
            <View style={LoginStyle.LoginBg}>
              <Appbar.Header
                style={[Styles.AppbarHeader, ProfileStyle.UserProfileBar]}>
                <Appbar.Action
                  animated={false}
                  size={20}
                  rippleColor="#00000008"
                  onPress={() => navigation.goBack()}
                  style={{backgroundColor: UiColor.SecondaryColor}}
                  icon={() => (
                    <Icon name="back" size={18} style={Styles.BackWhite} />
                  )}
                />
              </Appbar.Header>
              <ImageBackground
                source={IconAsset.Splash}
                resizeMode="cover"
                style={LoginStyle.BgImage}>
                <Image style={LoginStyle.Logo} source={IconAsset.SplashLogo} />
              </ImageBackground>
            </View>
            <View style={[LoginStyle.LoginForm]}>
              <View>
                <View style={LoginStyle.ForgotTitleHead}>
                  <Text style={LoginStyle.ForgotTitle}>Forgot Password</Text>
                  <Text style={[LoginStyle.ForgotDisc, LoginStyle.OtpDisc]}>
                    We sent the verification code on your registered email
                    <Text style={LoginStyle.OtpDiscLink}> {registerEmail}</Text>
                  </Text>
                </View>
                <View>
                  <View>
                    <OTPTextView
                      key={otpValue}
                      handleTextChange={text => handleOtpChange(text)}
                      inputCount="6"
                      containerStyle={LoginStyle.OtpInputHead}
                      textInputStyle={LoginStyle.OtpInput}
                      offTintColor="#0F0F18"
                      tintColor={UiColor.PrimaryColor}
                    />
                  </View>
                  <View style={LoginStyle.OtpResend}>
                    <Button
                      type="text"
                      textColor={UiColor.Gray}
                      rippleColor="#d2283d2e"
                      style={LoginStyle.OtpResendText}
                      onPress={ResendOtp}>
                      Resend
                    </Button>
                  </View>
                  <TouchableOpacity
                    disabled={inProcess}
                    loading={inProcess}
                    style={LoginStyle.Btn}
                    onPress={handleSubmit}>
                    <Text style={LoginStyle.BtnText}>
                      {inProcess ? (
                        <ActivityIndicator
                          style={Styles.Loader}
                          size={24}
                          color="#fff"
                        />
                      ) : (
                        'Verify'
                      )}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    </View>
  );
};

export default ForgotSuccess;
