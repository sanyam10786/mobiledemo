import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  KeyboardAvoidingView,
  TouchableWithoutFeedback,
  Platform,
  Keyboard,
  StatusBar,
  ScrollView,
  BackHandler,
} from 'react-native';
import {
  TextInput,
  HelperText,
  Appbar,
  ActivityIndicator,
} from 'react-native-paper';
import { SignUpUserThunk } from '../../../thunk';
import { setLogin } from '../../../slices/login';
import { LoginStyle } from '../login/LoginStyle';
import { Styles, Icon, IconAsset, UiColor, GlobalStyles } from '../../../../theme/Index';
import { useFocusEffect } from '@react-navigation/native';

const SignUp = ({ navigation }) => {
  const dispatch = useDispatch();
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(true);
  const [confirmPassVisible, setConfirmPassVisible] = useState(true);
  const [inProcess, setInProcess] = useState(false);
  const [formErrors, setFormErrors] = useState({});
  const [formData, setFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    password: '',
  });

  const hasErrors = () => {
    const errors = {};
    if (formData.first_name.length === 0) {
      errors.first_name = 'First name is required';
    }
    if (formData.last_name.length === 0) {
      errors.last_name = 'Last name is required';
    }
    if (formData.email.length === 0) {
      errors.email = 'Email is required';
    } else if (formData.email.length && !formData.email.includes('@')) {
      errors.email = 'Invalid email';
    }
    if (formData.password.length === 0) {
      errors.password = 'Password is required';
    } else if (formData.password.length < 8) {
      errors.password = 'Password must be at least 8 characters';
    }
    if (confirmPassword.length === 0) {
      errors.confirmPassword = 'Confirm password is required';
    } else if (confirmPassword.length < 8){
      errors.confirmPassword = 'Password must be at least 8 characters';
    }
    if (formData.password !== confirmPassword) {
      errors.confirmPassword = 'Password not match';
    }

    setFormErrors(errors);
    return Object.keys(errors).length > 0;
  };

  const Register = async () => {
    if (hasErrors()) {
      return;
    }
    setFormErrors({});
    setInProcess(true);
    const signUpResultAction = await dispatch(SignUpUserThunk(formData));
    if (SignUpUserThunk.fulfilled.match(signUpResultAction)) {
      dispatch(setLogin(false));
      setInProcess(false);
      navigation.navigate('SignUpSuccess', formData);
    } else {
      setInProcess(false);
    }
  };

  
  useFocusEffect(
    React.useCallback(() => {
      const backHandler = BackHandler.addEventListener(
        'hardwareBackPress',
        handleBackPress,
      );
      return () => {
        backHandler.remove();
      };
    }, []),
  );

  const handleBackPress = () => {
    navigation.goBack();
    return true;
  };

  return (
    <View>
      <Appbar.Header style={[Styles.AppbarHeader, Styles.AppBarShadow]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{ backgroundColor: UiColor.SecondaryColor }}
          icon={() => (
            <Icon name="back" size={18} style={Styles.BackWhite} />
          )}
        />
        <Appbar.Content titleStyle={[LoginStyle.Title, { marginBottom: 0 }]} title="Sign Up" />
        <Appbar.Action />
      </Appbar.Header>
      <ScrollView>
        <KeyboardAvoidingView>
          <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
            <View style={[Styles.Container]}>
              <View style={{ marginTop: 30 }}>
                <View style={LoginStyle.FormControl}>
                  <TextInput
                    label="First Name"
                    value={formData.first_name}
                    onChangeText={text => {
                      setFormErrors({ ...formErrors, first_name: '' }),
                        setFormData({ ...formData, first_name: text });
                    }}
                    theme={LoginStyle.TextInput}
                    style={[LoginStyle.FormInput,
                    {
                      borderColor: formErrors.first_name
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight
                    },
                    ]}
                    textColor={UiColor.PrimaryColor}
                    underlineStyle={{ backgroundColor: 'transparent' }}
                    autoCapitalize="none"
                    left={
                      <TextInput.Icon
                        style={LoginStyle.RightBorder}
                        icon={() => (
                          <Icon
                            name="user"
                            color={
                              formErrors.first_name
                                ? UiColor.SecondaryColor
                                : UiColor.GrayLight
                            }
                            size={18}
                          />
                        )}
                      />
                    }
                  />
                  <HelperText
                    type="error"
                    style={Styles.ErrorMsg}
                    visible={formErrors.first_name !== undefined}>
                    {formErrors.first_name}
                  </HelperText>
                </View>
                <View style={LoginStyle.FormControl}>
                  <TextInput
                    label="Last Name"
                    value={formData.last_name}
                    onChangeText={text => {
                      setFormErrors({ ...formErrors, last_name: '' }),
                        setFormData({ ...formData, last_name: text });
                    }}
                    theme={LoginStyle.TextInput}
                    style={[LoginStyle.FormInput, {
                      borderColor: formErrors.last_name
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight
                    },]}
                    textColor={UiColor.PrimaryColor}
                    underlineStyle={{ backgroundColor: 'transparent' }}
                    autoCapitalize="none"
                    left={
                      <TextInput.Icon
                        style={LoginStyle.RightBorder}
                        icon={() => (
                          <Icon
                            name="multi-user"
                            color={
                              formErrors.last_name
                                ? UiColor.SecondaryColor
                                : UiColor.GrayLight
                            }
                            size={18}
                          />
                        )}
                      />
                    }
                  />
                  <HelperText
                    type="error"
                    style={Styles.ErrorMsg}
                    visible={formErrors.last_name !== undefined}>
                    {formErrors.last_name}
                  </HelperText>
                </View>
                <View style={LoginStyle.FormControl}>
                  <TextInput
                    label="Email"
                    value={formData.email}
                    onChangeText={text => {
                      setFormErrors({ ...formErrors, email: '' }),
                        setFormData({ ...formData, email: text });
                    }}
                    theme={LoginStyle.TextInput}
                    style={[LoginStyle.FormInput, {
                      borderColor: formErrors.email
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight
                    },]}
                    textColor={UiColor.PrimaryColor}
                    underlineStyle={{ backgroundColor: 'transparent' }}
                    autoCapitalize="none"
                    left={
                      <TextInput.Icon
                        style={LoginStyle.RightBorder}
                        icon={() => (
                          <Icon
                            name="sms"
                            color={
                              formErrors.email
                                ? UiColor.SecondaryColor
                                : UiColor.GrayLight
                            }
                            size={18}
                          />
                        )}
                      />
                    }
                    keyboardType="email-address"
                  />
                  <HelperText
                    type="error"
                    style={Styles.ErrorMsg}
                    visible={formErrors.email !== undefined}>
                    {formErrors.email}
                  </HelperText>
                </View>
                <View style={LoginStyle.FormControl}>
                  <TextInput
                    label="Password"
                    onChangeText={text => {
                      setFormErrors({ ...formErrors, password: '' }),
                        setFormData({ ...formData, password: text });
                    }}
                    theme={LoginStyle.TextInput}
                    style={[LoginStyle.FormInput, {
                      borderColor: formErrors.password
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight
                    },]}
                    textColor={UiColor.PrimaryColor}
                    underlineColor="transparent"
                    underlineStyle={{ backgroundColor: 'transparent' }}
                    secureTextEntry={passwordVisible}
                    right={
                      <TextInput.Icon
                        icon={() => (
                          <Icon
                            name={passwordVisible ? 'eye-slash' : 'eye'}
                            style={LoginStyle.TextInputIcon}
                            size={20}
                          />
                        )}
                        onPress={() => setPasswordVisible(!passwordVisible)}
                      />
                    }
                    left={
                      <TextInput.Icon
                        style={LoginStyle.RightBorder}
                        icon={() => (
                          <Icon
                            name="lock"
                            color={
                              formErrors.password
                                ? UiColor.SecondaryColor
                                : UiColor.GrayLight
                            }
                            size={18}
                          />
                        )}
                      />
                    }
                  />
                  <HelperText
                    type="error"
                    style={Styles.ErrorMsg}
                    visible={formErrors.password !== undefined}>
                    {formErrors.password}
                  </HelperText>
                </View>
                <View style={[LoginStyle.FormControl, GlobalStyles.mb0]}>
                  <TextInput
                    label="Confirm Password"
                    value={confirmPassword}
                    onChangeText={text => {
                      setFormErrors({ ...formErrors, confirmPassword: '' }),
                        setConfirmPassword(text);
                    }}
                    theme={LoginStyle.TextInput}
                    underlineStyle={{ backgroundColor: 'transparent' }}
                    style={[LoginStyle.FormInput, {
                      borderColor: formErrors.confirmPassword
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight
                    },]}
                    textColor={UiColor.PrimaryColor}
                    autoCapitalize="none"
                    secureTextEntry={confirmPassVisible}
                    right={
                      <TextInput.Icon
                        icon={() => (
                          <Icon
                            name={confirmPassVisible ? 'eye-slash' : 'eye'}
                            style={LoginStyle.TextInputIcon}
                            size={20}
                          />
                        )}
                        onPress={() => setConfirmPassVisible(!confirmPassVisible)}
                      />
                    }
                    left={
                      <TextInput.Icon
                        style={LoginStyle.RightBorder}
                        icon={() => (
                          <Icon
                            name="lock"
                            color={
                              formErrors.confirmPassword
                                ? UiColor.SecondaryColor
                                : UiColor.GrayLight
                            }
                            size={18}
                          />
                        )}
                      />
                    }
                  />
                  {formErrors.confirmPassword && (
                    <HelperText type="error" style={Styles.ErrorMsg}>
                      {formErrors.confirmPassword}
                    </HelperText>
                  )}
                </View>
              </View>
              <TouchableOpacity
                disabled={inProcess}
                style={LoginStyle.Btn}
                onPress={Register}
                loading={inProcess}>
                <Text style={LoginStyle.BtnText}>
                  {inProcess ? (
                    <ActivityIndicator
                      style={Styles.Loader}
                      size={24}
                      color="#fff"
                    />
                  ) : (
                    'Sign Up'
                  )}
                </Text>
              </TouchableOpacity>
              <View style={[LoginStyle.SignUp]}>
                <Text style={LoginStyle.SignUpText}>
                  Already have an account?{' '}
                </Text>
                <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                  <Text style={LoginStyle.SignUpTextLink}>Login</Text>
                </TouchableOpacity>
              </View>
            </View>
          </TouchableWithoutFeedback>
        </KeyboardAvoidingView>
      </ScrollView>
    </View>
  );
};

export default SignUp;
