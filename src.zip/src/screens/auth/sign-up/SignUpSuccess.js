import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { View,Text, TouchableOpacity, KeyboardAvoidingView,TouchableWithoutFeedback, Platform, Keyboard, Image, ImageBackground} from 'react-native';
import {Appbar, ActivityIndicator, Button} from 'react-native-paper';
import { VerifyEmailThunk, ResendOtpThunk } from '../../../thunk';
import { useRoute } from '@react-navigation/native';
import { IconAsset, Icon, Styles, UiColor} from '../../../../theme/Index';
import { tokenService } from '../../../services';
import { ProfileStyle } from '../../user-profile/ProfileStyle';
import { setLogin } from '../../../slices/login';
import OTPTextView from 'react-native-otp-textinput';
import { LoginStyle } from '../login/LoginStyle';

const SignUpSuccess = ({ navigation }) => {
  const route = useRoute();
  const dispatch = useDispatch();
  const userData = route.params;
  const [verifyText, setVerifyText] = useState('For register user we sent the verification code on your registered email')
  const [formErrors, setFormErrors] = useState({});
  const [inProcess, setInProcess] = useState(false);
  const [otpValue, setOtpValue] = useState('');
  const otpRef = useRef(otpValue);

  useEffect(() => {
    if (userData.comeFrom === 'LoginScreen') {
      setVerifyText('For register user you are not verify your email, we sent the verification code on your registered email')
    }
  })
  const handleOtpChange = text => {
    if (text.length === 6) {
      otpRef.current = text; 
      setOtpValue(text); 
      handleSubmit();
    } else {
      otpRef.current = ''; 
    }
  };

  const handleSubmit = async () => {
    setFormErrors({});
    setInProcess(true);
    const params = {
      otp: otpRef.current,
    };
    const resultAction = await dispatch(VerifyEmailThunk(params));
    if (VerifyEmailThunk.fulfilled.match(resultAction)) {
      tokenService.setUser(resultAction.payload);
      dispatch(setLogin(true));
      setInProcess(false);
    } else {
      setInProcess(false);
    }
  };
  const ResendOtp = async () => {
    setInProcess(true);
    otpRef.current = '';
    setOtpValue('');
    const params = {
      email: userData.email,
    };
    const resultAction = await dispatch(ResendOtpThunk(params));
    if (ResendOtpThunk.fulfilled.match(resultAction)) {
      setInProcess(false);
    } else {
      setInProcess(false);
      console.log('ResendOtpThunk.payload', ResendOtpThunk.payload);
      if (
        ResendOtpThunk.payload.errors &&
        Object.keys(ResendOtpThunk.payload.errors).length > 0
      ) {
        setFormErrors(ResendOtpThunk.payload.errors);
      }
    }
  };

  return (
    <View>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <View style={LoginStyle.Container}>
            <View style={LoginStyle.LoginBg}>
              <Appbar.Header style={[Styles.AppbarHeader, ProfileStyle.UserProfileBar]}>
              <Appbar.Action
                animated={false}
                size={20}
                rippleColor="#00000008"
                onPress={() => navigation.goBack()}
                style={{ backgroundColor: UiColor.SecondaryColor }}
                icon={() => (
                  <Icon name="back" size={18} style={Styles.BackWhite} />
                )}
              />
                </Appbar.Header>
              <ImageBackground
                source={IconAsset.Splash}
                resizeMode="cover"
                style={LoginStyle.BgImage}>
                <Image style={LoginStyle.Logo} source={IconAsset.SplashLogo} />
              </ImageBackground>
            </View>
            <View style={[LoginStyle.LoginForm,]}>
              <View>
                <View style={LoginStyle.ForgotTitleHead}>
                  <Text style={LoginStyle.ForgotTitle}>Email Verification</Text>
                  <Text style={[LoginStyle.ForgotDisc, LoginStyle.OtpDisc]}>
                    {verifyText}
                    <Text style={LoginStyle.OtpDiscLink}> {userData.email}</Text>
                  </Text>
                </View>
                <View>
                  <View>
                    <OTPTextView
                      key={otpValue}
                      handleTextChange={text => handleOtpChange(text)}
                      inputCount="6"
                      containerStyle={LoginStyle.OtpInputHead}
                      textInputStyle={LoginStyle.OtpInput}
                      offTintColor="#0F0F18"
                      tintColor={UiColor.PrimaryColor}
                    />
                  </View>
                  <View style={LoginStyle.OtpResend}>
                    <Button
                      type="text"
                      textColor={UiColor.Gray}
                      rippleColor="#d2283d2e"
                      style={LoginStyle.OtpResendText}
                      onPress={ResendOtp}>
                      Resend
                    </Button>
                  </View>
                  <TouchableOpacity
                    disabled={inProcess}
                    loading={inProcess}
                    style={LoginStyle.Btn}
                    onPress={handleSubmit}>
                    <Text style={LoginStyle.BtnText}>
                      {inProcess ? (
                        <ActivityIndicator
                          style={Styles.Loader}
                          size={24}
                          color="#fff"
                        />
                      ) : (
                        'Verify'
                      )}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    </View>
  );
};

export default SignUpSuccess;
