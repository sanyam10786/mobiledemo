import React, {useState, useEffect} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import { View, Text, TouchableOpacity, KeyboardAvoidingView, TouchableWithoutFeedback, Platform, Keyboard} from 'react-native';
import { TextInput, HelperText, Appbar,ActivityIndicator } from 'react-native-paper';
import {ResetPasswordThunk} from '../../../thunk';
import {useRoute} from '@react-navigation/native';
import {IconAsset, Icon, Styles, UiColor, GlobalStyles} from '../../../../theme/Index';
import {LoginStyle} from '../login/LoginStyle';

const ResetPassword = ({navigation}) => {
  const stateVal = useSelector(state => state.forgotPass);
  const route = useRoute();
  const recentEmail = route.params;
  const dispatch = useDispatch();

  const [passwordVisible, setPasswordVisible] = useState(true);
  const [confirmPassVisible, setConfirmPassVisible] = useState(true);
  const [formErrors, setFormErrors] = useState({});
  const [inProcess, setInProcess] = useState(false);

  const [formData, setFormData] = useState({
    password: '',
    confirmpassword: '',
    email: recentEmail,
  });
  const hasErrors = () => {
    const errors = {};
    if (formData.password.length === 0) {
      errors.password = 'Password is required';
    } else if (formData.password.length < 8) {
      errors.password = 'Password must be at least 8 characters';
    }
    if (formData.confirmpassword.length === 0) {
      errors.confirmpassword = 'Confirm password is required';
    } else if (formData.confirmpassword.length < 8) {
      errors.confirmpassword = 'Password must be at least 8 characters';
    }
    if (formData.password !== formData.confirmpassword) {
      errors.confirmpassword = 'Password not match';
    }
    setFormErrors(errors);
    return Object.keys(errors).length > 0;
  };

  const ResetPass = async () => {
    if (hasErrors()) {
      return;
    }
    setFormErrors({});
    setInProcess(true);
    const params = {
      email: recentEmail,
      password: formData.password,
    };
    const resultAction = await dispatch(ResetPasswordThunk(params));
    if (ResetPasswordThunk.fulfilled.match(resultAction)) {
      navigation.navigate('Login');
    } else {
      setInProcess(false);
    }
  };

  return (
    <View style={Styles.WhiteBg}>
      <Appbar.Header style={[Styles.AppbarHeader,]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{ backgroundColor: UiColor.SecondaryColor }}
          icon={() => (
            <Icon name="back" size={18} style={Styles.BackWhite} />
          )}
        />
        {/* <Appbar.Content titleStyle={[LoginStyle.Title, { marginBottom: 0 }]} title="Sign Up" /> */}
        <Appbar.Action />
      </Appbar.Header>
      <KeyboardAvoidingView>
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <View style={Styles.Container}>
            <View style={[LoginStyle.LoginFromBody, {paddingTop: 20,}]}>
              <View style={LoginStyle.ForgotTitleHead}>
                <Text style={LoginStyle.ForgotTitle}>Reset Password</Text>
                <Text style={LoginStyle.ForgotDisc}>
                  Create your secured 8 character password
                </Text>
              </View>
              <View style={LoginStyle.FormControl}>
                <TextInput
                  label="New Password"
                  value={formData.password}
                  onChangeText={text => {
                    setFormErrors({...formErrors, password: ''}),
                      setFormData({...formData, password: text});
                  }}
                  theme={LoginStyle.TextInput}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  textColor={UiColor.PrimaryColor}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.password
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  autoCapitalize="none"
                  secureTextEntry={passwordVisible}
                  right={
                    <TextInput.Icon
                      icon={() => (
                        <Icon
                          name={passwordVisible ? 'eye-slash' : 'eye'}
                          style={LoginStyle.TextInputIcon}
                          size={20}
                        />
                      )}
                      onPress={() => setPasswordVisible(!passwordVisible)}
                    />
                  }
                  left={
                    <TextInput.Icon
                      style={LoginStyle.RightBorder}
                      icon={() => (
                        <Icon
                          name="lock"
                          color={
                            formErrors.password
                              ? UiColor.SecondaryColor
                              : UiColor.GrayLight
                          }
                          size={18}
                        />
                      )}
                    />
                  }
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.password !== undefined}>
                  {formErrors.password}
                </HelperText>
              </View>
              <View style={[LoginStyle.FormControl, GlobalStyles.mb0]}>
                <TextInput
                  label="Confirm Password"
                  value={formData.confirmpassword}
                  onChangeText={text => {
                    setFormErrors({...formErrors, confirmpassword: ''}),
                      setFormData({...formData, confirmpassword: text});
                  }}
                  theme={LoginStyle.TextInput}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.confirmpassword
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  autoCapitalize="none"
                  secureTextEntry={confirmPassVisible}
                  right={
                    <TextInput.Icon
                      icon={() => (
                        <Icon
                          name={confirmPassVisible ? 'eye-slash' : 'eye'}
                          style={LoginStyle.TextInputIcon}
                          size={20}
                        />
                      )}
                      onPress={() => setConfirmPassVisible(!confirmPassVisible)}
                    />
                  }
                  left={
                    <TextInput.Icon
                      style={LoginStyle.RightBorder}
                      icon={() => (
                        <Icon
                          name="lock"
                          color={
                            formErrors.confirmpassword
                              ? UiColor.SecondaryColor
                              : UiColor.GrayLight
                          }
                          size={18}
                        />
                      )}
                    />
                  }
                />
                {formErrors.confirmpassword && (
                  <HelperText type="error" style={Styles.ErrorMsg}>
                    {formErrors.confirmpassword}
                  </HelperText>
                )}
              </View>
              <TouchableOpacity
                disabled={inProcess}
                loading={inProcess}
                style={LoginStyle.Btn}
                onPress={ResetPass}>
                <Text style={LoginStyle.BtnText}>
                  {inProcess ? (
                    <ActivityIndicator
                      style={Styles.Loader}
                      size={24}
                      color="#fff"
                    />
                  ) : (
                    'Reset'
                  )}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    </View>
  );
};

export default ResetPassword;
