/* eslint-disable prettier/prettier */
import { StyleSheet, Platform } from 'react-native';
import { UiColor, Dm } from '../../../../theme/Index';

export const RemoveStyle = StyleSheet.create({
  DeleteBtn: {
    backgroundColor: UiColor.SecondaryColor,
    paddingHorizontal: 40,
    color: UiColor.White,
    paddingVertical: 10,
    borderRadius: Platform.OS === 'ios' ? 10 : 10,
    fontSize: 16,
    fontFamily: Dm.bold,
    textAlign: 'center',
  },
  RemoveBtn: {
    backgroundColor: UiColor.Gray,
    paddingHorizontal: 40,
    color: UiColor.White,
    paddingVertical: 10,
    borderRadius: 10,
    fontSize: 16,
    fontFamily: Dm.bold,
    marginTop: 10,
  },
  DoneBtnText: {
    color: UiColor.White,
    fontSize: 14,
    fontFamily: Dm.bold,
  },
  DeleteText: {
    marginTop: 20,
    paddingHorizontal: 20,
    lineHeight: 20,
    fontSize: 16,
    color: '#536471',
    fontFamily: Dm.medium,
    textAlign: 'center'
  },
  PopUpTitle: {
    fontSize: 24,
    fontFamily: Dm.bold,
    marginTop: 5,
    marginBottom: 20,
  },
});


