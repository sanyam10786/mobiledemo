import {Appbar, Avatar, ActivityIndicator, HelperText, TextInput} from 'react-native-paper';
import {Styles, UiColor, IconAsset, Icon, Dm, GlobalStyles} from '../../../../theme/Index';
import {removeUserAccount, EmailOtpThunk, VerifyOtpThunk} from '../../../thunk';
import {useIsFocused, useNavigation, useRoute} from '@react-navigation/native';
import React, {useState, useEffect, useRef, useContext} from 'react';
import {View, Text, TouchableOpacity, Modal} from 'react-native';
import {FriendsStyle} from '../../add-friends/FriendsStyle';
import { NetworkContext } from '../../../NetworkContext';
import firestore from '@react-native-firebase/firestore';
import {useDispatch, useSelector} from 'react-redux';
import OTPTextView from 'react-native-otp-textinput';
import {resetState} from '../../../slices/user';
import {LoginStyle} from '../login/LoginStyle';
import {tokenService} from '../../../services';
import {setLogin} from '../../../slices/login';
import {RemoveStyle} from './RemoveStyle';

const RemoveAccount = ({navigation}) => {
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const stateVal = useSelector(state => state.login);
  const stateValue = useSelector(state => state.user);
  const [inProcess, setInProcess] = useState(false);
  const isConnected = useContext(NetworkContext);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isEmailModalVisible, setIsEmailModalVisible] = useState(false);
  const [isOtpModalVisible, setIsOtpModalVisible] = useState(false);
  const [otpValue, setOtpValue] = useState('');
  const otpRef = useRef(otpValue);
  const [formErrors, setFormErrors] = useState({});
  const [formData, setFormData] = useState({
    email: '',
  });

  const hasErrors = () => {
    const errors = {};
    if (!formData.email || formData.email.length === 0) {
      errors.email = 'Email is required';
    } else if (formData.email.length && !formData.email.includes('@')) {
      errors.email = 'Invalid email';
    } else if (formData.email !== stateVal.email) {
      errors.email = 'Please use correct user email';
    }
    setFormErrors(errors);
    return Object.keys(errors).length > 0;
  };

  useEffect(() => {
    if (isFocused) {
    }
    return () => {
      dispatch(resetState({}));
      if (!isFocused) {
      }
    };
  }, [isFocused]);

  const onLogout = async () => {
    const refresh_token = await tokenService.getLocalRefreshToken();
    const params = {
      refresh_token: refresh_token,
    };
    await tokenService.setUser(null);
    await tokenService.removeUser('USER_DATA');
    dispatch(setLogin(false));
    setTimeout(function () {
      navigation.navigate('Login');
    }, 1000);
  };

  const DeleteUser = async () => {
    setInProcess(true);
    fetchChatlistsDataDelete();
    const params = {
      user_id: stateVal.id,
    };
    const resultAction = await dispatch(removeUserAccount(params));
    if (removeUserAccount.fulfilled.match(resultAction)) {
      setInProcess(false);
      onLogout();
    }
    setIsModalVisible(false);
  };

  const verifyEmail = async () => {
    if (hasErrors()) {
      return;
    }
    setInProcess(true);
    setFormErrors({});
    const resultAction = await dispatch(EmailOtpThunk(formData));
    if (EmailOtpThunk.fulfilled.match(resultAction)) {
      setInProcess(false);
      setIsEmailModalVisible(false);
      setIsOtpModalVisible(true);
      setFormData('');
    } else {
    }
  };

  const handleOtpChange = text => {
    if (text.length === 6) {
      otpRef.current = text;
      setOtpValue(text);
      handleSubmit();
    } else {
    }
  };

  const handleSubmit = async () => {
    setFormErrors({});
    setInProcess(true);
    const params = {
      otp: otpRef.current,
    };
    const resultAction = await dispatch(VerifyOtpThunk(params));
    if (VerifyOtpThunk.fulfilled.match(resultAction)) {
      setIsOtpModalVisible(false);
      setIsModalVisible(true);
      setInProcess(false);
    } else {
      setInProcess(false);
      otpRef.current = '';
      setOtpValue('');
    }
  };

  const toggleModal = () => {
    setIsModalVisible(!isModalVisible);
  };

  const fetchChatlistsDataDelete = async () => {
    const loginUserId = stateVal.id;
    try {
      const chatlistsSnapshot = await firestore().collection('chatlists').get();
      const deletePromises = [];
      chatlistsSnapshot.forEach(async doc => {
        const chatListId = doc.id;
        const batch = firestore().batch();
        const chatDocSnapshot = await firestore()
          .collection('chatlists')
          .doc(chatListId)
          .get();
        if (chatDocSnapshot.exists) {
          const chatData = chatDocSnapshot.data();
          const senderId = chatData.senderId;
          const receiverId = chatData.receiverId;
          if (senderId === loginUserId || receiverId === loginUserId) {
            const realSenderId = chatData.senderId;
            const realReceiverId = chatData.receiverId;
            const chatRoomId = chatData.chatRoomId;
            deletePromises.push(
              firestore().collection('chatlists').doc(realSenderId).delete(),
            );
            deletePromises.push(
              firestore().collection('chatlists').doc(realReceiverId).delete(),
            );
            const docRef = firestore().collection('chats').doc(chatRoomId);
            batch.delete(docRef);
            await batch.commit();
          }
        } else {
          console.log('No chat document found for chatlist:', chatListId);
        }
      });
      await Promise.all(deletePromises);
      console.log('Chatlists and chats deleted successfully');
    } catch (error) {
      console.error('Error fetching chatlists data:', error);
    }
  };

  return (
    <>
      <View style={{flex: 1}}>
        <Appbar.Header style={[Styles.AppbarHeader, Styles.AppBarShadow,]}>
          <Appbar.Action
            animated={false}
            size={20}
            rippleColor="#00000008"
            onPress={() => navigation.goBack()}
            style={{backgroundColor: UiColor.SecondaryColor}}
            icon={() => (
              <Icon name="back" size={18} style={Styles.BackWhite} />
            )}
          />
          <Appbar.Content
            titleStyle={Styles.NavTitle}
            title="Remove Account"
          />
          <Appbar.Action />
        </Appbar.Header>
        {!isConnected ?
          <View style={[GlobalStyles.NoData, {marginTop: 80}]}>
            <Icon name="no-connection" size={50} />
            <Text style={[GlobalStyles.NoDataMsg, {fontFamily: Dm.semiBold}]}>
              No Internet Connection
            </Text>
          </View> 
          :
            <View style={[FriendsStyle.Container, {paddingHorizontal: 16}]}>
              <TouchableOpacity
                onPress={() => setIsEmailModalVisible(true)}
                style={FriendsStyle.Card}>
                <View style={FriendsStyle.CardLeft}>
                  <Avatar.Image
                    style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                    size={51}
                    source={
                      stateVal && stateVal.profile_image_path
                        ? {uri: stateVal.profile_image_path}
                        : IconAsset.BlankUser
                    }
                  />
                  <View>
                    <Text style={FriendsStyle.CardTitle}>Delete Account</Text>
                  </View>
                </View>
              </TouchableOpacity>
            </View>
          }
        <Modal
          animationType="slide"
          transparent={true}
          visible={isModalVisible}>
          <View
            style={{
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
              backgroundColor: 'rgba(0, 0, 0, 0.5)',
            }}>
            <View
              style={{
                backgroundColor: UiColor.White,
                padding: 20,
                width: 300,
                height: 'auto',
                borderRadius: 10,
                alignItems: 'center',
              }}>
              <Text style={[FriendsStyle.CardTitle, RemoveStyle.PopUpTitle]}>
                Delete Account
              </Text>
              <Icon name="trash" color={UiColor.SecondaryColor} size={50} />
              <Text style={RemoveStyle.DeleteText}>
                Once you delete this account, there's no getting it back. Are
                you sure you want to delete your account ?
              </Text>
              <View
                style={{
                  marginTop: 25,
                }}>
                <TouchableOpacity onPress={() => DeleteUser()}>
                  <View style={[RemoveStyle.DeleteBtn, {alignItems: 'center'}]}>
                    <Text
                      style={{
                        color: UiColor.White,
                        fontSize: 16,
                        fontFamily: Dm.bold,
                        textAlign: 'center',
                      }}>
                      {inProcess ? (
                        <ActivityIndicator
                          // style={{}}
                          size={24}
                          color="#fff"
                        />
                      ) : (
                        'Yes, Delete Account'
                      )}
                    </Text>
                  </View>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => {
                    setIsModalVisible(false);
                  }}>
                  <View
                    style={[
                      RemoveStyle.DeleteBtn,
                      {marginTop: 10, backgroundColor: UiColor.Gray},
                    ]}>
                    <Text
                      style={{
                        color: UiColor.White,
                        fontSize: 16,
                        fontFamily: Dm.bold,
                        textAlign: 'center',
                      }}>
                      No, Keep It
                    </Text>
                  </View>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
        <Modal
          animationType="slide"
          transparent={true}
          visible={isEmailModalVisible}>
          <View
            style={{
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
              backgroundColor: 'rgba(0, 0, 0, 0.5)',
            }}>
            <View
              style={{
                backgroundColor: UiColor.White,
                padding: 20,
                width: 350,
                height: 'auto',
                borderRadius: 10,
                alignItems: 'center',
              }}>
              <Text style={[FriendsStyle.CardTitle, RemoveStyle.PopUpTitle]}>
                Verify User
              </Text>
              <View>
                <TextInput
                  value={formData.email}
                  placeholder="Enter Registered Email"
                  onChangeText={text => setFormData({...formData, email: text})}
                  theme={LoginStyle.TextInput}
                  style={[
                    LoginStyle.FormInput,
                    {
                      width: 300,
                      borderColor: formErrors.email
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  placeholderTextColor={UiColor.GrayLight}
                  textColor={UiColor.PrimaryColor}
                  autoCapitalize="none"
                  keyboardType="email-address"
                  underlineStyle={{backgroundColor: 'transparent'}}
                  left={
                    <TextInput.Icon
                      style={LoginStyle.RightBorder}
                      color={UiColor.SecondaryColor}
                      icon={() => (
                        <Icon
                          name="sms"
                          color={
                            formErrors.email
                              ? UiColor.SecondaryColor
                              : UiColor.GrayLight
                          }
                          size={20}
                        />
                      )}
                    />
                  }
                />
                <HelperText
                  type="error"
                  style={Styles.ErrorMsg}
                  visible={formErrors.email !== undefined}>
                  {formErrors.email}
                </HelperText>
              </View>
              <View
                style={{
                  marginTop: 25,
                }}>
                <TouchableOpacity
                  style={[RemoveStyle.DeleteBtn,{
                    alignItems: 'center'}]}
                  onPress={() => {
                    verifyEmail();
                  }}>
                    <Text
                      style={[RemoveStyle.DoneBtnText, {fontSize: 16,}]}>
                      {inProcess ? (
                        <ActivityIndicator size={22} color={UiColor.White} />
                      ) : (
                        'Verify'
                      )}
                    </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => {
                    setIsEmailModalVisible(false);
                  }}>
                  <View
                    style={[
                      RemoveStyle.DeleteBtn,
                      {marginTop: 10, backgroundColor: UiColor.Gray},
                    ]}>
                    <Text
                      style={{
                        color: UiColor.White,
                        fontSize: 16,
                        fontFamily: Dm.bold,
                        textAlign: 'center',
                      }}>
                      Close
                    </Text>
                  </View>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
        <Modal
          animationType="slide"
          transparent={true}
          visible={isOtpModalVisible}>
          <View
            style={{
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
              backgroundColor: 'rgba(0, 0, 0, 0.5)',
            }}>
            <View
              style={{
                backgroundColor: UiColor.White,
                padding: 20,
                width: 350,
                height: 'auto',
                borderRadius: 10,
                alignItems: 'center',
              }}>
              <Text style={RemoveStyle.DeleteText}>
                We sent the verification code on your registered email
              </Text>
              <OTPTextView
                key={otpValue}
                handleTextChange={text => handleOtpChange(text)}
                inputCount="6"
                containerStyle={LoginStyle.OtpInputHead}
                textInputStyle={LoginStyle.OtpInput}
                offTintColor="#0F0F18"
                tintColor={UiColor.PrimaryColor}
              />
              <View
                style={{
                  marginTop: 25,
                }}>
                <TouchableOpacity
                  style={[RemoveStyle.DeleteBtn,{
                    alignItems: 'center'}]}
                  onPress={() => {
                    handleSubmit();
                  }}>
                    <Text
                      style={[RemoveStyle.DoneBtnText, {fontSize: 16,}]}>
                      {inProcess ? (
                        <ActivityIndicator size={22} color={UiColor.White} />
                      ) : (
                        'Verify'
                      )}
                    </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => {
                    setIsOtpModalVisible(false);
                  }}>
                  <View
                    style={[
                      RemoveStyle.DeleteBtn,
                      {marginTop: 10, backgroundColor: UiColor.Gray},
                    ]}>
                    <Text
                      style={{
                        color: UiColor.White,
                        fontSize: 16,
                        fontFamily: Dm.bold,
                        textAlign: 'center',
                      }}>
                      Close
                    </Text>
                  </View>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      </View>
    </>
  );
};

export default RemoveAccount;
