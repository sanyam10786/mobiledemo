/* eslint-disable prettier/prettier */
import { View, Image, ImageBackground } from 'react-native';
import React, { useState, useEffect } from 'react';
import { Styles, IconAsset } from '../../../../theme/Index';
import { SplashStyle } from './SplashStyle';
import { setLogin } from '../../../slices/login';
import { useIsFocused } from '@react-navigation/native';
import tokenService from '../../../services/tokenservice';
import { useDispatch } from 'react-redux';

const Splash = ({ navigation }) => {
  const [isLogin, setisLogin] = useState(false);
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  useEffect(() => {
    if (isFocused) {
      fetchUser();
      async function setApp() {
        const userData = await tokenService.getUser();
        const token = await tokenService.getLocalAccessToken()
        setTimeout(() => {
          if (userData) {
            navigation.navigate('DrawerNav');
          } else {
            navigation.navigate('Login');
          }
        }, 5000);
      }
      setApp();
    }
  }, [isFocused]);

  const fetchUser = async () => {
    try {
      const userData = await tokenService.getUser();
      setisLogin(Object.keys(userData).length > 0 ? true : false);
      if (Object.keys(userData).length > 0) {
        dispatch(setLogin(true));
      }
    } catch (error) {
      // console.log('Fetch user error', error);
      // await tokenService.setUser(null);
      // await tokenService.removeUser('USER_DATA');
      // dispatch(setLogin(false));
      setTimeout(function () {
        navigation.navigate('Login');
      }, 5000);
    }
  };

  return (
    <View style={[SplashStyle.SplashContainer]}>
      <ImageBackground source={IconAsset.SplashGIF} resizeMode="cover" style={SplashStyle.BgImage}>
      </ImageBackground>
    </View>
  );
};

export default Splash;
