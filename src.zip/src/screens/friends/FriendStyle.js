/* eslint-disable prettier/prettier */
import { StyleSheet, Platform } from 'react-native';
import { UiColor, Dm } from '../../../theme/Index';


export const FriendStyle = StyleSheet.create({

    FriendListHead: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginHorizontal: -9,
    },

    FriendList: {
        width: "25%",
        paddingHorizontal: 9,
        marginBottom: 22,
        alignItems: 'center',
    },
    FriendText: {
        textAlign: 'center',
        marginTop: 5,
        fontSize: 12,
        color: UiColor.PrimaryColor,
        fontFamily: Dm.regular,
    },
    AddBtn: {
        width: 72,
        height: 72,
        backgroundColor: UiColor.PrimaryColor,
        borderRadius: 72,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    unreadCount: {
        fontWeight: 'bold',
        marginStart: -20,
        color: 'red',
        fontSize: 15,
    },
    acceptRequest: {
        flex: 1,
        flexDirection: 'row',
        position: 'absolute',
        top: 10,
        right: 5,
    },
    HeaderVisible: {
        color: 'black',
        backgroundColor: 'black',
        bottom: 55,
        width: 500,
        height: 80,
        position: 'absolute'
    },
});


