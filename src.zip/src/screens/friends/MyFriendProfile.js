import { View, Text, TouchableOpacity, ScrollView, Image, ImageBackground, Alert, Modal } from 'react-native';
import { Styles, GlobalStyles, UiColor, IconAsset, Icon } from '../../../theme/Index';
import { useIsFocused, useNavigation, useRoute } from '@react-navigation/native';
import { fetchUserData, fetchUserPosts, removeMyFriend } from '../../thunk';
import { Appbar, Avatar, ActivityIndicator } from 'react-native-paper';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import { ProfileStyle } from '../user-profile/ProfileStyle';
import React, { useState, useEffect, useRef } from 'react';
import firestore from '@react-native-firebase/firestore';
import { useDispatch, useSelector } from 'react-redux';
import RBSheet from 'react-native-raw-bottom-sheet';
import PTRView from 'react-native-pull-to-refresh';
import ImageView from 'react-native-image-viewing';
import { resetState } from '../../slices/user';
import { FriendStyle } from './FriendStyle';
import UserPosts from '../user-profile/UserPosts';

const MyFriendProfile = ({ navigation }) => {
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const route = useRoute();
  const refSheet = useRef({});
  const freindId = route.params;
  const stateVal= useSelector(state => state.login);
  const userData = useSelector(state => state.user);
  const stateValue = useSelector(state => state.posts);
  const posts = stateValue?.items;
  const user = userData.details;
  const [isLoad, setIsLoad] = useState(false);
  const ProfileImages = [user && user.profile_image && user.profile_image.path ? { uri: user && user.profile_image && user.profile_image.path } : IconAsset.BlankUser];
  const [isVisible, setIsVisible] = useState(false);
  const [deleteParams, setDeleteParams] = useState({
    story_id: '',
    comment_id: '',
    isComment: false,
  });
  const [isData, setIsData] = useState(false);

  const handleRefresh = () => {
    const params = {
      id: freindId,
    };
    dispatch(fetchUserData(params));
  };

  useEffect(() => {
    if (isFocused && freindId) {
      try {
        const params = {
          id: freindId,
        };
        dispatch(fetchUserData(params));
        setIsData(true);
      } catch (error) {
        console.error('Error in refreshData:', error);
      }
    }
    fetchAllPosts();
    return () => {
      dispatch(resetState({}));
      if (!isFocused) {
      }
    };
  }, [isFocused, freindId]);

  const fetchAllPosts = async () => {
    setIsLoad(true);
    const params = {
      user_id: freindId,
    };
    try {
      const resultAction = await dispatch(fetchUserPosts(params));
    } catch (error) {
      setIsLoad(false);
      console.error('Error in fetchAllPosts:', error);
    }
    setIsLoad(false);
  };

  const viewImage = () => {
    setIsVisible(true);
  };


  const deleteItem = async params => {
    const user_id = params;
    refSheet.current[user_id]?.close();
    try {
      const resultAction = await dispatch(removeMyFriend(user_id));
      fetchChatlistsDataDelete();
      fetchAllPosts();
      navigation.navigate('Friends');
    } catch (error) {
      console.error('Error in deleteItem:', error);
    }
  };

  const handleDeletePress = params => {
    refSheet.current.close();
    setDeleteParams(params);
    Alert.alert(
      'Remove Friend',
      'Are you sure you want to remove this friend?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'Remove',
          onPress: () => deleteItem(params.freind_id),
          style: 'destructive',
        },
      ],
    );
  };
  const fetchChatlistsDataDelete = async () => {
    const loginUserId = stateVal.id;
    try {
      const chatlistsSnapshot = await firestore().collection('chatlists').get();
      const deletePromises = [];
      chatlistsSnapshot.forEach(async doc => {
        const chatListId = doc.id;
        const batch = firestore().batch();
        const chatDocSnapshot = await firestore()
          .collection('chatlists')
          .doc(chatListId)
          .get();
        if (chatDocSnapshot.exists) {
          const chatData = chatDocSnapshot.data();
          const senderId = chatData.senderId;
          const receiverId = chatData.receiverId;
          if (senderId === loginUserId || receiverId === loginUserId) {
            const realSenderId = chatData.senderId;
            const realReceiverId = chatData.receiverId;
            const chatRoomId = chatData.chatRoomId;
            deletePromises.push(
              firestore().collection('chatlists').doc(realSenderId).delete(),
            );
            deletePromises.push(
              firestore().collection('chatlists').doc(realReceiverId).delete(),
            );
            const docRef = firestore().collection('chats').doc(chatRoomId);
            batch.delete(docRef);
            await batch.commit();
          }
        } else {
          console.log('No chat document found for chatlist:', chatListId);
        }
      });
      await Promise.all(deletePromises);
      console.log('Chatlists and chats deleted successfully');
    } catch (error) {
      console.error('Error fetching chatlists data:', error);
    }
  };

  const handleMessage = () => {
    refSheet.current.close();
    setTimeout(goToNextScreen, 600);
  };
  
  const goToNextScreen = () => {
    setTimeout(() => {
      navigation.navigate('Chat', {
        receiverId: user.id,
        Name: user.first_name + ' ' + user.last_name,
        userProfile: user?.profile_image?.path,
      });
    }, 100);
  };

  const params = {
    user_id: user.id,
    name: user.first_name + ' ' + user.last_name,
    friendsCount: user.friend_count,
  };

  return (
    <>
      {/* {user.first_name && user.id === freindId ? ( */}
      <>
        <Appbar.Header
          style={[Styles.AppbarHeader, ProfileStyle.UserProfileBar]}>
          {isVisible && <View style={FriendStyle.HeaderVisible}>
            <Text></Text>
          </View>}
          <Appbar.Action
            animated={false}
            size={20}
            rippleColor="#00000008"
            onPress={() => navigation.goBack()}
            style={{ backgroundColor: UiColor.SecondaryColor }}
            icon={() => (
              <Icon name="back" size={18} style={Styles.BackWhite} />
            )}
          />
          <Appbar.Action
            animated={false}
            size={30}
            rippleColor="#00000008"
            icon={() => (
              <Icon
                name="more"
                style={[Styles.Backbtn, Styles.More]}
                onPress={() => {
                  refSheet.current.open();
                }}
              />
            )}
          />
        </Appbar.Header>
        <RBSheet
          ref={refSheet}
          closeOnDragDown={true}
          closeOnPressMask={true}
          openDuration={800}
          height={250}
          customStyles={{
            wrapper: {
              backgroundColor: '#00000024',
            },
            draggableIcon: {
              backgroundColor: '#E3E3E3',
            },
            container: {
              borderTopLeftRadius: 30,
              borderTopRightRadius: 30,
            },
          }}>
          <View style={Styles.PostCardEdit}>
            <TouchableOpacity
              onPress={() => {
                handleDeletePress({
                  freind_id: freindId,
                });
              }}
              style={[Styles.PostActionBtn, {maxWidth: 200}]}>
              {/* <Icon name="trash" style={Styles.PostActionIcon} size={20} /> */}
              <Text style={[Styles.PostActionText]}>Remove Friend</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[Styles.PostActionBtn,  {marginTop: 10}]}
              onPress={handleMessage}>
              {/* <Icon name="msg" style={Styles.PostActionIcon} size={20} /> */}
              <Text style={[Styles.PostActionText]}>Message</Text>
            </TouchableOpacity>
          </View>
        </RBSheet>
        <>
          {Object.keys(user).length === 0 ? (
            <SkeletonPlaceholder>
              <SkeletonPlaceholder.Item height={200} width="100%" />
              <SkeletonPlaceholder.Item
                position='absolute'
                top={140}
                left={10}
                width={135}
                height={135}
                borderRadius={67.5}
                alignSelf="center"
              />
              <SkeletonPlaceholder.Item paddingTop={100}>
                <SkeletonPlaceholder.Item height={30} width={200} borderRadius={4} marginLeft={20} />
                <SkeletonPlaceholder.Item height={30} width={150} borderRadius={4} marginLeft={20} marginTop={6} />
              </SkeletonPlaceholder.Item>
              <SkeletonPlaceholder.Item flexDirection="row" justifyContent="space-between" padding={20}>
                <SkeletonPlaceholder.Item height={40} width={80} borderRadius={4} />
                <SkeletonPlaceholder.Item height={40} width={80} borderRadius={4} />
                <SkeletonPlaceholder.Item height={40} width={120} borderRadius={4} />
              </SkeletonPlaceholder.Item>
              <View style={ProfileStyle.ProfileImgList}>
                {Array.from({ length: 9 }).map((_, index) => (
                  <View style={ProfileStyle.ProfileImgHead} key={index}>
                    <View style={ProfileStyle.ProfileImg} />
                  </View>
                ))}
              </View>
            </SkeletonPlaceholder>
          ) : (
            <>
              <ImageBackground
                source={
                  user.cover_image && user.cover_image.path
                    ? { uri: user.cover_image.path }
                    : IconAsset.Splash
                }
                resizeMode="cover"
                style={ProfileStyle.UserProfileBg}>
                <View style={Styles.BannerOverlay}></View>
              </ImageBackground>
              <TouchableOpacity
                onPress={viewImage}
                style={{ marginTop: 40, width: 135, height: 135 }}>
                {user.profile_image && user.profile_image.path ? (
                  <Avatar.Image
                    style={[ProfileStyle.ProfileAvatar, GlobalStyles.mb0, {backgroundColor: UiColor.ImageLoad}]}
                    size={113}
                    source={{
                      uri: user.profile_image.path,
                    }}
                  />
                ) : (
                  <Avatar.Image
                    style={[ProfileStyle.ProfileAvatar, GlobalStyles.mb0, {backgroundColor: UiColor.ImageLoad}]}
                    size={113}
                    source={IconAsset.BlankUser}
                  />
                )}
              </TouchableOpacity>
              <Modal
                visible={isVisible}
                transparent={true}
                animationType="fade"
                onRequestClose={() => setIsVisible(false)}>
                <ImageView
                  images={ProfileImages}
                  visible={isVisible}
                  onRequestClose={() => setIsVisible(false)}
                />
              </Modal>
              {/* <ScrollView showsVerticalScrollIndicator={false} style={{ marginBottom: 260 }}>
                
                 <View style={{width: '100%', height: 0.8, backgroundColor: UiColor.Gray, marginTop: 15, opacity: 0.2  }}></View>
                <View style={[ProfileStyle.ProfileImgList, { marginBottom: 40 }]}>
                </View>
              </ScrollView> */}
                 <UserPosts navigation={navigation} friendId ={freindId} user={user} />
            </>
          )}
        </>
      </>
      {/* ) : (
        <ActivityIndicator
          animating={true}
          size={32}
          color={UiColor.BaseColor}
          style={{ marginTop: 100 }}
        />
      )} */}
    </>
  );
};
const absoluteFillObject = {
  position: 'absolute',
  left: 0,
  right: 0,
  top: 0,
  bottom: 0,
};

export default MyFriendProfile;
