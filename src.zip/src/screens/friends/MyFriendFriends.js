import {View, Text, TouchableOpacity, FlatList, SafeAreaView, Platform} from 'react-native';
import {Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm} from '../../../theme/Index';
import {Appbar, Searchbar, Avatar, ActivityIndicator} from 'react-native-paper';
import {useIsFocused, useNavigation, useRoute} from '@react-navigation/native';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import React, {useState, useEffect, useContext} from 'react';
import {resetState, setRefreshing} from '../../slices/user';
import {fetchMyFriends, removeMyFriend} from '../../thunk';
import {FriendsStyle} from '../add-friends/FriendsStyle';
import { NetworkContext } from '../../NetworkContext';
import {useDispatch, useSelector} from 'react-redux';

const MyFriendFriends = ({navigation}) => {
  const dispatch = useDispatch();
  const loginUser = useSelector(state => state.login);
  const allFriends = useSelector(state => state.friends);
  const isConnected = useContext(NetworkContext);
  const route = useRoute();
  const freindId = route.params;
  const isFocused = useIsFocused();
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [currentPage, setCurrentPage] = React.useState(1);
  const [shouldFetchNextPage, setShouldFetchNextPage] = useState(true);
  const [search, setSearch] = useState('');
  const [searchedFriends, setSearchedFriends] = useState([]);
  const [myFriendData, setMyFriendData] = useState([]);
  const [params, setParamData] = useState({
    search: search,
    user_id: freindId.user_id,
    page: 1,
    limit: 10,
  });

  useEffect(() => {
    if (isFocused) {
      const params = {
        page: currentPage,
        user_id: freindId.user_id,
        limit: 10,
        search: '',
      };
      fetchFriends(currentPage, params);
      fetchMyFriendsData();
    }
  }, [isFocused, params]);

  const handleOnSearchChange = text => {
    setSearch(text);
    params.search = text;
    params.user_id = freindId.user_id;
    params.page = 1;
    setIsSearching(true);
    fetchFriends(currentPage, params).then(() => {
      setIsSearching(false);
    });
  };

  const fetchFriends = async (page, params) => {
    setIsLoadingMore(true);
    try {
      if ('search' in params && params.search.trim() === '') {
        delete params.search;
      }
      const resultAction = await dispatch(fetchMyFriends(params));
      if (fetchMyFriends.fulfilled.match(resultAction)) {
        const newData = resultAction.payload.data.friends;
        if (newData.length < params.limit) {
          setShouldFetchNextPage(false);
        } else {
          setShouldFetchNextPage(true);
        }
        if (params.page === 1) {
          setSearchedFriends(newData);
        } else {
          setSearchedFriends(prevData => {
            const uniqueFilteredData = newData.filter(
              item => !prevData.map(prevItem => prevItem.id).includes(item.id),
            );
            return [...prevData, ...uniqueFilteredData];
          });
        }
      }
      setIsLoadingMore(false);
    } catch (error) {
      setIsLoadingMore(false);
      console.error('Error in fetchFriends:', error);
    }
  };

  const handleRefresh = () => {
    dispatch(setRefreshing({}));
    params.page = 1;
    fetchFriends(currentPage, params);
  };

  const fetchMyFriendsData = async () => {
    try {
      const params = {
        user_id: loginUser.id,
        page: 1,
        limit: 30,
      };
      let allFriends = [];
      while (true) {
        const resultAction = await dispatch(fetchMyFriends(params));
        if (fetchMyFriends.fulfilled.match(resultAction)) {
          const newData = resultAction.payload.data.friends;
          allFriends = allFriends.concat(newData);
          if (newData.length < params.limit) {
            break;
          }
          params.page++;
        } else {
          break;
        }
      }
      setMyFriendData(allFriends);
    } catch (error) {
      console.error('Error in fetchFriends:', error);
    }
  };

  const handleLoadMore = () => {
    if (!isLoadingMore && shouldFetchNextPage) {
      setIsLoadingMore(true);
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      const params = {
        page: nextPage,
        user_id: freindId.user_id,
        limit: 10,
        search: '',
      };
      fetchFriends(nextPage, params).then(() => setIsLoadingMore(false));
    }
  };

  const navigateToProfile = async text => {
    setCurrentPage(1);
    const item_id = text;
    if (item_id === loginUser.id) {
      navigation.navigate('UserProfile', (isProfile = true));
    } else {
      const hasFriend = myFriendData.some(item => item.id === item_id);
      if (hasFriend) {
        navigation.navigate('MyFriendProfile', item_id);
      } else {
        navigation.navigate('FriendProfile', item_id);
      }
    }
  };

  const ListItem = (item, index) => {
    const friendsData = item.friends;
    const userProfile = item.profile_image && item.profile_image.path;
    return (
      <View style={FriendsStyle.Card}>
        <TouchableOpacity onPress={() => navigateToProfile(item.id)}>
          <View style={FriendsStyle.CardLeft}>
            {userProfile ? (
              <Avatar.Image
                style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                size={51}
                source={{
                  uri: item.profile_image.path,
                }}
              />
            ) : (
              <Avatar.Image
                style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                size={51}
                source={IconAsset.BlankUser}
              />
            )}
            <View>
              <Text style={FriendsStyle.CardTitle}>
                {item.first_name + ' ' + item.last_name}
              </Text>
              <Text style={FriendsStyle.CardDisc}>{item.email}</Text>
            </View>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={{flex: 1}}>
      <View style={[Styles.AppBarShadow]}>
        <Appbar.Header style={[Styles.AppbarHeader, Styles.SubHeader]}>
          <Appbar.Action
            animated={false}
            size={20}
            rippleColor="#00000008"
            onPress={() => navigation.goBack()}
            style={{backgroundColor: UiColor.SecondaryColor}}
            icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
          />
          {freindId.name ? (
            <Appbar.Content
              titleStyle={Styles.NavTitle}
              title={freindId.name}
            />
          ) : (
            <Appbar.Content
              titleStyle={Styles.NavTitle}
              title={freindId.name}
            />
          )}
          <Appbar.Action />
        </Appbar.Header>
        <View style={Styles.SearchHead}>
          <Searchbar
            placeholder="Search..."
            value={search}
            theme={Styles.SearchInputTheme}
            style={[Styles.SearchInput]}
            onChangeText={text => handleOnSearchChange(text)}
            inputStyle={[Styles.SearchInputStyle]}
            placeholderTextColor={UiColor.PrimaryColor}
            iconColor={UiColor.PrimaryColor}
            icon={() => (
              <Icon name="search" size={24} color={UiColor.PrimaryColor} />
            )}
            clearIcon={() =>
              search.length > 0 ? (
                <Icon color={UiColor.PrimaryColor} name="cross" size={18} />
              ) : (
                ''
              )
            }
          />
        </View>
      </View>
      <View style={[FriendsStyle.Container, {backgroundColor: 'transparent'}]}>
        <SafeAreaView
          style={[
            FriendsStyle.FullCardArea,
            {marginBottom: Platform.OS === 'ios' ? 165 : 230,},
          ]}>
            <Text style={[FriendsStyle.CardTitle, {marginTop: 0, marginBottom: 15, marginLeft: 5, fontSize: 16, fontFamily: Dm.semiBold}]}>{freindId.friendsCount} {freindId.friendsCount === 1 ? 'Friend' : 'Friends'}</Text>
            {!isConnected && searchedFriends && searchedFriends.length === 0 ?
            <View style={[GlobalStyles.NoData, {marginTop: 80}]}>
              <Icon name="no-connection" size={50} />
              <Text style={[GlobalStyles.NoDataMsg, {fontFamily: Dm.semiBold}]}>
                No Internet Connection
              </Text>
            </View> 
            :
            <>
              {Object.keys(searchedFriends).length === 0 && isLoadingMore ? (
                <SkeletonPlaceholder>
                {Array.from({ length: 10 }).map((_, index) => (
                  <View style={[FriendsStyle.Card, {shadowOpacity: 0,
                    shadowRadius: 0,}]} key={index}>
                    <SkeletonPlaceholder.Item height={50} width="100%">
                      <View style={FriendsStyle.CardLeft}>
                        <SkeletonPlaceholder.Item
                          width={51}
                          height={51}
                          borderRadius={51}
                        />
                        <View>
                          <SkeletonPlaceholder.Item
                            height={20}
                            width={120}
                            marginLeft={10}
                          />
                          <SkeletonPlaceholder.Item
                            height={20}
                            width={180}
                            marginLeft={10}
                            marginTop={8}
                          />
                        </View>
                      </View>
                    </SkeletonPlaceholder.Item>
                  </View>
                ))}
              </SkeletonPlaceholder>
                ) : (
                <FlatList
                  data={searchedFriends}
                  onEndReachedThreshold={0.1}
                  onEndReached={handleLoadMore}
                  showsVerticalScrollIndicator={false}
                  keyExtractor={(item, index) => index.toString()}
                  renderItem={({item, index}) => ListItem(item, index)}
                  refreshing={allFriends.refreshing}
                  onRefresh={handleRefresh}
                />
              )}
              {!isSearching &&
                !isLoadingMore &&
                searchedFriends &&
                searchedFriends?.length === 0 && (
                  <View style={GlobalStyles.NoData}>
                    <Text style={GlobalStyles.NoDataMsg}>No Friends Found</Text>
                  </View>
              )}
            </>
          }
        </SafeAreaView>
      </View>
    </View>
  );
};
export default MyFriendFriends;
