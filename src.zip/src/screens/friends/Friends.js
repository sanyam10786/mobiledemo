import { Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm } from '../../../theme/Index';
import { View, Text, TouchableOpacity, ScrollView, Image, Platform } from 'react-native';
import { fetchMyFriends, fetchFriends, removeFriends, acceptFriends } from '../../thunk';
import { Appbar, Avatar, IconButton, ActivityIndicator } from 'react-native-paper';
import { useIsFocused, useNavigation, useRoute } from '@react-navigation/native';
import SegmentedControlTab from 'react-native-segmented-control-tab';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import { resetState, setRefreshing } from '../../slices/friends';
import React, { useEffect, useState, useContext } from 'react';
import fireStore from '@react-native-firebase/firestore';
import { FriendsStyle } from '../add-friends/FriendsStyle';
import { useDispatch, useSelector } from 'react-redux';
import { NetworkContext } from '../../NetworkContext';
import { FriendStyle } from './FriendStyle';

const AddFriends = ({ navigation }) => {
  const isFocused = useIsFocused();
  const dispatch = useDispatch();
  const route = useRoute();
  const isFromDrawer = route.params?.fromDrawer;
  const isFromTabNav = route.params?.isFromTabNav;
  const stateVal = useSelector(state => state.login);
  const stateValue = useSelector(state => state.friends);
  const notification = stateVal.notification_count;
  const friendData = stateValue.items;
  const [currentPage, setCurrentPage] = React.useState(1);
  const [formLayoutIndex, setFormLayoutIndex] = useState(0);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [isEndOfPage, setIsEndOfPage] = useState(false);
  const [friendsData, setFriendsData] = useState([]);
  const [shouldFetchNextPage, setShouldFetchNextPage] = useState(true);
  const [unreadCount, setUnreadCount] = useState(0);
  const isConnected = useContext(NetworkContext);
  const [params, setParamData] = useState({
    search: '',
    page: 1,
    user_id: stateVal.id,
    limit: 30,
  });

  useEffect(() => {
    if (isConnected && isFocused) {
      const params = {
        user_id: stateVal.id,
        page: currentPage,
        limit: 30,
        search: '',
      };
      if (stateVal.id) {
        fetchChatList();
        fetchMyFriendsData(currentPage, params);
        fetchFriendReq(stateVal.id);
      }
    }
  }, [isFocused, params, isConnected]);

  const fetchChatList = async () => {
    try {
      const loggedInUserId = stateVal.id;
      const chatListSnapshot = await fireStore()
        .collection('chatlists')
        .where('receiverId', '==', loggedInUserId)
        .get();
      const chatListData = chatListSnapshot.docs.map(doc => doc.data());
      chatListData.map((obj, index) => {
        setUnreadCount(obj.unreadMessages);
      });
    } catch (error) {
      console.error('Error fetching chat list:', error);
    }
  };

  const fetchMyFriendsData = async (page, params) => {
    setIsLoadingMore(true);
    const resultAction = await dispatch(fetchMyFriends(params));
    if (fetchMyFriends.fulfilled.match(resultAction)) {
      const newData = resultAction.payload.data.friends;
      setIsLoadingMore(false);
      if (newData.length < params.limit) {
        setShouldFetchNextPage(false);
      } else {
        setShouldFetchNextPage(true);
      }
      if (params.page === 1) {
        setFriendsData(newData);
      } else {
        setFriendsData(prevData => {
          const uniqueFilteredData = newData.filter(
            item => !prevData.map(prevItem => prevItem.id).includes(item.id),
          );
          return [...prevData, ...uniqueFilteredData];
        });
      }
    }
  };

  const handleLoadMore = () => {
    if (!isLoadingMore && shouldFetchNextPage && isEndOfPage) {
      setIsLoadingMore(true);
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      const params = {
        page: nextPage,
        user_id: stateVal.id,
        limit: 30,
        search: '',
      };
      fetchMyFriendsData(nextPage, params).then(() => setIsLoadingMore(false));
    }
  };

  const handleScroll = event => {
    const { contentOffset, layoutMeasurement, contentSize } = event.nativeEvent;
    const endOfFirstPageOffset = contentSize.height - layoutMeasurement.height;
    const isEndOfFirstPage = contentOffset.y >= endOfFirstPageOffset;
    setIsEndOfPage(true);
    if (isEndOfPage) {
      handleLoadMore();
    }
  };

  const fetchFriendReq = async () => {
    const params = { user_id: stateVal.id };
    const resultAction = await dispatch(fetchFriends(params));
    const data = resultAction.payload.data;
  };
  const handleFormLayout = index => {
    setFormLayoutIndex(index);
  };

  const removeRequest = async id => {
    const params = { friend_request_id: id };
    const resultAction = await dispatch(removeFriends(params));
    if (removeFriends.fulfilled.match(resultAction)) dispatch(resetState({}));
    fetchFriendReq(stateVal.id);
  };

  const acceptRequest = async id => {
    const params = { friend_request_id: id };
    const resultAction = await dispatch(acceptFriends(params));
    if (acceptFriends.fulfilled.match(resultAction)) {
      const data = resultAction.payload.data;
    }
    fetchFriendReq(stateVal.id);
  };

  return (
    <View
      style={[
        Styles.WhiteBg, !isFromDrawer && 
        { marginBottom: Platform.OS === 'ios' ? 125 : 125 },
      ]}>
      <Appbar.Header
        style={[
          Styles.AppbarHeader,
          Styles.AppBarShadow,
          { justifyContent: 'space-between' },
        ]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{backgroundColor: UiColor.SecondaryColor}}
          icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
        />
        <Appbar.Content titleStyle={Styles.NavTitle} title="Friends" />
        <Appbar.Action />
      </Appbar.Header>
      <View style={{ alignItems: 'flex-start' }}>
        <SegmentedControlTab
          values={['My friends', 'Friend requests']}
          selectedIndex={formLayoutIndex}
          onTabPress={handleFormLayout}
          borderRadius={18}
          tabsContainerStyle={[Styles.TabContainer]}
          tabStyle={Styles.TabStyle}
          activeTabStyle={Styles.ActiveTab}
          tabTextStyle={Styles.TabText}
          activeTabTextStyle={Styles.ActiveTabText}
        />
      </View>
      {!isConnected && friendsData && friendsData.length === 0 ? (
        <View style={[GlobalStyles.NoData, { marginTop: 80 }]}>
          <Icon name="no-connection" size={50} />
          <Text style={[GlobalStyles.NoDataMsg, { fontFamily: Dm.semiBold }]}>
            No Internet Connection
          </Text>
        </View>
      ) : (
        <>
          {formLayoutIndex === 0 && (
            <ScrollView
              showsVerticalScrollIndicator={false}
              onScroll={handleScroll}
              scrollEventThrottle={16}
              style={{ marginBottom: 150 }}>
              <View
                style={[
                  Styles.Container,
                  GlobalStyles.mt18,
                  { backgroundColor: 'transparent' },
                ]}>
                <View style={FriendStyle.FriendListHead}>
                  {Object.keys(friendsData).length === 0 && isLoadingMore ? (
                    <SkeletonPlaceholder>
                      <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: -9 }}>
                        {Array.from({ length: 20 }).map((_, index) => (
                          <View key={index} style={{ width: "25%", alignItems: 'center', marginBottom: 22, }}>
                            <SkeletonPlaceholder.Item
                              width={72}
                              height={72}
                              borderRadius={72}
                            />
                            <SkeletonPlaceholder.Item
                              height={10}
                              width={40}
                              marginLeft={8}
                              marginTop={5}
                            />
                          </View>
                        ))}
                      </View>
                    </SkeletonPlaceholder>
                  ) : (
                    <>
                      <View style={FriendStyle.FriendList}>
                        <TouchableOpacity
                          style={FriendStyle.AddBtn}
                          onPress={() => navigation.navigate('AddFriends')}>
                          <Icon name="plus" size={24} color={UiColor.White} />
                        </TouchableOpacity>
                        <Text style={FriendStyle.FriendText}>Add Friends</Text>
                      </View>
                      {friendsData &&
                        friendsData?.map((friend, index) => (
                          <View style={[FriendStyle.FriendList]} key={index}>
                            <TouchableOpacity
                              style={{ alignItems: 'center' }}
                              onPress={() =>
                                navigation.navigate(
                                  'MyFriendProfile',
                                  friend.id,
                                )
                              }>
                              <Avatar.Image
                                size={72}
                                style={{ marginHorizontal: 'auto', backgroundColor: UiColor.ImageLoad }}
                                source={
                                  friend.profile_image &&
                                    friend.profile_image.path
                                    ? {
                                      uri: friend.profile_image.path,
                                    }
                                    : IconAsset.BlankUser
                                }
                              />
                              <Text style={[FriendStyle.FriendText]}>
                                {friend.first_name} {friend.last_name}
                              </Text>
                            </TouchableOpacity>
                          </View>
                        ))}
                    </>
                  )}
                  {!isLoadingMore &&
                    friendsData &&
                    friendsData?.length === 0 && (
                      <View style={GlobalStyles.NoData}>
                        <Text style={GlobalStyles.NoDataMsg}>
                          No friends found
                        </Text>
                      </View>
                    )}
                </View>
              </View>
            </ScrollView>
          )}
          {formLayoutIndex === 1 && (
            <>
              <ScrollView showsVerticalScrollIndicator={false}>
                <View
                  style={[
                    FriendsStyle.Container,
                    { backgroundColor: 'transparent', marginBottom: 150, marginHorizontal: 6 },
                  ]}>
                  {friendData &&
                    friendData.friend_requests?.map((item, index) => (
                      <View style={FriendsStyle.Card} key={index}>
                        <TouchableOpacity>
                          <View style={FriendsStyle.CardLeft}>
                            {item.from_id &&
                              item.from_id.profile_image &&
                              item.from_id.profile_image.path ? (
                              <Avatar.Image
                                style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                                size={51}
                                source={{
                                  uri: item.from_id.profile_image.path,
                                }}
                              />
                            ) : (
                              <Avatar.Image
                                style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                                size={51}
                                source={IconAsset.BlankUser}
                              />
                            )}
                            <View>
                              <Text style={FriendsStyle.CardTitle}>
                                {item.from_id && item.from_id.first_name
                                  ? item.from_id.first_name
                                  : ''}{' '}
                                {item.from_id && item.from_id.last_name
                                  ? item.from_id.last_name
                                  : ''}{' '}
                                {''}
                              </Text>
                              <Text
                                style={{ maxWidth: '75%' }}
                                numberOfLines={3}
                                ellipsizeMode="tail">
                                has sent you friend request.
                              </Text>
                            </View>
                          </View>
                        </TouchableOpacity>
                        <View
                          style={FriendStyle.acceptRequest}>
                          <IconButton
                            style={[
                              FriendsStyle.CardIcon,
                              Styles.BorderSuccess,
                            ]}
                            onPress={() => acceptRequest(item.id)}
                            icon={() => <Icon name={'check'} size={18} />}
                            size={28}
                          />
                          <IconButton
                            style={[FriendsStyle.CardIcon]}
                            onPress={() => removeRequest(item.id)}
                            icon={() => <Icon name={'cross'} size={18} />}
                            size={28}
                          />
                        </View>
                      </View>
                    ))}
                </View>
              </ScrollView>
              {friendData &&
                friendData?.friend_requests &&
                friendData.friend_requests?.length === 0 && (
                  <View style={[GlobalStyles.NoData, { marginTop: 30 }]}>
                    <Text style={GlobalStyles.NoDataMsg}>
                      No friend request found
                    </Text>
                  </View>
                )}
            </>
          )}
        </>
      )}
    </View>
  );
};
export default AddFriends;
