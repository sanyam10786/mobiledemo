import { Styles, GlobalStyles, UiColor, IconAsset, Icon } from '../../../theme/Index';
import { View, Text, TouchableOpacity, FlatList, SafeAreaView} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {useIsFocused, useNavigation} from '@react-navigation/native';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import {FriendsStyle} from '../add-friends/FriendsStyle';
import {Appbar, Avatar} from 'react-native-paper';
import React, {useState, useEffect} from 'react';

const CatchesDraft = () => {
  const isFocused = useIsFocused();
  const navigation = useNavigation();
  const [loadDrafts, setLoadDrafts] = useState([]);
  const [isLoadingMore, setIsLoadingMore] = useState(false);

  useEffect(() => {
    if (isFocused) {
      fetchUserAndDrafts();
    }
  }, [isFocused]);

  const fetchUserAndDrafts = async () => {
    setIsLoadingMore(true);
    try {
      const [userObjString, draftsString] = await Promise.all([
        AsyncStorage.getItem('USER_DATA'),
        AsyncStorage.getItem('catch_drafts'),
      ]);
      let userId = '';
      if (userObjString) {
        const userObj = JSON.parse(userObjString);
        userId = userObj?.data?.user?._id || '';
      }

      let drafts = draftsString ? JSON.parse(draftsString) : [];
      if (userId) {
        drafts = drafts.filter(draft => draft.user_id === userId);
      }
      setLoadDrafts(drafts);
    } catch (err) {
      console.error('Error fetching user or drafts:', err);
      setIsLoadingMore(false);
      setLoadDrafts([]);
    }
    setIsLoadingMore(false);
  };

  const ListItem = ({item}) => (
    <View style={FriendsStyle.Card}>
      <TouchableOpacity
        onPress={() => navigation.navigate('OfflineDetail', item)}>
        <View style={FriendsStyle.CardLeft}>
          <Avatar.Image
            style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
            size={51}
            source={{uri: item.media_file ? item.media_file.uri : ''}}
          />
          <View>
            <Text style={FriendsStyle.CardTitle}>{item.fish_name}</Text>
            <Text
              style={[FriendsStyle.CardDisc, {maxWidth: '80%'}]}
              numberOfLines={3}
              ellipsizeMode="tail">
              {item.length}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={{flex: 1}}>
      <Appbar.Header style={[Styles.AppbarHeader, Styles.AppBarShadow,]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{backgroundColor: UiColor.SecondaryColor}}
          icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
        />
        <Appbar.Content titleStyle={Styles.NavTitle} title="Drafts" />
        <Appbar.Action />
      </Appbar.Header>
      <View style={[FriendsStyle.Container, {backgroundColor: 'transparent'}]}>
        <SafeAreaView style={[FriendsStyle.FullCardArea]}>
        {Object.keys(loadDrafts).length === 0 && isLoadingMore ? (
          <SkeletonPlaceholder>
            {Array.from({ length: 10 }).map((_, index) => (
              <View style={[FriendsStyle.Card, {shadowOpacity: 0,
                shadowRadius: 0,}]} key={index}>
                <SkeletonPlaceholder.Item height={50} width="100%">
                  <View style={FriendsStyle.CardLeft}>
                    <SkeletonPlaceholder.Item
                      width={51}
                      height={51}
                      borderRadius={51}
                    />
                    <View>
                      <SkeletonPlaceholder.Item
                        height={20}
                        width={120}
                        marginLeft={10}
                      />
                      <SkeletonPlaceholder.Item
                        height={20}
                        width={180}
                        marginLeft={10}
                        marginTop={8}
                      />
                    </View>
                  </View>
                </SkeletonPlaceholder.Item>
              </View>
            ))}
          </SkeletonPlaceholder>
            ) : (
            <>
              <FlatList
                data={loadDrafts}
                renderItem={({item, index}) => (
                  <ListItem item={item} index={index} />
                )}
                keyExtractor={(item, index) => index.toString()}
              />
              {loadDrafts && loadDrafts.length === 0 && !isLoadingMore && (
                <View style={GlobalStyles.NoData}>
                  <Text style={GlobalStyles.NoDataMsg}>No Drafts Found</Text>
                </View>
              )}
            </>
            )}
        </SafeAreaView>
      </View>
    </View>
  );
};

export default CatchesDraft;
