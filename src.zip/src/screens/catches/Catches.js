import { View, Text, TouchableOpacity, ScrollView, Image, Platform } from 'react-native';
import { Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm } from '../../../theme/Index';
import { useIsFocused, useNavigation, useRoute } from '@react-navigation/native';
import { Appbar, Avatar, ActivityIndicator } from 'react-native-paper';
import React, { useEffect, useState, useContext, useCallback, useMemo  } from 'react';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import { ProfileStyle } from '../user-profile/ProfileStyle';
import { useDispatch, useSelector } from 'react-redux';
import { NetworkContext } from '../../NetworkContext';
import { fetchCatchesGallery } from '../../thunk';
import FastImage from 'react-native-fast-image';
import { FlatList } from 'react-native';

const Catches = ({ navigation }) => {
  const dispatch = useDispatch();
  const route = useRoute();
  const isProfile = route.params;
  const isFocused = useIsFocused();
  const stateVal = useSelector(state => state.login);
  const userData = useSelector(state => state.user);
  const catches = useMemo(() => userData.catches, [userData.catches]);
  const currentPage = userData.params.page || 1;
  const totalPages = userData.totalPages || 1;
  const [isCatch, setIsCatch] = useState(false);
  const [hideSkeleton, setHideSkeleton] = useState(false);
  const isConnected = useContext(NetworkContext);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isConnected && isFocused) {
      fetchCatches(1);
      if(catches && catches.length > 0){
        setTimeout(() => {
          setHideSkeleton(true)
        }, 3000)
      }
    }
  }, [isConnected, isFocused]);

  const fetchCatches = async (page) => {
    setLoading(true);
    const params = { user_id: stateVal.id, page, limit: 20 };
    await dispatch(fetchCatchesGallery(params));
    setLoading(false);
  };

  const handleLoadMore = () => {
    if (currentPage < totalPages && !loading) {
      dispatch(fetchCatchesGallery({ 
        user_id: stateVal.id, 
        page: currentPage + 1, 
        limit: 20 
      }));
    }
  };

  const handlePress = obj => {
    const data = {
      media: obj.media.path,
      catch_weight: obj.weight,
      challenge_id: isProfile.challengeId,
    }
    if (isProfile.challengeId === '') {
      navigation.navigate('PostsUpload', { media: obj.media.path, isUserPosts: route.params.isUserPosts });
    } else if (isProfile.challengeId) {
      navigation.navigate('ChallengesStoryUpload', data);
    } else {
      navigation.navigate('JournalCatches', {
        catch_id: obj._id,
        isCatchGallery: isCatch,
        date: obj.date,
        isJournalUser: true,
      });
    }
  };

  const renderItem = useCallback(({ item }) => {
    if (item.media && item.media.path) {
      return (
        <View style={[ProfileStyle.ProfileImgHead]}>
          <TouchableOpacity onPress={() => handlePress(item)}>
          <FastImage
            style={ProfileStyle.ProfileImg}
            source={{
              uri: `${item.media.path}`,
              priority: FastImage.priority.normal,
            }}
            resizeMode={FastImage.resizeMode.cover}
          />
          </TouchableOpacity>
        </View>
      );
    }
    return null;
  }, [isCatch, isProfile]);

  return (
    <View
    style={[
      Styles.WhiteBg,
      route.params && route.params.isTrue !== true ? { marginBottom: Platform.OS === 'ios' ? 215 : 215 } : {marginBottom: Platform.OS === 'ios' ? 115 : 115},
    ]}>
      <Appbar.Header
        style={[
          Styles.AppbarHeader,
          Styles.AppBarShadow,
          {justifyContent: 'space-between'},
        ]}
      >
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{backgroundColor: UiColor.SecondaryColor}}
          icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
        />
        <Appbar.Content titleStyle={Styles.NavTitle} title="Catch Gallery" />
        <Appbar.Action />
      </Appbar.Header>
        <>
          {!isConnected && catches && catches.length === 0 ? (
            <View style={[GlobalStyles.NoData, { marginTop: 80 }]}>
              <Icon name="no-connection" size={50} />
              <Text style={[GlobalStyles.NoDataMsg, { fontFamily: Dm.semiBold }]}>
                No Internet Connection
              </Text>
            </View>
          ) :  (
            <>
              {loading && !hideSkeleton ? (
                <ScrollView>
                  <SkeletonPlaceholder>
                    <View style={[ProfileStyle.ProfileImgList, {marginTop: 10,}]}>
                      {Array.from({ length: 18 }).map((_, index) => (
                        <View style={ProfileStyle.ProfileImgHead} key={index}>
                          <View style={ProfileStyle.ProfileImg} />
                        </View>
                      ))}
                    </View>
                  </SkeletonPlaceholder>
                </ScrollView>
              ) : (
                <FlatList
                  data={catches}
                  renderItem={renderItem}
                  keyExtractor={(item, index) => item._id ? `${item._id}-${index}` : index.toString()}
                  numColumns={3}
                  showsVerticalScrollIndicator={false}
                  ListFooterComponent={loading ? <ActivityIndicator size={20} color={UiColor.PrimaryColor} /> : null}
                  onEndReached={handleLoadMore}
                  onEndReachedThreshold={0.5}
                  ListEmptyComponent={!loading && catches?.length === 0 && (
                    <View style={[GlobalStyles.NoData, {marginTop: 30}]}>
                      <Text style={GlobalStyles.NoDataMsg}>No Catches Found</Text>
                    </View>
                  )}
              />
              )}
            </>
          )}
        </>
    </View>
  );
};
export default Catches;
