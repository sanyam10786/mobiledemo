import {
  likePosts,
  removeLike,
  commentPost,
  fetchComments,
  likeComment,
  deleteComment,
  commentReply,
  deletePost,
  fetchMyFriends,
  fetchUserPosts,
  reportStoryPost,
} from '../../thunk';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  KeyboardAvoidingView,
  FlatList,
  Alert,
} from 'react-native';
import {
  Appbar,
  Avatar,
  IconButton,
  ActivityIndicator,
  TextInput,
} from 'react-native-paper';
import {
  Styles,
  GlobalStyles,
  UiColor,
  IconAsset,
  Icon,
  Dm,
} from '../../../theme/Index';
import {useIsFocused, useNavigation, useRoute} from '@react-navigation/native';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import {StoryBoardStyle} from '../story-board/StoryBoardStyle';
import {resetState, setRefreshing} from '../../slices/posts';
import React, {useEffect, useState, useRef, useContext} from 'react';
import FastImage from 'react-native-fast-image';
import {useDispatch, useSelector} from 'react-redux';
import {NetworkContext} from '../../NetworkContext';
import RBSheet from 'react-native-raw-bottom-sheet';
import {ProfileStyle} from './ProfileStyle';
import Share from 'react-native-share';
import Slick from 'react-native-slick';
import RNFS from 'react-native-fs';
import moment from 'moment';

const UserPosts = ({navigation, friendId, user}) => {
  const isFocused = useIsFocused();
  const flatListRef = useRef(null);
  const route = useRoute();
  const refCommentSheet = useRef({});
  const refPostSheet = useRef({});
  const refReportSheet = useRef({});
  const dispatch = useDispatch();
  const userDetails = user;
  const isConnected = useContext(NetworkContext);
  const stateVal = useSelector(state => state.login);
  const stateValue = useSelector(state => state.posts);
  const allFriends = useSelector(state => state.friends);
  const friendData = allFriends.myFriends.friends;
  const [postsData, setPostsData] = useState([]);
  const [paramsData, setParamData] = useState({
    user_id: friendId ? friendId : stateVal.id,
  });
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [hasScrolled, setHasScrolled] = useState(false);
  const [commentData, setCommentData] = useState([]);
  const [myFriendData, setMyFriendData] = useState([]);
  const [commentItems, setCommentItems] = useState(null);
  const [expandedComments, setExpandedComments] = useState([]);
  const toggleRepliesVisibility = commentId => {
    setExpandedComments(prev => ({
      ...prev,
      [commentId]: !prev[commentId],
    }));
  };
  const [deleteParams, setDeleteParams] = useState({
    story_id: '',
    comment_id: '',
    isComment: false,
  });
  const [isFetchingNewComments, setIsFetchingNewComments] = useState(false);
  const commentInputRef = useRef({});
  const [isSubmit, setIsSubmit] = useState(false);
  const [formData, setFormData] = useState({
    comment: '',
    text_comment: '',
    isReply: false,
  });

  useEffect(() => {
    if (isConnected && isFocused) {
      const params = {
        user_id: paramsData.user_id,
      };
      fetchAllPosts(params);
      setHasScrolled(false);
      fetchFriends();
    }
  }, [isFocused, paramsData]);

  const handleRefresh = () => {
    dispatch(setRefreshing({}));
    params.page = 1;
    fetchAllPosts(params);
  };

  const fetchFriends = async () => {
    try {
      const params = {
        user_id: stateVal.id,
        page: 1,
        limit: 30,
      };

      let allFriends = [];
      while (true) {
        const resultAction = await dispatch(fetchMyFriends(params));
        if (fetchMyFriends.fulfilled.match(resultAction)) {
          const newData = resultAction.payload.data.friends;
          allFriends = allFriends.concat(newData);
          if (newData.length < params.limit) {
            break;
          }
          params.page++;
        } else {
          break;
        }
      }
      setMyFriendData(allFriends);
    } catch (error) {
      console.error('Error in fetchFriends:', error);
    }
  };

  const fetchAllPosts = async params => {
    try {
      setIsLoadingMore(true);
      const resultAction = await dispatch(fetchUserPosts(params));
      if (fetchUserPosts.fulfilled.match(resultAction)) {
        const newPosts = resultAction.payload.data;
        setPostsData(newPosts);
      }
    } catch (error) {
      console.error('Error in fetchAllPosts:', error);
      setIsLoadingMore(false);
    }
    setIsLoadingMore(false);
  };

  const likePost = async text => {
    try {
      const params = {story_id: text};
      const resultAction = await dispatch(likePosts(params));
      const newLikes = resultAction.payload.data.likes;
      setPostsData(prevData => {
        return prevData.map(item => {
          if (item._id === text) {
            const updatedLikes = [...item.likes, ...newLikes].filter(
              (like, index, self) =>
                index === self.findIndex(l => l._id === like._id),
            );
            const updatedItem = {
              ...item,
              likes: updatedLikes,
              likes_count: updatedLikes.length,
            };
            return updatedItem;
          }
          return item;
        });
      });
    } catch (error) {
      console.error('Error in likePosts:', error);
    }
  };

  const dislikePost = async text => {
    try {
      const params = {
        story_id: text.story_id,
        like_id: text.like_id,
      };
      const resultAction = await dispatch(removeLike(params));
      if (text.isCommentDislike) {
        fetchPostComment(text.story_id);
      } else {
        const newLikes = resultAction.payload.data.likes;
        if (newLikes) {
          setPostsData(prevData => {
            return prevData.map(item => {
              if (item._id === text.story_id) {
                return {
                  ...item,
                  likes: newLikes,
                };
              }
              return item;
            });
          });
        }
      }
    } catch (error) {
      console.error('Error in dislikePosts:', error);
    }
  };

  const postCommentOrReply = async text => {
    setIsSubmit(true);
    setIsFetchingNewComments(true);
    const {isReply} = formData;
    try {
      let resultAction;
      if (isReply) {
        // Reply
        const commentsId = text.comment_id.comment_id;
        resultAction = await dispatch(
          commentReply({
            story_id: text.story_id,
            comment_id: commentsId,
            text_comment: formData.comment,
          }),
        );
      } else {
        // New Comment
        resultAction = await dispatch(
          commentPost({
            story_id: text.story_id,
            comment: formData.comment,
          }),
        );
      }
      setIsSubmit(false);
      if (
        commentReply.fulfilled.match(resultAction) ||
        commentPost.fulfilled.match(resultAction)
      ) {
        const newComment = resultAction.payload.data;
        if (newComment) {
          setCommentData(prevData => ({
            ...prevData,
            result: [...(prevData?.result || []), newComment],
          }));
        }
        fetchPostComment(text.story_id);
        setFormData({...formData, comment: '', isReply: false});
        setCommentItems('');
      }
    } catch (error) {
      console.error('Error in CommentReply/CommentPost:', error);
      setIsSubmit(false);
      setIsFetchingNewComments(false);
    }
  };

  const fetchPostComment = async text => {
    refCommentSheet.current[text]?.open();
    const params = {
      story_id: text,
    };
    try {
      const resultAction = await dispatch(fetchComments(params));
      if (fetchComments.fulfilled.match(resultAction)) {
        const data = resultAction.payload.data;
        setCommentData(data);
        if (data) {
          const updatedPostsData = postsData.map(post => {
            if (post._id === text) {
              return {
                ...post,
                comments_count: data.comment_count,
              };
            }
            return post;
          });
          setPostsData(updatedPostsData);
        }
      }
    } catch (error) {
      console.error('Error in CommentPosts:', error);
    }
  };

  const postCommentLike = async text => {
    try {
      const params = {
        story_id: text.story_id,
        comment_id: text.comment_id,
      };
      const resultAction = await dispatch(likeComment(params));
      const likeData = resultAction.payload.data;
      fetchPostComment(params.story_id);
    } catch (error) {
      console.error('Error in postCommentLike:', error);
    }
  };

  const deleteItem = async params => {
    try {
      const resultAction = await dispatch(
        params.isComment === true ? deleteComment(params) : deletePost(params),
      );
      const data = resultAction.meta.arg;
      refPostSheet.current[params.story_id]?.close();
      if (params.isComment) {
        if (resultAction.payload.status) {
          setCommentData(prevData => ({
            ...prevData,
            result: prevData.result.filter(
              item => item._id !== data.comment_id,
            ),
            comment_count: prevData.comment_count - 1,
          }));
          fetchPostComment(params.story_id);
        }
      } else {
        setPostsData(prevData =>
          prevData.filter(item => item._id !== params.story_id),
        );
      }
    } catch (error) {
      console.error('Error in deleteItem:', error);
    }
  };

  const handleDeletePress = params => {
    setDeleteParams(params);
    Alert.alert(
      'Delete', // Alert Title
      params.isComment === true
        ? 'Are you sure you want to delete this comment ?'
        : 'Are you sure you want to delete this post ?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'Delete',
          onPress: () => deleteItem(params),
          style: 'destructive',
        },
      ],
    );
  };

  const shareStoryImg = async storyImg => {
    try {
      const imageUrl = storyImg && storyImg[0].media && storyImg[0].media.path;
      const downloadDest = `${RNFS.CachesDirectoryPath}/catchImage.jpg`;
      const options = {
        fromUrl: imageUrl,
        toFile: downloadDest,
      };
      await RNFS.downloadFile(options).promise;
      const shareOptions = {
        title: 'Check out my story!',
        url: `file://${downloadDest}`,
        type: 'image/jpeg',
        failOnCancel: false,
      };
      setTimeout(() => {
        Share.open(shareOptions);
      }, 1000);
    } catch (error) {
      alert(error.message);
    }
  };

  const closeCommentSheet = () => {
    setCommentData('');
    setCommentItems('');
    setFormData('');
    setExpandedComments('');
    fetchAllPosts(params);
  };

  const navigateToProfile = text => {
    refCommentSheet.current[text.story_id]?.close();
    const item_id = text.user_id;
    if (item_id === stateVal.id) {
      navigation.navigate('UserProfile');
    } else {
      const hasFriend = myFriendData.some(item => item.id === item_id);
      if (hasFriend) {
        navigation.navigate('MyFriendProfile', item_id);
      } else {
        navigation.navigate('FriendProfile', item_id);
      }
    }
  };

  const reportPost = async text => {
    refReportSheet.current[text.story_id]?.close();
    try {
      const params = {story: text.story_id, text: text.reportText};
      const resultAction = await dispatch(reportStoryPost(params));
      if (reportStoryPost.fulfilled.match(resultAction)) {
        const data = resultAction.payload.data;
      }
    } catch (error) {
      console.error('Error in reportStoryPost:', error);
    }
  };

  const CommentText = ({ comment }) => {
    const usernameRegex = /(@\w+\s\w+)/g;
    const parts = comment.split(usernameRegex);
    return (
      <Text>
        {parts.map((part, index) => {
          if (usernameRegex.test(part)) {
            return (
              <Text key={index} style={[StoryBoardStyle.CommentText, {fontSize: 14, fontFamily: Dm.semiBold, color: UiColor.DarkBlue}]}>
                {part}
              </Text>
            );
          } else {
            return (
              <Text key={index} style={[StoryBoardStyle.CommentText, {fontSize: 14,}]}>
                {part}
              </Text>
            );
          }
        })}
      </Text>
    );
  };

  const renderReplies = parentCommentId => {
    const params = {
      story_id: parentCommentId.story_id,
      comment_id: parentCommentId.comment_id,
      user_id: parentCommentId.user_id,
    };
    const replies = commentData.result?.filter(
      comment => comment.parent_comment_id === params.comment_id,
    );

    return replies.map(reply => {
      const formatTime = moment(
        reply.created_at,
        'DD MM YYYY hh:mm:ss a',
      ).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
      const fromNowTime = moment(formatTime).fromNow();

      return (
        <View key={reply._id}>
          <View
            style={[
              StoryBoardStyle.CommentWrap,
              StoryBoardStyle.CommentWrapInner,
            ]}>
            <TouchableOpacity
              style={[StoryBoardStyle.ProfileCta, {marginRight: 6}]}
              onPress={() =>
                navigateToProfile({
                  user_id: reply.user_id._id,
                  story_id: params.story_id,
                })
              }>
              {reply?.user_id.profile_image?.path ? (
                <Avatar.Image
                  style={{backgroundColor: UiColor.ImageLoad}}
                  size={32}
                  source={{
                    uri: reply?.user_id?.profile_image.path,
                  }}
                />
              ) : (
                <Avatar.Image
                  style={{backgroundColor: UiColor.ImageLoad}}
                  size={32}
                  source={IconAsset.BlankUser}
                />
              )}
            </TouchableOpacity>
            <View style={StoryBoardStyle.CommentCardHead}>
              <View style={StoryBoardStyle.CommentCard}>
                <View style={StoryBoardStyle.CommentCardTitle}>
                  <Text style={StoryBoardStyle.CommentTitle}>
                    {reply?.user_id?.first_name +
                      ' ' +
                      reply?.user_id?.last_name}
                  </Text>
                  <Text style={StoryBoardStyle.CommentDate}>{fromNowTime}</Text>
                </View>
                {/* <Text style={StoryBoardStyle.CommentText}>
                  {reply?.text_comment}
                </Text> */}
                <CommentText comment={reply?.text_comment} />
              </View>
              <View style={StoryBoardStyle.CommentRange}>
                {reply && reply.like_count === 0 ? (
                  ''
                ) : (
                  <Text style={StoryBoardStyle.CommentRangeText}>
                    {reply.like_count}
                  </Text>
                )}
                {reply.likes?.some(like => like.user_id === stateVal.id) ? (
                  <TouchableOpacity
                    onPress={() => {
                      dislikePost({
                        story_id: params.story_id,
                        isCommentDislike: true,
                        like_id: reply.likes.find(
                          like => like.user_id === stateVal.id,
                        )._id,
                      });
                    }}>
                    <Text style={StoryBoardStyle.CommentRangeText}>Unlike</Text>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    onPress={() => {
                      postCommentLike({
                        story_id: params.story_id,
                        comment_id: reply._id,
                      });
                    }}>
                    <Text style={StoryBoardStyle.CommentRangeText}>Like</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity
                  onPress={() => {
                    setCommentItems({
                      comment_id: reply._id,
                      fullName:
                        reply.user_id.first_name +
                        ' ' +
                        reply.user_id.last_name,
                    });
                    setFormData({
                      ...formData,
                      comment: `@${reply.user_id.first_name } ${reply.user_id.last_name} `,
                      isReply: true,
                    });
                    commentInputRef.current && commentInputRef.current.focus();
                  }}>
                  <Text style={StoryBoardStyle.CommentRangeText}>Reply</Text>
                </TouchableOpacity>
                {reply.user_id._id === stateVal.id ||
                params.user_id === stateVal.id ? (
                  <TouchableOpacity
                    onPress={() => {
                      handleDeletePress({
                        story_id: params.story_id,
                        comment_id: reply._id,
                        isComment: true,
                      });
                    }}>
                    <Text style={StoryBoardStyle.CommentRangeText}>Delete</Text>
                  </TouchableOpacity>
                ) : (
                  ''
                )}
              </View>
            </View>
          </View>
          {renderReplies(
            {
              story_id: params.story_id,
              comment_id: reply._id,
              user_id: params.user_id,
            },
            commentData,
          )}
        </View>
      );
    });
  };

  const ListItem = ({item, index}) => {
    return (
      <>
        {!isConnected && item === '' ? (
          <View style={[GlobalStyles.NoData, {marginTop: 80}]}>
            <Icon name="no-connection" size={50} />
            <Text style={[GlobalStyles.NoDataMsg, {fontFamily: Dm.semiBold}]}>
              No Internet Connection
            </Text>
          </View>
        ) : (
          <>
            {item &&
              item.media &&
              item.media.some(
                mediaItem => mediaItem.media && mediaItem.media.path,
              ) && (
                <View style={Styles.PostCard} key={index}>
                  <View style={Styles.PostTitleHead}>
                    <View style={{flexDirection: 'row'}}>
                      <TouchableOpacity
                        onPress={() =>
                          navigateToProfile({user_id: item.user.id})
                        }>
                        {item?.user?.profile_image?.path ? (
                          <Avatar.Image
                            style={{backgroundColor: UiColor.ImageLoad}}
                            size={51}
                            source={{
                              uri: item.user?.profile_image?.path,
                            }}
                          />
                        ) : (
                          <Avatar.Image
                            style={{backgroundColor: UiColor.ImageLoad}}
                            size={60}
                            source={IconAsset.BlankUser}
                          />
                        )}
                      </TouchableOpacity>
                      <View>
                        <Text style={Styles.PostCardTitle}>
                          {item.user.first_name + ' ' + item.user.last_name}
                        </Text>
                        <Text style={Styles.PostCardSubTitle}>
                          {moment(item.created_at).fromNow()}
                        </Text>
                      </View>
                    </View>
                    <IconButton
                      onPress={() => {
                        refPostSheet.current[item._id]?.open();
                      }}
                      style={{marginRight: -10}}
                      icon={() => (
                        <Icon name={'more-fill'} color={'#536471'} size={18} />
                      )}
                      size={15}
                    />
                    <RBSheet
                      ref={ref => (refPostSheet.current[item._id] = ref)}
                      closeOnDragDown={true}
                      closeOnPressMask={true}
                      customStyles={{
                        wrapper: {
                          backgroundColor: '#100f4d3d',
                        },
                        draggableIcon: {
                          backgroundColor: '#E3E3E3',
                          marginTop: 10,
                        },
                        container: {
                          backgroundColor: '#fff',
                          borderTopLeftRadius: 30,
                          borderTopRightRadius: 30,
                        },
                      }}>
                      <>
                        <View style={{paddingVertical: 50}}>
                          {item.user.id === stateVal.id && (
                            <View style={[Styles.CardFoot]}>
                              <TouchableOpacity
                                style={[ProfileStyle.BtnFileUpload]}
                                onPress={() => {
                                  handleDeletePress({
                                    story_id: item._id,
                                    isComment: false,
                                  });
                                }}>
                                <Text style={ProfileStyle.BtnFileUploadText}>
                                  Delete
                                </Text>
                              </TouchableOpacity>
                            </View>
                          )}
                          {item.user.id !== stateVal.id && (
                            <View style={[Styles.CardFoot]}>
                              <TouchableOpacity
                                style={[ProfileStyle.BtnFileUpload]}
                                onPress={() => {
                                  refReportSheet.current[item._id]?.open();
                                  refPostSheet.current[item._id]?.close();
                                }}>
                                <Text style={ProfileStyle.BtnFileUploadText}>
                                  Report
                                </Text>
                              </TouchableOpacity>
                            </View>
                          )}
                          {item.user.id === stateVal.id && (
                            <View style={[Styles.CardFoot]}>
                              <TouchableOpacity
                                onPress={() => [
                                  refPostSheet.current[item._id]?.close(),
                                  shareStoryImg(item.media),
                                ]}
                                style={[ProfileStyle.BtnFileUpload]}>
                                <Text style={ProfileStyle.BtnFileUploadText}>
                                  Share
                                </Text>
                              </TouchableOpacity>
                            </View>
                          )}
                        </View>
                      </>
                    </RBSheet>
                    <RBSheet
                      ref={ref => (refReportSheet.current[item._id] = ref)}
                      closeOnDragDown={true}
                      closeOnPressMask={true}
                      openDuration={800}
                      height={400}
                      customStyles={{
                        wrapper: {
                          backgroundColor: '#00000024',
                        },
                        draggableIcon: {
                          backgroundColor: '#E3E3E3',
                        },
                        container: {
                          borderTopLeftRadius: 30,
                          borderTopRightRadius: 30,
                        },
                      }}>
                      <View
                        style={[
                          Styles.PostCardEdit,
                          {
                            flexDirection: 'column',
                            justifyContent: 'space-between',
                            alignItems: 'left',
                            marginTop: 10,
                          },
                        ]}>
                        <Text
                          style={[
                            Styles.ReportText,
                            {
                              fontFamily: Dm.semiBold,
                              fontSize: 20,
                              paddingTop: 5,
                            },
                          ]}>
                          Why are you reporting this post?
                        </Text>
                        <Text
                          style={[
                            Styles.ReportText,
                            {
                              fontFamily: Dm.regular,
                              fontSize: 12,
                              paddingTop: 5,
                              color: UiColor.GrayLight,
                            },
                          ]}>
                          Currently, you can report a post for any of the
                          following reasons:
                        </Text>
                        <TouchableOpacity
                          onPress={() =>
                            reportPost({
                              story_id: item._id,
                              reportText: "I just don't like it",
                            })
                          }>
                          <Text style={Styles.ReportText}>
                            I just don't like it
                          </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          onPress={() =>
                            reportPost({
                              story_id: item._id,
                              reportText: "It's a spam",
                            })
                          }>
                          <Text style={Styles.ReportText}>It's a spam</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          onPress={() =>
                            reportPost({
                              story_id: item._id,
                              reportText: 'Violence or dangerous organizations',
                            })
                          }>
                          <Text style={Styles.ReportText}>
                            Violence or dangerous organizations
                          </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          onPress={() =>
                            reportPost({
                              story_id: item._id,
                              reportText: 'Scam or fraud',
                            })
                          }>
                          <Text style={Styles.ReportText}>Scam or fraud</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          onPress={() =>
                            reportPost({
                              story_id: item._id,
                              reportText: 'Suicide or self-injury',
                            })
                          }>
                          <Text style={Styles.ReportText}>
                            Suicide or self-injury
                          </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          onPress={() =>
                            reportPost({
                              story_id: item._id,
                              reportText: 'Sale of illegal or regulated goods',
                            })
                          }>
                          <Text style={Styles.ReportText}>
                            Sale of illegal or regulated goods
                          </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          onPress={() =>
                            reportPost({
                              story_id: item._id,
                              reportText: 'Something else',
                            })
                          }>
                          <Text style={Styles.ReportText}>Something else</Text>
                        </TouchableOpacity>
                      </View>
                    </RBSheet>
                  </View>
                  <Text style={Styles.PostCardDisc}>{item.quote}</Text>
                  <View style={Styles.PostCardImgHead}>
                    {item.media && item.media.length > 1 ? (
                      <Slick
                        dotColor="#fff"
                        activeDotColor="#D1283D"
                        style={{
                          justifyContent: 'center',
                          alignItems: 'center',
                          height: 297,
                        }}>
                        {item.media &&
                          item.media.map((mediaItem, mediaIndex) => (
                            <View key={mediaIndex}>
                              <Image
                                source={{uri: mediaItem.media.path}}
                                style={Styles.PostCardImg}
                                key={mediaIndex}
                              />
                            </View>
                          ))}
                      </Slick>
                    ) : (
                      item.media &&
                      item.media.map((mediaItem, index) => (
                        <FastImage
                          key={index}
                          source={{uri: mediaItem.media.path}}
                          style={Styles.PostCardImg}
                        />
                      ))
                    )}
                  </View>

                  <View>
                    <View style={Styles.PostCardFoot}>
                      <TouchableOpacity
                        onPress={() =>
                          navigation.navigate('PostLikes', item._id)
                        }>
                        <View style={Styles.PostLikeCount}>
                          <Icon
                            name="unfill-hang-luss"
                            color={UiColor.SecondaryColor}
                            size={12}
                            // style={Styles.PostLikeCountIcon}
                          />
                          {item && item.likes?.length > 0 ? (
                            <Text style={Styles.PostLikeText}>
                              {item.likes?.length}{' '}
                              {item.likes?.length === 1 ? 'Like' : 'Likes'}
                            </Text>
                          ) : (
                            <Text style={Styles.PostLikeText}>Likes</Text>
                          )}
                        </View>
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => {
                          fetchPostComment(item._id);
                        }}>
                        {item && item.comments_count > 0 ? (
                          <Text style={Styles.PostLikeText}>
                            {item.comments_count}{' '}
                            {item && item.comments_count === 1
                              ? 'Comment'
                              : 'Comments'}
                          </Text>
                        ) : (
                          <Text style={Styles.PostLikeText}>Comments</Text>
                        )}
                      </TouchableOpacity>
                    </View>
                    <View
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        paddingTop: 8,
                      }}>
                      <TouchableOpacity
                        style={Styles.PostCardBtn}
                        onPress={() =>
                          item.likes.some(
                            likeItem => likeItem.user_id === stateVal.id,
                          )
                            ? dislikePost({
                                story_id: item._id,
                                like_id: item.likes.find(
                                  like => like.user_id === stateVal.id,
                                )._id,
                              })
                            : likePost(item._id)
                        }>
                        <Icon
                          name={
                            item.likes.some(
                              likeItem => likeItem.user_id === stateVal.id,
                            )
                              ? 'unfill-hang-luss'
                              : 'unfill-hang-luss'
                          }
                          color={
                            item.likes.some(
                              likeItem => likeItem.user_id === stateVal.id,
                            )
                              ? UiColor.SecondaryColor
                              : UiColor.GrayLight
                          }
                          size={18}
                        />
                        <Text
                          style={[
                            Styles.PostLikeText,
                            {
                              marginLeft: 5,
                              color: item.likes.some(
                                likeItem => likeItem.user_id === stateVal.id,
                              )
                                ? UiColor.SecondaryColor
                                : UiColor.GrayLight,
                            },
                          ]}>
                          Like
                        </Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={Styles.PostCardBtn}
                        onPress={() => {
                          fetchPostComment(item._id);
                        }}>
                        <Icon name="comment" size={20} color={'#536471'} />
                        <Text style={Styles.PostLikeText}>Comments</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              )}
          </>
        )}
      </>
    );
  };

  const params = {
    user_id:
      userDetails && userDetails !== undefined ? userDetails.id : stateVal.id,
    name:
      userDetails && userDetails !== undefined
        ? userDetails.first_name + ' ' + userDetails.last_name
        : stateVal.first_name + ' ' + stateVal.last_name,
    friendsCount:
      userDetails && userDetails !== undefined
        ? userDetails.friend_count
        : stateVal.total_friends,
  };
  const renderPostItem = user => (
    <>
      {user !== undefined ? (
        <>
          <View
            style={[
              ProfileStyle.UserProfileCont,
              {backgroundColor: 'transparent'},
            ]}>
            <View>
              <Text style={ProfileStyle.UserTitle}>
                {user.first_name + ' ' + user.last_name}
              </Text>
              <Text style={ProfileStyle.UserEmail}>
                {user.address ? user.address : ''}
              </Text>
            </View>
            <View style={ProfileStyle.UserCountHead}>
              <View style={ProfileStyle.UserCountList}>
                <TouchableOpacity
                  onPress={() =>
                    navigation.navigate('MyFriendFriends', params)
                  }>
                  <Text style={ProfileStyle.UserCountNo}>
                    {user.friend_count ? user.friend_count : '0'}
                  </Text>
                  <Text style={ProfileStyle.UserCountText}>
                    {user.friend_count === 1 ? 'Friend' : 'Friends'}
                  </Text>
                </TouchableOpacity>
              </View>
              <View>
                <Text style={ProfileStyle.UserCountNo}>{user.catch_count}</Text>
                <Text style={ProfileStyle.UserCountText}>
                  {user.catch_count === 1 ? 'Catch' : 'Catches'}
                </Text>
              </View>
              <TouchableOpacity
                style={[Styles.Btn, GlobalStyles.mlAuto]}
                onPress={() =>
                  navigation.navigate('Chat', {
                    receiverId: user.id,
                    Name: user.first_name + ' ' + user.last_name,
                    userProfile: user?.profile_image?.path,
                  })
                }>
                <Icon
                  style={Styles.BtnIcon}
                  name="msg"
                  color={UiColor.White}
                  size={24}
                />
                <Text style={Styles.BtnText}>Message</Text>
              </TouchableOpacity>
            </View>
            <Text
              style={
                user.about_us && user.about_us.length === 0
                  ? null
                  : ProfileStyle.ProfileDisc
              }>
              {user.about_us && user.about_us.replace(/\s+/g, ' ')}
            </Text>
          </View>
          <View
            style={{
              width: '100%',
              height: 0.8,
              backgroundColor: UiColor.Gray,
              marginTop: 10,
              opacity: 0.2,
              marginBottom: 10,
            }}></View>
        </>
      ) : (
        <>
          <View
            style={[
              ProfileStyle.UserProfileCont,
              {backgroundColor: 'transparent'},
            ]}>
            <View>
              <Text style={ProfileStyle.UserTitle}>
                {stateVal.first_name + ' ' + stateVal.last_name}
              </Text>
              <Text style={ProfileStyle.UserEmail}>
                {stateVal.email}
                {stateVal.address ? '  |  ' : ''}
                {stateVal.address}
              </Text>
            </View>
            <View style={ProfileStyle.UserCountHead}>
              <View style={ProfileStyle.UserCountList}>
                <TouchableOpacity
                  onPress={() =>
                    navigation.navigate('MyFriendFriends', params)
                  }>
                  <Text style={ProfileStyle.UserCountNo}>
                    {stateVal.total_friends ? stateVal.total_friends : '0'}
                  </Text>
                  <Text style={ProfileStyle.UserCountText}>
                    {stateVal.total_friends === 1 ? 'Friend' : 'Friends'}
                  </Text>
                </TouchableOpacity>
              </View>
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate('Catches', {
                    isProfile: true,
                    isTrue: route.params !== undefined ? true : false,
                  })
                }>
                <Text style={ProfileStyle.UserCountNo}>
                  {stateVal.catch_count ? stateVal.catch_count : '0'}
                </Text>
                <Text style={ProfileStyle.UserCountText}>
                  {stateVal.catch_count === 1 ? 'Catch' : 'Catches'}
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[Styles.Btn, GlobalStyles.mlAuto]}
                onPress={() => navigation.navigate('UserProfileEdit')}>
                <Icon
                  style={Styles.BtnIcon}
                  name="user-edit"
                  color={UiColor.White}
                  size={24}
                />
                <Text style={Styles.BtnText}>Edit Profile</Text>
              </TouchableOpacity>
            </View>
            <Text
              style={
                stateVal.about_us && stateVal.about_us.length === 0
                  ? null
                  : ProfileStyle.ProfileDisc
              }>
              {stateVal.about_us && stateVal.about_us.replace(/\s+/g, ' ')}
            </Text>
          </View>
          <View
            style={{
              width: '100%',
              height: 0.8,
              backgroundColor: UiColor.Gray,
              marginTop: 5,
              marginBottom: 10,
              opacity: 0.2,
            }}></View>
          <>
            <TouchableOpacity
              onPress={() =>
                navigation.navigate('PostsUpload', {isUserPosts: true})
              }>
              <View
                style={{
                  flexDirection: 'row',
                  paddingHorizontal: 16,
                  marginBottom: 20,
                  marginTop: 15,
                }}>
                <View>
                  {stateVal.profile_image_path ? (
                    <Avatar.Image
                      style={{
                        marginRight: 10,
                        backgroundColor: UiColor.ImageLoad,
                      }}
                      size={35}
                      source={{
                        uri: stateVal.profile_image_path,
                      }}
                    />
                  ) : (
                    <Avatar.Image
                      style={{backgroundColor: UiColor.ImageLoad}}
                      size={40}
                      source={IconAsset.BlankUser}
                    />
                  )}
                </View>
                <TextInput
                  style={{
                    fontSize: 14,
                    textAlignVertical: 'top',
                    width: 250,
                    backgroundColor: UiColor.White,
                    bottom: 15,
                  }}
                  placeholder="Write some caption..."
                  placeholderTextColor={
                    Platform.OS === 'ios' ? UiColor.Black : '#536471'
                  }
                  underlineColor="transparent"
                  disabled
                />
                <Icon
                  name="gallery"
                  size={26}
                  color={UiColor.Gray}
                  style={{marginHorizontal: 15, marginTop: 10}}
                />
              </View>
            </TouchableOpacity>
            <View
              style={{
                width: '100%',
                height: 0.8,
                backgroundColor: UiColor.Gray,
                marginTop: 15,
                opacity: 0.2,
              }}></View>
          </>
        </>
      )}

      <></>
    </>
  );
  return (
    <>
      <>
        {!isConnected && postsData && postsData.length === 0 ? (
          <View style={[GlobalStyles.NoData, {marginTop: 80}]}>
            <Icon name="no-connection" size={50} />
            <Text style={[GlobalStyles.NoDataMsg, {fontFamily: Dm.semiBold}]}>
              No Internet Connection
            </Text>
          </View>
        ) : (
          <>
            {Object.keys(postsData).length === 0 && isLoadingMore ? (
              <SkeletonPlaceholder>
                {[...Array(4)].map((_, index) => (
                  <SkeletonPlaceholder.Item
                    key={index}
                    flexDirection="row"
                    alignItems="center"
                    marginBottom={0}
                    marginTop={20}
                    marginHorizontal={18}>
                    <SkeletonPlaceholder.Item
                      width="100%"
                      height={200}
                      borderRadius={6}
                    />
                  </SkeletonPlaceholder.Item>
                ))}
              </SkeletonPlaceholder>
            ) : (
              <FlatList
                ref={flatListRef}
                data={postsData}
                showsVerticalScrollIndicator={false}
                ListHeaderComponent={renderPostItem(userDetails)}
                renderItem={({item, index}) => (
                  <ListItem item={item} index={index} />
                )}
                keyExtractor={item => item._id.toString()} // Assuming each post has a unique _id
                refreshing={stateValue.refreshing}
                onRefresh={handleRefresh}
                ListEmptyComponent={() => {
                  if (postsData && postsData.length === 0 && !isLoadingMore) {
                    return (
                      <View style={[GlobalStyles.NoData, {marginTop: 20}]}>
                        <Text style={GlobalStyles.NoDataMsg}>
                          No Posts Found
                        </Text>
                      </View>
                    );
                  }
                  return null;
                }}
                onEndReachedThreshold={0.5}
              />
            )}
            {postsData &&
              postsData.map((item, index) => (
                <RBSheet
                  key={index}
                  ref={ref => (refCommentSheet.current[item._id] = ref)}
                  closeOnDragDown={true}
                  closeOnPressMask={true}
                  onClose={() => closeCommentSheet()}
                  openDuration={1000}
                  customStyles={{
                    wrapper: {
                      backgroundColor: '#00000024',
                    },
                    draggableIcon: {
                      backgroundColor: '#000',
                    },
                    container: {
                      height: '55%',
                    },
                  }}>
                  <FlatList
                    data={commentData?.result}
                    keyExtractor={commentItem => commentItem._id}
                    showsVerticalScrollIndicator={false}
                    ListEmptyComponent={() => (
                      <View style={GlobalStyles.NoData}>
                        <Text style={GlobalStyles.NoDataMsg}>
                          No Comments Found
                        </Text>
                      </View>
                    )}
                    renderItem={({item: commentItem}) => {
                      const hasChildComments = commentData?.result.some(
                        c => c.parent_comment_id === commentItem._id,
                      );
                      const formatTime = moment(
                        commentItem.created_at,
                        'DD MM YYYY hh:mm:ss a',
                      ).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');

                      const fromNowTime = moment(formatTime).fromNow();
                      return (
                        <>
                          {commentItem.parent_comment_id === null && (
                            <View
                              style={[StoryBoardStyle.CommentWrap]}
                              key={commentItem._id}>
                              <TouchableOpacity
                                style={[StoryBoardStyle.ProfileCta]}
                                onPress={() =>
                                  navigateToProfile({
                                    user_id: commentItem.user_id._id,
                                    story_id: item._id,
                                  })
                                }>
                                {commentItem.user_id?.profile_image?.path ? (
                                  <Avatar.Image
                                    style={{backgroundColor: UiColor.ImageLoad}}
                                    size={40}
                                    source={{
                                      uri: commentItem.user_id.profile_image
                                        .path,
                                    }}
                                  />
                                ) : (
                                  <Avatar.Image
                                    style={{backgroundColor: UiColor.ImageLoad}}
                                    size={40}
                                    source={IconAsset.BlankUser}
                                  />
                                )}
                              </TouchableOpacity>
                              <TouchableOpacity style={{width: '100%'}}>
                                <View style={StoryBoardStyle.CommentCardHead}>
                                  <View style={StoryBoardStyle.CommentCard}>
                                    <View
                                      style={StoryBoardStyle.CommentCardTitle}>
                                      <Text
                                        style={StoryBoardStyle.CommentTitle}>
                                        {commentItem?.user_id.first_name +
                                          ' ' +
                                          commentItem?.user_id.last_name}
                                      </Text>
                                      <Text style={StoryBoardStyle.CommentDate}>
                                        {fromNowTime}
                                      </Text>
                                    </View>
                                    <Text style={StoryBoardStyle.CommentText}>
                                      {commentItem.text_comment}
                                    </Text>
                                  </View>
                                  <View style={StoryBoardStyle.CommentRange}>
                                    {commentItem &&
                                    commentItem.like_count === 0 ? (
                                      ''
                                    ) : (
                                      <Text
                                        style={
                                          StoryBoardStyle.CommentRangeText
                                        }>
                                        {commentItem.like_count}
                                      </Text>
                                    )}
                                    {commentItem.likes?.some(
                                      like => like.user_id === stateVal.id,
                                    ) ? (
                                      <TouchableOpacity
                                        onPress={() => {
                                          dislikePost({
                                            story_id: item._id,
                                            isCommentDislike: true,
                                            like_id: commentItem.likes.find(
                                              like =>
                                                like.user_id === stateVal.id,
                                            )._id,
                                          });
                                        }}>
                                        <Text
                                          style={
                                            StoryBoardStyle.CommentRangeText
                                          }>
                                          Unlike
                                        </Text>
                                      </TouchableOpacity>
                                    ) : (
                                      <TouchableOpacity
                                        onPress={() => {
                                          postCommentLike({
                                            story_id: item._id,
                                            comment_id: commentItem._id,
                                          });
                                        }}>
                                        <Text
                                          style={
                                            StoryBoardStyle.CommentRangeText
                                          }>
                                          Like
                                        </Text>
                                      </TouchableOpacity>
                                    )}
                                    <TouchableOpacity
                                      onPress={() => {
                                        setCommentItems({
                                          comment_id: commentItem._id,
                                          fullName:
                                            commentItem.user_id.first_name +
                                            ' ' +
                                            commentItem.user_id.last_name,
                                        });
                                        setFormData({
                                          ...formData,
                                          comment: `@${commentItem.user_id.first_name} ${commentItem.user_id.last_name} `,
                                          isReply: true,
                                        });
                                        commentInputRef.current &&
                                          commentInputRef.current.focus();
                                      }}>
                                      <Text
                                        style={
                                          StoryBoardStyle.CommentRangeText
                                        }>
                                        Reply
                                      </Text>
                                    </TouchableOpacity>
                                    {commentItem.user_id._id === stateVal.id ||
                                    item.user.id === stateVal.id ? (
                                      <TouchableOpacity
                                        onPress={() => {
                                          handleDeletePress({
                                            story_id: item._id,
                                            comment_id: commentItem._id,
                                            isComment: true,
                                          });
                                        }}>
                                        <Text
                                          style={
                                            StoryBoardStyle.CommentRangeText
                                          }>
                                          Delete
                                        </Text>
                                      </TouchableOpacity>
                                    ) : (
                                      ''
                                    )}
                                  </View>
                                  {hasChildComments && (
                                    <>
                                      <TouchableOpacity
                                        onPress={() =>
                                          toggleRepliesVisibility(
                                            commentItem._id,
                                          )
                                        }>
                                        <Text
                                          style={[
                                            StoryBoardStyle.CommentCount,
                                            {
                                              marginTop: expandedComments[
                                                commentItem._id
                                              ]
                                                ? 0
                                                : 8,
                                            },
                                          ]}>
                                          {expandedComments[commentItem._id]
                                            ? ''
                                            : 'View more replies...'}
                                        </Text>
                                      </TouchableOpacity>
                                      {/* Reply */}
                                      {expandedComments[commentItem._id] &&
                                        renderReplies(
                                          {
                                            story_id: item._id,
                                            comment_id: commentItem._id,
                                            user_id: item.user.id,
                                          },
                                          commentData,
                                        )}
                                      {expandedComments[commentItem._id] && (
                                        <TouchableOpacity
                                          onPress={() =>
                                            toggleRepliesVisibility(
                                              commentItem._id,
                                            )
                                          }>
                                          <Text
                                            style={
                                              StoryBoardStyle.CommentCount
                                            }>
                                            Hide replies
                                          </Text>
                                        </TouchableOpacity>
                                      )}
                                    </>
                                  )}
                                </View>
                              </TouchableOpacity>
                            </View>
                          )}
                        </>
                      );
                    }}
                    ListFooterComponent={() => {
                      {
                        isFetchingNewComments && (
                          <View>
                            <ActivityIndicator
                              animating={true}
                              size={32}
                              color={UiColor.BaseColor}
                            />
                          </View>
                        );
                      }
                    }}
                  />
                  <KeyboardAvoidingView
                    behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                    style={{
                      position: 'fixed',
                      bottom: 0,
                      ...Platform.select({
                        ios: {
                          bottom: 25,
                        },
                      }),
                      left: 0,
                      backgroundColor: '#fff',
                      width: '100%',
                      paddingVertical: 20,
                      paddingHorizontal: 16,
                      shadowColor: '#000',
                      shadowOffset: {
                        width: 0,
                        height: -20,
                      },
                      shadowOpacity: 0.1,
                      shadowRadius: 0,
                      elevation: 20,
                      ...Platform.select({
                        ios: {
                          shadowOffset: {
                            height: -5,
                          },
                          shadowRadius: 3.84,
                        },
                      }),
                    }}>
                    <View style={{flexDirection: 'row', alignItems: 'center'}}>
                      <View style={{width: '100%'}}>
                        <TextInput
                          placeholder={'Write a comment...'}
                          value={formData.comment}
                          ref={commentInputRef}
                          style={[StoryBoardStyle.FormInput]}
                          textColor={UiColor.PrimaryColor}
                          theme={StoryBoardStyle.TextInput}
                          onChangeText={text => {
                            const usernameExists =
                              commentItems && text.includes(`@${commentItems.fullName}`);
                            setFormData({
                              ...formData,
                              comment: text,
                              isReply: usernameExists,
                            });
                          }}
                          underlineStyle={{backgroundColor: 'transparent'}}
                          autoCapitalize="none"
                        />
                        <TouchableOpacity
                          style={{position: 'absolute', top: 0, right: 0}}
                          onPress={() => {
                            postCommentOrReply({
                              story_id: item._id,
                              comment_id: commentItems,
                            });
                          }}>
                          {isSubmit ? (
                            <ActivityIndicator
                              style={{width: 39, height: 39, top: 8, right: 8}}
                            />
                          ) : (
                            <Image
                              source={IconAsset.Share}
                              style={{width: 39, height: 39, top: 8, right: 8}}
                            />
                          )}
                        </TouchableOpacity>
                      </View>
                    </View>
                  </KeyboardAvoidingView>
                </RBSheet>
              ))}
          </>
        )}
      </>
    </>
  );
};

export default UserPosts;
