import { View, Text, Image, ImageBackground, TouchableOpacity, KeyboardAvoidingView, Platform, StatusBar, ScrollView } from 'react-native';
import { editUserProfile, profileImgUploadThunk, coverImgUploadThunk, removeProfileImage, removeCoverImage} from '../../thunk';
import { TextInput, HelperText, Appbar, Avatar, ActivityIndicator, IconButton } from 'react-native-paper';
import {Styles, Icon, IconAsset, UiColor, GlobalStyles, Dm} from '../../../theme/Index';
import { setProfileImagePath, setCoverImagePath } from '../../slices/login';
import { LoginStyle } from '../../screens/auth/login/LoginStyle';
import React, { useState, useEffect, useRef } from 'react';
import ImagePicker from 'react-native-image-crop-picker';
import { useDispatch, useSelector } from 'react-redux';
import RBSheet from 'react-native-raw-bottom-sheet';
import { ReAuthenticateThunk } from '../../thunk';
import { ProfileStyle } from './ProfileStyle';

const UserProfileEdit = ({ navigation }) => {
  const dispatch = useDispatch();
  const stateVal = useSelector(state => state.login);
  const userProfileId = stateVal.profile_image;
  const userCoverId = stateVal.cover_image;
  const refSheet = useRef();
  const [selectedImageUri, setSelectedImageUri] = useState('');
  const [coverProfileUri, setCoverProfileUri] = useState('');
  const [profileImageId, setProfileImageId] = useState('');
  const [coverImageId, setCoverImageId] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(true);
  const [inProcess, setInProcess] = useState(false);
  const [formErrors, setFormErrors] = useState({});
  const [selectedSheet, setSelectedSheet] = useState(null);
  const [combinedName, setCombinedName] = useState('');
  const [formData, setFormData] = useState({
    id: stateVal.id,
    name: combinedName,
    first_name: '',
    last_name: '',
    email: '',
    address: '',
    about_us: '',
    profile_image: '',
    cover_image: '',
  });
  useEffect(() => {
    if (userProfileId || userCoverId) {
      setProfileImageId(userProfileId);
      setCoverImageId(userCoverId);
    }
    setFormData({
      id: stateVal.id,
      name: combinedName,
      first_name: stateVal.first_name,
      last_name: stateVal.last_name,
      email: stateVal.email,
      address: stateVal.address,
      about_us: stateVal.about_us,
      profile_image: profileImageId,
      cover_image: coverImageId,
    });
    if (stateVal.profile_image_path && stateVal.cover_image_path) {
      setSelectedImageUri(stateVal.profile_image_path);
      setCoverProfileUri(stateVal.cover_image_path);
    }
    setCombinedName(`${stateVal.first_name} ${stateVal.last_name}`);
  }, [stateVal]);

  const hasErrors = () => {
    const errors = {};
    if (formData.first_name.length === 0) {
      errors.first_name = 'Name is required';
    }
    if (formData.email.length === 0) {
      errors.email = 'Email is required';
    } else if (formData.email.length && !formData.email.includes('@')) {
      errors.email = 'Invalid email';
    }

    setFormErrors(errors);

    return Object.keys(errors).length > 0;
  };

  const updateUser = async () => {
    if (hasErrors()) {
      return;
    }
    setFormErrors({});
    setInProcess(true);
    const params = {
      user_id: stateVal.id,
      name: combinedName,
      first_name: formData.first_name,
      last_name: formData.last_name,
      address: formData.address,
      about_us: formData.about_us,
      profile_image: profileImageId,
      cover_image: coverImageId,
    };
    const resultAction = await dispatch(editUserProfile(params));
    if (editUserProfile.fulfilled.match(resultAction)) {
      dispatch(ReAuthenticateThunk());
      navigation.navigate('Dashboard');
      setInProcess(false);
    } else {
      setInProcess(false);
    }
  };

  const openImagePickerWithCrop = async isProfileImage => {
    try {
      const image = await ImagePicker.openPicker({
        cropping: true,
        cropperCircleOverlay: false,
        compressImageQuality: 0.8,
        width: 300,
        height: 300,
        mediaType: 'photo',
      });
      if (image) {
        if (isProfileImage) {
          const profileImageFile = image.path
            ? {
              fileCopyUri: null,
              name: 'profile_image.jpg',
              size: 0,
              type: 'image/jpeg',
              uri: image.path,
            }
            : null;
          const params = {
            profile_image: profileImageFile,
          };
          refSheet.current.close();
          const resultAction = await dispatch(profileImgUploadThunk(params));
          if (profileImgUploadThunk.fulfilled.match(resultAction)) {
            const profileId =
              resultAction.payload.data && resultAction.payload.data._id
                ? resultAction.payload.data._id
                : resultAction.payload.data._id;
            setSelectedImageUri(
              resultAction.payload.data && resultAction.payload.data.path
                ? resultAction.payload.data.path
                : resultAction.payload.data.path,
            );
            setProfileImageId(profileId);
          } else {
            setSelectedImageUri('');
          }
        } else {
          const coverImageFile = image.path
            ? {
              fileCopyUri: null,
              name: 'cover_image.jpg',
              size: 0,
              type: 'image/jpeg',
              uri: image.path,
            }
            : null;
          const params = {
            cover_image: coverImageFile,
          };
          refSheet.current.close();
          const resultAction = await dispatch(coverImgUploadThunk(params));
          if (coverImgUploadThunk.fulfilled.match(resultAction)) {
            const coverId =
              resultAction.payload.data && resultAction.payload.data._id
                ? resultAction.payload.data._id
                : resultAction.payload.data._id;
            setCoverProfileUri(
              resultAction.payload.data && resultAction.payload.data.path
                ? resultAction.payload.data.path
                : resultAction.payload.data.path,
            );
            setCoverImageId(coverId);
          } else {
            setCoverProfileUri('');
          }
        }
      }
      refSheet.current.close();
      refSheet.current.close();
    } catch (error) {
      refSheet.current.close();
      refSheet.current.close();
    }
  };
  const removeImage = async isRemoveImage => {
    if (isRemoveImage) {
      const params = { media_id: profileImageId };
      const resultAction = await dispatch(removeProfileImage(params));
      if (removeProfileImage.fulfilled.match(resultAction)) {
        dispatch(setProfileImagePath(null));
        setSelectedImageUri('');
        dispatch(ReAuthenticateThunk());
        refSheet.current.close();
      } else {
        refSheet.current.close();
      }
    } else {
      const params = { media_id: coverImageId };
      const resultAction = await dispatch(removeCoverImage(params));
      if (removeCoverImage.fulfilled.match(resultAction)) {
        dispatch(setCoverImagePath(null));
        setCoverProfileUri('');
        dispatch(ReAuthenticateThunk());
        refSheet.current.close();
      } else {
        refSheet.current.close();
      }
    }
  };
  return (
    <>
      <StatusBar barStyle="light-content" />
      <Appbar.Header style={[Styles.AppbarHeader, ProfileStyle.UserProfileBar]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{ backgroundColor: UiColor.SecondaryColor }}
          icon={() => (
            <Icon name="back" size={18} style={Styles.BackWhite} />
          )}
        />
        <Appbar.Action
          animated={false}
          size={24}
          rippleColor="#00000008"
          style={{ backgroundColor: '#fff' }}
          onPress={() => {setSelectedSheet('cover');
          refSheet.current.open();
        }}
          icon={() => (
            <Icon name="pencil" size={18} style={UiColor.PrimaryColor} />
          )}
        />
      </Appbar.Header>
        <RBSheet
          ref={refSheet}
          closeOnDragDown={true}
          closeOnPressMask={true}
          customStyles={{
            wrapper: {
              backgroundColor: '#100f4d3d',
            },
            draggableIcon: {
              backgroundColor: '#E3E3E3',
              marginTop: 10,
            },
            container: {
              backgroundColor: '#fff',
              borderTopLeftRadius: 30,
              borderTopRightRadius: 30
            },
          }}>
          {selectedSheet === 'cover' && (
            <>
              <View style={{ paddingVertical: 50 }}>
                <View style={[Styles.CardFoot,]}>
                  <TouchableOpacity
                    style={[ProfileStyle.BtnFileUpload]}
                    onPress={() => openImagePickerWithCrop(false)}>
                    <Text style={ProfileStyle.BtnFileUploadText}>New Cover Profile Picture</Text>
                  </TouchableOpacity>
                </View>
                <View style={Styles.CardFoot}>
                  <TouchableOpacity
                    style={[Styles.BtnFileUpload]}
                    onPress={() => removeImage(false)}>
                    <Text style={ProfileStyle.BtnFileUploadText}>Remove Picture</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </>
          )}

          {selectedSheet === 'profile' && (
            <>
              <View style={{ paddingVertical: 50 }}>
                <View style={[Styles.CardFoot,]}>
                  <TouchableOpacity
                    style={[ProfileStyle.BtnFileUpload]}
                    onPress={() => openImagePickerWithCrop(true)}>
                    <Text style={ProfileStyle.BtnFileUploadText}>New Profile Picture</Text>
                  </TouchableOpacity>
                </View>
                <View style={Styles.CardFoot}>
                  <TouchableOpacity
                    style={[Styles.BtnFileUpload]}
                    onPress={() => removeImage(true)}>
                    <Text style={ProfileStyle.BtnFileUploadText}>Remove Picture</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </>
          )}
        </RBSheet>
      <ImageBackground
        source={
          coverProfileUri
            ? { uri: coverProfileUri }
            : stateVal.cover_image_path
              ? { uri: stateVal.cover_image_path }
              : IconAsset.Splash
        }
        resizeMode="cover"
        style={ProfileStyle.UserProfileBg}>
          <View style={Styles.BannerOverlay}></View>
        </ImageBackground>
      <View style={{ position: 'relative', width: 120, marginBottom: 34 }}>
        <Avatar.Image
          style={[
            ProfileStyle.ProfileAvatar,
            GlobalStyles.mb0,
            { marginTop: 40, backgroundColor: UiColor.ImageLoad },
          ]}
          size={113}
          source={
            selectedImageUri
              ? { uri: selectedImageUri }
              : stateVal.profile_image_path
                ? { uri: stateVal.profile_image_path }
                : IconAsset.BlankUser
          }
        />
        <IconButton
           onPress={() => { setSelectedSheet('profile');
           refSheet.current.open();
          }}
          icon={() => <Icon name="pencil" size={18} style={{ color: '#fff' }} />}
          size={40}
          style={ProfileStyle.EditProfileIcon}
        />
      </View>
      
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 700}>
          <ScrollView  showsVerticalScrollIndicator={false}>
              <View
                style={[
                  Styles.Container,
                  { backgroundColor: 'transparent', paddingHorizontal: 30, paddingBottom: 10, marginBottom: Platform.OS === 'ios' ? 10 : 280},
                ]}>
                <View>
                  <View style={LoginStyle.FormControl}>
                    <TextInput
                      label="Full Name"
                      value={combinedName}
                      onChangeText={text => {
                        setFormErrors({ ...formErrors, first_name: '' }),
                          setCombinedName(text);
                        setFormData(prevFormData => {
                          const nameParts = text.split(' ');
                          return {
                            ...prevFormData,
                            first_name: nameParts[0] || '',
                            last_name: nameParts.slice(1).join(' ') || '',
                            name: text,
                          };
                        });
                      }}
                      theme={LoginStyle.TextInput}
                      style={[
                        LoginStyle.FormInput,
                        {
                          borderColor: formErrors.first_name
                            ? UiColor.SecondaryColor
                            : UiColor.GrayLight,
                        },
                      ]}
                      textColor={UiColor.PrimaryColor}
                      underlineStyle={{ backgroundColor: 'transparent' }}
                      autoCapitalize="none"
                      left={
                        <TextInput.Icon
                          style={LoginStyle.RightBorder}
                          icon={() => (
                            <Icon
                              name="user"
                              color={
                                formErrors.first_name
                                  ? UiColor.SecondaryColor
                                  : UiColor.GrayLight
                              }
                              size={18}
                            />
                          )}
                        />
                      }
                    />
                    <HelperText
                      type="error"
                      style={Styles.ErrorMsg}
                      visible={formErrors.first_name !== undefined}>
                      {formErrors.first_name}
                    </HelperText>
                  </View>
                  <View style={LoginStyle.FormControl}>
                    <TextInput
                      label="Email"
                      value={stateVal.email}
                      onChangeText={text => {
                        setFormErrors({ ...formErrors, email: '' }),
                          setFormData({ ...formData, email: text });
                      }}
                      editable={false}
                      theme={LoginStyle.TextInput}
                      style={[
                        LoginStyle.FormInput,
                        {
                          borderColor: formErrors.email
                            ? UiColor.SecondaryColor
                            : UiColor.GrayLight,
                        },
                      ]}
                      textColor={UiColor.PrimaryColor}
                      underlineStyle={{ backgroundColor: 'transparent' }}
                      autoCapitalize="none"
                      left={
                        <TextInput.Icon
                          style={LoginStyle.RightBorder}
                          icon={() => (
                            <Icon
                              name="sms"
                              color={
                                formErrors.email
                                  ? UiColor.SecondaryColor
                                  : UiColor.GrayLight
                              }
                              size={18}
                            />
                          )}
                        />
                      }
                      keyboardType="email-address"
                    />
                    <HelperText
                      type="error"
                      style={Styles.ErrorMsg}
                      visible={formErrors.email !== undefined}>
                      {formErrors.email}
                    </HelperText>
                  </View>
                  <View style={LoginStyle.FormControl}>
                    <TextInput
                      label="Password"
                      value={'********'}
                      editable={false}
                      theme={LoginStyle.TextInput}
                      style={[
                        LoginStyle.FormInput,
                        {
                          borderColor: formErrors.password
                            ? UiColor.SecondaryColor
                            : UiColor.GrayLight,
                        },
                      ]}
                      textColor={UiColor.PrimaryColor}
                      underlineColor="transparent"
                      underlineStyle={{ backgroundColor: 'transparent' }}
                      secureTextEntry={passwordVisible}
                      right={
                        <TextInput.Icon
                          icon={() => (
                            <Icon
                              name="edit2"
                              style={LoginStyle.TextInputIcon}
                              size={20}
                            />
                          )}
                          onPress={() =>
                            navigation.navigate('ChangePassword', stateVal.email)
                          }
                        />
                      }
                      left={
                        <TextInput.Icon
                          style={LoginStyle.RightBorder}
                          icon={() => (
                            <Icon
                              name="lock"
                              color={
                                formErrors.password
                                  ? UiColor.SecondaryColor
                                  : UiColor.GrayLight
                              }
                              size={18}
                            />
                          )}
                        />
                      }
                    />
                    <HelperText
                      type="error"
                      style={Styles.ErrorMsg}
                      visible={formErrors.password !== undefined}>
                      {formErrors.password}
                    </HelperText>
                  </View>
                  <View style={LoginStyle.FormControl}>
                    <TextInput
                      label="Location"
                      value={formData.address}
                      onChangeText={text => {
                        setFormErrors({ ...formErrors, address: '' }),
                          setFormData({ ...formData, address: text });
                      }}
                      theme={LoginStyle.TextInput}
                      style={[
                        LoginStyle.FormInput,
                        {
                          borderColor: formErrors.email
                            ? UiColor.SecondaryColor
                            : UiColor.GrayLight,
                        },
                      ]}
                      textColor={UiColor.PrimaryColor}
                      underlineStyle={{ backgroundColor: 'transparent' }}
                      autoCapitalize="none"
                      left={
                        <TextInput.Icon
                          style={LoginStyle.RightBorder}
                          icon={() => (
                            <Icon
                              name="location1"
                              color={
                                formErrors.email
                                  ? UiColor.SecondaryColor
                                  : UiColor.GrayLight
                              }
                              size={18}
                            />
                          )}
                        />
                      }
                      keyboardType="email-address"
                    />
                    <HelperText
                      type="error"
                      style={Styles.ErrorMsg}
                      visible={formErrors.address !== undefined}>
                      {formErrors.address}
                    </HelperText>
                  </View>
                  <View style={LoginStyle.FormControl}>
                    <TextInput
                      label="Bio"
                      multiline={true}
                      value={formData.about_us}
                      onChangeText={text => {
                        if (text.length <= 200) {
                        setFormErrors({ ...formErrors, about_us: '' }),
                          setFormData({ ...formData, about_us: text });
                        } else {
                          setFormErrors({
                            ...formErrors,
                            about_us: 'Bio must be 200 characters or less',
                          });
                        }
                      }}
                      theme={LoginStyle.TextInput}
                      style={[
                        LoginStyle.FormInput,
                        {
                          borderColor: formErrors.about_us
                            ? UiColor.SecondaryColor
                            : UiColor.GrayLight,
                        },
                      ]}
                      textColor={UiColor.PrimaryColor}
                      underlineStyle={{ backgroundColor: 'transparent' }}
                      autoCapitalize="none"
                      left={
                        <TextInput.Icon
                          style={LoginStyle.RightBorder}
                          icon={() => (
                            <Icon
                              name="user-edit"
                              color={
                                formErrors.about_us
                                  ? UiColor.SecondaryColor
                                  : UiColor.GrayLight
                              }
                              size={18}
                            />
                          )}
                        />
                      }
                    />
                    <HelperText
                      type="error"
                      style={Styles.ErrorMsg}
                      visible={formErrors.about_us !== undefined}>
                      {formErrors.about_us}
                    </HelperText>
                  </View>
                </View>
                <TouchableOpacity
                  onPress={() => updateUser()}
                  disabled={inProcess}
                  style={[LoginStyle.Btn, { marginTop: 10 }]}
                  loading={inProcess}>
                  <Text style={LoginStyle.BtnText}>
                    {inProcess ? (
                      <ActivityIndicator
                        size={24}
                        color="#fff"
                      />
                    ) : (
                      'Save'
                    )}
                  </Text>
                </TouchableOpacity>
              </View>
              </ScrollView>
        </KeyboardAvoidingView>
    </>
  );
};

export default UserProfileEdit;
