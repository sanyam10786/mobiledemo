/* eslint-disable prettier/prettier */
import { StyleSheet, Platform } from 'react-native';
import { UiColor, Dm } from '../../../theme/Index';


export const ProfileStyle = StyleSheet.create({
    UserProfileBar: {
        justifyContent: 'space-between',
        backgroundColor: 'transparent',
    },
    UserProfileBg: {
        width: '100%',
        height: 211,
        position: 'absolute',
        top: 0,
    },
    UserProfileCont: {
        paddingHorizontal: 24,
    },
    ProfileAvatar: {
        marginTop: 20,
        marginLeft: 24,
        marginBottom: 21,
    },
    UserTitle: {
        fontSize: 26,
        fontFamily: Dm.regular,
        color: UiColor.PrimaryColor,
    },
    UserEmail: {
        fontSize: 12,
        fontFamily: Dm.regular,
        color: UiColor.PrimaryColor,
        marginTop: 4,
    },
    UserCountList: {
        marginRight: 38,
    },
    UserCountHead: {
        flexDirection: 'row',
        alignItems: 'center',
        marginTop: 30,
        flexWrap: 'wrap',
    },
    UserCountNo: {
        fontSize: 24,
        fontFamily: Dm.regular,
        color: UiColor.PrimaryColor,
    },
    UserCountText: {
        fontSize: 14,
        fontFamily: Dm.regular,
        color: UiColor.PrimaryColor,
    },
    ProfileDisc: {
        fontSize: 14,
        fontFamily: Dm.regular,
        color: UiColor.PrimaryColor,
        marginTop: 30,
    },
    ProfileDiscT: {
        fontSize: 14,
        fontFamily: Dm.medium,
        color: UiColor.PrimaryColor,
    },
    ProfileImgList: {
        flexDirection: 'row',
        marginHorizontal: -1.5,
        marginTop: 36,
        flexWrap: 'wrap',
        overflow: 'hidden',
    },
    ProfileImgHead: {
        paddingHorizontal: 1.5,
        width: '33.333%',
        marginBottom: 3,
    },
    ProfileImg: {
        width: '100%',
        height: 114,
        objectFit: 'cover',
    },
    EditProfileIcon: {
        position: 'absolute',
        bottom: -22,
        backgroundColor: UiColor.PrimaryColor,
        borderWidth: 4,
        borderColor: '#fff',
        right: -32
    },
    BtnFileUpload: {
        alignItems: 'center',
        marginBottom: 30
    },
    BtnFileUploadText: {
        fontSize: 16,
        fontFamily: Dm.semiBold,
        color: UiColor.PrimaryColor,
        textAlign: 'center',
    },
});


