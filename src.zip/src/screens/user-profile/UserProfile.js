import { View, Text, TouchableOpacity, ScrollView, Image, ImageBackground, Platform, Modal } from 'react-native';
import { Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm } from '../../../theme/Index';
import { useIsFocused, useNavigation, useRoute } from '@react-navigation/native';
import { Appbar, Avatar, ActivityIndicator, TextInput } from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import { ReAuthenticateThunk, fetchUserPosts } from '../../thunk';
import React, { useEffect, useState, useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { NetworkContext } from '../../NetworkContext';
import PTRView from 'react-native-pull-to-refresh';
import ImageView from 'react-native-image-viewing';
import UserPosts from './UserPosts';
import { ProfileStyle } from './ProfileStyle';

const UserProfile = ({ navigation }) => {
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const stateVal = useSelector(state => state.login);
  const stateValue = useSelector(state => state.posts);
  const posts = stateValue && stateValue.items;
  const isConnected = useContext(NetworkContext);
  const [isLoad, setIsLoad] = useState(false);
  const route = useRoute();
  const [offlineData, setOfflineData] = useState('');
  const [isVisible, setIsVisible] = useState(false);
  const ProfileImages = [stateVal && stateVal.profile_image_path ? { uri: stateVal && stateVal.profile_image_path } : IconAsset.BlankUser];

  useEffect(() => {
    if (isConnected && isFocused) {
      fetchAllPosts();
    }
    fetchOfflineInfo();
  }, [isConnected, isFocused]);

  const fetchOfflineInfo = async () => {
    try {
      const [userObjString] = await Promise.all([
        AsyncStorage.getItem('USER_DATA'),
      ]);
      let userData = '';
      if (userObjString) {
        const userObj = JSON.parse(userObjString);
        userData = userObj?.data?.user|| '';
      }
    
      setOfflineData(userData);
    } catch (err) {
      console.error('Error fetching user or drafts:', err);
      setOfflineData('');
    }
  };

  const params = {
    user_id: stateVal.id,
    name: stateVal.first_name + " " + stateVal.last_name,
  };

  const fetchAllPosts = async () => {
    setIsLoad(true);
    const params = { user_id: stateVal.id ? stateVal.id : offlineData._id };
    try {
      await dispatch(fetchUserPosts(params));
    } catch (error) {
      setIsLoad(false);
      console.error('Error in fetchAllPosts:', error);
    }
    setIsLoad(false);
  };

  const viewImage = () => {
    setIsVisible(true);
  };

  return (
    <>
      <Appbar.Header style={[Styles.AppbarHeader, ProfileStyle.UserProfileBar]}>
        {isVisible &&  <View style={{color: 'black',backgroundColor : 'black', bottom: 55, width: 500, height: 80, position: 'absolute'}}>
          <Text></Text>
        </View>}
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{ backgroundColor: UiColor.SecondaryColor }}
          icon={() => (
            <Icon name="back" size={18} style={Styles.BackWhite} />
          )}
        />
        <Appbar.Action
          animated={false}
          size={30}
          rippleColor="#00000008"
        />
      </Appbar.Header>
      <ImageBackground
        source={stateVal.cover_image_path ? { uri: stateVal.cover_image_path } : IconAsset.Splash}
        resizeMode="cover"
        style={ProfileStyle.UserProfileBg}>
        <View style={Styles.BannerOverlay}></View>
      </ImageBackground>
      <TouchableOpacity onPress={viewImage} style={{ marginTop: 40, width: 135, height: 135 }}>
        {stateVal.profile_image_path ? (
          <Avatar.Image
            style={[ProfileStyle.ProfileAvatar, GlobalStyles.mb0, {backgroundColor: UiColor.ImageLoad}]}
            size={113}
            source={{
              uri: stateVal.profile_image_path,
            }}
          />
        ) : (
          <Avatar.Image
            style={[ProfileStyle.ProfileAvatar, GlobalStyles.mb0, {backgroundColor: UiColor.ImageLoad}]}
            size={113}
            source={IconAsset.BlankUser}
          />
        )}
      </TouchableOpacity>
      <Modal
        visible={isVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setIsVisible(false)}>
        <ImageView
          images={ProfileImages}
          visible={isVisible}
          onRequestClose={() => setIsVisible(false)}
        />
      </Modal>
      <UserPosts navigation={navigation} />
         {/* <TouchableOpacity
            onPress={() => navigation.navigate('PostsUpload', { isUserPosts: true })}
            style={[Styles.AddBtn, {marginBottom: 65}]}>
            <Icon name="plus" size={18} color={UiColor.White} />
          </TouchableOpacity> */}
      {route.params !== true && <View style={{ marginBottom: Platform.OS === 'ios' ? 95 : 85 }}></View>}
    </>
  );
};

export default UserProfile;
