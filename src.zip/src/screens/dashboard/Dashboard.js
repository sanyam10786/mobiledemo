import {
  View,
  Text,
  Image,
  TouchableOpacity,
  Platform,
  ImageBackground,
  PermissionsAndroid,
  ScrollView,
} from 'react-native';
import {NotificationListener} from '../../utils/pushnotification_helper';
import {Dm, Icon, IconAsset, Styles, UiColor} from '../../../theme/Index';
import {useIsFocused, useNavigation} from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import {ReAuthenticateThunk, addFcmTokenNotification, fetchMyFriends} from '../../thunk';
import {Appbar, IconButton, Avatar} from 'react-native-paper';
import React, {useState, useEffect, useContext} from 'react';
import Geolocation from '@react-native-community/geolocation';
import {FriendsStyle} from '../add-friends/FriendsStyle';
import firestore from '@react-native-firebase/firestore';
import {useDispatch, useSelector} from 'react-redux';
import {NetworkContext} from '../../NetworkContext';
import {DashStyleNew} from './DashStyleNew';
import axios from 'axios';

const Dashboard = ({route, navigation}) => {
  const stateVal = useSelector(state => state.login);
  const keysData = useSelector(state => state.login.third_party_keys);
  const [weatherData, setWeatherData] = useState(null);
  const notification = stateVal.notification_count;
  const isConnected = useContext(NetworkContext);
  const [unreadCount, setUnreadCount] = useState(0);
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const [friendProfiles, setFriendProfiles] = useState();
  const [offlineData, setOfflineData] = useState('');
  const [IsLoading, setIsLoading] = useState(false);
  const [IsLoadWeather, setIsLoadWeather] = useState(false);
  const [hideCard, setHideCard] = useState(false);
  const [loadDrafts, setLoadDrafts] = useState('');
  const params = {
    user_id: stateVal.id,
    name: stateVal.first_name + ' ' + stateVal.last_name,
    friendsCount: stateVal && stateVal.total_friends,
  };
  const [timezone, setTimezone] = useState('');

  useEffect(() => {
    if (isFocused && stateVal.id) {
      checkAndAddFcmToken();
      checkAndRequestPermissions();
      fetchDrafts();
      fetchFriends();
      dispatch(ReAuthenticateThunk());
      ChatNotification();
      NotificationListener(stateVal.id, navigation);
    }
    if (isConnected && stateVal.id) {
      updateFirestoreStatus('Online');
    }

    fetchOfflineInfo();
    const fetchTimezone = async () => {
      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
      setTimezone(tz);
    };
    fetchTimezone();
  }, [isFocused, stateVal.id]);

  const checkAndRequestPermissions = async () => {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          getOneTimeLocation();
        } else {
          Alert.alert('Permission denied', 'Location permission is required to use this feature.');
        }
      } catch (err) {
        console.warn(err);
      }
    } else if (Platform.OS === 'ios') {
      // On iOS, permissions are managed via Info.plist
      getOneTimeLocation();
    }
 
  };
  
  const getOneTimeLocation = async () => {
    try {
      console.log('Geolocation');
      const position = await new Promise((resolve, reject) => {
        Geolocation.getCurrentPosition(resolve, reject);
      });
      console.log('position');
      const currentLongitude = JSON.stringify(position.coords.longitude);
      const currentLatitude = JSON.stringify(position.coords.latitude);
      fetchOpenWeatherWeekly(currentLatitude, currentLongitude);
    } catch (error) {
      getOneTimeLocation();
      if (error.code === 1) {
        console.log('Permission denied');
      } else if (error.code === 2) {
        console.log('Position unavailable');
      } else if (error.code === 3) {
        console.log('Timeout');
      } else {
        console.log('Other error', error);
      }
    }
  };

  const fetchOpenWeatherWeekly = async (latitude, longitude) => {
    setIsLoadWeather(true);
    const apiKey = keysData && keysData.weather;
    try {
      const response = await axios.get(
        'https://api.openweathermap.org/data/2.5/forecast',
        {
          params: {
            lat: latitude,
            lon: longitude,
            appid: apiKey,
            units: 'metric',
          },
        },
      );
      organizeWeatherData(response.data);
    } catch (error) {
     setIsLoadWeather(false);
      console.log('Error fetching weather data', error);
    }
  };
  const organizeWeatherData = data => {
    const filteredData = {
      city: {
        country: data.city.country,
        name: data.city.name,
      },
      list: data.list.map(item => ({
        dt_txt: item.dt_txt,
        main: {
          temp: item.main.temp,
          temp_max: item.main.temp_max,
          temp_min: item.main.temp_min,
        },
        weather: item.weather.map(weatherItem => ({
          description: weatherItem.description,
          main: weatherItem.main,
        })),
      })),
    };
    organizeWeather(filteredData);
  };

  const organizeWeather = data => {
    const groupedData = {};
    data.list.forEach(item => {
      const date = item.dt_txt.split(' ')[0];
      if (!groupedData[date]) {
        groupedData[date] = [];
      }
      groupedData[date].push(item);
    });

    const days = Object.keys(groupedData).map(date => ({
      date,
      data: groupedData[date],
    }));
    setWeatherData(days);
    setIsLoadWeather(false);
  };

  const updateFirestoreStatus = async status => {
    if (stateVal.id) {
      const userStatusRef = firestore()
        .collection('userStatus')
        .doc(stateVal.id);
      await userStatusRef.set(
        {
          status: status,
          user_id: stateVal.id,
          [status === 'Online' ? 'onlineTime' : 'offlineTime']:
            firestore.FieldValue.serverTimestamp(),
        },
        {merge: true},
      );
    }
  };

  const fetchOfflineInfo = async () => {
    try {
      const [userObjString] = await Promise.all([
        AsyncStorage.getItem('USER_DATA'),
      ]);
      let userData = '';
      if (userObjString) {
        const userObj = JSON.parse(userObjString);
        userData = userObj?.data?.user || '';
      }

      setOfflineData(userData);
    } catch (err) {
      console.error('Error fetching user or drafts:', err);
      setOfflineData('');
    }
  };

  const fetchFriends = async () => {
    try {
      const params = {user_id: stateVal.id};
      const resultAction = await dispatch(fetchMyFriends(params));
      if (fetchMyFriends.fulfilled.match(resultAction)) {
        const newData = resultAction.payload.data.friends;
        setFriendProfiles(newData);
        setIsLoading(true);
      }
    } catch (error) {
      console.error('Error in fetchFriends:', error);
    }
  };

  const ChatNotification = async () => {
    try {
      const loggedInUserId = stateVal.id;
      const chatListSnapshot = await firestore()
        .collection('chatlists')
        .where('receiverId', '==', loggedInUserId)
        .get();
      const chatListData = chatListSnapshot.docs.map(doc => doc.data());
      chatListData.map((obj, index) => {
        setUnreadCount(obj.unreadMessages);
      });
    } catch (error) {
      console.error('Error fetching chat list:', error);
    }
  };

  const fetchDrafts = async () => {
    try {
      const [userObjString, draftsString] = await Promise.all([
        AsyncStorage.getItem('USER_DATA'),
        AsyncStorage.getItem('catch_drafts'),
      ]);
      let userId = '';
      if (userObjString) {
        const userObj = JSON.parse(userObjString);
        userId = userObj?.data?.user?._id || '';
      }
      let drafts = draftsString ? JSON.parse(draftsString) : [];
      if (userId) {
        drafts = drafts.filter(draft => draft.user_id === userId);
      }
      setLoadDrafts(drafts);
    } catch (err) {
      console.error('Error fetching user or drafts:', err);
      setLoadDrafts([]);
    }
  };
  const convertCelsiusToFahrenheit = celsius => {
    return (celsius * 9) / 5 + 32;
  };

  const getWeatherImage = weatherType => {
    switch (weatherType) {
      case 'Clear':
        return IconAsset.Sunny;
      case 'Clouds':
        return IconAsset.Clouds;
      case 'Rain':
        return IconAsset.Rain;
      default:
        return IconAsset.PartlySunny;
    }
  };

  const checkAndAddFcmToken = async () => {
    const tokenAdded = await AsyncStorage.getItem('fcmTokenAdded');
    const tokenAdd = JSON.parse(tokenAdded);
    if (!tokenAdd) {
      addFcmToken();
    }
  };

  const addFcmToken = async () => {
    const fcmtoken = await AsyncStorage.getItem('fcmtoken');
    const data = {
      user_id: stateVal.id,
      fcm_device_token: fcmtoken,
    };
    const tokenData = await dispatch(addFcmTokenNotification(data));
    console.log('tokenData dasboard', tokenData.payload.data )
    await AsyncStorage.setItem('fcmTokenAdded', 'true');
  }
  return (
    <ImageBackground
      source={IconAsset.Bg4}
      resizeMode="cover"
      style={{flex: 1}}>
      <View style={{flex: 1, paddingBottom: 87}}>
        <Appbar.Header
          style={[
            Styles.AppbarHeader,
            Styles.AppBarShadow,
            {justifyContent: 'space-between', backgroundColor: 'transparent'},
          ]}>
          {!IsLoading && isConnected ? (
            <SkeletonPlaceholder>
              <SkeletonPlaceholder.Item
                width={43}
                height={43}
                borderRadius={21}
              />
            </SkeletonPlaceholder>
          ) : (
            <>
              {!isConnected ? (
                <Appbar.Action
                  animated={false}
                  size={30}
                  rippleColor="#00000008"
                  icon={() =>
                    offlineData &&
                    offlineData.profile_image &&
                    offlineData.profile_image.path ? (
                      <Avatar.Image
                        style={{backgroundColor: UiColor.ImageLoad}}
                        size={40}
                        source={{
                          uri:
                            offlineData &&
                            offlineData.profile_image &&
                            offlineData.profile_image.path,
                        }}
                      />
                    ) : (
                      <Avatar.Image style={{backgroundColor: UiColor.ImageLoad}} size={40} source={IconAsset.BlankUser} />
                    )
                  }
                  onPress={() => navigation.toggleDrawer()}
                />
              ) : (
                <Appbar.Action
                  animated={false}
                  size={30}
                  rippleColor="#00000008"
                  icon={() =>
                    stateVal.profile_image_path ? (
                      <Avatar.Image
                      style={{backgroundColor: UiColor.ImageLoad}}
                        size={40}
                        source={{uri: stateVal.profile_image_path}}
                      />
                    ) : (
                      <Avatar.Image style={{backgroundColor: UiColor.ImageLoad}} size={40} source={IconAsset.BlankUser} />
                    )
                  }
                  onPress={() => navigation.toggleDrawer()}
                />
              )}
            </>
          )}
          <View>
            <Image style={Styles.MenuLogo} source={IconAsset.DashLogo} />
          </View>
          <View style={{flexDirection: 'row'}}>
            <>
              <IconButton
                size={24}
                icon={() => (
                  <Icon
                    name="msg"
                    size={24}
                    color={UiColor.PrimaryColor}
                    onPress={() => navigation.navigate('ChatNotification')}
                  />
                )}
              />
              <Text style={DashStyleNew.unreadCount}>
                {unreadCount > 0 ? unreadCount : ''}
              </Text>
            </>
            <>
              <IconButton
                size={24}
                icon={() => (
                  <Icon
                    name="notification"
                    size={24}
                    color={UiColor.PrimaryColor}
                    onPress={() => navigation.navigate('Notification')}
                  />
                )}
              />
              <Text style={DashStyleNew.unreadCount}>
                {notification ? notification : null}
              </Text>
            </>
          </View>
        </Appbar.Header>
        <ScrollView contentContainerStyle={{flex: 1}}>
        <View style={{flex: 1, flexGrow: 1, marginTop: 5, paddingTop: 0}}>
          <View
            style={[
              Styles.Container, 
              {backgroundColor: 'transprent', justifyContent: 'center'},
            ]}>
            <View style={[DashStyleNew.DashTitleHead]}>
              <View style={DashStyleNew.Users}>
                <TouchableOpacity
                  onPress={() =>
                    navigation.navigate('MyFriendFriends', params)
                  }>
                  <View style={DashStyleNew.ImgBox}>
                    {!IsLoading && isConnected ? (
                      <SkeletonPlaceholder>
                        <SkeletonPlaceholder.Item flexDirection="row">
                          {Array.from({length: 3}).map((_, index) => (
                            <SkeletonPlaceholder.Item
                              key={index}
                              width={41}
                              height={43}
                              borderRadius={18}
                              borderWidth={2}
                              borderColor={UiColor.White}
                              marginLeft={index === 0 ? 0 : -12}
                            />
                          ))}
                        </SkeletonPlaceholder.Item>
                      </SkeletonPlaceholder>
                    ) : (
                      <>
                        {!isConnected && !friendProfiles
                          ? Array.from({length: 3}).map((_, index) => (
                              <Image
                                key={index}
                                style={
                                  index === 0
                                    ? DashStyleNew.Img
                                    : [DashStyleNew.Img, DashStyleNew.Img2]
                                }
                                source={IconAsset.BlankUser}
                              />
                            ))
                          : friendProfiles
                              ?.slice(0, 3)
                              .map((user, index) => (
                                <Image
                                  key={index}
                                  style={
                                    index === 0
                                      ? DashStyleNew.Img
                                      : [DashStyleNew.Img, DashStyleNew.Img2]
                                  }
                                  source={
                                    user.profile_image &&
                                    user.profile_image.path
                                      ? {uri: user.profile_image.path}
                                      : IconAsset.BlankUser
                                  }
                                />
                              ))}
                      </>
                    )}
                  </View>
                </TouchableOpacity>
                <View style={DashStyleNew.UsersCount}>
                  <View>
                    {!IsLoading && isConnected ? (
                      <SkeletonPlaceholder>
                        <SkeletonPlaceholder.Item
                          width={40}
                          height={12}
                          borderRadius={3}
                        />
                        <SkeletonPlaceholder.Item
                          width={70}
                          height={15}
                          borderRadius={4}
                          marginTop={12}
                        />
                      </SkeletonPlaceholder>
                    ) : (
                      <TouchableOpacity
                        onPress={() =>
                          navigation.navigate('MyFriendFriends', params)
                        }>
                        {!isConnected ? (
                          <Text style={DashStyleNew.Num}>
                            {offlineData.friend_count
                              ? offlineData.friend_count
                              : '0'}
                          </Text>
                        ) : (
                          <Text style={DashStyleNew.Num}>
                            {stateVal.total_friends
                              ? stateVal.total_friends
                              : '0'}
                          </Text>
                        )}
                        <Text style={DashStyleNew.Text}>
                          {stateVal.total_friends === 1 ? 'Friend' : 'Friends'}
                        </Text>
                      </TouchableOpacity>
                    )}
                  </View>
                </View>
                <View style={DashStyleNew.UsersCount}>
                  {!IsLoading && isConnected ? (
                    <SkeletonPlaceholder>
                      <SkeletonPlaceholder.Item
                        width={40}
                        height={12}
                        borderRadius={3}
                        marginRight={15}
                      />
                      <SkeletonPlaceholder.Item
                        width={80}
                        height={15}
                        borderRadius={4}
                        marginTop={12}
                        marginRight={15}
                      />
                    </SkeletonPlaceholder>
                  ) : (
                    <TouchableOpacity
                      onPress={() => navigation.navigate('Catches')}>
                      {!isConnected ? (
                        <Text style={DashStyleNew.Num}>
                          {offlineData.catch_count
                            ? offlineData.catch_count
                            : '0'}
                        </Text>
                      ) : (
                        <Text style={DashStyleNew.Num}>
                          {stateVal.catch_count ? stateVal.catch_count : '0'}
                        </Text>
                      )}
                      <Text style={DashStyleNew.Text}>Catch Gallery</Text>
                    </TouchableOpacity>
                  )}
                </View>
                {IsLoading && (
                  <IconButton
                    icon={() => (
                      <Icon name="Edit" size={16} color={UiColor.White} />
                    )}
                    style={DashStyleNew.UserProfileEdit}
                    onPress={() => navigation.navigate('UserProfileEdit')}
                  />
                )}
              </View>
            </View>
            <View style={[DashStyleNew.DashTitleHead]}>
              <View
                style={[
                  DashStyleNew.Users,
                  {flexDirection: 'column', height: 75},
                ]}>
                <Text style={[DashStyleNew.DashContText]}>WEATHER</Text>
                <View
                  style={{
                    width: '100%',
                    height: 1,
                    backgroundColor: 'white',
                  }}></View>
                   {!weatherData && !isConnected ? (
                    <SkeletonPlaceholder>
                      <SkeletonPlaceholder.Item
                        width={40}
                        height={8}
                        borderRadius={3}
                        marginTop={5}
                        marginLeft={100}
                      />
                      <SkeletonPlaceholder.Item
                        width={80}
                        height={8}
                        borderRadius={4}
                        marginTop={10}
                        marginLeft={100}
                      />
                    </SkeletonPlaceholder>
                  ) : (
                  <TouchableOpacity  onPress={() => navigation.navigate('WeatherDetail')}>
                    <View
                      style={{flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 2}}>
                      {weatherData &&
                        weatherData.map((item, index) => (
                          <View
                            key={index}
                            style={{
                              flexDirection: 'column',
                              alignContent: 'center',
                              marginHorizontal: 10,
                            }}>
                            <Image
                              source={getWeatherImage(item.data[0].weather[0].main)}
                              style={{width: 15, height: 15}}
                            />
                            <Text style={{fontSize: 12, color: 'white'}}>
                              {convertCelsiusToFahrenheit(
                                item.data[0].main.temp_min,
                              ).toFixed(0)}
                              °
                            </Text>
                          </View>
                        ))}
                        {weatherData && weatherData.length === 0 &&
                        <Text style={DashStyleNew.DashContText}>No Forecast</Text>
                        }
                    </View>
                  </TouchableOpacity>
                  )}

              </View>
            </View>
            <View style={[DashStyleNew.OptionsHead]}>
              <View style={[DashStyleNew.Options]}>
                <TouchableOpacity
                  style={{width: '100%'}}
                  onPress={() => navigation.navigate('Journal')}>
                  <View style={DashStyleNew.IconBox}>
                    <Image
                      style={DashStyleNew.DashContImg}
                      source={IconAsset.FinalJournal}
                    />
                    <Text style={DashStyleNew.DashContText}>JOURNAL</Text>
                  </View>
                </TouchableOpacity>
              </View>
              <View style={[DashStyleNew.Options]}>
                <TouchableOpacity
                  style={{width: '100%'}}
                  onPress={() => navigation.navigate('CameraCapture')}>
                  <View style={DashStyleNew.IconBox}>
                    <Image
                      style={[DashStyleNew.DashContImg]}
                      source={IconAsset.FinalCapture}
                    />
                    <Text style={[DashStyleNew.DashContText]}>CAPTURE</Text>
                  </View>
                </TouchableOpacity>
              </View>
              <View style={DashStyleNew.Options}>
                <TouchableOpacity
                  style={{width: '100%'}}
                  onPress={() => navigation.navigate('Friends')}>
                  <View style={DashStyleNew.IconBox}>
                    <Image
                      style={DashStyleNew.DashContImg}
                      source={IconAsset.FinalFriends}
                    />
                    <Text style={DashStyleNew.DashContText}>FRIENDS</Text>
                  </View>
                </TouchableOpacity>
              </View>
              <View style={DashStyleNew.Options}>
                <TouchableOpacity
                  style={{width: '100%'}}
                  onPress={() =>
                    navigation.navigate('Challenges', {isDelete: false})
                  }>
                  <View style={DashStyleNew.IconBox}>
                    <Image
                      style={DashStyleNew.DashContImg}
                      source={IconAsset.FinalDuel}
                    />
                    <Text style={DashStyleNew.DashContText}>TOURNAMENT</Text>
                  </View>
                </TouchableOpacity>
              </View>
              <View style={DashStyleNew.Options}>
                <TouchableOpacity
                  style={{width: '100%'}}
                  onPress={() => navigation.navigate('StoryBoard')}>
                  <View style={DashStyleNew.IconBox}>
                    <Image
                      style={DashStyleNew.DashContImg}
                      source={IconAsset.FinalStory}
                    />
                    <Text style={[DashStyleNew.DashContText]}>STORY BOARD</Text>
                  </View>
                </TouchableOpacity>
              </View>
              <View style={DashStyleNew.Options}>
                <TouchableOpacity
                  style={{width: '100%'}}
                  onPress={() => navigation.navigate('Catches')}>
                  <View style={DashStyleNew.IconBox}>
                    <Image
                      style={[DashStyleNew.DashContImg]}
                      source={IconAsset.FinalPhotos}
                    />
                    <Text
                      style={[
                        DashStyleNew.DashContText,
                        {paddingHorizontal: 10, top: -10},
                      ]}>
                      CATCH GALLERY
                    </Text>
                  </View>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>
        </ScrollView>
      </View>
      {!hideCard && (
        <View
          style={{
            width: '100%',
            position: 'absolute',
            bottom: Platform.OS === 'ios' ? 85 : 75,
            left: 0,
          }}>
          {loadDrafts.length > 0 && isConnected === true && (
            <View
              style={[
                FriendsStyle.Card,
                {
                  marginHorizontal: 12,
                  padding: 10,
                  zIndex: 0,
                },
              ]}>
              <TouchableOpacity onPress={() => ''}>
                <View style={FriendsStyle.CardLeft}>
                  <Avatar.Image
                    style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                    size={45}
                    source={
                      loadDrafts[0] && loadDrafts[0].media_file
                        ? {uri: loadDrafts[0].media_file.uri}
                        : IconAsset.BlankUser
                    }
                  />
                  <View>
                    <Text style={FriendsStyle.CardTitle}>
                      {loadDrafts[0] && loadDrafts[0].fish_name}
                    </Text>
                    <Text style={[FriendsStyle.CardDisc, {marginTop: 1}]}>
                      {loadDrafts.length + ' ' + 'catch ready for upload'}
                    </Text>
                  </View>
                </View>
              </TouchableOpacity>
              <IconButton
                style={DashStyleNew.CatchesDraft}
                onPress={() => navigation.navigate('CatchesDraft')}
                icon={() => (
                  <Text style={{color: 'white', fontSize: 14}}>View</Text>
                )}
                size={28}
              />
              <IconButton
                style={DashStyleNew.CrossCta}
                onPress={() => setHideCard(true)}
                icon={() => (
                  <Icon name="cross" size={14} color={UiColor.White} />
                )}
                size={28}
              />
            </View>
          )}
        </View>
      )}
    </ImageBackground>
  );
};
export default Dashboard;
