import {
  View,
  Text,
  Image,
  TouchableOpacity,
  Platform,
  ImageBackground,
  PermissionsAndroid,
  ScrollView,
  StyleSheet,
  Dimensions,
} from 'react-native';
import {
  Dm,
  GlobalStyles,
  Icon,
  IconAsset,
  Styles,
  UiColor,
} from '../../../theme/Index';
import {useIsFocused, useNavigation} from '@react-navigation/native';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import {Appbar, IconButton, Avatar} from 'react-native-paper';
import Geolocation from '@react-native-community/geolocation';
import React, {useState, useEffect, useContext, useRef} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {NetworkContext} from '../../NetworkContext';
import RBSheet from 'react-native-raw-bottom-sheet';
import * as Localize from 'react-native-localize';
import {heplerService} from '../../services';
import moment from 'moment-timezone';
import MapboxGL from '@rnmapbox/maps';
import axios from 'axios';
import {RemoveStyle} from '../auth/remove-account/RemoveStyle';

const WeatherDetail = ({weather_data, navigation}) => {
  const isFocused = useIsFocused();
  const dispatch = useDispatch();
  const refSheet = useRef();
  const stateVal = useSelector(state => state.login);
  const keysData = useSelector(state => state.login.third_party_keys);
  const isConnected = useContext(NetworkContext);
  const [weatherData, setWeatherData] = useState(null);
  const [tideWave, setTideWave] = useState(null);
  const [cityInfo, setCityInfo] = useState(null);
  const [openWeather, setOpenWeather] = useState('');
  const [expandedDay, setExpandedDay] = useState(null);
  const [coordinates, setCoordinates] = useState(null);
  const [currentLat, setCurrentLat] = useState(null);
  const [currentLong, setCurrentLong] = useState(null);
  const defaultCoordinates = [currentLong, currentLat];
  const [pinCoordinates, setPinCoordinates] = useState(null);

  // console.log("tideWave",tideWave)
  useEffect(() => {
    if (isFocused && isConnected) {
      checkAndRequestPermissions();
    }
  }, [isFocused, isConnected]);

  if (Platform.OS === 'ios') {
    MapboxGL.setWellKnownTileServer('mapbox');
  } else {
    MapboxGL.setWellKnownTileServer('Mapbox');
  }
  MapboxGL.setAccessToken(
    'pk.eyJ1IjoiZXhhY3RpbmsiLCJhIjoiY2x3enpzejFpMGMzejJqc2RrNjR4ZWs4dCJ9.8Xuj0V6TUuh3T8Bzt7QIHw',
  );

  const formattedTideData =
    tideWave &&
    tideWave?.reduce((acc, item) => {
      const date = item.date.substring(0, 16); // Extract date and hour part (e.g., "2024-10-11T01:00")
      acc[date] = item.height; // Store wave height by date-time key
      return acc;
    }, {});

  const deviceTimeZoneLocalize = Localize.getTimeZone();
  const formatToLocalizedTime = dateTime => {
    return moment(dateTime).tz(deviceTimeZoneLocalize).format('h A'); // Format for hours (12-hour format)
  };

  const formatToLocalizedDate = dateTime => {
    return moment(dateTime)
      .tz(deviceTimeZoneLocalize)
      .format('ddd, MMM DD, YYYY'); // Format for full date
  };

  const handlePress = event => {
    const {geometry} = event;
    const lat = geometry.coordinates[1]; // Latitude
    const long = geometry.coordinates[0]; // Longitude
    setCoordinates({lat, long});
    fetchOpenWeatherWeekly(lat, long);
    fetchOpenWeatherMap(lat, long);
    fetchTideData(lat, long);
    setPinCoordinates([long, lat]);
  };

  const renderMarker = () => {
    return (
      pinCoordinates && (
        <MapboxGL.PointAnnotation id="pin" coordinate={pinCoordinates}>
          <View style={styles.markerContainer}>
            {/* Render the marker with proper image styling */}
            {/* <Image
              source={IconAsset.LocationPin}
              style={styles.markerImage} // Apply image styling
            /> */}
            <Icon name="location-pin" size={25} color={'white'} />
          </View>
        </MapboxGL.PointAnnotation>
      )
    );
  };

  const checkAndRequestPermissions = async () => {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          getOneTimeLocation();
        } else {
          Alert.alert(
            'Permission denied',
            'Location permission is required to use this feature.',
          );
        }
      } catch (err) {
        console.warn(err);
      }
    } else if (Platform.OS === 'ios') {
      // On iOS, permissions are managed via Info.plist
      getOneTimeLocation();
    }
  };

  const getOneTimeLocation = async () => {
    try {
      const position = await new Promise((resolve, reject) => {
        Geolocation.getCurrentPosition(resolve, reject);
      });
      const currentLongitude = JSON.stringify(position.coords.longitude);
      const currentLatitude = JSON.stringify(position.coords.latitude);
      setCurrentLat(currentLatitude);
      setCurrentLong(currentLongitude);
      fetchOpenWeatherWeekly(currentLatitude, currentLongitude);
      fetchOpenWeatherMap(currentLatitude, currentLongitude);
      fetchTideData(currentLatitude, currentLongitude);
    } catch (error) {
      getOneTimeLocation();
      if (error.code === 1) {
        console.log('Permission denied');
      } else if (error.code === 2) {
        console.log('Position unavailable');
      } else if (error.code === 3) {
        console.log('Timeout');
      } else {
        console.log('Other error', error);
      }
    }
  };

  const fetchOpenWeatherMap = async (latitude, longitude) => {
    const ApiKey = keysData.weather;
    try {
      const response = await axios.get(
        'https://api.openweathermap.org/data/2.5/weather',
        {
          params: {
            lat: latitude,
            lon: longitude,
            appid: ApiKey,
            units: 'metric',
          },
        },
      );
      setOpenWeather(response.data);
    } catch (error) {
      console.log('error', error);
    } finally {
    }
  };

  const fetchOpenWeatherWeekly = async (latitude, longitude) => {
    const apiKey = keysData && keysData.weather;
    try {
      const response = await axios.get(
        'https://api.openweathermap.org/data/2.5/forecast',
        {
          params: {
            lat: latitude,
            lon: longitude,
            appid: apiKey,
            units: 'metric',
          },
        },
      );
      organizeWeatherData(response.data);
    } catch (error) {
      console.log('Error fetching weather data', error);
    }
  };

  const organizeWeatherData = data => {
    const filteredData = {
      city: {
        country: data.city.country,
        name: data.city.name,
      },
      list: data.list.map(item => ({
        dt_txt: item.dt_txt,
        main: {
          temp: item.main.temp,
          temp_max: item.main.temp_max,
          temp_min: item.main.temp_min,
        },
        weather: item.weather.map(weatherItem => ({
          description: weatherItem.description,
          main: weatherItem.main,
        })),
        wind: item.wind,
      })),
    };
    organizeWeather(filteredData);
  };

  const organizeWeather = data => {
    setCityInfo(data.city);
    const groupedData = {};
    data.list.forEach(item => {
      const date = item.dt_txt.split(' ')[0];
      if (!groupedData[date]) {
        groupedData[date] = [];
      }
      groupedData[date].push(item);
    });

    const days = Object.keys(groupedData).map(date => ({
      date,
      data: groupedData[date],
    }));
    setWeatherData(days);
  };

  const fetchTideData = async (latitude, longitude) => {
    const lat = latitude;
    const lon = longitude;
    const apiKey = keysData && keysData.tide_weather;
    // Adjust the API URL to request 7 days of data with heights and extremes
    const apiUrl = `https://www.worldtides.info/api/v3?heights&extremes&datum=CD&lat=${lat}&lon=${lon}&days=7&key=${apiKey}`;

    try {
      const response = await fetch(apiUrl);
      if (!response.ok) {
        throw new Error('Failed to fetch tide data');
      }
      const jsonData = await response.json();
      // Assuming jsonData.extremes contains an array of extremes over the 7-day period
      setTideWave(jsonData && jsonData.heights && jsonData.heights);
    } catch (error) {
      console.error('Error fetching tide data:', error);
    }
  };
  const convertCelsiusToFahrenheit = celsius => {
    return (celsius * 9) / 5 + 32;
  };

  const getWeatherImage = weatherType => {
    switch (weatherType) {
      case 'Clear':
        return IconAsset.Sunny;
      case 'Clouds':
        return IconAsset.Clouds;
      case 'Rain':
        return IconAsset.Rain;
      default:
        return IconAsset.PartlySunny;
    }
  };

  const getWindDirection = deg => {
    if (deg >= 337.5 || deg < 22.5) return 'North';
    if (deg >= 22.5 && deg < 67.5) return 'North East';
    if (deg >= 67.5 && deg < 112.5) return 'East';
    if (deg >= 112.5 && deg < 157.5) return 'South East';
    if (deg >= 157.5 && deg < 202.5) return 'South';
    if (deg >= 202.5 && deg < 247.5) return 'South West';
    if (deg >= 247.5 && deg < 292.5) return 'West';
    if (deg >= 292.5 && deg < 337.5) return 'North West';
  };
  const todayDate = moment().format('YYYY-MM-DD');
  const todayWeather = weatherData
    ? weatherData.find(day => day.date === todayDate)
    : null;

  const toggleDay = date => {
    if (expandedDay === date) {
      setExpandedDay(null);
    } else {
      setExpandedDay(date);
    }
  };

  return (
    <>
      <Appbar.Header
        style={[
          Styles.AppbarHeader,
          Styles.AppBarShadow,
          {justifyContent: 'space-between'},
        ]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{backgroundColor: UiColor.SecondaryColor}}
          icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
        />
        <Appbar.Content titleStyle={Styles.NavTitle} title="Weather Details" />
        <Appbar.Action />
      </Appbar.Header>
      {!isConnected && !todayWeather ? (
        <View style={[GlobalStyles.NoData, {marginTop: 80}]}>
          <Icon name="no-connection" size={50} />
          <Text
            style={[
              GlobalStyles.NoDataMsg,
              {fontFamily: Dm.semiBold, fontWeight: '600'},
            ]}>
            No Internet Connection
          </Text>
        </View>
      ) : (
        <View style={styles.mainContainer}>
          {!todayWeather ? (
            <SkeletonPlaceholder>
              <SkeletonPlaceholder.Item
                height={150}
                width="100%"
                marginTop={20}
                borderRadius={10}
              />
              <SkeletonPlaceholder.Item
                paddingTop={20}
                width="100%"
                borderRadius={10}>
                <SkeletonPlaceholder.Item height={200} width="100%" />
                {Array.from({length: 5}).map((_, index) => (
                  <SkeletonPlaceholder.Item
                    key={index}
                    height={50}
                    width="100%"
                    marginTop={20}
                    borderRadius={10}
                  />
                ))}
              </SkeletonPlaceholder.Item>
            </SkeletonPlaceholder>
          ) : (
            <>
              <ScrollView showsVerticalScrollIndicator={false}>
                <View style={styles.container}>
                  {todayWeather && todayWeather.data.length > 0 && (
                    <View
                      style={[
                        styles.todayWeatherContainer,
                        {
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          backgroundColor: '#e9e9f0',
                          borderRadius: 8,
                          paddingVertical: 14,
                          paddingHorizontal: 16,
                        },
                      ]}>
                      <View>
                        <Text style={styles.todayTempText}>
                          {convertCelsiusToFahrenheit(
                            todayWeather.data[0].main.temp,
                          ).toFixed(2)}
                          °
                        </Text>
                        <Text style={styles.dateText}>
                          {formatToLocalizedDate(todayWeather.data[0].dt_txt)}
                        </Text>
                        {cityInfo && (
                          <View style={{flexDirection: 'row', marginTop: 10}}>
                            <Icon
                              name="location"
                              size={22}
                              color={'#09193D'}
                              style={{marginRight: 8, marginTop: 0}}
                            />
                            <Text style={[styles.cityName]}>
                              {cityInfo.name}, {cityInfo.country}
                            </Text>
                          </View>
                        )}
                      </View>
                      <View>
                        <Image
                          source={getWeatherImage(
                            todayWeather.data[0].weather[0].main,
                          )}
                          style={{width: 100, height: 100}}
                        />
                        <Text
                          style={[
                            styles.descriptionText,
                            {marginLeft: 10, width: 80},
                          ]}>
                          {heplerService.capitalizeFirstLetter(
                            todayWeather.data[0].weather[0].description,
                          )}
                        </Text>
                      </View>
                    </View>
                  )}
                  <View style={{flex: 1, height: 300}}>
                    <MapboxGL.MapView
                      style={{flex: 1}}
                      styleURL="mapbox://styles/exactink/clx1vdour003b01qs7fej67yk"
                      onPress={handlePress}>
                      <MapboxGL.Camera
                        zoomLevel={10} // Zoom level
                        centerCoordinate={defaultCoordinates} // San Francisco coordinates
                      />
                      <MapboxGL.PointAnnotation
                        id="sfPoint" // San Francisco point annotation
                        coordinate={defaultCoordinates} // San Francisco coordinates
                      />
                      {renderMarker()}
                      <MapboxGL.SymbolLayer
                        id="place-labels"
                        sourceID="composite"
                        sourceLayerID="place_label"
                        style={{
                          textField: ['get', 'name'],
                          textFont: ['DIN Pro Medium', 'Arial Unicode MS Bold'],
                          textSize: 12,
                          textColor: 'white',
                        }}
                      />
                    </MapboxGL.MapView>
                  </View>
                  {todayWeather && (
                    <Text style={[styles.sectionTitle, styles.headTitle]}>
                      Today
                    </Text>
                  )}
                  <View style={styles.todayMainView}>
                    <View
                      style={{
                        flexDirection: 'column',
                        marginRight: 10,
                        marginLeft: 10,
                      }}>
                      <Text style={styles.todaySideText}>Time</Text>
                      <Text style={styles.todaySideText}>Sky</Text>
                      <Text style={styles.todaySideText}>Sky description</Text>
                      <Text style={styles.todaySideText}>°F</Text>
                      <Text style={styles.todaySideText}>Wind Speed</Text>
                      <Text style={[styles.todaySideText, {marginBottom: 24}]}>
                        Wind Direction
                      </Text>
                      <Text style={styles.todaySideText}>Wind Gusts</Text>
                      <Text style={styles.todaySideText}>Wave Height</Text>
                    </View>
                    {todayWeather && (
                      <ScrollView
                        horizontal
                        showsHorizontalScrollIndicator={false}>
                        {todayWeather.data.map((item, index) => {
                          // Extract date and hour part from item.dt_txt (e.g., "2024-10-11 09:00")
                          const timeSlot = moment(item.dt_txt).format(
                            'YYYY-MM-DDTHH:mm',
                          ); // Format as "2024-10-11T09:00"
                          const waveHeight =
                            formattedTideData && formattedTideData[timeSlot];
                          // Log the waveHeight value to check if it's being found

                          return (
                            <View key={index} style={{flexDirection: 'row'}}>
                              <View style={styles.todayViewLine}></View>
                              <View style={styles.hourlyItem}>
                                <Text
                                  style={[
                                    styles.hourText,
                                    {color: UiColor.Black},
                                  ]}>
                                  {formatToLocalizedTime(item.dt_txt)}
                                </Text>
                                <Image
                                  source={getWeatherImage(item.weather[0].main)}
                                  style={styles.weatherImage}
                                />
                                <Text
                                  style={[
                                    styles.hourTempText,
                                    {color: UiColor.Black},
                                  ]}>
                                  {heplerService.capitalizeFirstLetter(
                                    item.weather[0].description,
                                  )}
                                </Text>
                                <Text
                                  style={[
                                    styles.hourTempText,
                                    {color: UiColor.Black},
                                  ]}>
                                  {convertCelsiusToFahrenheit(
                                    item.main.temp,
                                  ).toFixed(0)}
                                  °
                                </Text>
                                <Text
                                  style={[
                                    styles.hourTempText,
                                    {marginVertical: 5, color: UiColor.Black},
                                  ]}>
                                  {item.wind ? `${item.wind.speed} mph` : 'N/A'}
                                </Text>
                                <View style={styles.degView}>
                                  <Text
                                    style={[
                                      styles.hourTempText,
                                      {color: UiColor.Black},
                                    ]}>
                                    {getWindDirection(item.wind.deg)}
                                  </Text>
                                  <View style={styles.windDirection}>
                                    <Icon
                                      name="back"
                                      color={UiColor.White}
                                      size={15}
                                      style={{
                                        transform: [
                                          {rotate: `${item.wind.deg}deg`},
                                        ],
                                      }}
                                    />
                                  </View>
                                </View>
                                <Text
                                  style={[
                                    styles.hourTempText,
                                    {marginVertical: 5, color: UiColor.Black},
                                  ]}>
                                  {item.wind ? item.wind.gust : 'N/A'}
                                </Text>
                                <Text
                                  style={[
                                    styles.hourTempText,
                                    {marginVertical: 5, color: UiColor.Black},
                                  ]}>
                                  {waveHeight ? `${waveHeight} ft` : 'N/A'}
                                </Text>
                              </View>
                            </View>
                          );
                        })}
                      </ScrollView>
                    )}
                  </View>

                  <View style={styles.detailContainer}>
                    <View style={{flexDirection: 'row'}}>
                      <Text style={styles.headTitle}>Wind:</Text>
                      <Text style={styles.detailText}>
                        {' '}
                        {openWeather &&
                          openWeather.wind &&
                          openWeather.wind.speed}{' '}
                        miles/hour,{' '}
                        {getWindDirection(
                          openWeather &&
                            openWeather.wind &&
                            openWeather.wind.deg,
                        )}
                      </Text>
                    </View>
                    <View style={{flexDirection: 'row'}}>
                      <Text style={styles.headTitle}>Sea Level : </Text>
                      <Text style={styles.detailText}>
                        {' '}
                        {openWeather &&
                          openWeather.main &&
                          openWeather.main.sea_level}{' '}
                        hectopascals (hPa)
                      </Text>
                    </View>
                    <View style={{flexDirection: 'row'}}>
                      <Text style={styles.headTitle}>Ground Level :</Text>
                      <Text style={styles.detailText}>
                        {' '}
                        {openWeather &&
                          openWeather.main &&
                          openWeather.main.grnd_level}{' '}
                        hectopascals (hPa)
                      </Text>
                    </View>
                  </View>
                  {todayWeather ? (
                    <View
                      style={{
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                      }}>
                      <Text style={[styles.sectionTitle, styles.headTitle]}>
                        6 days forecast
                      </Text>
                      <TouchableOpacity
                        style={[
                          RemoveStyle.DeleteBtn,
                          {height: 40, paddingHorizontal: 10},
                        ]}
                        onPress={() => {
                          refSheet.current.open();
                        }}>
                        <Text
                          style={{
                            color: UiColor.White,
                            fontSize: 14,
                            fontFamily: Dm.bold,
                          }}>
                          Click to know more
                        </Text>
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <Text style={[styles.sectionTitle, {textAlign: 'center'}]}>
                      No forecast record found
                    </Text>
                  )}
                  <View style={{marginBottom: 10}}>
                    {weatherData &&
                      weatherData.map((item, index) => (
                        <View key={index}>
                          <View>
                            <TouchableOpacity
                              onPress={() => toggleDay(item.date)}>
                              <View style={styles.dailyItem}>
                                <Text style={styles.dailyText}>
                                  {moment(item.date).format('ddd')}
                                </Text>
                                <View
                                  style={{
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                    position: 'absolute',
                                    marginLeft: 80,
                                  }}>
                                  <Image
                                    source={getWeatherImage(
                                      item.data[0].weather[0].main,
                                    )}
                                    style={styles.weatherImage}
                                  />
                                  <Text style={[styles.dailyText]}>
                                    {item.data[0].weather[0].main}
                                  </Text>
                                </View>
                                <Text style={styles.dailyTempText}>
                                  {convertCelsiusToFahrenheit(
                                    item.data[0].main.temp_max,
                                  ).toFixed(0)}
                                  ° /{' '}
                                  {convertCelsiusToFahrenheit(
                                    item.data[0].main.temp_min,
                                  ).toFixed(0)}
                                  °
                                </Text>
                              </View>
                            </TouchableOpacity>
                          </View>
                          {expandedDay === item.date && (
                            <ScrollView
                              horizontal
                              showsHorizontalScrollIndicator={false}>
                              {item.data.map((hourItem, hourIndex) => {
                                const timeSlot = moment(hourItem.dt_txt).format(
                                  'YYYY-MM-DDTHH:mm',
                                );
                                const waveHeight =
                                  formattedTideData &&
                                  formattedTideData[timeSlot];
                                return (
                                  <View
                                    key={hourIndex}
                                    style={[
                                      styles.hourlyItem,
                                      {marginBottom: 10},
                                    ]}>
                                    <Text style={styles.hourText}>
                                      Time:{' '}
                                      {formatToLocalizedTime(hourItem.dt_txt)}
                                    </Text>
                                    <Image
                                      source={getWeatherImage(
                                        hourItem.weather[0].main,
                                      )}
                                      style={styles.weatherImage}
                                    />
                                    <Text style={styles.hourTempText}>
                                      °F:{' '}
                                      {convertCelsiusToFahrenheit(
                                        hourItem.main.temp,
                                      ).toFixed(0)}
                                      °
                                    </Text>
                                    <Text
                                      style={[
                                        styles.hourTempText,
                                        {marginVertical: 3},
                                      ]}>
                                      Speed: {hourItem.wind.speed} mph
                                    </Text>
                                    <View
                                      style={{
                                        flexDirection: 'column',
                                        alignItems: 'center',
                                      }}>
                                      <Text
                                        style={[
                                          styles.hourTempText,
                                          {marginVertical: 2},
                                        ]}>
                                        WD:{' '}
                                        {getWindDirection(hourItem.wind.deg)}
                                      </Text>
                                      <View
                                        style={[
                                          styles.windDirection,
                                          {backgroundColor: UiColor.White},
                                        ]}>
                                        <Icon
                                          name="back"
                                          color={UiColor.DarkBlue}
                                          size={15}
                                          style={{
                                            transform: [
                                              {
                                                rotate: `${hourItem.wind.deg}deg`,
                                              },
                                            ],
                                          }}
                                        />
                                      </View>
                                    </View>
                                    <Text
                                      style={[
                                        styles.hourTempText,
                                        {marginVertical: 5},
                                      ]}>
                                      Gust: {hourItem.wind.gust}
                                    </Text>
                                    {/* Display the wave height */}
                                    <Text
                                      style={[
                                        styles.hourTempText,
                                        {marginVertical: 5},
                                      ]}>
                                      Height:{' '}
                                      {waveHeight ? `${waveHeight} ft` : 'N/A'}
                                    </Text>
                                  </View>
                                );
                              })}
                            </ScrollView>
                          )}
                        </View>
                      ))}
                  </View>
                </View>
              </ScrollView>
              <RBSheet
                ref={refSheet}
                height={500}
                openDuration={250}
                closeOnDragDown={true}
                customStyles={{
                  container: {
                    padding: 10,
                  },
                }}>
                <ScrollView showsVerticalScrollIndicator={false}>
                  {weatherData && weatherData.length > 0 ? (
                    weatherData.map((item, index) => {
                      // Safely access values and provide defaults if missing
                      const weatherDescription =
                        item.data[0]?.weather[0]?.description ||
                        'No weather data available';
                      const tempMax = item.data[0]?.main?.temp_max
                        ? convertCelsiusToFahrenheit(
                            item.data[0].main.temp_max,
                          ).toFixed(0)
                        : 'N/A';
                      const tempMin = item.data[0]?.main?.temp_min
                        ? convertCelsiusToFahrenheit(
                            item.data[0].main.temp_min,
                          ).toFixed(0)
                        : 'N/A';
                      const humidity =
                        item.data[0]?.main?.humidity !== undefined
                          ? item.data[0].main.humidity
                          : 'N/A';
                      const windSpeed = item.data[0]?.wind?.speed
                        ? item.data[0].wind.speed.toFixed(2)
                        : 'N/A';
                      // Check if it will rain and extract the rain data (if available)
                      const isRainy = item.data[0]?.weather.some(
                        w =>
                          w.main.toLowerCase() === 'rain' ||
                          w.main.toLowerCase() === 'drizzle',
                      );
                      const rainAmount = item.data[0]?.rain?.['1h'] || 0; // 1 hour of rain (in mm)
                      const rainForecast = isRainy
                        ? `Expect rain. Expected rain amount: ${rainAmount} mm in the next hour.`
                        : 'No rain expected.';

                      // Paragraph description with safe data
                      const description = `The weather on ${moment(
                        item.date,
                      ).format(
                        'dddd, MMMM D',
                      )} will be ${weatherDescription}. Expect a high of ${tempMax}°F and a low of ${tempMin}°F. Humidity will be around ${humidity}%, with wind speeds reaching ${windSpeed} mph. ${rainForecast}`;

                      return (
                        <TouchableOpacity
                          key={index}
                          style={styles.dayContainer}>
                          <Text style={styles.dayHeader}>
                            {moment(item.date).format('dddd, MMMM D')}
                          </Text>
                          <Text style={styles.paragraphText}>
                            {description}
                          </Text>
                        </TouchableOpacity>
                      );
                    })
                  ) : (
                    <Text>No forecast data available.</Text>
                  )}
                </ScrollView>
              </RBSheet>
            </>
          )}
        </View>
      )}
    </>
  );
};

const styles = StyleSheet.create({
  mainContainer: {
    marginHorizontal: 5,
    backgroundColor: UiColor.White,
    height: '100%',
    position: 'relative',
  },
  container: {
    flex: 1,
    paddingHorizontal: 8,
    backgroundColor: '#1E3A8A',
    borderRadius: 10,
    margin: 10,
    marginBottom: 150,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  marker: {
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#FF0000',
  },
  markerStick: {
    width: 2,
    height: 20,
    backgroundColor: '#FF0000',
  },
  headTitle: {
    color: UiColor.White,
    fontWeight: 'bold',
    fontSize: 18,
  },
  cityName: {
    fontSize: 16,
    color: UiColor.PrimaryColor,
    width: 150,
  },
  todayWeatherContainer: {
    alignItems: 'center',
    marginVertical: 20,
  },
  todayMainView: {
    flexDirection: 'row',
    backgroundColor: UiColor.White,
    paddingVertical: 15,
    borderRadius: 4,
  },
  todayViewLine: {
    height: '100%',
    width: 1,
    opacity: 0.5,
    backgroundColor: UiColor.GrayLight,
  },
  todayTempText: {
    fontSize: 48,
    fontWeight: 'bold',
    color: UiColor.PrimaryColor,
  },
  degView: {
    flexDirection: 'column',
    alignItems: 'center',
    marginTop: 3,
  },
  dateText: {
    fontSize: 16,
    color: UiColor.PrimaryColor,
  },
  descriptionText: {
    fontSize: 16,
    color: UiColor.PrimaryColor,
  },
  sectionTitle: {
    fontSize: 16,
    color: 'white',
    marginVertical: 10,
    marginLeft: 10,
  },
  hourlyItem: {
    alignItems: 'center',
    marginHorizontal: 15,
  },
  hourText: {
    fontSize: 14,
    color: 'white',
  },
  todaySideText: {
    fontSize: 14,
    color: UiColor.Black,
    marginBottom: 6,
  },
  windDirection: {
    width: 24,
    height: 22,
    paddingHorizontal: 3,
    addingVertical: 1,
    backgroundColor: UiColor.DarkBlue,
    borderRadius: 2,
  },
  hourTempText: {
    fontSize: 14,
    color: 'white',
  },
  dailyItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    paddingHorizontal: 15,
    backgroundColor: '#fff',
    borderRadius: 10,
    marginVertical: 5,
  },
  dailyText: {
    fontSize: 16,
    color: '#000000',
    flex: 1,
  },
  dailyTempText: {
    fontSize: 16,
    color: '#000000',
  },
  weatherImage: {
    width: 30,
    height: 30,
    marginHorizontal: 10,
  },
  detailContainer: {
    alignItems: 'flex-start',
    marginLeft: 10,
    marginTop: 15,
    marginBottom: 20,
  },
  detailText: {
    fontSize: 14,
    marginLeft: 10,
    color: 'white',
    textAlign: 'left',
    marginTop: 2,
    marginBottom: 5,
  },
  dayContainer: {
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
    backgroundColor: '#f2f5f5',
    marginBottom: 5,
  },
  dayHeader: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
    marginHorizontal: 5,
  },
  paragraphText: {
    fontSize: 16,
    color: '#666',
    lineHeight: 24, // Spacing between lines for easier reading
    marginHorizontal: 5,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  markerImage: {
    width: 35, // Width of the image
    height: 35, // Height of the image
    resizeMode: 'contain', // Ensures the image fits properly within the bounds
  },
});
export default WeatherDetail;
4;
