/* eslint-disable prettier/prettier */
import { StyleSheet, Platform, useColorScheme } from 'react-native';
import { UiColor, Dm } from '../../../theme/Index';



export const DashStyleNew = StyleSheet.create({
    DashTitleHead: {
        backgroundColor: '#E6ECF4',
        borderRadius: 20,
        marginBottom: 10,
        marginHorizontal: 20,
        // marginTop: 10,
        marginTop: 0,
    },
    Users: {
        paddingVertical: 18,
        paddingHorizontal: 14,
        backgroundColor: '#09193D',
        borderRadius: 20,
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    ImgBox: {
        flexDirection: 'row',
    },
    Img: {
        width: 41,
        height: 43,
        borderRadius: 18,
        borderWidth: 2,
        borderColor: UiColor.White,
    },
    DashTopBox: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginHorizontal: 22,
        paddingVertical: 12,
    },
    Title: {
        fontSize: 16,
        color: UiColor.PrimaryColor,
        flexShrink: 1,
        // color: isDarkTheme ? 'red' : UiColor.PrimaryColor,
        fontFamily: Dm.semiBold,
    },
    SubTitle: {
        fontSize: 12,
        color: UiColor.SecondaryColor,
        fontFamily: Dm.semiBold,
        flexShrink: 1,
    },
    disc: {
        fontSize: 14,
        fontFamily: Dm.medium,
        color: UiColor.PrimaryColor,
        marginTop: 2,
    },
    UsersCount: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    Num: {
        fontSize: 16,
        fontFamily: Dm.medium,
        color: UiColor.White,
        paddingBottom: 4
    },
    Text: {
        fontSize: 14,
        fontFamily: Dm.regular,
        color: UiColor.White,
    },
    Img2: {
        marginLeft: -12,
    },
    DashCont: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginHorizontal: 2,
        justifyContent: 'center',
    },
    OptionsHead: {
        // marginHorizontal: 20,
        marginHorizontal: -8,
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'center',
        alignItems: 'center',
        // marginTop: 10,
        marginTop: 0,
    },
    Options: {
        paddingHorizontal: 8,
        alignItems: 'center',
        width: '47%',
        textAlign: 'center',
        marginBottom: 12,
        // backgroundColor:'red'
    },
    IconBox: {
        // width: 130,
        width: '100%',
        // height: 130,
        height: 120,
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
        // borderWidth: 1,
        // borderColor: '#DDE8F3'
        backgroundColor: '#09193D',
    },
    DashContImg: {
        top: 3,
        // width: 100,
        // height: 100,
        width: 90,
        height: 90,
        objectFit: 'contain',
    },
    DashContText: {
        fontSize: 14,
        lineHeight: 14,
        top: -5,
        paddingBottom: 5,
        paddingHorizontal: 8,
        fontFamily: Dm.bold,
        textAlign: 'center',
        color: UiColor.White,
    },
    UserProfileEdit: {
        position: 'absolute',
        top: 2,
        right: 10,
    },
    unreadCount: {
        fontWeight: 'bold',
        marginStart: -20,
        color: 'red',
        fontSize: 15,
    },
    CatchesDraft: {
        width: 60,
        height: 30,
        position: 'absolute',
        top: 12,
        right: 35,
        backgroundColor: UiColor.SecondaryColor,
    },
    CrossCta: {
        width: 25,
        height: 25,
        position: 'absolute',
        top: -14,
        right: -10,
        backgroundColor: UiColor.SecondaryColor,
    },
});