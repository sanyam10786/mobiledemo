/* eslint-disable prettier/prettier */
import { StyleSheet, Platform, useColorScheme } from 'react-native';
import { UiColor, Dm } from '../../../theme/Index';

const theme = useColorScheme();
const isDarkTheme = theme === 'dark';
export const DashStyle = StyleSheet.create({
    DashTitleHead: {
        backgroundColor: '#E6ECF4',
        borderRadius: 24,
        paddingBottom: 1,
        marginBottom: 56,
        marginTop: 26,

        DashTopBox: {
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            paddingHorizontal: 18,
            paddingVertical: 16,

            Title: {
                fontSize: 18,
                color: UiColor.PrimaryColor,
                // color: isDarkTheme ? 'red' : UiColor.PrimaryColor,
                fontFamily: Dm.medium,
            },

            SubTitle: {
                fontSize: 13,
                color: UiColor.SecondaryColor,
                fontFamily: Dm.medium,
            },
        },

        Users: {
            paddingVertical: 16,
            paddingHorizontal: 18,
            backgroundColor: UiColor.White,
            borderRadius: 24,
            flexDirection: 'row',
            justifyContent: 'space-between',

            ImgBox: {
                flexDirection: 'row',
                Img: {
                    width: 43,
                    height: 47,
                    borderRadius: 18,
                    borderWidth: 3,
                    borderColor: UiColor.White,
                }
            },
        },
    },

    disc: {
        fontSize: 14,
        fontFamily: Dm.regular,
        color: UiColor.PrimaryColor,
        marginTop: 2,
    },

    UsersCount: {
        flexDirection: 'row',
        alignItems: 'center',
        Num: {
            fontSize: 18,
            fontFamily: Dm.medium,
            color: UiColor.PrimaryColor
        },
        Text: {
            fontSize: 14,
            fontFamily: Dm.regular,
            color: '#2E3660',
        },
    },

    Img2: {
        marginLeft: -12,
    },

    DashCont: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginHorizontal: -8,
        justifyContent: 'center',

        Options: {
            paddingHorizontal: 8,
            alignItems: 'center',
            width: '33.333%',
            textAlign: 'center',
            marginBottom: 19,
        },

        IconBox: {
            width: 93,
            height: 93,
            borderRadius: 100,
            justifyContent: 'center',
            alignItems: 'center',
            borderWidth: 1,
            borderColor: '#DDE8F3'
        },
        Img: {
            width: 52,
            height: 52,
            objectFit: 'contain',
        },

        Text: {
            fontSize: 14,
            textAlign: 'center',
            color: UiColor.PrimaryColor,
            marginTop: 9,
        },
    },
});


