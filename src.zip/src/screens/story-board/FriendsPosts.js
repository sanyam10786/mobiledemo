import {fetchPosts, likePosts, removeLike, commentPost, fetchComments, likeComment, deleteComment, commentReply, deletePost, fetchMyFriends, reportStoryPost} from '../../thunk';
import {View, Text, TouchableOpacity,Image, KeyboardAvoidingView, FlatList, Platform, Alert} from 'react-native';
import {Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm} from '../../../theme/Index';
import {Avatar, IconButton, ActivityIndicator, TextInput} from 'react-native-paper';
import {useIsFocused, useNavigation} from '@react-navigation/native';
import React, {useEffect, useState, useRef, useContext} from 'react';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import {resetState, setRefreshing} from '../../slices/posts';
import { NetworkContext } from '../../NetworkContext'; 
import {useDispatch, useSelector} from 'react-redux';
import RBSheet from 'react-native-raw-bottom-sheet';
import {StoryBoardStyle} from './StoryBoardStyle';
import {useRoute} from '@react-navigation/native';
import FastImage from 'react-native-fast-image';
import Slick from 'react-native-slick';
import Share from 'react-native-share';
import RNFS from 'react-native-fs';
import moment from 'moment';

const FriendsPosts = () => {
  const navigation = useNavigation();
  const isFocused = useIsFocused();
  const route = useRoute();
  const isConnected = useContext(NetworkContext);
  const refCommentSheet = useRef({});
  const refPostSheet = useRef({});
  const refReportSheet = useRef({});
  const [currentPage, setCurrentPage] = React.useState(1);
  const dispatch = useDispatch();
  const stateVal = useSelector(state => state.login);
  const notification = stateVal.notification_count;
  const stateValue = useSelector(state => state.posts);
  const allFriends = useSelector(state => state.friends);
  const friendData = allFriends.myFriends.friends;
  const [postsData, setPostsData] = useState([]);
  const [isEndOfFirstPage, setIsEndOfFirstPage] = useState(false);
  const [params, setParamData] = useState({
    stories: 'friends',
    page: 1,
    limit: 10,
  });
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [isLoadingComment, setIsLoadingComment] = useState(false);
  const [shouldFetchNextPage, setShouldFetchNextPage] = useState(true);
  const [commentData, setCommentData] = useState([]);
  const [myFriendData, setMyFriendData] = useState([]);
  const [commentItems, setCommentItems] = useState(null);
  const [expandedComments, setExpandedComments] = useState([]);
  const toggleRepliesVisibility = commentId => {
    setExpandedComments(prev => ({
      ...prev,
      [commentId]: !prev[commentId],
    }));
  };
  const [deleteParams, setDeleteParams] = useState({
    story_id: '',
    comment_id: '',
    isComment: false,
  });
  const [isFetchingNewComments, setIsFetchingNewComments] = useState(false);
  const commentInputRef = useRef({});
  const [isSubmit, setIsSubmit] = useState(false);
  const [formData, setFormData] = useState({
    comment: '',
    text_comment: '',
    isReply: false,
  });

  useEffect(() => {
    if (isConnected && isFocused) {
      const params = {
        page: currentPage,
        limit: 10,
        stories: 'friends',
      };
      fetchAllPosts(currentPage, params);
      fetchFriends();
    }
  }, [isConnected, isFocused]);

  const handleRefresh = () => {
    dispatch(setRefreshing({}));
    params.page = 1;
    fetchAllPosts(currentPage, params);
  };

  const fetchFriends = async () => {
    try {
      const params = {
        user_id: stateVal.id,
        page: 1,
        limit: 30,
      };

      let allFriends = [];
      while (true) {
        const resultAction = await dispatch(fetchMyFriends(params));
        if (fetchMyFriends.fulfilled.match(resultAction)) {
          const newData = resultAction.payload.data.friends;
          allFriends = allFriends.concat(newData);
          if (newData.length < params.limit) {
            break;
          }
          params.page++;
        } else {
          break;
        }
      }
      setMyFriendData(allFriends);
    } catch (error) {
      console.error('Error in fetchFriends:', error);
    }
  };

  const fetchAllPosts = async (page, params) => {
    try {
      setIsLoadingMore(true);
      const resultAction = await dispatch(fetchPosts(params));
      if (fetchPosts.fulfilled.match(resultAction)) {
        const newPosts = resultAction.payload.data.result;
        if (page === 1) {
          setPostsData(newPosts);
        } else {
          setPostsData(prevPosts => {
            const uniqueFilteredData = newPosts.filter(
              item =>
                !prevPosts.map(prevItem => prevItem._id).includes(item._id),
            );
            return [...prevPosts, ...uniqueFilteredData];
          });
        }
        if (newPosts.length < params.limit) {
          setShouldFetchNextPage(false);
        } else {
          setShouldFetchNextPage(true);
        }
      }
      setIsLoadingMore(false);
    } catch (error) {
      console.error('Error in fetchAllPosts:', error);
      setIsLoadingMore(false);
    }
  };

  const handleEndReached = () => {
    if (shouldFetchNextPage) {
      handleLoadMore();
    }
  };

  const handleLoadMore = () => {
    if (!isLoadingMore && shouldFetchNextPage && isEndOfFirstPage) {
      setIsLoadingMore(true);
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      const params = {
        page: nextPage,
        limit: 10,
        stories: 'friends',
      };
      fetchAllPosts(nextPage, params).then(() => setIsLoadingMore(false));
      setIsEndOfFirstPage(false);
    }
  };
  const handleScroll = event => {
    const {contentOffset, layoutMeasurement, contentSize} = event.nativeEvent;
    const endOfFirstPageOffset = contentSize.height - layoutMeasurement.height;
    if (!contentOffset.y <= endOfFirstPageOffset) {
      setIsEndOfFirstPage(true);
    } else {
      setIsEndOfFirstPage(false);
    }
  };

  const likePost = async text => {
    try {
      const params = {story_id: text};
      const resultAction = await dispatch(likePosts(params));
      const newLikes = resultAction.payload.data.likes;
      setPostsData(prevData => {
        return prevData.map(item => {
          if (item._id === text) {
            const updatedLikes = [...item.likes, ...newLikes].filter(
              (like, index, self) =>
                index === self.findIndex(l => l._id === like._id),
            );
            const updatedItem = {
              ...item,
              likes: updatedLikes,
              likes_count: updatedLikes.length,
            };
            return updatedItem;
          }
          return item;
        });
      });
    } catch (error) {
      console.error('Error in likePosts:', error);
    }
  };

  const dislikePost = async text => {
    try {
      const params = {
        story_id: text.story_id,
        like_id: text.like_id,
      };
      const resultAction = await dispatch(removeLike(params));
      if (text.isCommentDislike) {
        fetchPostComment(text.story_id);
      } else {
        const newLikes = resultAction.payload.data.likes;
        if (newLikes) {
          setPostsData(prevData => {
            return prevData.map(item => {
              if (item._id === text.story_id) {
                return {
                  ...item,
                  likes: newLikes,
                };
              }
              return item;
            });
          });
        }
      }
    } catch (error) {
      console.error('Error in dislikePosts:', error);
    }
  };

  const postCommentOrReply = async text => {
    setIsSubmit(true);
    setIsFetchingNewComments(true);
    const {isReply} = formData;
    try {
      let resultAction;
      if (isReply) {
        // Reply
        const commentsId = text.comment_id.comment_id;
        resultAction = await dispatch(
          commentReply({
            story_id: text.story_id,
            comment_id: commentsId,
            text_comment: formData.comment,
          }),
        );
      } else {
        // New Comment
        resultAction = await dispatch(
          commentPost({
            story_id: text.story_id,
            comment: formData.comment,
          }),
        );
      }
      setIsSubmit(false);
      if (
        commentReply.fulfilled.match(resultAction) ||
        commentPost.fulfilled.match(resultAction)
      ) {
        const newComment = resultAction.payload.data;
        if (newComment) {
          setCommentData(prevData => ({
            ...prevData,
            result: [...(prevData?.result || []), newComment],
          }));
        }
        fetchPostComment(text.story_id);
        setFormData({...formData, comment: '', isReply: false});
        setCommentItems('');
      }
    } catch (error) {
      console.error('Error in CommentReply/CommentPost:', error);
      setIsSubmit(false);
      setIsFetchingNewComments(false);
    }
  };

  const fetchPostComment = async text => {
    refCommentSheet.current[text]?.open();
    setIsLoadingComment(true);
    const params = {
      story_id: text,
    };
    try {
      const resultAction = await dispatch(fetchComments(params));
      if (fetchComments.fulfilled.match(resultAction)) {
        const data = resultAction.payload.data;
        setCommentData(data);
        if (data) {
          const updatedPostsData = postsData.map(post => {
            if (post._id === text) {
              return {
                ...post,
                comments_count: data.comment_count,
              };
            }
            return post;
          });
          setPostsData(updatedPostsData);
        }
      }
    } catch (error) {
      setIsLoadingComment(false);
      console.error('Error in CommentPosts:', error);
    }
    setIsLoadingComment(false);
  };

  const postCommentLike = async text => {
    try {
      const params = {
        story_id: text.story_id,
        comment_id: text.comment_id,
      };
      const resultAction = await dispatch(likeComment(params));
      const likeData = resultAction.payload.data;
      fetchPostComment(params.story_id);
    } catch (error) {
      console.error('Error in postCommentLike:', error);
    }
  };

  const deleteItem = async params => {
    try {
      const resultAction = await dispatch(
        params.isComment === true ? deleteComment(params) : deletePost(params),
      );
      const data = resultAction.meta.arg;
      refPostSheet.current[params.story_id]?.close();
      if (params.isComment) {
        if (resultAction.payload.status) {
          setCommentData(prevData => ({
            ...prevData,
            result: prevData.result.filter(
              item => item._id !== data.comment_id,
            ),
            comment_count: prevData.comment_count - 1,
          }));
          fetchPostComment(params.story_id);
        }
      } else {
        setPostsData(prevData =>
          prevData.filter(item => item._id !== params.story_id),
        );
      }
    } catch (error) {
      console.error('Error in deleteItem:', error);
    }
  };

  const handleDeletePress = params => {
    setDeleteParams(params);
    Alert.alert(
      'Delete', // Alert Title
      params.isComment === true
        ? 'Are you sure you want to delete this comment ?'
        : 'Are you sure you want to delete this post ?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'Delete',
          onPress: () => deleteItem(params),
          style: 'destructive',
        },
      ],
    );
  };

  const shareStoryImg = async (storyImg) => {
    try {
      const imageUrl = storyImg && storyImg[0].media && storyImg[0].media.path;
      const downloadDest = `${RNFS.CachesDirectoryPath}/catchImage.jpg`;
      const options = {
        fromUrl: imageUrl,
        toFile: downloadDest,
      };
      await RNFS.downloadFile(options).promise;
      const shareOptions = {
        title: 'Check out my story!',
        url: `file://${downloadDest}`,
        type: 'image/jpeg',
        failOnCancel: false,
      };
        Share.open(shareOptions);

    } catch (error) {
      alert(error.message);
    }
  };

  const closeCommentSheet = () => {
    setCommentData('');
    setCommentItems('');
    setFormData('');
    setExpandedComments('');
    fetchAllPosts(currentPage, params);
  };

  function navigateToProfile(text) {
    refCommentSheet.current[text.story_id]?.close();
    setTimeout(() => {
    const item_id = text.user_id;
    if (item_id === stateVal.id) {
      navigation.navigate('UserProfile', isProfile = true);
    } else {
      const hasFriend = myFriendData.some(item => item.id === item_id);
      if (hasFriend) {
        navigation.navigate('MyFriendProfile', item_id);
      } else {
        navigation.navigate('FriendProfile', item_id);
      }
    }
  }, 1500);
  }

  const reportPost = async text => {
    refReportSheet.current[text.story_id]?.close();
    try {
      const params = {story: text.story_id, text: text.reportText};
      const resultAction = await dispatch(reportStoryPost(params));
      if (reportStoryPost.fulfilled.match(resultAction)) {
        const data = resultAction.payload.data;
      }
    } catch (error) {
      console.error('Error in reportStoryPost:', error);
    }
  };

  const CommentText = ({ comment }) => {
    const usernameRegex = /(@\w+\s\w+)/g;
    const parts = comment.split(usernameRegex);
    return (
      <Text>
        {parts.map((part, index) => {
          if (usernameRegex.test(part)) {
            return (
              <Text key={index} style={[StoryBoardStyle.CommentText, {fontSize: 14, fontFamily: Dm.semiBold, color: UiColor.DarkBlue}]}>
                {part}
              </Text>
            );
          } else {
            return (
              <Text key={index} style={[StoryBoardStyle.CommentText, {fontSize: 14,}]}>
                {part}
              </Text>
            );
          }
        })}
      </Text>
    );
  };

  const renderReplies = parentCommentId => {
    const params = {
      story_id: parentCommentId.story_id,
      comment_id: parentCommentId.comment_id,
      user_id: parentCommentId.user_id,
    };
    const replies = commentData.result?.filter(
      comment => comment.parent_comment_id === params.comment_id,
    );

    return replies.map(reply => {
      const formatTime = moment(
        reply.created_at,
        'DD MM YYYY hh:mm:ss a',
      ).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
      const fromNowTime = moment(formatTime).fromNow();
      return (
        <View key={reply._id}>
          <View
            style={[
              StoryBoardStyle.CommentWrap,
              StoryBoardStyle.CommentWrapInner,
            ]}>
            <TouchableOpacity
              style={[StoryBoardStyle.ProfileCta, {marginRight: 6}]}
              onPress={() =>
                navigateToProfile({
                  user_id: reply.user_id._id,
                  story_id: params.story_id,
                })
              }>
              {reply?.user_id.profile_image?.path ? (
                <Avatar.Image
                  style={{backgroundColor: UiColor.ImageLoad}}
                  size={32}
                  source={{
                    uri: reply?.user_id?.profile_image.path,
                  }}
                />
              ) : (
                <Avatar.Image style={{backgroundColor: UiColor.ImageLoad}} size={32} source={IconAsset.BlankUser} />
              )}
            </TouchableOpacity>
            <View style={StoryBoardStyle.CommentCardHead}>
              <View style={StoryBoardStyle.CommentCard}>
                <View style={StoryBoardStyle.CommentCardTitle}>
                  <Text style={StoryBoardStyle.CommentTitle}>
                    {reply?.user_id?.first_name +
                      ' ' +
                      reply?.user_id?.last_name}
                  </Text>
                  <Text style={StoryBoardStyle.CommentDate}>{fromNowTime}</Text>
                </View>
                {/* <Text style={StoryBoardStyle.CommentText}>
                  {reply?.text_comment}
                </Text> */}
                <CommentText comment={reply?.text_comment} />
              </View>
              <View style={StoryBoardStyle.CommentRange}>
                {reply && reply.like_count === 0 ? (
                  ''
                ) : (
                  <Text style={StoryBoardStyle.CommentRangeText}>
                    {reply.like_count}
                  </Text>
                )}
                {reply.likes?.some(like => like.user_id === stateVal.id) ? (
                  <TouchableOpacity
                    onPress={() => {
                      dislikePost({
                        story_id: params.story_id,
                        isCommentDislike: true,
                        like_id: reply.likes.find(
                          like => like.user_id === stateVal.id,
                        )._id,
                      });
                    }}>
                    <Text style={StoryBoardStyle.CommentRangeText}>Unlike</Text>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    onPress={() => {
                      postCommentLike({
                        story_id: params.story_id,
                        comment_id: reply._id,
                      });
                    }}>
                    <Text style={StoryBoardStyle.CommentRangeText}>Like</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity
                  onPress={() => {
                    setCommentItems({
                      comment_id: reply._id,
                      fullName:
                        reply.user_id.first_name +
                        ' ' +
                        reply.user_id.last_name,
                    });
                    setFormData({
                      ...formData,
                      comment: `@${reply.user_id.first_name } ${reply.user_id.last_name} `,
                      isReply: true,
                    });
                    commentInputRef.current && commentInputRef.current.focus();
                  }}>
                  <Text style={StoryBoardStyle.CommentRangeText}>Reply</Text>
                </TouchableOpacity>
                {reply.user_id._id === stateVal.id ||
                params.user_id === stateVal.id ? (
                  <TouchableOpacity
                    onPress={() => {
                      handleDeletePress({
                        story_id: params.story_id,
                        comment_id: reply._id,
                        isComment: true,
                      });
                    }}>
                    <Text style={StoryBoardStyle.CommentRangeText}>Delete</Text>
                  </TouchableOpacity>
                ) : (
                  ''
                )}
              </View>
            </View>
          </View>
          {renderReplies(
            {
              story_id: params.story_id,
              comment_id: reply._id,
              user_id: params.user_id,
            },
            commentData,
          )}
        </View>
      );
    });
  };

  const ListItem = ({item, index}) => {
    return (
      <View style={Styles.PostCard} key={index}>
        <View style={Styles.PostTitleHead}>
          <View style={{flexDirection: 'row'}}>
            <TouchableOpacity
              onPress={() => navigateToProfile({user_id: item.user._id})}>
              {item?.user?.profile_image?.path ? (
                <Avatar.Image
                  style={{backgroundColor: UiColor.ImageLoad}}
                  size={51}
                  source={{
                    uri: item.user?.profile_image?.path,
                  }}
                />
              ) : (
                <Avatar.Image style={{backgroundColor: UiColor.ImageLoad}} size={60} source={IconAsset.BlankUser} />
              )}
            </TouchableOpacity>
            <View>
              <Text style={Styles.PostCardTitle}>
                {item.user.first_name + ' ' + item.user.last_name}
              </Text>
              <Text style={Styles.PostCardSubTitle}>
                {moment(item.created_at).fromNow()}
              </Text>
            </View>
          </View>
          <IconButton
            onPress={() => {
              refPostSheet.current[item._id]?.open();
            }}
            style={{marginRight: -10}}
            icon={() => <Icon name={'more-fill'} color={'#536471'} size={18} />}
            size={15}
          />
          <RBSheet
            ref={ref => (refPostSheet.current[item._id] = ref)}
            closeOnDragDown={true}
            closeOnPressMask={true}
            openDuration={800}
            height={250}
            customStyles={{
              wrapper: {
                backgroundColor: '#00000024',
              },
              draggableIcon: {
                backgroundColor: '#E3E3E3',
              },
              container: {
                borderTopLeftRadius: 30,
                borderTopRightRadius: 30,
              },
            }}>
            <View style={Styles.PostCardEdit}>
              {item.user._id === stateVal.id && (
                <TouchableOpacity
                  onPress={() => {
                    handleDeletePress({
                      story_id: item._id,
                      isComment: false,
                    });
                  }}
                  style={[Styles.PostActionBtn, {marginTop: 10}]}>
                  <Text style={Styles.PostActionText}>Delete</Text>
                </TouchableOpacity>
              )}
              {item.user._id !== stateVal.id && (
                <TouchableOpacity
                  style={[[Styles.PostActionBtn, {marginTop: 10}]]}
                  onPress={() => {
                    refPostSheet.current[item._id]?.close();
                    setTimeout(() => {
                      refReportSheet.current[item._id]?.open();
                    }, 1500);
                  }}>
                  <Text style={Styles.PostActionText}>Report</Text>
                </TouchableOpacity>
              )}
              {item.user._id === stateVal.id && (
              <TouchableOpacity onPress={() => [refPostSheet.current[item._id]?.close(), shareStoryImg(item.media)]}
               style={[Styles.PostActionBtn, {marginTop: 10}]}>
                <Text style={Styles.PostActionText}>Share</Text>
              </TouchableOpacity>
              )}
            </View>
          </RBSheet>
          <RBSheet
            ref={ref => (refReportSheet.current[item._id] = ref)}
            closeOnDragDown={true}
            closeOnPressMask={true}
            openDuration={800}
            height={400}
            customStyles={{
              wrapper: {
                backgroundColor: '#00000024',
              },
              draggableIcon: {
                backgroundColor: '#E3E3E3',
              },
              container: {
                borderTopLeftRadius: 30,
                borderTopRightRadius: 30,
              },
            }}>
            <View
              style={[
                Styles.PostCardEdit,
                {flexDirection: 'column',
                  justifyContent: 'space-between', alignItems: 'left', marginTop: 10},
              ]}>
              <Text
                style={[
                  Styles.ReportText,
                  {fontFamily: Dm.semiBold, fontSize: 20, paddingTop: 5},
                ]}>
                Why are you reporting this post?
              </Text>
              <Text
                style={[
                  Styles.ReportText,
                  {
                    fontFamily: Dm.regular,
                    fontSize: 12,
                    paddingTop: 5,
                    color: UiColor.GrayLight,
                  },
                ]}>
                Currently, you can report a post for any of the following
                reasons:
              </Text>
              <TouchableOpacity
                onPress={() =>
                  reportPost({
                    story_id: item._id,
                    reportText: "I just don't like it",
                  })
                }>
                <Text style={Styles.ReportText}>I just don't like it</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() =>
                  reportPost({story_id: item._id, reportText: "It's a spam"})
                }>
                <Text style={Styles.ReportText}>It's a spam</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() =>
                  reportPost({
                    story_id: item._id,
                    reportText: 'Violence or dangerous organizations',
                  })
                }>
                <Text style={Styles.ReportText}>
                  Violence or dangerous organizations
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() =>
                  reportPost({story_id: item._id, reportText: 'Scam or fraud'})
                }>
                <Text style={Styles.ReportText}>Scam or fraud</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() =>
                  reportPost({
                    story_id: item._id,
                    reportText: 'Suicide or self-injury',
                  })
                }>
                <Text style={Styles.ReportText}>Suicide or self-injury</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() =>
                  reportPost({
                    story_id: item._id,
                    reportText: 'Sale of illegal or regulated goods',
                  })
                }>
                <Text style={Styles.ReportText}>
                  Sale of illegal or regulated goods
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() =>
                  reportPost({story_id: item._id, reportText: 'Something else'})
                }>
                <Text style={Styles.ReportText}>Something else</Text>
              </TouchableOpacity>
            </View>
          </RBSheet>
        </View>
       {item.quote ? <Text style={[Styles.PostCardDisc]}>{item.quote}</Text> : <Text></Text>}
        <View style={Styles.PostCardImgHead}>
          {item.media && item.media.length > 1 ? (
            <Slick
              dotColor="#fff"
              activeDotColor="#D1283D"
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                height: 297,
              }}>
              {item.media &&
                item.media.map((mediaItem, mediaIndex) => (
                  <View key={mediaIndex}>
                    <FastImage
                      source={{uri: mediaItem.media.path}}
                      style={Styles.PostCardImg}
                      key={mediaIndex}
                    />
                  </View>
                ))}
            </Slick>
          ) : (
            item.media &&
            item.media.map((mediaItem, index) => (
              <Image
                key={index}
                source={{uri: mediaItem.media.path}}
                style={Styles.PostCardImg}
              />
            ))
          )}
        </View>

        <View>
          <View style={Styles.PostCardFoot}>
            <TouchableOpacity
              onPress={() => navigation.navigate('PostLikes', item._id)}>
              <View style={Styles.PostLikeCount}>
                  <Icon
                  name="unfill-hang-luss"
                  color={UiColor.SecondaryColor}
                  size={12}
                />
                {item && item.likes?.length > 0 ? (
                  <Text style={Styles.PostLikeText}>
                    {item.likes?.length}{' '}
                    {item.likes?.length === 1 ? 'Like' : 'Likes'}
                  </Text>
                ) : (
                  <Text style={Styles.PostLikeText}>Likes</Text>
                )}
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                fetchPostComment(item._id);
              }}>
              {item && item.comments_count > 0 ? (
                <Text style={Styles.PostLikeText}>
                  {item.comments_count}{' '}
                  {item && item.comments_count === 1 ? 'Comment' : 'Comments'}
                </Text>
              ) : (
                <Text style={Styles.PostLikeText}>Comments</Text>
              )}
            </TouchableOpacity>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              paddingTop: 8,
            }}>
            <TouchableOpacity
              style={Styles.PostCardBtn}
              onPress={() =>
                item.likes.some(likeItem => likeItem.user_id === stateVal.id)
                  ? dislikePost({
                      story_id: item._id,
                      like_id: item.likes.find(like => like.user_id === stateVal.id)._id,
                    })
                  : likePost(item._id)
              }
            >
               <Icon
                  name= {item.likes.some(likeItem => likeItem.user_id === stateVal.id) ? "unfill-hang-luss" : "unfill-hang-luss"}
                  color={item.likes.some(likeItem => likeItem.user_id === stateVal.id) ? UiColor.SecondaryColor : UiColor.GrayLight}
                  size={18}
                />
              <Text style={[Styles.PostLikeText, {marginLeft: 5, color: item.likes.some(likeItem => likeItem.user_id === stateVal.id) ? UiColor.SecondaryColor : UiColor.GrayLight,}]}>Like</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={Styles.PostCardBtn}
              onPress={() => {
                fetchPostComment(item._id);
              }}>
              <Icon name="comment" size={20} color={'#536471'} />
              <Text style={Styles.PostLikeText}>Comment</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  };

  return (
    <>
    { !isConnected && postsData && postsData.length === 0 ?
      <View style={[GlobalStyles.NoData, {marginTop: 80}]}>
        <Icon name="no-connection" size={50} />
        <Text style={[GlobalStyles.NoDataMsg, {fontFamily: Dm.semiBold}]}>
          No Internet Connection
        </Text>
      </View> 
    :
    <>
      {Object.keys(postsData).length === 0 && isLoadingMore ? (
          <SkeletonPlaceholder>
            {[...Array(4)].map((_, index) => (
              <SkeletonPlaceholder.Item
                key={index}
                flexDirection="row"
                alignItems="center"
                marginBottom={0}
                marginTop={20}
                marginHorizontal={18}>
                <SkeletonPlaceholder.Item
                  width="100%"
                  height={200}
                  borderRadius={6}
                />
              </SkeletonPlaceholder.Item>
            ))}
          </SkeletonPlaceholder>
        ) : (
        <FlatList
          data={postsData}
          onEndReached={handleEndReached}
          onEndReachedThreshold={0.1}
          renderItem={({item, index}) => <ListItem item={item} index={index} />}
          keyExtractor={(item, index) => index.toString()}
          refreshing={stateValue.refreshing}
          onRefresh={handleRefresh}
          onScroll={handleScroll}
          showsVerticalScrollIndicator={false}
          ListFooterComponent={() => {
            return isEndOfFirstPage ? (
              <ActivityIndicator
                animating={true}
                size={32}
                color={UiColor.BaseColor}
              />
            ) : null;
          }}
          ListEmptyComponent={() => {
            if (!isLoadingMore && postsData && postsData.length === 0) {
              return (
                <View style={[GlobalStyles.NoData, {marginTop: 30}]}>
                  <Text style={GlobalStyles.NoDataMsg}>No Posts Found</Text>
                </View>
              );
            }
            return null;
          }}
        />
      )}
    </>
    }

      {postsData &&
        postsData.map((item, index) => (
          <RBSheet
            key={index}
            ref={ref => (refCommentSheet.current[item._id] = ref)}
            closeOnDragDown={true}
            closeOnPressMask={true}
            onClose={() => closeCommentSheet()}
            openDuration={1000}
            customStyles={{
              wrapper: {
                backgroundColor: '#00000024',
              },
              draggableIcon: {
                backgroundColor: '#000',
              },
              container: {
                height: '55%',
              },
            }}>
            <FlatList
              data={commentData?.result}
              keyExtractor={commentItem => commentItem._id}
              showsVerticalScrollIndicator={false}
              ListEmptyComponent={() => {
                if (!isLoadingComment && !commentData.result) {
                  return (
                    <View style={[GlobalStyles.NoData, {marginTop: 30}]}>
                      <Text style={GlobalStyles.NoDataMsg}>No Comments Found</Text>
                    </View>
                  );
                }
                return null;
              }}
              renderItem={({item: commentItem}) => {
                const hasChildComments = commentData?.result.some(
                  c => c.parent_comment_id === commentItem._id,
                );
                const formatTime = moment(
                  commentItem.created_at,
                  'DD MM YYYY hh:mm:ss a',
                ).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
                const fromNowTime = moment(formatTime).fromNow();
                return (
                  <>
                    {commentItem.parent_comment_id === null && (
                      <View
                        style={[StoryBoardStyle.CommentWrap]}
                        key={commentItem._id}>
                        <TouchableOpacity
                          style={[StoryBoardStyle.ProfileCta]}
                          onPress={() =>
                            navigateToProfile({
                              user_id: commentItem.user_id._id,
                              story_id: item._id,
                            })
                          }>
                          {commentItem.user_id?.profile_image?.path ? (
                            <Avatar.Image
                              style={{backgroundColor: UiColor.ImageLoad}}
                              size={40}
                              source={{
                                uri: commentItem.user_id.profile_image.path,
                              }}
                            />
                          ) : (
                            <Avatar.Image
                              style={{backgroundColor: UiColor.ImageLoad}}
                              size={40}
                              source={IconAsset.BlankUser}
                            />
                          )}
                        </TouchableOpacity>
                        <TouchableOpacity style={{width: '100%'}}>
                          <View style={StoryBoardStyle.CommentCardHead}>
                            <View style={StoryBoardStyle.CommentCard}>
                              <View style={StoryBoardStyle.CommentCardTitle}>
                                <Text style={StoryBoardStyle.CommentTitle}>
                                  {commentItem?.user_id.first_name +
                                    ' ' +
                                    commentItem?.user_id.last_name}
                                </Text>
                                <Text style={StoryBoardStyle.CommentDate}>
                                  {fromNowTime}
                                </Text>
                              </View>
                              <Text style={StoryBoardStyle.CommentText}>
                                {commentItem.text_comment}
                              </Text>
                            </View>
                            <View style={StoryBoardStyle.CommentRange}>
                              {commentItem && commentItem.like_count === 0 ? (
                                ''
                              ) : (
                                <Text style={StoryBoardStyle.CommentRangeText}>
                                  {commentItem.like_count}
                                </Text>
                              )}
                              {commentItem.likes?.some(
                                like => like.user_id === stateVal.id,
                              ) ? (
                                <TouchableOpacity
                                  onPress={() => {
                                    dislikePost({
                                      story_id: item._id,
                                      isCommentDislike: true,
                                      like_id: commentItem.likes.find(
                                        like => like.user_id === stateVal.id,
                                      )._id,
                                    });
                                  }}>
                                  <Text
                                    style={StoryBoardStyle.CommentRangeText}>
                                    Unlike
                                  </Text>
                                </TouchableOpacity>
                              ) : (
                                <TouchableOpacity
                                  onPress={() => {
                                    postCommentLike({
                                      story_id: item._id,
                                      comment_id: commentItem._id,
                                    });
                                  }}>
                                  <Text
                                    style={StoryBoardStyle.CommentRangeText}>
                                    Like
                                  </Text>
                                </TouchableOpacity>
                              )}
                              <TouchableOpacity
                                onPress={() => {
                                  setCommentItems({
                                    comment_id: commentItem._id,
                                    fullName:
                                      commentItem.user_id.first_name +
                                      ' ' +
                                      commentItem.user_id.last_name,
                                  });
                                  setFormData({
                                    ...formData,
                                    comment: `@${commentItem.user_id.first_name} ${commentItem.user_id.last_name} `,
                                    isReply: true,
                                  });
                                  commentInputRef.current &&
                                    commentInputRef.current.focus();
                                }}>
                                <Text style={StoryBoardStyle.CommentRangeText}>
                                  Reply
                                </Text>
                              </TouchableOpacity>
                              {commentItem.user_id._id === stateVal.id ||
                              item.user._id === stateVal.id ? (
                                <TouchableOpacity
                                  onPress={() => {
                                    handleDeletePress({
                                      story_id: item._id,
                                      comment_id: commentItem._id,
                                      isComment: true,
                                    });
                                  }}>
                                  <Text
                                    style={StoryBoardStyle.CommentRangeText}>
                                    Delete
                                  </Text>
                                </TouchableOpacity>
                              ) : (
                                ''
                              )}
                            </View>
                            {hasChildComments && (
                              <>
                                <TouchableOpacity
                                  onPress={() =>
                                    toggleRepliesVisibility(commentItem._id)
                                  }>
                                  <Text
                                    style={[
                                      StoryBoardStyle.CommentCount,
                                      {
                                        marginTop: expandedComments[
                                          commentItem._id
                                        ]
                                          ? 0
                                          : 8,
                                      },
                                    ]}>
                                    {expandedComments[commentItem._id]
                                      ? ''
                                      : 'View more replies...'}
                                  </Text>
                                </TouchableOpacity>
                                {/* Reply */}
                                {expandedComments[commentItem._id] &&
                                  renderReplies(
                                    {
                                      story_id: item._id,
                                      comment_id: commentItem._id,
                                      user_id: item.user._id,
                                    },
                                    commentData,
                                  )}
                                {expandedComments[commentItem._id] && (
                                  <TouchableOpacity
                                    onPress={() =>
                                      toggleRepliesVisibility(commentItem._id)
                                    }>
                                    <Text style={StoryBoardStyle.CommentCount}>
                                      Hide replies
                                    </Text>
                                  </TouchableOpacity>
                                )}
                              </>
                            )}
                          </View>
                        </TouchableOpacity>
                      </View>
                    )}
                  </>
                );
              }}
              ListFooterComponent={() => {
                {
                  isFetchingNewComments && (
                    <View>
                      <ActivityIndicator
                        animating={true}
                        size={32}
                        color={UiColor.BaseColor}
                      />
                    </View>
                  );
                }
              }}
            />
           {/* )} */}
            <KeyboardAvoidingView
              behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
              style={{
                position: 'fixed',
                bottom: 0,
                ...Platform.select({
                  ios: {
                    bottom: 25,
                  },
                }),
                left: 0,
                backgroundColor: '#fff',
                width: '100%',
                paddingVertical: 20,
                paddingHorizontal: 16,
                shadowColor: '#000',
                shadowOffset: {
                  width: 0,
                  height: -20,
                },
                shadowOpacity: 0.1,
                shadowRadius: 0,
                elevation: 20,
                ...Platform.select({
                  ios: {
                    shadowOffset: {
                      height: -5,
                    },
                    shadowRadius: 3.84,
                  },
                }),
              }}>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <View style={{width: '100%'}}>
                  <TextInput
                    placeholder={'Write a comment...'}
                    value={formData.comment}
                    ref={commentInputRef}
                    style={[StoryBoardStyle.FormInput]}
                    textColor={UiColor.PrimaryColor}
                    theme={StoryBoardStyle.TextInput}
                    onChangeText={text => {
                      const usernameExists =
                        commentItems && text.includes(`@${commentItems.fullName}`);
                      setFormData({
                        ...formData,
                        comment: text,
                        isReply: usernameExists,
                      });
                    }}
                    underlineStyle={{backgroundColor: 'transparent'}}
                    autoCapitalize="none"
                  />
                  <TouchableOpacity
                    style={{position: 'absolute', top: 0, right: 0}}
                    onPress={() => {
                      postCommentOrReply({
                        story_id: item._id,
                        comment_id: commentItems,
                      });
                    }}>
                    {isSubmit ? (
                      <ActivityIndicator
                        style={{width: 39, height: 39, top: 8, right: 8}}
                      />
                    ) : (
                      <Image
                        source={IconAsset.Share}
                        style={{width: 39, height: 39, top: 8, right: 8}}
                      />
                    )}
                  </TouchableOpacity>
                </View>
              </View>
            </KeyboardAvoidingView>
          </RBSheet>
        ))}

      <TouchableOpacity
        onPress={() => navigation.navigate('PostsUpload', {isUserPosts: false})}
        style={[Styles.AddBtn]}>
        <Icon name="plus" size={18} color={UiColor.White} />
      </TouchableOpacity>
    </>
  );
};

export default FriendsPosts;
