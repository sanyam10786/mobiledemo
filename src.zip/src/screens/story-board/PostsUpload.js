import {View, Text, TextInput, Modal, TouchableOpacity, Image, FlatList, Platform, KeyboardAvoidingView, StyleSheet, Keyboard} from 'react-native';
import {Appbar, Avatar, ActivityIndicator, HelperText, FAB} from 'react-native-paper';
import { Styles, UiColor, IconAsset, Icon, Dm } from '../../../theme/Index';
import { useIsFocused, useRoute } from '@react-navigation/native';
import { RemoveStyle } from '../auth/remove-account/RemoveStyle';
import ImageCropPicker from 'react-native-image-crop-picker';
import { FriendsStyle } from '../add-friends/FriendsStyle';
import { useDispatch, useSelector } from 'react-redux';
import React, { useEffect, useState } from 'react';
import { addPosts } from '../../thunk';
import FastImage from 'react-native-fast-image';

const PostsUpload = ({ navigation }) => {
  const dispatch = useDispatch();
  const route = useRoute();
  const userPosts = route.params;
  const profileRoute =  userPosts.isUserPosts;
  const isFocused = useIsFocused();
  const [takePost, setTakePost] = useState(false);
  const [isSubmit, setIsSubmit] = useState(false);
  const [selectedImages, setSelectedImages] = useState([]);
  const stateVal = useSelector(state => state.login);
  const userData = useSelector(state => state.user);
  const [isModalVisible, setModalVisible] = useState(false);
  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false); 
  const [previewIndex, setPreviewIndex] = useState(null);
  const [isDropdownOpen, setDropdownOpen] = useState(false);
  const [selectedOption, setSelectedOption] = useState('public');
  const [formErrors, setFormErrors] = useState({});
  const [state, setState] = React.useState({open: false});
  const onStateChange = ({open}) => setState({open});
  const {open} = state;
  const [formData, setFormData] = useState({
    stories: '',
    quote: '',
    visibility: 'friends',
    story_type: 'post',
  });

  useEffect(() => {
    if (isFocused) {
      if (userPosts && userPosts.media) {
        setFormData({
          ...formData,
          stories: userPosts && userPosts.media,
        });
        setSelectedImages([userPosts && userPosts.media]);
      }
    }
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => setIsKeyboardVisible(true),
    );
    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => setIsKeyboardVisible(false),
    );
    return () => {
      keyboardDidHideListener.remove();
      keyboardDidShowListener.remove();
    };
  }, [isFocused]);

  const hasErrors = () => {
    const errors = {};
    if (selectedImages.length === 0) {
      errors.stories = 'please select image for upload';
    }
    setFormErrors(errors);
    return Object.keys(errors).length > 0;
  };

  const submitData = async () => {
    if (hasErrors()) {
      return;
    }
    setFormErrors({});
    setIsSubmit(true);

    const updatedPostPickParams = {
      stories: selectedImages.map(uri => ({
        fileCopyUri: null,
        name: 'images.jpg',
        size: '20',
        type: 'image/jpeg',
        uri: uri,
      })),
      quote: formData.quote,
      visibility: formData.visibility,
      story_type: formData.story_type,
    };
    try {
      const resultAction = await dispatch(addPosts(updatedPostPickParams));
      setIsSubmit(false);
      if (addPosts.fulfilled.match(resultAction)) {
        setFormData(prevState => ({
          ...prevState,
          quote: '',
        }));
        setSelectedImages('');
        if (userPosts.isUserPosts === true) {
          navigation.goBack();
        } else {
          navigation.navigate('StoryBoard');
        }
        const fetchedPosts = resultAction.payload.data;
      }
      return resultAction.payload.data;
    } catch (error) {
      console.log('Error submitting data:', error);
      setIsSubmit(false);
    }
    setTakePost(false);
  };

  const handleImagePicker = async () => {
    try {
      const response = await ImageCropPicker.openPicker({
        cropping: false,
        cropperCircleOverlay: false,
        compressImageQuality: 0.8,
        width: 300,
        height: 300,
        multiple: true,
        mediaType: 'photo',
      });
      console.log('response', response);
      const remainingSlots = 6 - selectedImages.length;
      if (response.length > 0 && remainingSlots > 0) {
        const newImages = response
          .slice(0, remainingSlots)
          .map(item => item.path);
        setSelectedImages(prevImages => [
          ...prevImages,
          ...response.map(item => item.path),
        ]);
      }
    } catch (err) {
      console.log('File picking error:', err);
      setTakePost(false);
    }
  };

  const renderItem = ({ item, index }) => (
    <TouchableOpacity style={{ flex: 1 }} onPress={() => toggleModal(index)}>
      <FastImage
        source={{ uri: `${item}?timestamp=${new Date().getTime()}` }}
        style={{ flex: 1, aspectRatio: 1, margin: 4 }}
        resizeMode="cover"
      />
    </TouchableOpacity>
  );

  const toggleModal = item => {
    setModalVisible(!isModalVisible);
    setPreviewIndex(item);
  };

  const cancelSelectedImage = index => {
    setSelectedImages(prevImages => {
      const updatedImages = [...prevImages];
      updatedImages.splice(index, 1);
      return updatedImages;
    });
    setPreviewIndex(null);
    setModalVisible(false);
  };

  return (
    
    <View style={[{flex:1,paddingBottom: isKeyboardVisible ? 0 : 130 }]}>
      <View style={[Styles.AppBarShadow]}>
        <Appbar.Header style={[Styles.AppbarHeader, Styles.AppBarShadow]}>
          <Appbar.Action
            animated={false}
            size={20}
            rippleColor="#00000008"
            onPress={() => navigation.goBack()}
            style={{ backgroundColor: UiColor.SecondaryColor }}
            icon={() => (
              <Icon name="back" size={18} style={Styles.BackWhite} />
            )}
          />
          <Appbar.Content titleStyle={[Styles.NavTitle]} title="Create Post" />
          <TouchableOpacity
            style={[RemoveStyle.DeleteBtn,{ paddingHorizontal: 20,  paddingVertical: 7,
              alignItems: 'center'}]}
            onPress={() => {
              submitData();
            }}>
              <Text
                style={{
                  color: UiColor.White,
                  fontSize: 14,
                  fontFamily: Dm.bold,
                }}>
                {isSubmit ? (
                  <ActivityIndicator size={24} color="#fff" />
                ) : (
                  'Done'
                )}
              </Text>
          </TouchableOpacity>
        </Appbar.Header>
      </View>
      <View style={styles.userInfo}>
        <Avatar.Image
          style={styles.avatar}
          size={50}
          source={stateVal.profile_image_path ? { uri: stateVal.profile_image_path } : IconAsset.BlankUser}
        />
        <View style={styles.userNameContainer}>
          <Text style={styles.userName}>
            {stateVal.first_name + ' ' + stateVal.last_name}
          </Text>
        </View>
      </View>
      <HelperText
        type="error"
        style={styles.errorText}
        visible={formErrors.stories !== undefined}
      >
        {formErrors.stories}
      </HelperText>
      <View>
        <TextInput
          style={styles.textInput}
          value={formData.quote}
          placeholder="Write some caption..."
          placeholderTextColor={Platform.OS === 'ios' ? UiColor.Black : '#536471'}
          onChangeText={text => {
            if (text.length <= 250) {
              setFormErrors({ ...formErrors, quote: '' });
              setFormData({ ...formData, quote: text });
            } else {
              setFormErrors({ quote: 'quote must be 250 characters or less' });
            }
          }}
          multiline
          numberOfLines={4}
        />
        <HelperText
          type="error"
          style={Styles.ErrorMsg}
          visible={formErrors.quote !== undefined}
        >
          {formErrors.quote}
        </HelperText>
      </View>
        <FlatList
          data={selectedImages}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          numColumns={2}
        />
        {!isKeyboardVisible && (
          <View style={styles.bottomContainer}>
            <TouchableOpacity onPress={() => navigation.navigate('Catches',  {isProfile: true, isTrue: true, challengeId: '', isUserPosts: profileRoute })} style={styles.bottomBtn}>
              <View style={FriendsStyle.CardImageIcon}>
                <Image
                  style={styles.bottomIcon}
                  source={IconAsset.CatchGallery}
                />
              </View>
              <Text style={styles.bottomText}>Catch Gallery</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={handleImagePicker} style={styles.bottomBtn}>
              <View style={FriendsStyle.CardImageIcon}>
                <Icon name="gallery" size={20} color={UiColor.White} />
              </View>
              <Text style={styles.bottomText}>Photos</Text>
            </TouchableOpacity>
          </View>
        )}
      <Modal visible={isModalVisible} transparent={true} onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalContainer}>
          {selectedImages && (
            <Image
              source={{ uri: selectedImages[previewIndex] }}
              style={styles.modalImage}
              resizeMode="contain"
            />
          )}
          <TouchableOpacity style={styles.modalBackBtn} onPress={() => setModalVisible(false)}>
            <Icon name="back" size={26} color={UiColor.White} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.modalCloseBtn} onPress={() => cancelSelectedImage(previewIndex)}>
            <Icon name="cross" size={26} color={UiColor.White} />
          </TouchableOpacity>
        </View>
      </Modal>
    
      </View>
  );
};
export default PostsUpload;

const styles = StyleSheet.create({
  backAction: {
    backgroundColor: UiColor.SecondaryColor,
  },
  submitBtn: {
    paddingHorizontal: 20,
    paddingVertical: 7,
    alignItems: 'center',
    backgroundColor: RemoveStyle.DeleteBtn.backgroundColor,
  },
  submitText: {
    color: UiColor.White,
    fontSize: 14,
    fontFamily: Dm.bold,
  },
  userInfo: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    marginBottom: 20,
    marginTop: 12,
  },
  avatar: {
    marginRight: 10,
    backgroundColor: UiColor.ImageLoad,
  },
  userNameContainer: {
    marginTop: 12,
    marginLeft: 5,
  },
  userName: {
    marginBottom: 6,
    fontFamily: Dm.bold,
    fontSize: 16,
  },
  errorText: {
    left: 70,
    position: 'absolute',
    width: 250,
    top: 180,
  },
  textInput: {
    color: Platform.OS === 'ios' ? UiColor.Black : '#536471',
    fontSize: 15,
    paddingHorizontal: 10,
    textAlignVertical: 'top',
  },
  flatListContainer: {
    marginBottom: 400,
  },
  imageItem: {
    width: '100%',
    height: 150,
    margin: 5,
  },
  bottomContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    marginBottom: 0,
    width: '100%',
    backgroundColor: UiColor.White,
    flexDirection: 'column',
  },
  bottomBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    marginLeft: 10,
  },
  bottomIcon: {
    width: 20,
    height: 20,
    tintColor: UiColor.White,
  },
  bottomText: {
    fontFamily: Dm.bold,
  },
  modalContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
  },
  modalImage: {
    width: '100%',
    height: '100%',
    backgroundColor: '#222',
  },
  modalBackBtn: {
    position: 'absolute',
    top: 50,
    left: 20,
  },
  modalCloseBtn: {
    position: 'absolute',
    top: 50,
    right: 20,
  },
});
