import { useIsFocused, useNavigation, useRoute } from '@react-navigation/native';
import {Styles, UiColor, IconAsset, Icon, Dm} from '../../../theme/Index';
import React, { useEffect, useState, useRef } from 'react';
import { Appbar,IconButton,} from 'react-native-paper';
import { useDispatch, useSelector } from 'react-redux';
import {View, Text, Image,} from 'react-native';
import FriendsPosts from './FriendsPosts';
import fireStore from '@react-native-firebase/firestore'; 

const StoryBoard = ({ navigation }) => {
  const isFocused = useIsFocused();
  const route = useRoute();
  const [currentPage, setCurrentPage] = React.useState(1);
  const dispatch = useDispatch();
  const stateVal = useSelector(state => state.login);
  const notification = stateVal.notification_count;
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (isFocused) {
      const params = {
        page: currentPage,
        limit: 10,
        stories: 'public',
      };
      ChatNotification();
    }
  }, [isFocused]);

  const ChatNotification = async () => {
    try {
      const loggedInUserId = stateVal.id;
      const chatListSnapshot = await fireStore()
        .collection('chatlists')
        .where('receiverId', '==', loggedInUserId)
        .get();
      const chatListData = chatListSnapshot.docs.map(doc => doc.data());
      chatListData.map((obj, index) => {
        setUnreadCount(obj.unreadMessages);
      });
    } catch (error) {
      console.error('Error fetching chat list:', error);
    }
  };

  return (
    <>
      <Appbar.Header
        style={[
          Styles.AppbarHeader,
          Styles.AppBarShadow,
          { justifyContent: 'space-between' },
        ]}>
         <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{backgroundColor: UiColor.SecondaryColor}}
          icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
        />
        <Appbar.Content titleStyle={Styles.NavTitle} title="Story Board" />
        <Appbar.Action />
      </Appbar.Header>
      <FriendsPosts />
    </>
  );
};

export default StoryBoard;
