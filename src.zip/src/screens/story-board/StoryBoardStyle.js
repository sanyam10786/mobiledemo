/* eslint-disable prettier/prettier */
import { StyleSheet, Platform } from 'react-native';
import { Dm, UiColor } from '../../../theme/Index.js';

export const StoryBoardStyle = StyleSheet.create({

  FormInput: {
    color: ' UiColor.GrayLight',
    backgroundColor: '#E9E9E9',
    fontSize: 14,
    fontFamily: Dm.regular,
    width: '100%',
    marginBottom: 0,
    borderWidth: 0,
    borderRadius: 110,
    paddingRight: 40,
    ...Platform.select({
      ios: {
        height: 62,
      },
    }),
  },

  TextInput: {
    colors: {
      primary: UiColor.GrayLight,
      underlineColor: 'transparent',
      text: UiColor.PrimaryColor,
      placeholder: UiColor.PrimaryColor,
      onSurfaceVariant: '#7F7F7F',
      fontFamily: Dm.regular,
    },
    roundness: 110,
  },
  CommentWrap: {
    flexDirection: 'row',
    marginBottom: 22,
    paddingHorizontal: 18,
    marginLeft: 0,
    // paddingVertical: 30
  },
  CommentWrapInner: {
    marginBottom: 10,
    marginTop: 16,
    paddingHorizontal: 0,
    paddingVertical: 0
  },
  ProfileCta: {
    marginRight: 10,
    marginLeft: 0,
    maxWidth: '12%'
  },
  CommentCardHead: {
    maxWidth: '88%'
  },
  CommentCard: {
    backgroundColor: 'transparent',
    paddingHorizontal: 16,
    // paddingVertical: 13,
    // borderRadius: 15,
    // borderWidth: 1,
    // borderColor: '#00000014'
  },
  CommentCardTitle: {
    marginBottom: 3,
    flexDirection: 'row'
  },
  CommentTitle: {
    fontSize: 12,
    fontFamily: Dm.semiBold,
    color: '#100F4D',
    marginRight: 8,
    flexShrink: 1
  },
  CommentDate: {
    fontSize: 10,
    fontFamily: Dm.regular,
    color: '#7F7F7F',
    marginTop: 2
  },
  CommentText: {
    fontSize: 15,
    fontFamily: Dm.regular,
    color: '#100F4D',
    flexShrink: 1
  },
  CommentRange: {
    flexDirection: 'row',
    marginTop: 5,
    paddingHorizontal: 16,
  },
  CommentRangeText: {
    fontSize: 11,
    fontFamily: Dm.medium,
    color: '#536471',
    marginRight: 18,
  },
  CommentCount: {
    fontSize: 12,
    fontFamily: Dm.medium,
    color: '#536471',
    marginTop: 8
  },
});


