import {View, Text, TouchableOpacity, FlatList, SafeAreaView, Platform} from 'react-native';
import {Appbar, Searchbar, Avatar, IconButton, ActivityIndicator} from 'react-native-paper';
import {Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm} from '../../../theme/Index';
import {useIsFocused, useNavigation, useRoute} from '@react-navigation/native';
import {fetchAllUsers, addFriends, removeFriends} from '../../thunk';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import {resetState, setRefreshing} from '../../slices/posts';
import React, {useState, useEffect, useContext} from 'react';
import {fetchAllLikes, fetchMyFriends} from '../../thunk';
import {FriendsStyle} from '../add-friends/FriendsStyle';
import {useDispatch, useSelector} from 'react-redux';
import { NetworkContext } from '../../NetworkContext';

const PostLikes = ({navigation}) => {
  const dispatch = useDispatch();
  const stateVal = useSelector(state => state.user);
  const loginUser = useSelector(state => state.login);
  const stateValue = useSelector(state => state.posts);
  const posts = stateValue.likeUserData;
  const allFriends = useSelector(state => state.friends);
  const friendData = allFriends.myFriends.friends;
  const isFocused = useIsFocused();
  const [loadedData, setLoadedData] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [currentPage, setCurrentPage] = React.useState(1);
  const [shouldFetchNextPage, setShouldFetchNextPage] = useState(true);
  const [isEndOfFirstPage, setIsEndOfFirstPage] = useState(false);
  const [sentRequests, setSentRequests] = useState([]);
  const [loadingStates, setLoadingStates] = useState({});
  const isConnected = useContext(NetworkContext);
  const [search, setSearch] = useState('');
  const route = useRoute();
  const itemId = route.params;
  const [params, setParamData] = useState({
    search: search,
    page: 1,
    limit: 10,
    story_id: itemId,
  });

  useEffect(() => {
    if (isConnected  && isFocused) {
      const params = {
        page: currentPage,
        limit: 10,
        search: '',
        story_id: itemId,
      };
      fetchData(currentPage, params);
    }
  }, [isFocused, params]);

  const fetchData = async (page, params) => {
    setIsLoadingMore(true);
    try {
      if ('search' in params && params.search.trim() === '') {
        delete params.search; 
      }
      const resultAction = await dispatch(fetchAllLikes(params));
      if (fetchAllLikes.fulfilled.match(resultAction)) {
        const newData = resultAction.payload.data.result;
        if (newData.length < params.limit) {
          setShouldFetchNextPage(false);
        } else {
          setShouldFetchNextPage(true);
        }
        if (params.page === 1) {
          setLoadedData(newData);
        } else {
          setLoadedData(prevData => {
            const uniqueFilteredData = newData.filter(item => !prevData.map(prevItem => prevItem.like.user_id.id).includes(item.like.user_id.id));
            return [...prevData, ...uniqueFilteredData];
          });
        }
      }
      setIsLoadingMore(false);
    } catch (error) {
      setIsLoadingMore(false);
      console.error('Error fetching users:', error);
    }
  };

  const handleLoadMore = () => {
    if (!isLoadingMore && shouldFetchNextPage) {
      setIsLoadingMore(true);
      setIsEndOfFirstPage(true);
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      const params = {
        page: nextPage,
        limit: 10,
        search: '',
        story_id: itemId,
      };
      fetchData(nextPage, params).then(() => setIsLoadingMore(false));
      setIsEndOfFirstPage(false);
    }
  };

  const handleRefresh = () => {
    dispatch(setRefreshing({}));
    params.page = 1;
    fetchData(currentPage, params);
  };

  const handleOnSearchChange = text => {
    setSearch(text);
    params.search = text;
    params.page = 1;
    setIsSearching(true);
    fetchData(currentPage, params).then(() => {
      setIsSearching(false);
    });
  };

  const sendRequest = async id => {
    try {
      setLoadingStates(prevStates => ({...prevStates, [id]: true}));
      const params = {
        user_id: id,
      };
      const resultAction = await dispatch(addFriends(params));
      if (addFriends.fulfilled.match(resultAction)) {
        setLoadingStates(prevStates => ({...prevStates, [id]: false}));
        setLoadedData(prevData =>
          prevData.map(item =>
            item.like.user_id.id === id
              ? {
                  ...item,
                  friend: [
                    ...item.friend,
                    {
                      friend_id: resultAction.payload.data.id,
                      status: 'pending',
                    },
                  ],
                }
              : item,
          ),
        );
        setSentRequests([...sentRequests, id]);
        const sentRequest = resultAction.payload.data;
      }
      setLoadingStates(prevStates => ({...prevStates, [id]: false}));
    } catch (error) {
      console.error('Error sending request:', error);
      setLoadingStates(prevStates => ({...prevStates, [id]: false}));
    }
  };

  const removeRequest = async id => {
    try {
      setLoadingStates(prevStates => ({...prevStates, [id]: true}));
      const params = {friend_request_id: id};
      const resultAction = await dispatch(removeFriends(params));
      if (removeFriends.fulfilled.match(resultAction)) {
        setLoadingStates(prevStates => ({...prevStates, [id]: false}));
        setLoadedData(prevData =>
          prevData.map(item =>
            item.friend.some(friend => friend.friend_id === id)
              ? {
                  ...item,
                  friend: item.friend.filter(friend => friend.friend_id !== id),
                }
              : item,
          ),
        );
      }
      setLoadingStates(prevStates => ({...prevStates, [id]: false}));
    } catch (error) {
      console.error('Error removing request:', error);
      setLoadingStates(prevStates => ({...prevStates, [id]: false}));
    }
  };

  const navigateToProfile = (text, item) => {
    const item_id = text;
    if (item_id === loginUser.id) {
      navigation.navigate('UserProfile');
    } else {
      const isPending = item.friend.length === 0 || item.friend.some(friend => friend.status === 'pending');
      if (isPending === true) {
        navigation.navigate('FriendProfile', item_id);
      } else {
        navigation.navigate('MyFriendProfile', item_id);
      }
    }
  };

  const ListItem = (item, index) => {
    const friendsData = item.friend;
    return (
      <View
        style={[
          FriendsStyle.Card,
          {flexDirection: 'row', paddingTop: 25, paddingLeft: 20},
        ]}
        key={index}>
        <TouchableOpacity
          onPress={() => navigateToProfile(item.like.user_id.id, item)}>
          <View style={FriendsStyle.CardLeft}>
            {item.like.user_id.profile_image ? (
              <Avatar.Image
                style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                size={51}
                source={{uri: item.like.user_id.profile_image.path}}
              />
            ) : (
              <Avatar.Image
                style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                size={51}
                source={IconAsset.BlankUser}
              />
            )}
            <View>
              <Text style={FriendsStyle.CardTitle}>
                {item.like.user_id.first_name +
                  ' ' +
                  item.like.user_id.last_name}
              </Text>
              <Text style={FriendsStyle.CardDisc}>Liked your post</Text>
            </View>
          </View>
        </TouchableOpacity>
        {loginUser.id === item.like.user_id.id ||
        item.friend.some(friend => friend.status === 'accepted') ? (
          ''
        ) : (
          <View
            style={{
              flex: 1,
              flexDirection: 'row',
              position: 'absolute',
              right: 5,
              alignItems: 'center',
            }}>
            {friendsData[0] && friendsData[0].status === 'pending' ? (
              <>
                {loadingStates[friendsData[0] && friendsData[0].friend_id] ? (
                  <ActivityIndicator
                    animating={true}
                    color={UiColor.BaseColor}
                    size={30}
                    style={{marginRight: 5, paddingTop: 10}}
                  />
                ) : (
                  <IconButton
                    style={[FriendsStyle.CardIcon, Styles.BorderSuccess]}
                    onPress={() => removeRequest(friendsData[0].friend_id)}
                    icon={() => (
                      <Icon name={'check'} color={UiColor.Success} size={18} />
                    )}
                    size={28}
                  />
                )}
              </>
            ) : (
              <>
                {loadingStates[item.like.user_id.id] ? (
                  <ActivityIndicator
                    animating={true}
                    color={UiColor.BaseColor}
                    size={30}
                    style={{marginRight: 5, paddingTop: 10}}
                  />
                ) : (
                  <IconButton
                    style={[FriendsStyle.CardIcon]}
                    onPress={() => sendRequest(item.like.user_id.id)}
                    icon={() => (
                      <Icon
                        name={'plus'}
                        color={UiColor.PrimaryColor}
                        size={18}
                      />
                    )}
                    size={28}
                  />
                )}
              </>
            )}
          </View>
        )}
      </View>
    );
  };

  return (
    <>
      <View style={{flex: 1}}>
        <View style={[Styles.AppBarShadow]}>
          <Appbar.Header style={[Styles.AppbarHeader, Styles.SubHeader]}>
            <Appbar.Action
              animated={false}
              size={20}
              rippleColor="#00000008"
              onPress={() => navigation.goBack()}
              style={{ backgroundColor: UiColor.SecondaryColor }}
              icon={() => (
                <Icon name="back" size={18} style={Styles.BackWhite} />
              )}
            />
            <Appbar.Content titleStyle={Styles.NavTitle} title="Likes" />
            <Appbar.Action />
          </Appbar.Header>
          <View style={Styles.SearchHead}>
            <Searchbar
              placeholder="Search..."
              value={params.search}
              theme={Styles.SearchInputTheme}
              style={[Styles.SearchInput]}
              onChangeText={text => handleOnSearchChange(text)}
              inputStyle={[Styles.SearchInputStyle]}
              placeholderTextColor={UiColor.PrimaryColor}
              iconColor={UiColor.PrimaryColor}
              icon={() => (
                <Icon name="search" size={24} color={UiColor.PrimaryColor} />
              )}
              clearIcon={() =>
                search.length > 0 ? (
                  <Icon color={UiColor.PrimaryColor} name="cross" size={18} />
                ) : (
                  ''
                )
              }
            />
          </View>
        </View>
        <View style={[FriendsStyle.Container, {backgroundColor: 'transparent'}]}>
        <SafeAreaView style={[FriendsStyle.CardArea, {marginBottom: Platform.OS === 'ios' ? 170 : 160}]}>
        {!isConnected && loadedData && loadedData.length === 0 ?
          <View style={[GlobalStyles.NoData, {marginTop: 80}]}>
            <Icon name="no-connection" size={50} />
            <Text style={[GlobalStyles.NoDataMsg, {fontFamily: Dm.semiBold}]}>
              No Internet Connection
            </Text>
          </View> 
        :
        <>
          {Object.keys(loadedData).length === 0 && isLoadingMore ? (
            <SkeletonPlaceholder>
              {Array.from({ length: 10 }).map((_, index) => (
                <View style={[FriendsStyle.Card, {shadowOpacity: 0,
                  shadowRadius: 0,}]} key={index}>
                  <SkeletonPlaceholder.Item height={50} width="100%">
                    <View style={FriendsStyle.CardLeft}>
                      <SkeletonPlaceholder.Item
                        width={51}
                        height={51}
                        borderRadius={51}
                      />
                      <View>
                        <SkeletonPlaceholder.Item
                          height={20}
                          width={120}
                          marginLeft={10}
                        />
                        <SkeletonPlaceholder.Item
                          height={20}
                          width={150}
                          marginLeft={10}
                          marginTop={8}
                        />
                      </View>
                    </View>
                  </SkeletonPlaceholder.Item>
                </View>
              ))}
            </SkeletonPlaceholder>
            ) : (
            <FlatList
              data={loadedData}
              renderItem={({item, index}) => ListItem(item, index)}
              onEndReachedThreshold={0.1}
              onEndReached={handleLoadMore}
              keyExtractor={(item, index) => index.toString()}
              refreshing={stateValue.refreshing}
              showsVerticalScrollIndicator={false}
              onRefresh={handleRefresh}
              ListFooterComponent={() => {
                return isLoadingMore ? (
                  <ActivityIndicator
                    animating={true}
                    size={32}
                    color={UiColor.BaseColor}
                  />
                ) : null;
              }}
            />
          )}
        
          {!isSearching && !isLoadingMore && loadedData && loadedData?.length === 0 && (
            <View style={GlobalStyles.NoData}>
              <Text style={GlobalStyles.NoDataMsg}>No users Found</Text>
            </View>
          )}
        </>
        }
          </SafeAreaView>
        </View>
      </View>
    </>
  );
};
export default PostLikes;
