import {View, Text, TouchableOpacity, Image, FlatList, SafeAreaView, Platform, BackHandler } from 'react-native';
import {useFocusEffect, useIsFocused, useNavigation, useRoute} from '@react-navigation/native';
import { Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm} from '../../../theme/Index';
import {fetchMyFriends, fetchAllChallenges, tournamentRemainder} from '../../thunk';
import { Appbar, IconButton, ActivityIndicator, Chip} from 'react-native-paper';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SegmentedControlTab from 'react-native-segmented-control-tab';
import React, {useEffect, useState, useRef, useContext} from 'react';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import {setRefreshing} from '../../slices/fish-challenges';
import fireStore from '@react-native-firebase/firestore'; 
import {FriendsStyle} from '../add-friends/FriendsStyle';
import { NetworkContext } from '../../NetworkContext';
import {useDispatch, useSelector} from 'react-redux';
import FastImage from 'react-native-fast-image';
import moment from 'moment-timezone';
import * as Localize from 'react-native-localize';
import { ChallengesStyle } from './ChallengesStyle';

const Challenges = ({navigation}) => {
  const isFocused = useIsFocused();
  const dispatch = useDispatch();
  const route = useRoute();
  const deviceTimeZoneLocalize = Localize.getTimeZone();
  const challengeDelete = route.params;
  const stateVal = useSelector(state => state.login);
  const challenge = useSelector(state => state.challenge);
  const [currentPage, setCurrentPage] = React.useState(1);
  const [loadedDataMyChallenges, setLoadedDataMyChallenges] = useState([]);
  const [loadedDataJoinedChallenges, setLoadedDataJoinedChallenges] = useState([]);
  const notification = stateVal.notification_count;
  const [formLayoutIndex, setFormLayoutIndex] = useState(0);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [shouldFetchNextPage, setShouldFetchNextPage] = useState(true);
  const [isSearching, setIsSearching] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const isConnected = useContext(NetworkContext);
  const [params, setParamsData] = useState({
    search: '',
    fish_challenges: 'my_challenges',
    page: 1,
    limit: 10,
  });

  useEffect(() => {
    const callIfNeeded = async () => {
      const lastExecutedTime = await AsyncStorage.getItem('lastTournamentRemainderTime');
      const currentTime = new Date().getTime(); // Get current timestamp in milliseconds

      if (!lastExecutedTime || (currentTime - lastExecutedTime) >= 4 * 60 * 60 * 1000) {
        // If no previous time or 8 hours (in ms) have passed, call sendTournamentRemainder
        await sendTournamentRemainder();

        // Update last execution time in AsyncStorage
        await AsyncStorage.setItem('lastTournamentRemainderTime', currentTime.toString());
      }
    };

    if (isConnected && isFocused) {
        callIfNeeded();
      if (challengeDelete.isDelete === true) {
          setCurrentPage(1);
          const params = {
            page: 1,
            limit: 10,
            search: '',
            fish_challenges: 'my_challenges',
          };
          fetchMyChallenge(formLayoutIndex, currentPage, params);
        } else {
          setCurrentPage(currentPage);
          const params = {
          page: currentPage,
          limit: 10,
          search: '',
          fish_challenges: 'my_challenges',
        };
        fetchMyChallenge(formLayoutIndex, currentPage, params);
        }
        fetchMyFriendsData();
        ChatNotification();
    }
  }, [isFocused, isConnected,  params]);

  const handleBackPress = () => {
    navigation.navigate('DrawerNav');
    return true;
  };
  
  useFocusEffect(
    React.useCallback(() => {
      const backHandler = BackHandler.addEventListener(
        'hardwareBackPress',
        handleBackPress,
      );
      return () => {
        backHandler.remove();
      };
    }, []),
  );

  const ChatNotification = async () => {
    try {
      const loggedInUserId = stateVal.id;
      const chatListSnapshot = await fireStore()
        .collection('chatlists')
        .where('receiverId', '==', loggedInUserId)
        .get();
      const chatListData = chatListSnapshot.docs.map(doc => doc.data());
      chatListData.map((obj, index) => {
        setUnreadCount(obj.unreadMessages);
      });
    } catch (error) {
      console.error('Error fetching chat list:', error);
    }
  };

  const sendTournamentRemainder = async () => {
    const resultAction = await dispatch(tournamentRemainder());
    console.log("resultAction",resultAction.payload.message)
  }

  const fetchMyChallenge = async (updatedIndex, page, params) => {
    setIsLoadingMore(true);
    try {
      const updateParams = {
        ...params,
        fish_challenges:
          updatedIndex === 0 ? 'my_challenges' : 'joined_challenges',
      };
      const resultAction = await dispatch(fetchAllChallenges(updateParams));

      if (fetchAllChallenges.fulfilled.match(resultAction)) {
        const loadedData =
          resultAction.payload.data && resultAction.payload.data.result
            ? resultAction.payload.data.result
            : '';
        if (params.page === 1) {
          if (updatedIndex === 0) {
            setLoadedDataMyChallenges(loadedData);
          } else if (updatedIndex === 1) {
            setLoadedDataJoinedChallenges(loadedData);
          }
        } else {
          if (updatedIndex === 0) {
            setLoadedDataMyChallenges(prevData => {
              const uniqueFilteredData = loadedData.filter(item => !prevData.map(prevItem => prevItem._id).includes(item._id));
              return [...prevData, ...uniqueFilteredData];
            });
          } else if (updatedIndex === 1) {
            setLoadedDataJoinedChallenges(prevData => {
              const uniqueFilteredData = loadedData.filter(item => !prevData.map(prevItem => prevItem._id).includes(item._id));
              return [...prevData, ...uniqueFilteredData];
            });
          }
        }
        if (loadedData.length < params.limit) {
          setShouldFetchNextPage(false);
        } else {
          setShouldFetchNextPage(true);
        }
      }
      setIsLoadingMore(false);
    } catch (error) {
      console.error('Error fetching challenges:', error);
      setIsLoadingMore(false);
    }
  };

  const fetchMyFriendsData = async () => {
    setIsLoadingMore(true);
    const params = {user_id: stateVal.id};
    const resultAction = await dispatch(fetchMyFriends(params));
    if (fetchMyFriends.fulfilled.match(resultAction)) {
      setIsLoadingMore(false);
    }
  };

  const handleFormLayout = index => {
    setFormLayoutIndex(index);
    fetchMyChallenge(index, currentPage, params);
  };

  const handleLoadMore = () => {
    if (!isLoadingMore && shouldFetchNextPage) {
      setIsLoadingMore(true);
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      const params = {
        page: nextPage,
        search: '',
        limit: 10,
        fish_challenges: 'my_challenges',
      };
      fetchMyChallenge(formLayoutIndex, nextPage, params).then(() =>
        setIsLoadingMore(false),
      );
    }
  };

  const handleRefresh = () => {
    dispatch(setRefreshing({}));
    params.page = 1;
    fetchMyChallenge(formLayoutIndex, currentPage, params);
  };

  const ListItem = ({item, index}) => {
    const itemMeta = item.meta;
    const toIds = itemMeta.fish_challenge.map(fish => fish.to_id);
    const joinedFish = itemMeta.fish_challenge.filter(fish => fish.status === 'joined');
    const challengeStartDate = moment(itemMeta && itemMeta.start_date);
    const challengeEndDate = moment(itemMeta && itemMeta.end_date);
    const challengeStartTime = moment(itemMeta && itemMeta.start_time);
    const challengeEndTime = moment(itemMeta && itemMeta.end_time);
    
    // Convert to UTC
    const currentTimeUTC = moment();
    
    // Set start and end times
    const startDateTime = moment(challengeStartDate).set({
      hour: moment(challengeStartTime).hour(),
      minute: moment(challengeStartTime).minute(),
      second: moment(challengeStartTime).second(),
    });
    const endDateTime = moment(challengeEndDate).set({
      hour: moment(challengeEndTime).hour(),
      minute: moment(challengeEndTime).minute(),
      second: moment(challengeEndTime).second(),
    });
    
    // Check if the challenge has started or ended
    const isChallengeNotStarted = currentTimeUTC.isBefore(startDateTime);
    const isChallengeRunning = currentTimeUTC.isBetween(startDateTime, endDateTime, null, '[]');
    console.log("isChallengeRunning", isChallengeRunning)

    return (
      <View
        key={`${item._id}-${index}`}
        style={{
          padding: 12,
          marginVertical: 8,
          marginHorizontal: 18,
          borderRadius: 10,
          marginBottom: Platform.OS === 'ios' ? 15 : 10,
          backgroundColor: '#fff',
          shadowColor: '#505588',
          shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.1,
          shadowRadius: 0,
          ...Platform.select({
            android: {
              elevation: 20,
            },
          }),
        }}>
        <TouchableOpacity
          onPress={() => navigation.navigate('ChallengesDetail', item)}>
          {item.media &&
            item.media?.map((mediaItem, mediaIndex) => (
              <View key={mediaIndex}>
                {mediaItem.media && mediaItem.media.path ? (
                  <>
                  <FastImage
                    source={
                      mediaItem.media
                        ? {uri: mediaItem.media.path}
                        : IconAsset.Splash
                    }
                    style={{
                      width: '100%',
                      height: 180,
                      borderRadius: 6,
                      objectFit: 'cover',
                      marginBottom: 17,
                    }}
                  />
                  <>
                    {isChallengeRunning  && (
                        <View style={ChallengesStyle.LiveTagView}><Chip style={ChallengesStyle.LiveTag} textStyle={ChallengesStyle.LiveTagText} >Live</Chip></View>
                      )}
                  </>
                  </>
                ) : (
                  <ActivityIndicator />
                )}
              </View>
            ))}
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: 4,
            }}>
            <View style={{marginRight: 5}}>
              <Text
                style={{
                  width: 230,
                  flexShrink: 1,
                  fontSize: 16,
                  fontFamily: Dm.semiBold,
                  marginBottom: 4,
                  color: '#100F4D',
                }}>
                {item.quote}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  fontFamily: Dm.regular,
                  color: '#100F4D',
                }}>
                {itemMeta.start_date &&
                  moment(itemMeta.start_date, 'YYYY-MM-DD').format('DD MMM')}
                {' - '}
                {itemMeta.end_date &&
                  moment(itemMeta.end_date, 'YYYY-MM-DD').format('DD MMM')}{' '}
              </Text>
             
            </View>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                marginRight: 10,
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginRight: 6,
                }}>
                  {joinedFish.slice(0, 3).map((fish, index) => (
                    <View key={index}>
                    <Image
                      size={40}
                      source={fish.to_id && fish.to_id.profile_image && fish.to_id.profile_image.path ? { uri: fish.to_id && fish.to_id.profile_image && fish.to_id.profile_image.path }: IconAsset.BlankUser}
                      style={{
                        borderColor: '#fff',
                        borderWidth: 2,
                        width: 34,
                        height: 34,
                        borderRadius: 32,
                        marginRight: -12,
                      }}
                    />
                    </View>
                  ))}
              </View>
              {joinedFish.length > 3 && (
                <Text
                  style={{
                    fontSize: 14,
                    fontFamily: Dm.medium,
                    color: '#100F4D',
                    paddingLeft: 8,
                    paddingRight: 5,
                  }}>
                  +{joinedFish.length - 3}
                </Text>
              )}
            </View>
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <>
      <Appbar.Header style={[Styles.AppbarHeader, Styles.AppBarShadow,]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          style={{ backgroundColor: UiColor.SecondaryColor }}
          onPress={() => navigation.navigate('DrawerNav')}
          icon={() => (
            <Icon name="back" size={18} style={Styles.BackWhite} />
          )}
        />
        <Appbar.Content
          titleStyle={Styles.NavTitle}
          title="Tournaments"
        />
        <Appbar.Action />
      </Appbar.Header>
      <View style={{alignItems: 'flex-start'}}>
        <SegmentedControlTab
          values={['My Tournaments', 'Joined Tournaments']}
          selectedIndex={formLayoutIndex}
          onTabPress={handleFormLayout}
          borderRadius={18}
          tabsContainerStyle={[Styles.TabContainer]}
          tabStyle={Styles.TabStyle}
          activeTabStyle={Styles.ActiveTab}
          tabTextStyle={Styles.TabText}
          activeTabTextStyle={Styles.ActiveTabText}
        />
      </View>
      <>
      {!isConnected && loadedDataMyChallenges && loadedDataMyChallenges.length === 0 ?
        <View style={[GlobalStyles.NoData, {marginTop: 80}]}>
          <Icon name="no-connection" size={50} />
          <Text style={[GlobalStyles.NoDataMsg, {fontFamily: Dm.semiBold}]}>
            No Internet Connection
          </Text>
        </View> 
      :
        <>
          {formLayoutIndex === 0 && (
            <>
              <View
                style={[FriendsStyle.Container, {backgroundColor: 'transparent'}]}>
                <View style={{flex: 1}}>
                  <SafeAreaView style={{marginBottom: 70}}>
                  {loadedDataMyChallenges && loadedDataMyChallenges.length === 0 && isLoadingMore ? (
                      <SkeletonPlaceholder>
                        {[...Array(4)].map((_, index) => (
                          <SkeletonPlaceholder.Item
                            key={index}
                            flexDirection="row"
                            alignItems="center"
                            marginBottom={20}
                            marginHorizontal={18}>
                            <SkeletonPlaceholder.Item
                              width="100%"
                              height={180}
                              borderRadius={6}
                            />
                          </SkeletonPlaceholder.Item>
                        ))}
                      </SkeletonPlaceholder>
                    ) : (
                      <FlatList
                        data={loadedDataMyChallenges}
                        keyExtractor={item => item._id}
                        renderItem={({item, index}) => (
                          <ListItem item={item} index={index} />
                        )}
                        refreshing={challenge.refreshing}
                        onRefresh={handleRefresh}
                        onEndReached={handleLoadMore}
                        onEndReachedThreshold={0.1}
                        showsVerticalScrollIndicator={false}
                        ListFooterComponent={() => {
                          return isLoadingMore ? (
                            <ActivityIndicator
                              animating={true}
                              size={32}
                              color={UiColor.BaseColor}
                            />
                          ) : null;
                        }}
                        contentContainerStyle={{paddingBottom: 150}}
                      />
                     )}
                    {!isSearching && !isLoadingMore &&
                      loadedDataMyChallenges &&
                      loadedDataMyChallenges?.length === 0 && (
                        <View style={GlobalStyles.NoData}>
                          <Text style={GlobalStyles.NoDataMsg}>
                            No Tournaments Found
                          </Text>
                        </View>
                      )}
                  </SafeAreaView>
                </View>
              </View>
              <TouchableOpacity
                onPress={() => navigation.navigate('ChallengesCreate')}
                style={[Styles.AddBtn]}>
                <Icon name="plus" size={18} color={UiColor.White} />
              </TouchableOpacity>
            </>
          )}
        </>
      }
      {!isConnected && loadedDataJoinedChallenges && loadedDataJoinedChallenges.length === 0 ?
        <View style={[GlobalStyles.NoData, {marginTop: 80}]}>
          <Icon name="no-connection" size={50} />
          <Text style={[GlobalStyles.NoDataMsg, {fontFamily: Dm.semiBold}]}>
            No Internet Connection
          </Text>
        </View> 
      :
        <>
          {formLayoutIndex === 1 && (
            <>
              <View
                style={[FriendsStyle.Container, {backgroundColor: 'transparent'}]}>
                <View style={{flex: 1}}>
                  <SafeAreaView style={{marginBottom: 70}}>
                  {loadedDataJoinedChallenges && loadedDataJoinedChallenges.length === 0 && isLoadingMore ? (
                      <SkeletonPlaceholder>
                        {[...Array(4)].map((_, index) => (
                          <SkeletonPlaceholder.Item
                            key={index}
                            flexDirection="row"
                            alignItems="center"
                            marginBottom={20}
                            marginHorizontal={18}>
                            <SkeletonPlaceholder.Item
                              width="100%"
                              height={180}
                              borderRadius={6}
                            />
                          </SkeletonPlaceholder.Item>
                        ))}
                      </SkeletonPlaceholder>
                    ) : (
                    <FlatList
                      data={loadedDataJoinedChallenges}
                      keyExtractor={(item, index) => index.toString()}
                      renderItem={({item, index}) => (
                        <ListItem item={item} index={index} />
                      )}
                      refreshing={challenge.refreshing}
                      onRefresh={handleRefresh}
                      onEndReached={handleLoadMore}
                      onEndReachedThreshold={0.1}
                      showsVerticalScrollIndicator={false}
                      ListFooterComponent={() => {
                        return isLoadingMore ? (
                          <ActivityIndicator
                            animating={true}
                            size={32}
                            color={UiColor.BaseColor}
                          />
                        ) : null;
                      }}
                      contentContainerStyle={{paddingBottom: 150}}
                    />
                    )}
                    {!isSearching && !isLoadingMore &&
                      loadedDataJoinedChallenges &&
                      loadedDataJoinedChallenges?.length === 0 && (
                        <View style={GlobalStyles.NoData}>
                          <Text style={GlobalStyles.NoDataMsg}>
                            No Tournaments Found
                          </Text>
                        </View>
                      )}
                  </SafeAreaView>
                </View>
              </View>
            </>
          )}
        </>
      }
      </>
    </>
  );
};

export default Challenges;
