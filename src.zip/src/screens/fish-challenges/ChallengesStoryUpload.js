import {Appbar, Avatar, ActivityIndicator, HelperText, TextInput, FAB} from 'react-native-paper';
import {View, Text, Modal, TouchableOpacity, Image, FlatList, Platform, StyleSheet, Keyboard} from 'react-native';
import {Styles, UiColor, IconAsset, Icon, Dm} from '../../../theme/Index';
import {useIsFocused, useRoute} from '@react-navigation/native';
import {RemoveStyle} from '../auth/remove-account/RemoveStyle';
import ImageCropPicker from 'react-native-image-crop-picker';
import { FriendsStyle } from '../add-friends/FriendsStyle';
import {useDispatch, useSelector} from 'react-redux';
import {LoginStyle} from '../auth/login/LoginStyle';
import React, {useEffect, useState} from 'react';
import {addPosts} from '../../thunk';

const ChallengesStoryUpload = ({navigation}) => {
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const route = useRoute();
  const challengeData = route.params;
  const challengeId = route.params && route.params.challenge_id;
  const [takePost, setTakePost] = useState(false);
  const [isSubmit, setIsSubmit] = useState(false);
  const [isIcon, setIsIcon] = useState(false);
  const [selectedImages, setSelectedImages] = useState([]);
  const stateVal = useSelector(state => state.login);
  const [isModalVisible, setModalVisible] = useState(false);
  const [previewIndex, setPreviewIndex] = useState(null);
  const [formErrors, setFormErrors] = useState({});
  const [state, setState] = React.useState({open: false});
  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false); 
  const onStateChange = ({open}) => setState({open});
  const {open} = state;
  const [formData, setFormData] = useState({
    visibility: 'public',
    stories: '',
    story_type: 'fish_challenge_post',
    quote: '',
    fish_weight: '',
    fish_challenge_id: challengeId,
  });
  useEffect(() => {
    if (isFocused) {
      if (challengeData && challengeData.media) {
        setFormData({
          ...formData,
          stories: challengeData && challengeData.media,
          fish_weight: challengeData && challengeData.catch_weight,
          fish_challenge_id: challengeData && challengeData.challenge_id,
        });
        setSelectedImages([challengeData && challengeData.media]);
      }
    }
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => setIsKeyboardVisible(true),
    );
    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => setIsKeyboardVisible(false),
    );
    return () => {
      keyboardDidHideListener.remove();
      keyboardDidShowListener.remove();
    };
  }, [isFocused]);

  const extractNumber = str => {
    const match = str.match(/\d+/);
    return match ? match[0] : '';
  };

  const hasErrors = () => {
    const errors = {};

    if (selectedImages.length === 0) {
      errors.stories = 'please select image for upload';
    }
    if (formData.fish_weight.length === 0) {
      errors.fish_weight = 'Fish weight is required';
    }
  
    setFormErrors(errors);
    return Object.keys(errors).length > 0;
  };
  const submitData = async () => {
    if (hasErrors()) {
      return;
    }
    setFormErrors({});
    setIsSubmit(true);
    const updatedPostPickParams = {
      stories: selectedImages.map(uri => ({
        fileCopyUri: null,
        name: 'images.jpg',
        size: '20',
        type: 'image/jpeg',
        uri: uri,
      })),
      quote: formData.quote,
      story_type: formData.story_type,
      fish_challenge_id: formData.fish_challenge_id,
      visibility: formData.visibility,
      fish_weight: formData.fish_weight,
    };
    try {
      const resultAction = await dispatch(addPosts(updatedPostPickParams));
      if (addPosts.fulfilled.match(resultAction)) {
        const challengeId =
          resultAction.payload.data &&
          resultAction.payload.data.fish_challenge_id;
        setIsSubmit(false);
        navigation.navigate('ChallengesDetail', {_id: challengeId});
      }
      setIsSubmit(false);
      return resultAction.payload.data;
    } catch (error) {
      console.log('Error submitting data:', error);
      setIsSubmit(false);
    }
    setTakePost(false);
  };

  const handleImagePicker = async () => {
    setTakePost(true);
    try {
      const response = await ImageCropPicker.openPicker({
        cropping: false,
        cropperCircleOverlay: false,
        compressImageQuality: 0.8,
        width: 300,
        height: 300,
        multiple: true,
        mediaType: 'photo',
      });
      if (response.length > 0) {
        setSelectedImages(prevImages => [
          ...prevImages,
          ...response.map(item => item.path),
        ]);
      }
    } catch (err) {
      console.log('File picking error:', err);
      setTakePost(false);
    }
  };

  const renderItem = ({item, index}) => (
    <TouchableOpacity style={{flex: 1}} onPress={() => toggleModal(index)}>
      <Image
        source={{uri: `${item}?timestamp=${new Date().getTime()}`}}
        style={{flex: 1, aspectRatio: 1, margin: 4}}
        resizeMode="cover"
      />
    </TouchableOpacity>
  );

  const toggleModal = item => {
    setModalVisible(!isModalVisible);
    setPreviewIndex(item);
  };

  const cancelSelectedImage = index => {
    setSelectedImages(prevImages => {
      const updatedImages = [...prevImages];
      updatedImages.splice(index, 1);
      return updatedImages;
    });
    setFormData({
      ...formData,
      fish_weight: '',
    });
    setPreviewIndex(null);
    setModalVisible(false);
  };

  return (
    <View style={[{flex:1,paddingBottom: isKeyboardVisible ? 0 : 130 }]}>
      <Appbar.Header style={[Styles.AppbarHeader, Styles.AppBarShadow]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{backgroundColor: UiColor.SecondaryColor}}
          icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
        />
        <Appbar.Content titleStyle={[Styles.NavTitle]} title="Create Post" />
        <TouchableOpacity
          style={[RemoveStyle.DeleteBtn,{ paddingHorizontal: 20,  paddingVertical: 7,
            alignItems: 'center'}]}
          onPress={() => {
            submitData();
          }}>
            <Text
              style={{
                color: UiColor.White,
                fontSize: 14,
                fontFamily: Dm.bold,
              }}>
              {isSubmit ? (
                <ActivityIndicator size={24} color="#fff" />
              ) : (
                'Done'
              )}
            </Text>
        </TouchableOpacity>
      </Appbar.Header>
      <View
        style={{flexDirection: 'row', paddingHorizontal: 16, marginBottom: 10, marginTop: 15}}>
        <View>
          {stateVal.profile_image_path ? (
            <Avatar.Image
              style={{marginRight: 10, backgroundColor: UiColor.ImageLoad}}
              size={50}
              source={{
                uri: stateVal.profile_image_path,
              }}
            />
          ) : (
            <Avatar.Image style={{backgroundColor: UiColor.ImageLoad}} size={40} source={IconAsset.BlankUser} />
          )}
        </View>
        <View style={{marginTop: 12, marginLeft: 5}}>
          <Text style={{marginBottom: 0, fontFamily: Dm.bold, fontSize: 16}}>
            {stateVal.first_name + ' ' + stateVal.last_name}
          </Text>
        </View>
      </View>
      <HelperText
          type="error"
          style={[
            Styles.ErrorMsg,
            { left: 70,  position: 'absolute', width: 250, top: 170},
          ]}
          visible={formErrors.stories !== undefined}>
          {formErrors.stories}
      </HelperText>
      <View>
        <TextInput
          style={{
            color: Platform.OS === 'ios' ? UiColor.Black : '#536471',
            fontSize: 15,
            paddingLeft: 10,
            paddingTop: 5,
            paddingHorizontal: 10,
            textAlignVertical: 'top',
            backgroundColor: 'transparent',
          }}
          placeholder="Write some caption..."
          placeholderTextColor={
            Platform.OS === 'ios' ? UiColor.Black : '#536471'
          }
          underlineStyle={{backgroundColor: 'transparent'}}
          textColor={UiColor.PrimaryColor}
          onChangeText={text => {
            if (text.length <= 250) {
              setFormErrors({...formErrors, quote: ''}),
                setFormData({
                  ...formData,
                  quote: text,
                  stories: selectedImages,
                });
            } else {
              setFormErrors({
                quote: 'qoute must be 250 characters or less',
              });
            }
          }}
          multiline
          // numberOfLines={4}
        />
        <HelperText
          type="error"
          style={Styles.ErrorMsg}
          visible={formErrors.quote !== undefined}>
          {formErrors.quote}
        </HelperText>
        <View style={[LoginStyle.FormControl, {paddingHorizontal: 15}]}>
          <TextInput
            placeholder="Weight"
            value={extractNumber(formData.fish_weight)}
            onChangeText={text => {
              setFormErrors({...formErrors, fish_weight: ''}),
                setFormData({...formData, fish_weight: text});
            }}
            theme={LoginStyle.TextInput}
            style={[
              LoginStyle.FormInput,
              {
                borderColor: formErrors.fish_weight
                  ? UiColor.SecondaryColor
                  : UiColor.GrayLight,
              },
            ]}
            right={<TextInput.Affix text="LBS" />}
            textColor={UiColor.PrimaryColor}
            underlineStyle={{backgroundColor: 'transparent'}}
            autoCapitalize="none"
            keyboardType="numeric"
            editable={true}
          />
          <HelperText
            type="error"
            style={Styles.ErrorMsg}
            visible={formErrors.fish_weight !== undefined}>
            {formErrors.fish_weight}
          </HelperText>
        </View>
       
      </View>
      <FlatList
        data={selectedImages}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
        numColumns={2}
      />
      {!isKeyboardVisible && (
        <View style={styles.bottomContainer}>
          <TouchableOpacity onPress={() => navigation.navigate('Catches',  {isProfile: true, isTrue: true, challengeId: challengeId,})} style={styles.bottomBtn}>
            <View style={FriendsStyle.CardImageIcon}>
              <Image
                style={styles.bottomIcon}
                source={IconAsset.CatchGallery}
              />
            </View>
            <Text style={styles.bottomText}>Catch Gallery</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleImagePicker} style={styles.bottomBtn}>
            <View style={FriendsStyle.CardImageIcon}>
              <Icon name="gallery" size={20} color={UiColor.White} />
            </View>
            <Text style={styles.bottomText}>Photos</Text>
          </TouchableOpacity>
        </View>
      )}
      <Modal
        visible={isModalVisible}
        transparent={true}
        onRequestClose={() => setModalVisible(false)}>
        <View
          style={{
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
          }}>
          {selectedImages && (
            <Image
              source={{uri: selectedImages[previewIndex]}}
              style={{width: '100%', height: '100%', backgroundColor: '#222'}}
              resizeMode="contain"
            />
          )}
          <TouchableOpacity
            style={{position: 'absolute', top: 50, left: 20}}
            onPress={() => {
              setModalVisible(false);
              setPreviewIndex(null);
            }}>
            <Icon name="back" size={26} color={UiColor.White} />
          </TouchableOpacity>
          <TouchableOpacity
            style={{position: 'absolute', top: 50, right: 20}}
            onPress={() => cancelSelectedImage(previewIndex)}>
            <Icon name="cross" size={26} color={UiColor.White} />
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
};
export default ChallengesStoryUpload;

const styles = StyleSheet.create({
  
  bottomContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    marginBottom: 0,
    width: '100%',
    backgroundColor: UiColor.White,
    flexDirection: 'column',
  },
  bottomBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    marginLeft: 10,
  },
  bottomIcon: {
    width: 20,
    height: 20,
    tintColor: UiColor.White,
  },
  bottomText: {
    fontFamily: Dm.bold,
  },
});