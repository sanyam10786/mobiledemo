import {Appbar, Avatar, ActivityIndicator, TextInput, HelperText} from 'react-native-paper';
import {View, Text, TouchableOpacity, ScrollView, Image} from 'react-native';
import {fetchMyFriends, addPosts, updateChallenge } from '../../thunk';
import {Styles, UiColor, IconAsset, Icon, Dm} from '../../../theme/Index';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import {ProfileStyle} from '../user-profile/ProfileStyle';
import ImagePicker from 'react-native-image-crop-picker';
import React, {useEffect, useState, useRef} from 'react';
import {useIsFocused} from '@react-navigation/native';
import {useDispatch, useSelector} from 'react-redux';
import {LoginStyle} from '../auth/login/LoginStyle';
import {FriendStyle} from '../friends/FriendStyle';
import * as Localize from 'react-native-localize';
import {useRoute} from '@react-navigation/native';
import moment from 'moment';

const ChallengesCreate = ({navigation}) => {
  const isFocused = useIsFocused();
  const route = useRoute();
  const dispatch = useDispatch();
  const routeData = route.params;
  const stateVal = useSelector(state => state.login);
  const stateValue = useSelector(state => state.challenge);
  const challengeDetail = stateValue.details;
  const challenge = challengeDetail && challengeDetail.challenge;
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [inProcess, setInProcess] = useState(false);
  const [selectedImage, setSelectedImage] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [selectedEndTime, setSelectedEndTime] = useState('');
  const [currentPage, setCurrentPage] = React.useState(1);
  const [isEndOfPage, setIsEndOfPage] = useState(false);
  const [friendsData, setFriendsData] = useState([]);
  const [shouldFetchNextPage, setShouldFetchNextPage] = useState(true);
  const deviceTimeZoneLocalize = Localize.getTimeZone();
  const [params, setParamData] = useState({
    search: '',
    page: 1,
    user_id: stateVal.id,
    limit: 20,
  });
  const [selectedFriendIds, setSelectedFriendIds] = useState([]);
  const [formErrors, setFormErrors] = useState({});
  const [formData, setFormData] = useState({
    stories: '',
    story_type: 'fish_challenge',
    quote: '',
    start_date: '',
    end_date: '',
    start_time: '',
    end_time: '',
    user_id: '',
    winning_prize: '',
    timezone: deviceTimeZoneLocalize,
  });
  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showEndDatePicker, setShowEndDatePicker] = useState(false);
  const [showStartTimePicker, setShowStartTimePicker] = useState(false);
  const [showEndTimePicker, setShowEndTimePicker] = useState(false);

  useEffect(() => {
    if (isFocused) {
      const params = {
        user_id: stateVal.id,
        page: currentPage,
        limit: 20,
        search: '',
      };
      fetchMyFriendsData(currentPage, params);
      setTimeout(() => {
        setData();
      }, 3000);
    }
  }, [isFocused, params]);
  const setData = async () => {
    if (routeData && routeData.id !== '') {
      const selectedFriendIds =
        challenge &&
        challenge.meta &&
        challenge.meta.fish_challenge.map(challenge => challenge.to_id && challenge.to_id.id);
      const media =
        challenge &&
        challenge.media &&
        challenge.media[0].media &&
        challenge.media[0].media.path;
      setSelectedImage(media);
      setSelectedFriendIds(selectedFriendIds);
      const timeString =
        challenge && challenge.meta && challenge?.meta.start_time;
      const formatStart = moment(timeString).format('hh:mm:ss A');
      setSelectedTime(formatStart);
      const timeEndString =
        challenge && challenge.meta && challenge?.meta.end_time;
      const formatEnd = moment(timeEndString).format('hh:mm:ss A');
      setSelectedEndTime(formatEnd);
      setFormData({
        ...formData,
        stories:
          challenge &&
          challenge.media &&
          challenge.media[0].media &&
          challenge.media[0].media.path,
        quote: challenge && challenge.quote ? challenge.quote : '',
        start_date:
          challenge && challenge.meta ? challenge.meta.start_date : '',
        end_date: challenge && challenge.meta ? challenge.meta.end_date : '',
        start_time: timeString,
        end_time: timeEndString,
        winning_prize:
          challenge && challenge.meta ? challenge.meta.winning_prize : '',
        user_id: selectedFriendIds,
      });
    }
  };

  const fetchMyFriendsData = async (page, params) => {
    setIsLoadingMore(true);
    const resultAction = await dispatch(fetchMyFriends(params));
    if (fetchMyFriends.fulfilled.match(resultAction)) {
      const newData = resultAction.payload.data.friends;
      setIsLoadingMore(false);
      if (newData.length < params.limit) {
        setShouldFetchNextPage(false);
      } else {
        setShouldFetchNextPage(true);
      }
      if (page === 1) {
        setFriendsData(newData);
      } else {
        setFriendsData(prevData => [...prevData, ...newData]);
      }
    }
  };

  const handleLoadMore = () => {
    if (!isLoadingMore && shouldFetchNextPage && isEndOfPage) {
      setIsLoadingMore(true);
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      const params = {
        page: nextPage,
        user_id: stateVal.id,
        limit: 20,
        search: '',
      };
      fetchMyFriendsData(nextPage, params).then(() => setIsLoadingMore(false));
    }
  };

  const handleScroll = event => {
    const {contentOffset, layoutMeasurement, contentSize} = event.nativeEvent;
    const endOfFirstPageOffset = contentSize.height - layoutMeasurement.height;
    const isEndOfFirstPage = contentOffset.y >= endOfFirstPageOffset;
    setIsEndOfPage(true);
    if (isEndOfPage) {
      handleLoadMore();
    }
  };

  const hasErrors = () => {
    const errors = {};

    if (formData.quote.length === 0) {
      errors.quote = 'Tournament name is required';
    }
    if (!selectedImage) {
      errors.stories = 'Image is required';
    }
    if (!formData.start_date || formData.start_date.length === 0) {
      errors.start_date = 'Start date is required';
    }
    if (!formData.end_date || formData.end_date.length === 0) {
      errors.end_date = 'End date is required';
    }
    if (formData.start_date && formData.end_date && moment(formData.end_date).isBefore(moment(formData.start_date))) {
      errors.end_date = 'End date cannot be less than start date';
    }
    if (!formData.start_time || formData.start_time.length === 0) {
      errors.start_time = 'Start time is required';
    }
    if (!formData.end_time || formData.end_time.length === 0) {
      errors.end_time = 'End time is required';
    }
    if (formData.start_date === formData.end_date && formData.start_time && formData.end_time && moment(formData.end_time).isBefore(moment(formData.start_time))) {
      errors.end_time = 'End time cannot be less than start time';
    }
    if (!formData.winning_prize || formData.winning_prize.length === 0) {
      errors.winning_prize = 'Winning prize is required';
    }
    if (selectedFriendIds.length === 0) {
      errors.friends = 'Please select friends';
    }

    setFormErrors(errors);
    return Object.keys(errors).length > 0;
  };

  const createChallenge = async () => {
    if (hasErrors()) {
      return;
    }
    setFormErrors({});
    setInProcess(true);
    try {
      if (routeData && routeData.id !== '') {
        const updatedData = {
          params: {
            quote: formData.quote,
            winning_prize: formData.winning_prize,
            start_date: formData.start_date,
            end_date: formData.end_date,
            start_time: formData.start_time,
            end_time: formData.end_time,
            user_id: formData.user_id,
            stories: formData.stories,
            timezone: deviceTimeZoneLocalize,
          },
          fish_challenge_id: routeData.id,
        };
        const resultAction = await dispatch(updateChallenge(updatedData));
        if (updateChallenge.fulfilled.match(resultAction)) {
          const itemId = resultAction.payload.data._id;
          navigation.navigate('ChallengesDetail', {_id : itemId, isCreated: true});
          setFormData('');
          setSelectedFriendIds('');
          setSelectedImage('');
        }
      } else {
        const resultAction = await dispatch(addPosts(formData));
        if (addPosts.fulfilled.match(resultAction)) {
          const itemId = resultAction.payload.data._id;
          navigation.navigate('ChallengesDetail', {_id : itemId, isCreated: true});
          setFormData('');
          setSelectedFriendIds('');
          setSelectedImage('');
        }
      }
      setInProcess(false);
    } catch (error) {
      setInProcess(false);
      console.error('Error in create Tournament:', error);
    }
  };

  const handleStartDateChange = date => {
    setShowStartDatePicker(false);
    if (date) {
      const localDate = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
      const formattedDate = localDate.toISOString().split('T')[0];
      setFormData({...formData, start_date: formattedDate});
    }
  };

  const handleEndDateChange = date => {
    setShowEndDatePicker(false);
    if (date) {
      const localEndDate = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
      const formattedEndDate = localEndDate.toISOString().split('T')[0];
      setFormData({...formData, end_date: formattedEndDate});
    }
  };

  const handleStartTimeChange = date => {
    setShowStartTimePicker(false);
    if (date) {
      const timeString = date;
      const formatStartTime = moment(timeString).format('hh:mm:ss A');
      setSelectedTime(formatStartTime);
      setFormData({...formData, start_time: date});
    }
  };

  const handleEndTimeChange = date => {
    setShowEndTimePicker(false);
    if (date) {
      const timeEndString = date;
      const formatEndTime = moment(timeEndString).format('hh:mm:ss A');
      setSelectedEndTime(formatEndTime);
      setFormData({...formData, end_time: date});
    }
  };

  const handleFriendSelection = friendId => {
    const isSelected = selectedFriendIds.includes(friendId);

    if (isSelected) {
      const updatedIds = selectedFriendIds.filter(id => id !== friendId);
      setSelectedFriendIds(updatedIds);
    } else {
      setSelectedFriendIds([...selectedFriendIds, friendId]);
    }
    setFormData({
      ...formData,
      user_id: isSelected
        ? selectedFriendIds.filter(id => id !== friendId)
        : [...selectedFriendIds, friendId],
    });
  };

  const openImagePicker = async isProfileImage => {
    try {
      const image = await ImagePicker.openPicker({
        cropping: false,
        cropperCircleOverlay: false,
        compressImageQuality: 0.8,
        width: 300,
        height: 300,
        mediaType: 'photo',
      });
      if (image) {
        const media = {
          fileCopyUri: null,
          name: 'challenge.jpg',
          size: image.size,
          type: image.mime,
          uri: image.path,
        };
        setFormData({
          ...formData,
          stories: media,
        });
        setSelectedImage(image.path);
      }
    } catch (error) {}
  };

  const formatDate = (dateString) => {
    const [year, month, day] = dateString.split('-');
    return `${month}-${day}-${year}`;
  };

  return (
    <>
      <Appbar.Header
        style={[Styles.AppbarHeader, Styles.AppBarShadow ]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{backgroundColor: UiColor.SecondaryColor}}
          icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
        />
        {routeData && routeData.id !== '' ? (
          <Appbar.Content
            titleStyle={Styles.NavTitle}
            title="Update Tournament"
          />
        ) : (
          <Appbar.Content
            titleStyle={Styles.NavTitle}
            title="Add New Tournament"
          />
        )}
        <Appbar.Action animated={false} size={30} rippleColor="#00000008" />
      </Appbar.Header>
      <View style={[LoginStyle.Container, {marginTop: 10}]}>
        <ScrollView
          onScroll={handleScroll}
          scrollEventThrottle={16}
          style={{marginBottom: 90}}
          showsVerticalScrollIndicator={false}>
          <View style={LoginStyle.LoginForm}>
            <View style={[LoginStyle.FormControl, {marginBottom: 100}]}>
              <TouchableOpacity onPress={() => openImagePicker()}>
                <Text
                  style={{
                    marginTop: -25,
                    marginLeft: 8,
                    color: UiColor.GrayLight,
                  }}>
                  Tournament Image
                </Text>
                <View
                  style={{
                    position: 'absolute',
                    width: 90,
                    height: 90,
                    left: 2,
                    borderRadius: 10,
                    borderWidth: 1,
                    // borderColor: '#0A141B80',
                    borderColor: formErrors.stories
                      ? UiColor.SecondaryColor
                      : UiColor.GrayLight,
                    backgroundColor: 'transparent',
                  }}>
                  {selectedImage ? (
                    <Image
                      source={{uri: selectedImage}}
                      style={{
                        flex: 1,
                        borderRadius: 10,
                      }}
                    />
                  ) : (
                    <Icon name="gallery-1" color={UiColor.GrayLight} size={25} style={{position: 'absolute', top: 32, left: 30}} />
                  )}
                  <HelperText
                    type="error"
                    style={[
                      Styles.ErrorMsg,
                      {left: 90, bottom: 0, position: 'absolute', width: 200},
                    ]}
                    visible={formErrors.stories !== undefined}>
                    {formErrors.stories}
                  </HelperText>
                </View>
              </TouchableOpacity>
            </View>
            <View style={[LoginStyle.FormControl]}>
              <TextInput
                label="Tournament Name"
                value={formData.quote}
                style={[
                  LoginStyle.FormInput,
                  {
                    borderColor: formErrors.quote
                      ? UiColor.SecondaryColor
                      : UiColor.GrayLight,
                  },
                ]}
                textColor={UiColor.PrimaryColor}
                theme={LoginStyle.TextInput}
                onChangeText={text => {
                  if (text.length <= 50) {
                    setFormErrors({...formErrors, quote: ''});
                    setFormData({...formData, quote: text});
                  } else {
                    setFormErrors({
                      ...formErrors,
                      quote: 'Tournament name must be 50 characters or less',
                    });
                  }
                }}
                underlineStyle={{backgroundColor: 'transparent'}}
                autoCapitalize="none"
                left={
                  <TextInput.Icon
                    style={LoginStyle.RightBorder}
                    icon={() => (
                      <Icon name="user" color={UiColor.GrayLight} size={20} />
                    )}
                  />
                }
              />
              <HelperText
                type="error"
                style={[Styles.ErrorMsg]}
                visible={formErrors.quote !== undefined}>
                {formErrors.quote}
              </HelperText>
            </View>
            <View style={[LoginStyle.FormControl]}>
              <TouchableOpacity onPress={() => setShowStartDatePicker(true)}>
                <TextInput
                  label="Start Date"
                  onPressIn={() => setShowStartDatePicker(true)}
                  editable={false}
                  value={formData.start_date ? formatDate(formData.start_date) : ''}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.start_date
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  theme={{
                    ...LoginStyle.TextInput,
                    colors: {
                      ...LoginStyle.TextInput.colors,
                      placeholder: UiColor.PrimaryColor,
                    },
                  }}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  autoCapitalize="none"
                  left={
                    <TextInput.Icon
                      style={LoginStyle.RightBorder}
                      icon={() => (
                        <Icon name="calendar" color={UiColor.GrayLight} size={25} style={{marginRight: 3}} />
                      )}
                    />
                  }
                />
              </TouchableOpacity>
              {showStartDatePicker && (
                <DateTimePickerModal
                  isVisible={showStartDatePicker}
                  mode="date"
                  date={
                    formData.start_date
                      ? new Date(new Date(formData.start_date).getTime() + new Date().getTimezoneOffset() * 60000)
                      : new Date()
                  }
                  onConfirm={handleStartDateChange}
                  onCancel={() => setShowStartDatePicker(false)}
                />
              )}
              <HelperText
                type="error"
                style={[Styles.ErrorMsg]}
                visible={formErrors.start_date !== undefined}>
                {formErrors.start_date}
              </HelperText>
            </View>
            <View style={[LoginStyle.FormControl]}>
              <TouchableOpacity onPress={() => setShowStartTimePicker(true)}>
                <TextInput
                  label="Start Time"
                  onPressIn={() => setShowStartTimePicker(true)}
                  editable={false}
                  value={selectedTime}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.start_time
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  theme={{
                    ...LoginStyle.TextInput,
                    colors: {
                      ...LoginStyle.TextInput.colors,
                      placeholder: UiColor.PrimaryColor,
                    },
                  }}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  autoCapitalize="none"
                  left={
                    <TextInput.Icon
                      style={LoginStyle.RightBorder}
                      icon={() => (
                        <Icon name="clock" color={UiColor.GrayLight} size={21} style={{marginRight: 3}} />
                      )}
                    />
                  }
                />
              </TouchableOpacity>
              {showStartTimePicker && (
                <DateTimePickerModal
                  isVisible={showStartTimePicker}
                  mode="time"
                  date={
                    formData.start_time
                      ? new Date(formData.start_time)
                      : new Date()
                  }
                  onConfirm={handleStartTimeChange}
                  onCancel={() => setShowStartTimePicker(false)}
                />
              )}
              <HelperText
                type="error"
                style={[Styles.ErrorMsg]}
                visible={formErrors.start_time !== undefined}>
                {formErrors.start_time}
              </HelperText>
            </View>
            <View style={[LoginStyle.FormControl]}>
              <TouchableOpacity onPress={() => setShowEndDatePicker(true)}>
                <TextInput
                  label="End Date"
                  value={formData.end_date ? formatDate(formData.end_date) : ''}
                  onPressIn={() => setShowEndDatePicker(true)}
                  editable={false}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.end_date
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  theme={LoginStyle.TextInput}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  autoCapitalize="none"
                  left={
                    <TextInput.Icon
                      style={LoginStyle.RightBorder}
                      icon={() => (
                        <Icon name="calendar" color={UiColor.GrayLight} size={25} style={{marginRight: 3}} />
                      )}
                    />
                  }
                />
              </TouchableOpacity>
              {showEndDatePicker && (
                <DateTimePickerModal
                  isVisible={showEndDatePicker}
                  mode="date"
                  date={
                    formData.end_date ? new Date(new Date(formData.end_date).getTime() + new Date().getTimezoneOffset() * 60000) : new Date()
                  }
                  onConfirm={handleEndDateChange}
                  onCancel={() => setShowEndDatePicker(false)}
                />
              )}
              <HelperText
                type="error"
                style={[Styles.ErrorMsg]}
                visible={formErrors.end_date !== undefined}>
                {formErrors.end_date}
              </HelperText>
            </View>
            <View style={[LoginStyle.FormControl]}>
              <TouchableOpacity onPress={() => setShowEndTimePicker(true)}>
                <TextInput
                  label="End Time"
                  onPressIn={() => setShowEndTimePicker(true)}
                  editable={false}
                  value={selectedEndTime}
                  style={[
                    LoginStyle.FormInput,
                    {
                      borderColor: formErrors.end_time
                        ? UiColor.SecondaryColor
                        : UiColor.GrayLight,
                    },
                  ]}
                  textColor={UiColor.PrimaryColor}
                  theme={{
                    ...LoginStyle.TextInput,
                    colors: {
                      ...LoginStyle.TextInput.colors,
                      placeholder: UiColor.PrimaryColor,
                    },
                  }}
                  underlineStyle={{backgroundColor: 'transparent'}}
                  autoCapitalize="none"
                  left={
                    <TextInput.Icon
                      style={LoginStyle.RightBorder}
                      icon={() => (
                        <Icon name="clock" color={UiColor.GrayLight} size={21} style={{marginRight: 3}} />
                      )}
                    />
                  }
                />
              </TouchableOpacity>
              {showEndTimePicker && (
                <DateTimePickerModal
                  isVisible={showEndTimePicker}
                  mode="time"
                  date={
                    formData.end_time ? new Date(formData.end_time) : new Date()
                  }
                  onConfirm={handleEndTimeChange}
                  onCancel={() => setShowEndTimePicker(false)}
                />
              )}
              <HelperText
                type="error"
                style={[Styles.ErrorMsg]}
                visible={formErrors.end_time !== undefined}>
                {formErrors.end_time}
              </HelperText>
            </View>
            <View style={[LoginStyle.FormControl]}>
              <TextInput
                label="Winning Prize"
                value={formData.winning_prize}
                style={[
                  LoginStyle.FormInput,
                  {
                    borderColor: formErrors.winning_prize
                      ? UiColor.SecondaryColor
                      : UiColor.GrayLight,
                  },
                ]}
                textColor={UiColor.PrimaryColor}
                theme={LoginStyle.TextInput}
                onChangeText={text => {
                  if (text.length <= 50) {
                    setFormErrors({...formErrors, winning_prize: ''});
                    setFormData({...formData, winning_prize: text});
                  } else {
                    setFormErrors({
                      ...formErrors,
                      winning_prize:
                        'Tournament name must be 50 characters or less',
                    });
                  }
                }}
                underlineStyle={{backgroundColor: 'transparent'}}
                autoCapitalize="none"
                left={
                  <TextInput.Icon
                    style={LoginStyle.RightBorder}
                    icon={() => (
                      <Icon name="winning" color={UiColor.GrayLight} size={25} style={{marginRight: 3}} />
                      )}
                  />
                }
              />
              <HelperText
                type="error"
                style={[Styles.ErrorMsg]}
                visible={formErrors.winning_prize !== undefined}>
                {formErrors.winning_prize}
              </HelperText>
            </View>
            <View>
              {isLoadingMore ? (
                <ActivityIndicator
                  animating={true}
                  size={32}
                  color={UiColor.BaseColor}
                />
              ) : (
                <>
                <Text
                  style={{
                    marginVertical: 15,
                    marginLeft: 8,
                    fontSize: 18,
                    fontFamily: Dm.semiBold,
                    color: UiColor.GrayLight,
                  }}>
                  Select Friends {formErrors.friends ? (
                    <Text style={{ color: UiColor.SecondaryColor }}>*</Text>
                  ) : (
                    ''
                  )}
                </Text>
                <HelperText
                  type="error"
                  style={{
                    position: 'absolute',
                    top: 12,
                    right: 20,
                    fontSize: 12,
                    color: UiColor.SecondaryColor,
                  }}
                  visible={formErrors.friends !== undefined}>
                  {formErrors.friends}
                </HelperText>
                <View style={[FriendStyle.FriendListHead, {marginTop: 5}]}>
                  <>
                    {friendsData &&
                      friendsData?.map((friend, index) => (
                        <View style={FriendStyle.FriendList} key={index}>
                          <TouchableOpacity
                            onPress={() => handleFriendSelection(friend.id)}>
                            {selectedFriendIds &&
                              selectedFriendIds?.includes(friend.id) && (
                                <View
                                  style={{
                                    position: 'absolute',
                                    zIndex: 1,
                                    top: 0,
                                    right: 0,
                                    backgroundColor: '#fff',
                                    width: 28,
                                    height: 28,
                                    borderRadius: 28,
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                  }}>
                                  <Icon
                                    name="check"
                                    size={18}
                                    color={UiColor.Success}
                                  />
                                </View>
                              )}
                              <View style={{width: 72,height: 72,overflow:'hidden', borderRadius: 72}}>
                                <Image  style={{width:'100%',height:'100%',objectFit:'cover'}} source={
                                friend.profile_image &&
                                friend.profile_image.path
                                  ? {
                                      uri: friend.profile_image.path,
                                    }
                                  : IconAsset.BlankUser
                              } />
                              </View>
                            <Text style={FriendStyle.FriendText}>
                              {friend.first_name} {friend.last_name}
                            </Text>
                          </TouchableOpacity>
                        </View>
                      ))}
                      <View style={FriendStyle.FriendList}>
                        <TouchableOpacity
                          style={FriendStyle.AddBtn}
                          onPress={() => navigation.navigate('AddFriends')}>
                          <Icon name="plus" size={24} color={UiColor.White} />
                        </TouchableOpacity>
                        <Text style={FriendStyle.FriendText}>Add Friend</Text>
                      </View>
                  </>
                </View>
                </>
              )}
            </View>
          </View>
        </ScrollView>
      </View>
      <View
        style={{
          position: 'absolute',
          bottom: 20,
          right: 10,
          width: 64,
          height: 64,
          backgroundColor: UiColor.SecondaryColor,
          borderRadius: 64,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        {inProcess ? (
          <ActivityIndicator size={24} color="#fff" />
        ) : (
          <TouchableOpacity
            onPress={() => createChallenge()}
            style={{
              width: 64,
              height: 64,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Icon name="check" size={24} color={UiColor.White} />
          </TouchableOpacity>
        )}
      </View>
    </>
  );
};

export default ChallengesCreate;
