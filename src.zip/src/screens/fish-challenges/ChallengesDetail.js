import { View, Text, Modal, TouchableOpacity, ScrollView, Image, ImageBackground, SafeAreaView, FlatList, Platform, Alert, BackHandler, StyleSheet, useWindowDimensions, Pressable, Animated, Easing } from 'react-native';
import { useIsFocused, useNavigation, useRoute, useFocusEffect } from '@react-navigation/native';
import { Styles, Dm, GlobalStyles, UiColor, IconAsset, Icon } from '../../../theme/Index';
import { Appbar, Avatar, IconButton, ActivityIndicator, FAB } from 'react-native-paper';
import { fetchChallengesDetail, removeChallenge, deletePost } from '../../thunk';
import React, { useEffect, useState, useRef, useContext } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SegmentedControlTab from 'react-native-segmented-control-tab';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import { RemoveStyle } from '../auth/remove-account/RemoveStyle';
import { ProfileStyle } from '../user-profile/ProfileStyle';
import { FriendsStyle } from '../add-friends/FriendsStyle';
import { resetState } from '../../slices/fish-challenges';
import { SplashStyle } from '../auth/splash/SplashStyle';
import { useDispatch, useSelector } from 'react-redux';
import { NetworkContext } from '../../NetworkContext';
import { ChallengesStyle } from './ChallengesStyle';
import * as Localize from 'react-native-localize';
import ChallengesStory from './ChallengesStory';
import LottieView from 'lottie-react-native';
import Sound from 'react-native-sound';
import moment from 'moment';

const CustomCountdown = ({ startDate, endDate, startTime, endTime, params, currentPage, fetchChallenge, playLevelUpSound }) => {
  const isFocused = useIsFocused();
  const [remainingTime, setRemainingTime] = useState(() => calculateRemainingTime());
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [lastAlertTime, setLastAlertTime] = useState(moment());
  const stateValue = useSelector(state => state.challenge);
  const [tickSound, setTickSound] = useState(null);
  const [overGameSound, setOverGameSound] = useState(null);

  useEffect(() => {
    const loadSounds = () => {
      const tickPath = Platform.select({
        ios: 'tick.mp3',
        android: 'tick'
      });

      const gameOverPath = Platform.select({
        ios: 'over.mp3',
        android: 'over'
      });

      const tick = new Sound(tickPath, Sound.MAIN_BUNDLE, (error) => {
        if (error) {
          console.log('Failed to load tick sound', error);
          return;
        }
        setTickSound(tick);
      });

      const overGame = new Sound(gameOverPath, Sound.MAIN_BUNDLE, (error) => {
        if (error) {
          console.log('Failed to load game over sound', error);
          return;
        }
        setOverGameSound(overGame);
      });
    };
    playLevelUpSound();
    loadSounds();

    return () => {
      // Release sounds on component unmount
      if (tickSound) {
        tickSound.release();
      }
      if (overGameSound) {
        overGameSound.release();
      }
    };
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      const newRemainingTime = calculateRemainingTime();
      setRemainingTime(newRemainingTime);
      // Play beep sound if 10 seconds or less remaining
      if (isFocused && newRemainingTime.minutes === 0 && newRemainingTime.seconds <= 11) {
        if (tickSound) {
          tickSound.play();
        }
        setTimeout(() => {
          if (tickSound !== null) {
            tickSound.stop();
          }
        }, 12000);
      } else {
      }
      // Play game over sound and show modal if challenge has ended
      if (isFocused && newRemainingTime.hours === 0 && newRemainingTime.minutes === 0 && newRemainingTime.seconds === 0) {
        if (overGameSound !== null) {
          overGameSound.play();
        }
        fetchChallenge(currentPage, params);
      } else if (newRemainingTime.message === 'Tournament has ended') {
        setTimeout(() => {
          if (overGameSound !== null) {
            overGameSound.stop();
          }
          if (tickSound !== null) {
            tickSound.stop();
          }
        }, 2000)
      }
      // Show modal if an hour is complete
      if (newRemainingTime.hours !== 0 && newRemainingTime.minutes === 0 && newRemainingTime.seconds === 11) {
        tickSound.play();
      } else if (newRemainingTime.hours !== 0 && newRemainingTime.minutes === 0 && newRemainingTime.seconds === 0) {
        setIsModalVisible(true);
        if (tickSound !== null) {
          tickSound.stop();
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isFocused, tickSound, overGameSound]);

  function calculateRemainingTime() {
    const currentTimeLocal = moment();
    const startDateTime = moment(startDate).set({
      hour: moment(startTime).hour(),
      minute: moment(startTime).minute(),
      second: moment(startTime).second(),
    });

    const endDateTime = moment(endDate).set({
      hour: moment(endTime).hour(),
      minute: moment(endTime).minute(),
      second: moment(endTime).second(),
    });

    if (currentTimeLocal.isBefore(startDateTime)) {
      const formattedStartTime = startDateTime.format('MMMM Do YYYY, hh:mm:ss A');
      return { message: `Tournament starts on ${formattedStartTime}` };
    } else if (currentTimeLocal.isAfter(endDateTime)) {
      return { message: 'Tournament has ended' };
    } else {
      const duration = moment.duration(endDateTime.diff(currentTimeLocal));
      const days = duration.days();
      const hours = duration.hours();
      const minutes = duration.minutes();
      const seconds = duration.seconds();
      return { days, hours, minutes, seconds };
    }
  }

  return (
    <View style={[styles.container, { left: 60, bottom: 80 }]}>
      {remainingTime.message ? (
        <View style={[styles.gameOverContainer, remainingTime.message !== 'Tournament has ended' ? { right: 10, width: 240 } : '']}>
          <View style={styles.gameOverPopup}>
            <Text style={[styles.gameOverMessageText, remainingTime.message !== 'Tournament has ended' ? { color: UiColor.PrimaryColor } : '']}>
              {remainingTime.message}
            </Text>
          </View>
        </View>
      ) : (
        <>
          <View style={[styles.timerRow]}>
            <Text style={styles.timerText}>{remainingTime.days}</Text>
            <Text>{remainingTime.days === 1 ? 'Day' : 'Days'}</Text>
          </View>
          <View style={styles.timerRow}>
            <Text style={styles.timerText}>{remainingTime.hours}</Text>
            <Text>{remainingTime.hours === 1 ? 'Hour' : 'Hours'}</Text>
          </View>
          <View style={styles.timerRow}>
            <Text style={styles.timerText}>{remainingTime.minutes}</Text>
            <Text style={styles.label}>Min</Text>
          </View>
          <View style={styles.timerRow}>
            <Text style={styles.timerText}>{remainingTime.seconds}</Text>
            <Text style={styles.label}>Sec</Text>
          </View>
        </>
      )}
      <AlertModal visible={isModalVisible} onClose={() => setIsModalVisible(false)} remainingTime={remainingTime} />
    </View>
  );
};

const AlertModal = ({ visible, onClose, remainingTime }) => {
  const [alertSound, setAlertSound] = useState(null);

  useEffect(() => {
    const alertSounds = () => {
      const alertModelSound = Platform.select({
        ios: 'modelalert.mp3',
        android: 'modelalert'
      });

      const alert = new Sound(alertModelSound, Sound.MAIN_BUNDLE, (error) => {
        if (error) {
          console.log('Failed to load model alert sound', error);
          return;
        }
        setAlertSound(alert);
      });
    };
    alertSounds();

    return () => {
      // Release sounds on component unmount
      if (alertSound) {
        alertSound.release();
      }
    };
  }, []);

  useEffect(() => {
    if (visible && alertSound) {
      alertSound.play();
    }
    return () => {
      if (alertSound !== null) {
        alertSound.stop();
      }
    };
  }, [visible, alertSound]);
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={visible}
      onRequestClose={onClose}>
      <View style={[styles.modalOverlay, { width: '100%', height: 550 }]}>
        <View style={styles.modalContent}>
          <LottieView
            source={require('../animation/fishAnnimation.json')}
            autoPlay
            loop
            style={{ width: 400, height: 200, position: 'absolute', right: 0, top: -75 }}
          />
          <LottieView
            source={require('../animation/Animation.json')}
            autoPlay
            loop
            style={{ width: 200, height: 200, position: 'absolute', marginTop: 120 }}
          />
          <View style={{ marginTop: 300, marginRight: 20 }}>
            <Text style={[styles.modalText, { left: 30 }]}>Hurry up! You have left. </Text>
            <View style={{ flexDirection: 'row', left: 15 }}>
              <View style={[styles.timerRow]}>
                <Text style={[styles.timerText]}>{remainingTime.days}</Text>
                <Text style={[styles.label]}>Days</Text>
              </View>
              <View style={styles.timerRow}>
                <Text style={styles.timerText}>{remainingTime.hours}</Text>
                <Text style={styles.label}>Hours</Text>
              </View>
              <View style={styles.timerRow}>
                <Text style={styles.timerText}>{remainingTime.minutes}</Text>
                <Text style={styles.label}>Min</Text>
              </View>
              <View style={styles.timerRow}>
                <Text style={styles.timerText}>{remainingTime.seconds}</Text>
                <Text style={styles.label}>Sec</Text>
              </View>
            </View>
            {/* <TouchableOpacity onPress={onClose}>
            <View style={[RemoveStyle.DeleteBtn, { marginTop: 20, left: 15 }]}>
              <Text
                style={{
                  color: UiColor.White,
                  fontSize: 16,
                  fontFamily: Dm.bold,
                  textAlign: 'center',
                }}>
                Close
              </Text>
            </View>
          </TouchableOpacity> */}
          </View>
          <IconButton
            style={{
              width: 25,
              height: 25,
              position: 'absolute',
              top: -14,
              right: -10,
              backgroundColor: '#D2283D',
            }}
            onPress={() => onClose()}
            icon={() => (
              <Icon name="cross" size={14} color={UiColor.White} />
            )}
            size={28}
          />
        </View>
      </View>
    </Modal>
  );
};

const ChallengesDetail = ({ navigation }) => {
  const animatedValue = useRef(new Animated.Value(0)).current;
  const deviceTimeZoneLocalize = Localize.getTimeZone();
  const [showTextAnimation, setShowTextAnimation] = useState(false);
  const dispatch = useDispatch();
  const isConnected = useContext(NetworkContext);
  const route = useRoute();
  const challengeId = route.params && route.params._id;
  const isCreated = route.params && route.params.isCreated;
  const isFocused = useIsFocused();
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const stateVal = useSelector(state => state.login);
  const stateValue = useSelector(state => state.challenge);
  const allFriends = useSelector(state => state.friends);
  const challengeData = stateValue.details;
  const challengeAdmin = challengeData && challengeData.challenge && challengeData.challenge.user;
  const challengeMedia = challengeData && challengeData.challenge && challengeData.challenge.media;
  const [state, setState] = React.useState({ open: false });
  const onStateChange = ({ open }) => setState({ open });
  const { open } = state;
  const [currentPage, setCurrentPage] = React.useState(1);
  const [modalVisible, setModalVisible] = useState(null);
  const [winnerModalVisible, setWinnerModalVisible] = useState(false);
  const [topUserModal, setTopUserModal] = useState(false);
  const [firstUserModal, setFirstUserModal] = useState(false);
  const [formLayoutIndex, setFormLayoutIndex] = useState(0);
  const [isPastEndDate, setIsPastEndDate] = useState(false);
  const [isChallengeWinner, setIsChallengeWinner] = useState(false);
  const [firstUserJoinModal, setFirstUserJoinModal] = useState(false);
  const [userName, setUserName] = useState([]);
  const [intervalRunning, setIntervalRunning] = useState(false);
  const [sortedData, setSortedData] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [deleteParams, setDeleteParams] = useState({
    story_id: '',
    comment_id: '',
    isComment: false,
  });
  const [tickSound, setTickSound] = useState(null);
  const [levelUpSound, setLevelUpSound] = useState(null);
  const [prevSortedUser, setPrevSortedUser] = useState([]);
  const [previousTopUser, setPreviousTopUser] = useState(null);
  const [firstVisitSound, setFirstVisitSound] = useState(null);
  const [firstVisit, setFirstVisit] = useState(false);
  const [params, setParamData] = useState({
    page: 1,
    limit: 10,
    fish_challenge_id: challengeId,
  });
  const [showSplash, setShowSplash] = useState(true);

  const startDate = moment(challengeData && challengeData.challenge && challengeData.challenge.meta && challengeData.challenge.meta.start_date,
  );
  const endDate = moment(challengeData && challengeData.challenge && challengeData.challenge.meta && challengeData.challenge.meta.end_date,
  );
  const startTime = moment(challengeData?.challenge?.meta?.start_time);
  const endTime = moment(challengeData?.challenge?.meta?.end_time);
  const winningPrize = challengeData && challengeData.challenge && challengeData.challenge.meta && challengeData.challenge.meta.winning_prize;

  const currentTime = moment();

  const isChallengeNotStarted = currentTime.isBefore(startDate) || (currentTime.isSame(startDate, 'day') && currentTime.isBefore(startTime));
  const isChallengeRunning = (currentTime.isSameOrAfter(startDate, 'day') && currentTime.isBefore(endDate, 'day')) || (currentTime.isSame(endDate, 'day') && currentTime.isBefore(endTime));

  const parseCatchCount = (count) => {
    const match = count.match(/(\d+(\.\d+)?)/);
    return match ? parseFloat(match[0]) : 0;
  };

  const getTotalCatchCount = (user) => {
    return user.catch_count.reduce((total, count) => total + parseCatchCount(count), 0);
  };

  const sortedUsers = sortedData && sortedData
    .map(user => ({ ...user, totalCatchCount: getTotalCatchCount(user) }))
    .sort((a, b) => b.totalCatchCount - a.totalCatchCount || a.catch_count.length - b.catch_count.length);
  const maxTotalCatchCount = Math.max(...(sortedUsers && sortedUsers.map(user => user.totalCatchCount) || [0]), 0);
  const findTopUser = (users) => {
    if (!Array.isArray(users) || users.length === 0) {
      return null;
    }
    return users.reduce((topUser, currentUser) => {
      return (currentUser.totalCatchCount > topUser.totalCatchCount) ? currentUser : topUser;
    }, users[0]);
  }
  const topUser = findTopUser(sortedUsers);
  const topUserMatched = topUser && topUser.totalCatchCount === maxTotalCatchCount;

  useEffect(() => {
    const loadSounds = async () => {
      const levelUpSound = new Sound('levelup.mp3', Sound.MAIN_BUNDLE, (error) => {
        if (error) {
          console.log('Failed to load levelup sound', error);
          return;
        }
        setLevelUpSound(levelUpSound);

      });
    };
    const firstVisitUser = () => {
      const userSound = Platform.select({
        ios: 'entry.mp3',
        android: 'entry'
      });

      const firstUser = new Sound(userSound, Sound.MAIN_BUNDLE, (error) => {
        if (error) {
          console.log('Failed to load entry sound', error);
          return;
        }
        setFirstVisitSound(firstUser);
      });
    };

    if (isFocused) {
      const params = {
        page: currentPage,
        limit: 10,
        fish_challenge_id: challengeId,
      };
      fetchChallenge(currentPage, params);
      firstVisitUser();
      loadSounds();
      const timer = setTimeout(() => {
        setShowSplash(false);
      }, 10000);

      return () => clearTimeout(timer);
    }
    const timer = setTimeout(() => {
      setShowTextAnimation(true);
    }, 2000);

    return () => {
      if (levelUpSound) {
        levelUpSound.release();
      }
      if (firstVisitSound) {
        firstVisitSound.release();
      }
      dispatch(resetState({}));
      if (!isFocused) {
      }
      clearTimeout(timer);
    };
  }, [isFocused,]);

  useEffect(() => {
    if (firstVisit && firstVisitSound && isPastEndDate && showSplash) {
      playFirstVisitSound();
    }

    if (!showSplash && firstVisit) {
      setTimeout(() => {
        setFirstUserModal(false);
      }, 1000);
    }

    if (sortedUsers && sortedUsers.length > 0) {
      playLevelUpSound();
    }
    if (intervalRunning) {
      const interval = setInterval(() => {
        setCurrentIndex(prevIndex => {
          const newIndex = prevIndex + 1;
          if (newIndex >= userName.length) {
            setIntervalRunning(false);
            setFirstUserJoinModal(true)
            return prevIndex;
          }
          return newIndex;
        });
      }, 5000);
      return () => clearInterval(interval);

    }
  }, [firstVisit, isPastEndDate, firstVisitSound, sortedData, intervalRunning]);

  useEffect(() => {
    const params = {
      page: 1,
      limit: 10,
      fish_challenge_id: challengeId,
    };

    const intervalId = setInterval(() => {
      fetchChallenge(currentPage, params);
    }, 20 * 1000);

    return () => clearInterval(intervalId);
  }, [currentPage, challengeId]);

  const handleBackPress = () => {
    navigation.navigate('Challenges', { isDelete: true });
    dispatch(resetState({}))
    return true;
  };

  useFocusEffect(
    React.useCallback(() => {
      const backHandler = BackHandler.addEventListener(
        'hardwareBackPress',
        handleBackPress,
      );
      return () => {
        backHandler.remove();
      };
    }, []),
  );

  const playFirstVisitSound = async () => {
    try {
      firstVisitSound.play();
    } catch (error) {
      console.log('Error playing firstVisit sound:', error);
    }
  };

  const playLevelUpSound = async () => {
    try {
      if (isPastEndDate && levelUpSound && (topUser?.user_id !== previousTopUser?.user_id)) {
        setTimeout(() => {
          setTopUserModal(true);
          playSound();
        }, 3000)
        setPreviousTopUser(topUser);
      } else if (!topUser && !previousTopUser && topUser.user_id === previousTopUser.user_id) {
        setPreviousTopUser(topUser);

      }
      setPreviousTopUser(topUser);
    } catch (error) {
      console.log('Error playing levelup sound11:', error);
    }
  };

  const playSound = async () => {
    try {
      if (levelUpSound !== null) {
        levelUpSound.play();
        setTimeout(() => {
          setTopUserModal(false);
        }, 3000);
      }

    } catch (error) {
      console.log('Error playing levelup sound:', error);
    }
  };

  const handleFormLayout = index => {
    setFormLayoutIndex(index);
  };

  const calculateTimeDuration = async data => {
    const challengeStartDate = moment(
      data &&
      data.challenge &&
      data.challenge.meta &&
      data.challenge.meta.start_date,
    );
    const challengeEndDate = moment(
      data &&
      data.challenge &&
      data.challenge.meta &&
      data.challenge.meta.end_date,
    );
    const challengeStartTime = moment(
      data &&
      data.challenge &&
      data.challenge.meta &&
      data.challenge.meta.start_time,
    );
    const challengeEndTime = moment(
      data &&
      data.challenge &&
      data.challenge.meta &&
      data.challenge.meta.end_time,
    );

    const currentTimeUTC = moment();
    const startDateTime = moment(challengeStartDate).set({
      hour: moment(challengeStartTime).hour(),
      minute: moment(challengeStartTime).minute(),
      second: moment(challengeStartTime).second(),
    });
    const endDateTime = moment(challengeEndDate).set({
      hour: moment(challengeEndTime).hour(),
      minute: moment(challengeEndTime).minute(),
      second: moment(challengeEndTime).second(),
    });
    if (currentTimeUTC.isBefore(startDateTime)) {
      setIsPastEndDate(false);
      setIsChallengeWinner(false);
    } else if (currentTimeUTC.isAfter(endDateTime)) {
      setIsPastEndDate(false);
      setIsChallengeWinner(true);
      if (isPastEndDate) {
        setWinnerModalVisible(true);
      }
    } else {
      setIsPastEndDate(true);
      const duration = moment.duration(endDateTime.diff(currentTimeUTC));
      setIsPastEndDate(true);
      setIsChallengeWinner(false);
    }
  };

  const fetchChallenge = async (page, params) => {
    try {
      setIsLoadingMore(true);
      const resultAction = await dispatch(fetchChallengesDetail(params));
      if (fetchChallengesDetail.fulfilled.match(resultAction)) {
        const newData = resultAction.payload.data;
        const catchesData = newData && newData.user_catch_counts;
        setSortedData(catchesData);
        const itemMeta = newData.challenge.meta.fish_challenge;
        const challengeId = newData.challenge && newData.challenge._id;

        const joinedUsers = itemMeta && itemMeta.filter(item => item.status === "joined" && item.first_visit === false && item.to_id.id !== stateVal.id);

        const checkAndSetModalsForNewUsers = async () => {
          const newUsers = [];
          for (const user of joinedUsers) {
            const alreadyShown = await AsyncStorage.getItem(`challenge_${challengeId}_user_${user.to_id.id}`);
            if (!alreadyShown) {
              await AsyncStorage.setItem(`challenge_${challengeId}_user_${user.to_id.id}`, 'true');
              newUsers.push(user);
            }
          }

          if (newUsers.length > 0) {
            console.log("newUsers", newUsers);
            if (isPastEndDate) {
              setUserName(newUsers || []);
              setTimeout(() => {
                playSound();
                setFirstUserJoinModal(true);
                setTimeout(() => {
                  setFirstUserJoinModal(false);
                }, 4000);
              }, 2000);
            }
          }
        };

        if (joinedUsers && joinedUsers.length > 0) {
          checkAndSetModalsForNewUsers();
        }

        const matchId = itemMeta && itemMeta.find(fish => fish && fish.to_id && fish.to_id.id === stateVal.id);
        if (matchId && matchId.first_visit === false) {
          setFirstVisit(true);
          setFirstUserModal(true);
        } else {
          setFirstVisit(false);
        }

        calculateTimeDuration(newData);
      }
      setIsLoadingMore(false);
    } catch (error) {
      console.error('Error in fetchTournament:', error);
      setIsLoadingMore(false);
    }
  };

  const deleteItem = async params => {
    try {
      const resultAction = await dispatch(
        params.isChallenge === true
          ? removeChallenge(params)
          : deletePost(params),
      );
      const data = resultAction.meta.arg;
      if (params.isChallenge === true) {
        navigation.navigate('Challenges', { isDelete: true });
      }
    } catch (error) {
      console.error('Error in deleteItem:', error);
    }
  };

  const handleDeletePress = params => {
    setDeleteParams(params);
    Alert.alert(
      'Delete', // Alert Title
      params.isChallenge === true
        ? 'Are you sure you want to delete this Tournament ?'
        : 'Are you sure you want to delete this Tournament post ?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'Delete',
          onPress: () => deleteItem(params),
          style: 'destructive',
        },
      ],
    );
  };

  const navigateToEdit = async () => {
    setTimeout(() => {
      navigation.navigate('ChallengesCreate', { id: params.fish_challenge_id });
    }, 1000);
  };

  const handleWinnerModalVisible = () => {
    setWinnerModalVisible(true);
  };

  const { height, width } = useWindowDimensions();
  const ListItem = (item, index, maxTotalCatchCount) => {
    const userProfile = item.user_profile && item.user_profile.path;
    const sortedCatchCount =
      item &&
      item.catch_count &&
      [...item.catch_count].sort((a, b) => parseFloat(b) - parseFloat(a));
    const formatCount = (count, idx) => {
      const number = parseFloat(count);
      return isNaN(number) ? '' : `${number} LBS`;
    };
    const isWinner = item.totalCatchCount === maxTotalCatchCount;
    return (
      <View style={FriendsStyle.Card} key={item.id}>
        <View style={[FriendsStyle.CardLeft, { marginVertical: 10, }]}>
          <Avatar.Image
            style={[FriendsStyle.CardImg, { backgroundColor: UiColor.ImageLoad }]}
            size={51}
            source={userProfile ? { uri: userProfile } : IconAsset.BlankUser}
          />
          <View>
            {challengeAdmin === item.user_id && (
              <View style={{ width: 50, justifyContent: 'center', backgroundColor: UiColor.DarkBlue, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4, }}>
                <Text style={{ fontSize: 12, fontFamily: Dm.medium, color: UiColor.White, }}>Admin</Text>
              </View>
            )}
            <Text style={FriendsStyle.CardTitle}>
              {item.user_first_name + ' ' + item.user_last_name}
            </Text>
          </View>
          {isChallengeWinner === true && (
            <>
              {isWinner && item.totalCatchCount > 0 ?
                <Pressable style={{ position: 'absolute', top: -24, right: -8, borderRadius: 0 }} onPress={handleWinnerModalVisible} >
                  <Image
                    style={[FriendsStyle.CardImg, { width: 35, height: 35, objectFit: 'contain' }]}
                    source={IconAsset.WinnerIcon}
                  />
                </Pressable>
                : ''
              }
            </>
          )}
          {sortedCatchCount && sortedCatchCount.length > 0 && (
            <View style={{ marginLeft: 'auto' }}>
              <Text
                style={{
                  position: 'absolute',
                  right: 52,
                  top: 8,
                  color: '#000000',
                  paddingVertical: 5,
                  fontSize: 14,
                }}>
                {formatCount(sortedCatchCount[0])}
              </Text>
              <IconButton
                onPress={() => setModalVisible(item.user_id)}
                icon={() => <Icon name="list-icon" size={24} color={UiColor.GrayBlack} />}
              />
            </View>
          )}
          <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible === item.user_id}
            onRequestClose={() => setModalVisible(null)}>
            <View
              style={{
                flex: 1,
                justifyContent: 'center',
                alignItems: 'center',
                backgroundColor: 'rgba(0, 0, 0, 0.5)',
                paddingHorizontal: 15,
              }}>
              <View
                style={{
                  backgroundColor: UiColor.White,
                  padding: 20,
                  width: '100%',
                  borderRadius: 10,
                }}>
                <View
                  style={{
                    marginTop: 10,
                  }}>
                  <View
                    style={{
                      paddingVertical: 12,
                      paddingHorizontal: 16,
                      width: '100%',
                      flexDirection: 'row',
                      borderRadius: 12,
                      backgroundColor: UiColor.SecondaryColor,
                      justifyContent: 'space-between'
                    }}>
                    <Text
                      style={{
                        color: UiColor.White,
                        fontSize: 16,
                        fontFamily: Dm.semiBold,
                        width: '33.333%'
                      }}>
                      #
                    </Text>
                    <Text
                      style={{
                        color: UiColor.White,
                        fontSize: 16,
                        fontFamily: Dm.semiBold,
                        width: '33.333%',
                      }}>
                      Media
                    </Text>
                    <Text
                      style={{
                        color: UiColor.White,
                        fontSize: 16,
                        fontFamily: Dm.semiBold,
                        width: '33.333%',
                      }}>
                      Weight
                    </Text>
                  </View>
                  <ScrollView style={{ width: '100%', maxHeight: height - 200, marginTop: 10 }} showsVerticalScrollIndicator={false}>
                    {sortedCatchCount && sortedCatchCount?.map((count, idx) => {
                      const matchedStory = item.user_story.find(
                        (story) => story.fish_weight === count
                      );
                      return (
                        <View key={idx.toString()}
                          style={{
                            paddingHorizontal: 16,
                            paddingVertical: 8,
                            width: '100%',
                            flexDirection: 'row',
                            justifyContent: 'space-between'
                          }}>

                          <Text
                            style={{
                              color: UiColor.Black,
                              marginTop: 14,
                              fontSize: 14,
                              fontFamily: Dm.semiBold,
                              width: '33.333%'
                            }}>
                            {idx + 1}
                          </Text>
                          {matchedStory &&
                            matchedStory.media &&
                            matchedStory.media.map((mediaItem, mediaIndex) => (
                              <View key={mediaIndex} style={{ width: '33.333%' }}>
                                <Image
                                  source={{ uri: mediaItem.media.path }}
                                  style={{ borderRadius: 30, width: 45, height: 45 }}
                                />
                              </View>
                            ))}
                          <Text
                            style={{
                              color: UiColor.Black,
                              marginTop: 12,
                              fontSize: 14,
                              fontFamily: Dm.semiBold,
                              width: '33.333%'
                            }}>
                            {formatCount(count)}
                          </Text>
                        </View>
                      );
                    })}
                  </ScrollView>
                </View>
                <IconButton
                  style={{
                    width: 25,
                    height: 25,
                    position: 'absolute',
                    top: -14,
                    right: -10,
                    backgroundColor: '#D2283D',
                  }}
                  onPress={() => setModalVisible(null)}
                  icon={() => (
                    <Icon name="cross" size={14} color={UiColor.White} />
                  )}
                  size={28}
                />
              </View>
            </View>
          </Modal>
        </View>
      </View>
    );
  };

  const actions = [
    ...(isPastEndDate
      ? [
        {
          icon: () => <Image
            style={{ width: 22, height: 22, objectFit: 'contain', tintColor: UiColor.White, marginLeft: 1 }}
            source={IconAsset.CatchGallery}
          />,
          label: 'Upload Catch',
          onPress: () => {
            navigation.navigate('ChallengesStoryUpload', { challenge_id: challengeId });
          },
          style: { backgroundColor: '#D2283D' },
        },
      ]
      : []
    ),
    ...(challengeData &&
      challengeData.challenge &&
      challengeData.challenge.user === stateVal.id
      ? [
        {
          icon: () => <Icon name="trash" size={24} color="white" />,
          label: 'Remove',
          onPress: () => {
            handleDeletePress({
              fish_challenge_id: params.fish_challenge_id,
              isChallenge: true,
            });
          },
          style: { backgroundColor: '#D2283D' },
        },
        {
          icon: () => <Icon name="edit2" size={24} color="white" />,
          label: 'Edit',
          onPress: () => {
            navigateToEdit();
          },
          style: { backgroundColor: '#D2283D' },
        },
      ]
      : []
    ),
  ];

  const SplitTextAnimation = ({ text }) => {
    const firstHalf = text.slice(0, Math.ceil(text.length / 2));
    const secondHalf = text.slice(Math.ceil(text.length / 2));

    const firstHalfX = useRef(new Animated.Value(-200)).current;
    const secondHalfX = useRef(new Animated.Value(200)).current;

    useEffect(() => {
      Animated.parallel([
        Animated.timing(firstHalfX, {
          toValue: 0,
          duration: 1000,
          easing: Easing.bounce,
          useNativeDriver: true,
        }),
        Animated.timing(secondHalfX, {
          toValue: 0,
          duration: 1000,
          easing: Easing.bounce,
          useNativeDriver: true,
        }),
      ]).start();
    }, [firstHalfX, secondHalfX]);

    return (
      <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
        <Animated.Text style={{ color: '#fff', fontSize: 24, fontWeight: 'bold', transform: [{ translateX: firstHalfX }] }}>
          {firstHalf}
        </Animated.Text>
        <Animated.Text style={{ color: '#fff', fontSize: 24, fontWeight: 'bold', transform: [{ translateX: secondHalfX }] }}>
          {secondHalf}
        </Animated.Text>
      </View>
    );
  };
  const currentUserID = userName[currentIndex]?.to_id.id;
  const matchedUser = sortedUsers?.find(user => user.user_id === currentUserID);

  return (
    <>
      {!challengeMedia ? (
        <SkeletonPlaceholder>
          <SkeletonPlaceholder.Item height={250} width="100%" />
          <SkeletonPlaceholder.Item flexDirection="row" alignItems="center" marginTop={20} marginLeft={20}>
            <SkeletonPlaceholder.Item width={120} height={35} borderRadius={15} />
            <SkeletonPlaceholder.Item width={120} height={35} borderRadius={15} marginLeft={22} />
          </SkeletonPlaceholder.Item>
          <SkeletonPlaceholder.Item paddingTop={20} marginLeft={20}>
            {Array.from({ length: 6 }).map((_, index) => (
              <View style={[FriendsStyle.Card, {
                shadowOpacity: 0,
                shadowRadius: 0,
              }]} key={index}>
                <SkeletonPlaceholder.Item height={50} width="100%">
                  <View style={FriendsStyle.CardLeft}>
                    <SkeletonPlaceholder.Item
                      width={51}
                      height={51}
                      borderRadius={51}
                    />
                    <View>
                      <SkeletonPlaceholder.Item
                        height={22}
                        width={150}
                        marginLeft={10}
                      />
                    </View>
                  </View>
                </SkeletonPlaceholder.Item>
              </View>
            ))}
          </SkeletonPlaceholder.Item>
        </SkeletonPlaceholder>
      ) : (
        <>
          {firstVisit && showSplash ?
            <View style={[SplashStyle.SplashContainer]}>
              <ImageBackground source={IconAsset.Challengethumb} resizeMode="cover" style={SplashStyle.BgImage}>
                <Image source={IconAsset.Logo2} style={{ width: 100, height: 100 }} />
                {route.params && route.params.quote && (
                  <SplitTextAnimation text={route.params.quote} />
                )}
                {route.params && route.params.meta && (
                  <Text style={styles.StartDateText}>
                    Challenge starts on {moment(route.params.meta.start_date).format('MMM DD')},
                    {moment(route.params.meta.start_time).tz(deviceTimeZoneLocalize).format(' hh:mm:ss A')}
                  </Text>
                )}
              </ImageBackground>
            </View>
            : <>
              <Appbar.Header style={[Styles.AppbarHeader, ProfileStyle.UserProfileBar]}>
                <Appbar.Action
                  animated={false}
                  size={20}
                  rippleColor="#00000008"
                  onPress={() => [dispatch(resetState({})), isCreated === true ? navigation.navigate('Challenges', { isDelete: true }) : navigation.navigate('Challenges', { isDelete: true })]}
                  style={{ backgroundColor: UiColor.SecondaryColor }}
                  icon={() => (
                    <Icon name="back" size={18} style={Styles.BackWhite} />
                  )}
                />
                <Appbar.Action animated={false} size={30} rippleColor="#00000008" />
                <Appbar.Action
                  animated={false}
                  size={26}
                  style={{ backgroundColor: '#ffffffa6', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                  rippleColor="#00000008"
                  onPress={() => { setWinnerModalVisible(true) }}
                  icon={() => (
                    <Image
                      style={{ width: 32, height: 32, objectFit: 'contain' }}
                      source={IconAsset.WinnerIcon}
                    />
                  )}
                />
              </Appbar.Header>

              <Modal
                animationType="slide"
                transparent={true}
                visible={winnerModalVisible}
                onRequestClose={() => setWinnerModalVisible(false)}>
                <View
                  style={{
                    flex: 1,
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: 'rgba(0, 0, 0, 0.5)',
                    paddingHorizontal: 15,
                  }}>
                  <View
                    style={{
                      backgroundColor: UiColor.White,
                      padding: 20,
                      width: '100%',
                      borderRadius: 10,
                    }}>
                    <View style={{ justifyContent: 'center', alignItems: 'center' }}>
                      <Image
                        style={{ width: 200, height: 200, objectFit: 'contain', marginBottom: 10 }}
                        source={IconAsset.WinnerIcon}
                      />
                      {isChallengeWinner === true && topUser && topUser.totalCatchCount === 0 && !isPastEndDate && (
                        <Text style={{ fontFamily: Dm.bold, fontSize: 22, color: UiColor.PrimaryColor, marginBottom: 15 }}>No anyone won this {winningPrize}</Text>
                      )}
                      {topUserMatched && isChallengeWinner === true && topUser && topUser.totalCatchCount !== 0 && (
                        <Text style={{ fontFamily: Dm.bold, fontSize: 22, color: UiColor.PrimaryColor, marginBottom: 15 }}>{`${stateVal.id === topUser.user_id ? 'You' : topUser.user_name} Won ${winningPrize}`}</Text>
                      )}
                      {(isChallengeNotStarted || isChallengeRunning || isPastEndDate) && (
                        <Text style={{ fontFamily: Dm.bold, fontSize: 22, color: UiColor.PrimaryColor, marginBottom: 15 }}>
                          You Can Win {winningPrize}
                        </Text>
                      )}
                      {
                        isChallengeWinner === true && topUser && topUser.totalCatchCount !== 0 &&
                        <LottieView
                          source={require('../animation/SparckleAnimation.json')}
                          autoPlay
                          loop
                          style={{ width: 500, height: 500, position: 'absolute', bottom: 100 }}
                        />
                      }
                    </View>
                    <IconButton
                      style={{
                        width: 25,
                        height: 25,
                        position: 'absolute',
                        top: -14,
                        right: -10,
                        backgroundColor: '#D2283D',
                      }}
                      onPress={() => setWinnerModalVisible(false)}
                      icon={() => (
                        <Icon name="cross" size={14} color={UiColor.White} />
                      )}
                      size={28}
                    />
                  </View>
                </View>
              </Modal>
              <Modal
                animationType="slide"
                transparent={true}
                visible={topUserModal}
                onRequestClose={() => setTopUserModal(false)}>
                <View
                  style={{
                    flex: 1,
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: 'rgba(0, 0, 0, 0.5)',
                    width: '100%',
                    // height: 200,
                    paddingHorizontal: 12
                  }}>

                  <View style={[FriendsStyle.Card, { flexDirection: 'column', width: '100%', }]}>
                    <Text style={{
                      color: UiColor.SecondaryColor,
                      fontSize: 22,
                      fontFamily: Dm.bold,
                      textAlign: 'center',
                      marginBottom: 10,
                    }}>Top User In List</Text>
                    <View style={[FriendsStyle.CardLeft, { marginVertical: 10, marginLeft: 30 }]}>
                      <Avatar.Image
                        style={[FriendsStyle.CardImg, { backgroundColor: UiColor.ImageLoad }]}
                        size={51}
                        source={topUser && topUser.user_profile && topUser.user_profile.path ? { uri: topUser.user_profile && topUser.user_profile.path } : IconAsset.BlankUser}
                      />
                      <View>
                        <Text style={FriendsStyle.CardTitle}>
                          {topUser ? `${topUser.user_first_name} ${topUser.user_last_name}` : '---'}
                        </Text>
                      </View>
                    </View>
                    <LottieView
                      source={require('../animation/StarAnimation.json')}
                      autoPlay
                      loop
                      style={{ width: 120, height: 120, position: 'absolute', right: -10, top: 0 }}
                    />
                    {/* <TouchableOpacity onPress={() => setTopUserModal(false)}>
                  <View
                    style={[
                      RemoveStyle.DeleteBtn, {marginTop: 10}
                    ]}>
                    <Text
                      style={{
                        color: UiColor.White,
                        fontSize: 16,
                        fontFamily: Dm.bold,
                        textAlign: 'center',
                      }}>
                      Close
                    </Text>
                  </View>
                </TouchableOpacity> */}
                    <IconButton
                      style={{
                        width: 25,
                        height: 25,
                        position: 'absolute',
                        top: -14,
                        right: -10,
                        backgroundColor: '#D2283D',
                      }}
                      onPress={() => setTopUserModal(false)}
                      icon={() => (
                        <Icon name="cross" size={14} color={UiColor.White} />
                      )}
                      size={28}
                    />
                  </View>
                </View>
              </Modal>
              <Modal
                animationType="slide"
                transparent={true}
                visible={firstUserModal}
                onRequestClose={() => setFirstUserModal(false)}>
                <View
                  style={{
                    flex: 1,
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: 'rgba(0, 0, 0, 0.5)',
                    width: '100%',
                    // height: 200,
                    paddingHorizontal: 12
                  }}>

                  <View style={[FriendsStyle.Card, { flexDirection: 'column', width: '100%', }]}>
                    <Text style={{
                      color: UiColor.SecondaryColor,
                      fontSize: 22,
                      fontFamily: Dm.bold,
                      textAlign: 'center',
                      marginBottom: 10,
                    }}>Welcome</Text>
                    <View style={[FriendsStyle.CardLeft, { marginVertical: 10, marginLeft: 30 }]}>
                      <Avatar.Image
                        style={[FriendsStyle.CardImg, { backgroundColor: UiColor.ImageLoad }]}
                        size={51}
                        source={stateVal && stateVal.profile_image_path ? { uri: stateVal.profile_image_path } : IconAsset.BlankUser}
                      />
                      <View>
                        <Text style={FriendsStyle.CardTitle}>
                          {stateVal ? `${stateVal.name}` : '---'}
                        </Text>
                      </View>
                    </View>
                    <LottieView
                      source={require('../animation/SparckleAnimation.json')}
                      autoPlay
                      loop
                      style={{ width: 500, height: 500, position: 'absolute', bottom: 100 }}
                    />
                    <LottieView
                      source={require('../animation/StarAnimation.json')}
                      autoPlay
                      loop
                      style={{ width: 120, height: 120, position: 'absolute', right: -10, top: 0 }}
                    />
                    {/* <TouchableOpacity onPress={() => setFirstUserModal(false)}>
                  <View
                    style={[
                      RemoveStyle.DeleteBtn, {marginTop: 10}
                    ]}>
                    <Text
                      style={{
                        color: UiColor.White,
                        fontSize: 16,
                        fontFamily: Dm.bold,
                        textAlign: 'center',
                      }}>
                      Close
                    </Text>
                  </View>
                </TouchableOpacity> */}
                    <IconButton
                      style={{
                        width: 25,
                        height: 25,
                        position: 'absolute',
                        top: -14,
                        right: -10,
                        backgroundColor: '#D2283D',
                      }}
                      onPress={() => setFirstUserModal(false)}
                      icon={() => (
                        <Icon name="cross" size={14} color={UiColor.White} />
                      )}
                      size={28}
                    />
                  </View>
                </View>
              </Modal>
              <Modal
                animationType="slide"
                transparent={true}
                visible={firstUserJoinModal}
                onRequestClose={() => setFirstUserJoinModal(false)}>
                <View
                  style={{
                    flex: 1,
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: 'rgba(0, 0, 0, 0.5)',
                    width: '100%',
                    // height: 200,
                    paddingHorizontal: 12
                  }}>
                  <View style={[FriendsStyle.Card, { flexDirection: 'column', width: '100%', }]}>
                    <View style={[FriendsStyle.CardLeft, { marginVertical: 10, marginLeft: 30 }]}>
                      <Avatar.Image
                        style={[styles.avatarImage, { backgroundColor: UiColor.ImageLoad }]}
                        size={51}
                        source={matchedUser && matchedUser.user_profile?.path ? { uri: matchedUser.user_profile.path } : IconAsset.BlankUser}
                      />
                      <View style={{ marginLeft: 10 }}>

                        <Text style={{ fontSize: 14, lineHeight: 14, color: UiColor.PrimaryColor, width: 250 }}>
                          {userName[currentIndex]?.to_id.name} has joined the tournament.
                        </Text>
                        <LottieView
                          source={require('../animation/EntryAnimation.json')}
                          autoPlay
                          style={{ width: 200, height: 200, position: 'absolute', left: 100, bottom: 0 }}
                        />
                      </View>
                    </View>

                    {/* <TouchableOpacity onPress={() => setFirstUserJoinModal(false)}>
                  <View
                    style={[
                      RemoveStyle.DeleteBtn, {marginTop: 10}
                    ]}>
                    <Text
                      style={{
                        color: UiColor.White,
                        fontSize: 16,
                        fontFamily: Dm.bold,
                        textAlign: 'center',
                      }}>
                      Close
                    </Text>
                  </View>
                </TouchableOpacity> */}
                    <IconButton
                      style={{
                        width: 25,
                        height: 25,
                        position: 'absolute',
                        top: -14,
                        right: -10,
                        backgroundColor: '#D2283D',
                      }}
                      onPress={() => setFirstUserJoinModal(false)}
                      icon={() => (
                        <Icon name="cross" size={14} color={UiColor.White} />
                      )}
                      size={28}
                    />
                  </View>
                </View>
              </Modal>
              {challengeData?.challenge &&
                challengeData.challenge.media &&
                challengeData.challenge.media?.map((mediaItem, mediaIndex) => (
                  <ImageBackground
                    key={mediaIndex}
                    source={
                      mediaItem && mediaItem.media && mediaItem.media.path
                        ? { uri: mediaItem.media.path }
                        : IconAsset.Splash
                    }
                    resizeMode="cover"
                    style={{
                      width: '100%',
                      height: 250,
                      position: 'absolute',
                      top: 0,
                      justifyContent: 'flex-end',
                    }}>
                    <View style={Styles.BannerOverlay}></View>
                    <CustomCountdown
                      startDate={startDate}
                      endDate={endDate}
                      startTime={startTime}
                      endTime={endTime}
                      params={params}
                      curruntPage={currentPage}
                      fetchChallenge={fetchChallenge}
                      playLevelUpSound={playLevelUpSound}

                    />
                    <View style={ChallengesStyle.BannerTextHead}>
                      <View>
                        <Text style={ChallengesStyle.BannerTextTitle}>
                          {challengeData?.challenge.quote}
                        </Text>
                        <Text style={ChallengesStyle.BannerTextDisc}>
                          {challengeData?.challenge &&
                            moment(challengeData?.challenge.meta.start_date).format(
                              'DD MMM',
                            )}{' '}
                          -{' '}
                          {challengeData?.challenge &&
                            moment(challengeData?.challenge.meta.end_date).format(
                              'DD MMM',
                            )}
                        </Text>
                      </View>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'center',
                          paddingRight: 12,
                        }}>
                        {challengeData?.user_catch_counts
                          ?.slice(0, 3)
                          .map((toId, smallIndex) => (
                            <Image
                              key={smallIndex}
                              style={{
                                borderColor: '#fff',
                                borderWidth: 2,
                                width: 46,
                                height: 46,
                                borderRadius: 46,
                                marginRight: -12,
                              }}
                              source={
                                toId && toId.user_profile && toId.user_profile.path
                                  ? { uri: toId.user_profile.path }
                                  : IconAsset.BlankUser
                              }
                            />
                          ))}
                        {challengeData?.user_catch_counts.length > 3 && (
                          <Text
                            style={{
                              fontSize: 14,
                              fontFamily: Dm.medium,
                              color: '#fff',
                              paddingLeft: 8,
                              paddingRight: 5,
                            }}>
                            +{challengeData?.user_catch_counts.length - 3}
                          </Text>
                        )}
                      </View>
                    </View>
                  </ImageBackground>
                ))}
              <View style={[ChallengesStyle.TabHead,]}>
                <SegmentedControlTab
                  values={['Score Board', 'Story Board']}
                  selectedIndex={formLayoutIndex}
                  onTabPress={handleFormLayout}
                  borderRadius={18}
                  tabsContainerStyle={[Styles.TabContainer, { marginTop: 0 }]}
                  tabStyle={[Styles.TabStyle]}
                  activeTabStyle={Styles.ActiveTab}
                  tabTextStyle={Styles.TabText}
                  activeTabTextStyle={Styles.ActiveTabText}
                />
              </View>

              {formLayoutIndex === 0 && (
                <>
                  <View
                    style={[
                      FriendsStyle.Container,
                      { backgroundColor: 'transparent', top: 100 },
                    ]}>
                    <ImageBackground
                      source={IconAsset.Bg4}
                      resizeMode="cover"
                      style={{
                        width: '100%',
                        height: '100%',
                      }}>
                      <SafeAreaView
                        style={[FriendsStyle.FullCardArea, { marginBottom: 310, marginTop: 12 }]}>
                        <ScrollView showsVerticalScrollIndicator={false}>
                          {!isSearching && sortedUsers && sortedUsers.map((sortedItem, index) => (
                            <FlatList
                              key={index.toString()}
                              scrollEnabled={false}
                              data={[sortedItem]}
                              extraData={prevSortedUser}
                              renderItem={({ item }) => ListItem(item, index, maxTotalCatchCount)}
                            />
                          ))}
                        </ScrollView>
                        {!isSearching &&
                          challengeData?.user_catch_counts &&
                          challengeData.user_catch_counts.length === 0 && (
                            <View style={[GlobalStyles.NoData, { top: 20 }]}>
                              <Text style={GlobalStyles.NoDataMsg}>
                                No one join challenge
                              </Text>
                            </View>
                          )}
                      </SafeAreaView>
                    </ImageBackground>
                  </View>
                </>
              )}
              {formLayoutIndex === 1 && (
                <>
                  <ChallengesStory />
                </>
              )}

              {actions && actions.length > 0 && (
                <FAB.Group
                  open={open}
                  visible
                  icon={() => <Icon name="plus" size={16} color="white" style={{ marginTop: 3, verticalAlign: 'middle', textAlign: 'center' }} />}
                  actions={actions}
                  onStateChange={onStateChange}
                  onPress={() => {
                    if (open) {
                      // do something if the speed dial is open
                    }
                  }}
                  fabStyle={{ backgroundColor: '#D2283D', bottom: 0 }}
                  color="white"
                />
              )}
            </>}
        </>
      )}
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    position: 'absolute',
    bottom: 22,
    left: 20,
  },
  timerRow: {
    alignItems: 'center',
    marginHorizontal: 3,
    // backgroundColor: '#ffffff57',
    backgroundColor: '#ffffffa6',
    width: 50,
    height: 50,
    borderRadius: 8,
    paddingVertical: 4
  },
  timerText: {
    color: UiColor.PrimaryColor,
    // color: UiColor.BaseColor,
    fontSize: 20,
    fontFamily: Dm.bold
  },
  label: {
    color: '#000',
    fontFamily: Dm.semiBold,
    fontSize: 12,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    paddingHorizontal: 15,
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    width: '100%',
    maxWidth: 350,
    height: 500,
    borderRadius: 10,
    alignItems: 'center',
  },
  modalText: {
    fontSize: 18,
    marginBottom: 20,
  },
  closeButton: {
    backgroundColor: 'blue',
    padding: 10,
    borderRadius: 5,
    width: 60,
    marginLeft: 90,
    marginTop: 20

  },
  closeButtonText: {
    color: 'white',
    alignItems: 'center'
  },
  lottie: {
    width: 300,
    height: 300,
  },
  gameOverContainer: {
    backgroundColor: UiColor.SecondaryColor,
    padding: 8,
    borderRadius: 10,
    marginLeft: 20
  },
  gameOverPopup: {
    backgroundColor: 'white',
    padding: 10,
    borderRadius: 10,
    marginHorizontal: 5
  },
  gameOverMessageText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: 'red',
    paddingHorizontal: 8,
  },
  headerContainer: {
    width: '100%',
    height: '100%',
    position: 'relative',

  },
  overlay: {
    position: 'absolute',
    width: '100%',
    height: 40,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    overflow: 'hidden',
    top: 40,
    alignItems: 'center',
    flexDirection: 'row'
  },
  headerText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
    lineHeight: 14
    // backgroundColor:'red'
  },
  StartDateText: {
    position: 'absolute',
    bottom: 20,
    color: '#fff',
    fontSize: 18,
    textAlign: 'center',
  },
});

export default ChallengesDetail;
