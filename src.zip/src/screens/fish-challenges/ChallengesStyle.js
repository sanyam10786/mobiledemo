/* eslint-disable prettier/prettier */
import { StyleSheet, Platform } from 'react-native';
import { Dm, UiColor } from '../../../theme/Index';

export const ChallengesStyle = StyleSheet.create({
  TabHead: {
    alignItems: 'flex-start',
    top: 118,
    paddingVertical: 16,
    backgroundColor: '#fff',
    shadowColor: '#505588',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 0,
    ...Platform.select({
      android: {
        elevation: 6,
      },
    }),
  },
  Overlay: {
    width: '100%',
    height: '100%',
    position: 'absolute',
    top: 0,
    left: 0,
    backgroundColor: '#000',
    opacity: .2
  },
  BannerTextHead: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: 30,
    paddingHorizontal: 18
  },
  BannerTextTitle: {
    width: 250,
    color: 'white',
    fontSize: 20,
    backgroundColor: 'transparent',
    fontFamily: Dm.bold,
    flexShrink: 1
  },
  BannerTextDisc: {
    color: 'white',
    fontSize: 14,
    flexShrink: 1,
    fontFamily: Dm.regular,
  },
  LiveTagView:{
    position:"absolute",right:8,top:8,
  },
  LiveTag:{
    backgroundColor:UiColor.SecondaryColor,
  },
  LiveTagText:{
    fontSize: 10,color:'#fff',textAlign:"center",fontFamily:Dm.medium,fontWeight:"500"
  }
});
