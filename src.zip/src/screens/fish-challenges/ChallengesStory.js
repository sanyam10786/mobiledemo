import {fetchMyFriends, fetchChallengesDetail, removeChallenge, likePosts, removeLike, commentPost, fetchComments, likeComment, deletePost, deleteComment, commentReply} from '../../thunk';
import {View, Text, TouchableOpacity, Image, SafeAreaView, FlatList, Platform, Alert, KeyboardAvoidingView} from 'react-native';
import {Avatar, IconButton, ActivityIndicator, TextInput} from 'react-native-paper';
import {Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm} from '../../../theme/Index';
import {useIsFocused, useNavigation, useRoute} from '@react-navigation/native';
import React, {useEffect, useState, useRef, useContext} from 'react';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import {StoryBoardStyle} from '../story-board/StoryBoardStyle';
import FastImage from 'react-native-fast-image';
import {setRefreshing} from '../../slices/fish-challenges';
import {useDispatch, useSelector} from 'react-redux';
import RBSheet from 'react-native-raw-bottom-sheet';
import {NetworkContext} from '../../NetworkContext';
import Slick from 'react-native-slick';
import moment from 'moment';

const ChallengesStory = () => {
  const navigation = useNavigation();
  const refCommentSheet = useRef({});
  const refPostSheet = useRef({});
  const dispatch = useDispatch();
  const route = useRoute();
  const challengeId = route.params._id;
  const isFocused = useIsFocused();
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const stateVal = useSelector(state => state.login);
  const stateValue = useSelector(state => state.challenge);
  const [storyData, setStoryData] = useState([]);
  const [commentData, setCommentData] = useState([]);
  const [myFriendData, setMyFriendData] = useState([]);
  const [currentPage, setCurrentPage] = React.useState(1);
  const [commentItems, setCommentItems] = useState(null);
  const [expandedComments, setExpandedComments] = useState([]);
  const toggleRepliesVisibility = commentId => {
    setExpandedComments(prev => ({
      ...prev,
      [commentId]: !prev[commentId],
    }));
  };
  const [deleteParams, setDeleteParams] = useState({
    story_id: '',
    comment_id: '',
    isComment: false,
  });
  const [isFetchingNewComments, setIsFetchingNewComments] = useState(false);
  const [shouldFetchNextPage, setShouldFetchNextPage] = useState(true);
  const commentInputRef = useRef({});
  const [isSubmit, setIsSubmit] = useState(false);
  const [isEndOfFirstPage, setIsEndOfFirstPage] = useState(false);
  const [formData, setFormData] = useState({
    comment: '',
    text_comment: '',
    isReply: false,
  });
  const [params, setParamData] = useState({
    page: 1,
    limit: 10,
    fish_challenge_id: challengeId,
  });

  useEffect(() => {
    if (isFocused) {
      const params = {
        page: currentPage,
        limit: 10,
        fish_challenge_id: challengeId,
      };
      fetchChallenge(currentPage, params);
      fetchFriends();
    }
    return () => {
      if (!isFocused) {
      }
    };
  }, [isFocused]);

  const handleRefresh = () => {
    const params = {
      page: 1,
      limit: 10,
      fish_challenge_id: challengeId,
    };
    fetchChallenge(1, params);
    fetchFriends();
  };

  const fetchChallenge = async (page, params) => {
    try {
      setIsLoadingMore(true);
      const resultAction = await dispatch(fetchChallengesDetail(params));
      if (fetchChallengesDetail.fulfilled.match(resultAction)) {
        const newData = resultAction.payload.data;
        const newStoryData = newData.user_stories;
        if (params.page === 1) {
          setStoryData(newStoryData);
        } else {
          setStoryData(prevPosts => {
            const uniqueFilteredData = newStoryData.filter(newItem => {
              return !prevPosts.some(prevItem => prevItem._id === newItem._id);
            });

            return [...prevPosts, ...uniqueFilteredData];
          });
        }
        if (newStoryData.length < params.limit) {
          setShouldFetchNextPage(false);
        } else {
          setShouldFetchNextPage(true);
        }
      }
      setIsLoadingMore(false);
    } catch (error) {
      console.error('Error in fetchChallenge:', error);
      setIsLoadingMore(false);
    }
  };

  const fetchFriends = async () => {
    try {
      const params = {
        user_id: stateVal.id,
        page: 1,
        limit: 30,
      };

      let allFriends = [];
      while (true) {
        const resultAction = await dispatch(fetchMyFriends(params));
        if (fetchMyFriends.fulfilled.match(resultAction)) {
          const newData = resultAction.payload.data.friends;
          allFriends = allFriends.concat(newData);
          if (newData.length < params.limit) {
            break;
          }
          params.page++;
        } else {
          break;
        }
      }
      setMyFriendData(allFriends);
    } catch (error) {
      console.error('Error in fetchFriends:', error);
    }
  };

  const handleOnRefresh = () => {
    dispatch(setRefreshing({}));
    params.page = 1;
    fetchChallenge(currentPage, params);
  };

  const handleEndReached = () => {
    if (shouldFetchNextPage) {
      handleLoadMore();
    }
  };

  const handleLoadMore = () => {
    if (!isLoadingMore && shouldFetchNextPage && isEndOfFirstPage) {
      setIsLoadingMore(true);
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      const params = {
        page: nextPage,
        limit: 10,
        fish_challenge_id: challengeId,
      };
      fetchChallenge(nextPage, params).then(() => setIsLoadingMore(false));
      setIsEndOfFirstPage(false);
    }
  };
  
  const handleScroll = event => {
    const {contentOffset, layoutMeasurement, contentSize} = event.nativeEvent;
    const endOfFirstPageOffset = contentSize.height - layoutMeasurement.height;
    if (!contentOffset.y <= endOfFirstPageOffset) {
      setIsEndOfFirstPage(true);
    } else {
      setIsEndOfFirstPage(false);
    }
  };

  const likePost = async text => {
    try {
      const params = {story_id: text};
      const resultAction = await dispatch(likePosts(params));
      const newLikes = resultAction.payload.data.likes;

      setStoryData(prevData => {
        return prevData?.map(userData => {
          if (userData._id === text) {
            const updatedLikes = [...userData.likes, ...newLikes].filter(
              (like, index, self) =>
                index === self.findIndex(l => l._id === like._id),
            );
            return {
              ...userData,
              likes: updatedLikes,
            };
          }
          return userData;
        });
      });
    } catch (error) {
      console.error('Error in likePosts:', error);
    }
  };

  const dislikePost = async text => {
    try {
      const params = {
        story_id: text.story_id,
        like_id: text.like_id,
      };
      const resultAction = await dispatch(removeLike(params));
      if (text.isCommentDislike) {
        fetchPostComment(text.story_id);
      } else {
        const newLikes = resultAction.payload.data.likes;
        if (newLikes) {
          setStoryData(prevData => {
            return prevData?.map(userData => {
              if (userData._id === text.story_id) {
                return {
                  ...userData,
                  likes: userData.likes.filter(
                    like => like._id !== text.like_id,
                  ),
                };
              }
              return userData;
            });
          });
        }
      }
    } catch (error) {
      console.error('Error in dislikePosts:', error);
    }
  };

  const postCommentOrReply = async text => {
    setIsSubmit(true);
    setIsFetchingNewComments(true);
    const {isReply} = formData;
    try {
      let resultAction;
      if (isReply) {
        // Reply
        const commentsId = text.comment_id.comment_id;
        resultAction = await dispatch(
          commentReply({
            story_id: text.story_id,
            comment_id: commentsId,
            text_comment: formData.comment,
          }),
        );
      } else {
        // New Comment
        resultAction = await dispatch(
          commentPost({
            story_id: text.story_id,
            comment: formData.comment,
          }),
        );
      }
      setIsSubmit(false);
      if (
        commentReply.fulfilled.match(resultAction) ||
        commentPost.fulfilled.match(resultAction)
      ) {
        const newComment = resultAction.payload.data;
        if (newComment) {
          setCommentData(prevData => ({
            ...prevData,
            result: [...(prevData?.result || []), newComment],
          }));
        }
        fetchPostComment(text.story_id);
        setFormData({...formData, comment: '', isReply: false});
        setCommentItems('');
      }
    } catch (error) {
      console.error('Error in CommentReply/CommentPost:', error);
      setIsSubmit(false);
      setIsFetchingNewComments(false);
    }
  };

  const fetchPostComment = async text => {
    refCommentSheet.current[text]?.open();
    const params = {
      story_id: text,
    };
    try {
      const resultAction = await dispatch(fetchComments(params));
      if (fetchComments.fulfilled.match(resultAction)) {
        const data = resultAction.payload.data;
        setCommentData(data);
        if (data) {
          setStoryData(prevData =>
            prevData.map(item => {
              if (item._id === text) {
                return {
                  ...item,
                  comments: data.result,
                };
              }
              return item;
            }),
          );
        }
      }
    } catch (error) {
      console.error('Error in CommentPosts:', error);
    }
  };

  const closeCommentSheet = () => {
    setCommentData('');
    setCommentItems('');
    setFormData('');
    setExpandedComments('');
    fetchChallenge(currentPage, params);
  };

  const postCommentLike = async text => {
    try {
      const params = {
        story_id: text.story_id,
        comment_id: text.comment_id,
      };
      const resultAction = await dispatch(likeComment(params));
      const likeData = resultAction.payload.data;
      fetchPostComment(params.story_id);
    } catch (error) {
      console.error('Error in postCommentLike:', error);
    }
  };

  const deleteItem = async params => {
    try {
      const resultAction = await dispatch(
        params.isComment === true
          ? deleteComment(params)
          : params.isChallenge === true
          ? removeChallenge(params)
          : deletePost(params),
      );
      const data = resultAction.meta.arg;
      refPostSheet.current[params.story_id]?.close();
      if (params.isChallenge === true) {
        navigation.navigate('Challenges', {isDelete: true});
      }
      if (params.isComment) {
        if (resultAction.payload.status) {
          setCommentData(prevData => ({
            ...prevData,
            result: prevData.result.filter(
              item => item._id !== data.comment_id,
            ),
            comment_count: prevData.comment_count - 1,
          }));
          fetchPostComment(params.story_id);
        }
      } else {
        setStoryData(prevData => {
          return prevData.filter(userData => {
            if (userData._id === params.story_id) {
              return false;
            }
            return true;
          });
        });
      }
    } catch (error) {
      console.error('Error in deleteItem:', error);
    }
  };

  const handleDeletePress = params => {
    // refSheet.current?.close();
    setDeleteParams(params);
    Alert.alert(
      'Delete', // Alert Title
      params.isComment === true
        ? 'Are you sure you want to delete this comment ?'
        : params.isChallenge === true
        ? 'Are you sure you want to delete this challenge ?'
        : 'Are you sure you want to delete this challenge post ?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Cancel Pressed'),
          style: 'cancel',
        },
        {
          text: 'Delete',
          onPress: () => deleteItem(params),
          style: 'destructive',
        },
      ],
    );
  };

  const navigateToProfile = text => {
    refCommentSheet.current[text.story_id]?.close();
    setTimeout(() => {
      const item_id = text.user_id;
      if (item_id === stateVal.id) {
        navigation.navigate('UserProfile', (isProfile = true));
      } else {
        const hasFriend = myFriendData.some(item => item.id === item_id);
        if (hasFriend) {
          navigation.navigate('MyFriendProfile', item_id);
        } else {
          navigation.navigate('FriendProfile', item_id);
        }
      }
    }, 1500);
  };

  const StoryPost = ({item, index}) => {
    return (
      <>
        <View key={index}>
          <View style={Styles.PostCard}>
            <View style={Styles.PostTitleHead}>
              <View style={{flexDirection: 'row'}}>
                <TouchableOpacity
                  onPress={() => navigateToProfile({user_id: item.user.id})}>
                  <Avatar.Image
                    size={51}
                    style={{backgroundColor: UiColor.ImageLoad}}
                    source={
                      item &&
                      item.user &&
                      item.user.profile_image &&
                      item.user.profile_image.path
                        ? {
                            uri:
                              item &&
                              item.user &&
                              item.user.profile_image &&
                              item.user.profile_image.path,
                          }
                        : IconAsset.Splash
                    }
                  />
                </TouchableOpacity>
                <View>
                  <Text style={Styles.PostCardTitle}>
                    {item && item.user && item.user.name}
                  </Text>
                  <Text style={Styles.PostCardSubTitle}>
                    {moment(item.created_at).fromNow()}
                  </Text>
                </View>
              </View>
              <IconButton
                onPress={() => {
                  refPostSheet.current[item._id]?.open();
                }}
                style={{marginRight: -10}}
                icon={() => (
                  <Icon name={'more-fill'} color={'#536471'} size={18} />
                )}
                size={15}
              />
              <RBSheet
                ref={ref => (refPostSheet.current[item._id] = ref)}
                closeOnDragDown={true}
                closeOnPressMask={true}
                openDuration={800}
                height={200}
                customStyles={{
                  wrapper: {
                    backgroundColor: '#00000024',
                  },
                  draggableIcon: {
                    backgroundColor: '#E3E3E3',
                  },
                  container: {
                    borderTopLeftRadius: 30,
                    borderTopRightRadius: 30,
                  },
                }}>
                <View style={Styles.PostCardEdit}>
                  {item.user.id === stateVal.id && (
                    <TouchableOpacity
                      onPress={() => {
                        handleDeletePress({
                          story_id: item._id,
                          isComment: false,
                        });
                      }}
                      style={Styles.PostActionBtn}>
                      {/* <Icon
                        name="trash"
                        style={Styles.PostActionIcon}
                        size={20}
                      /> */}
                      <Text style={Styles.PostActionText}>Delete</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </RBSheet>
            </View>
            {item.quote ? <Text style={[Styles.PostCardDisc]}>{item.quote}</Text> : <Text></Text>}
            <View style={Styles.PostCardImgHead}>
              {item.media && item.media.length > 1 ? (
                <Slick
                  dotColor="#fff"
                  activeDotColor="#D1283D"
                  style={{
                    justifyContent: 'center',
                    alignItems: 'center',
                    height: 297,
                  }}>
                  {item.media &&
                    item.media.map((mediaItem, mediaIndex) => (
                      <View key={mediaIndex}>
                        <FastImage
                          source={{uri: mediaItem.media.path}}
                          style={Styles.PostCardImg}
                        />
                      </View>
                    ))}
                </Slick>
              ) : (
                item.media &&
                item.media.map((mediaItem, mediaId) => (
                  <Image
                    key={mediaId}
                    source={{uri: mediaItem.media.path}}
                    style={Styles.PostCardImg}
                  />
                ))
              )}
            </View>
            <View>
              <View style={Styles.PostCardFoot}>
                <TouchableOpacity
                  onPress={() => navigation.navigate('PostLikes', item._id)}>
                  <View style={Styles.PostLikeCount}>
                    <Icon
                      name="unfill-hang-luss"
                      color={UiColor.SecondaryColor}
                      size={12}
                      // style={Styles.PostLikeCountIcon}
                    />
                    {item && item.likes.length > 0 ? (
                      <Text style={Styles.PostLikeText}>
                        {item.likes.length}{' '}
                        {item && item.likes?.length === 1 ? 'Like' : 'Likes'}
                      </Text>
                    ) : (
                      <Text style={Styles.PostLikeText}>Likes</Text>
                    )}
                  </View>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => {
                    fetchPostComment(item._id);
                  }}>
                  {item && item.comments.length > 0 ? (
                    <Text style={Styles.PostLikeText}>
                      {item.comments.length}{' '}
                      {item && item.comments?.length === 1
                        ? 'Comment'
                        : 'Comments'}
                    </Text>
                  ) : (
                    <Text style={Styles.PostLikeText}>Comments</Text>
                  )}
                </TouchableOpacity>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  paddingTop: 8,
                }}>
                <TouchableOpacity
                  style={Styles.PostCardBtn}
                  onPress={() =>
                    item.likes.some(likeItem => likeItem.user_id === stateVal.id)
                      ? dislikePost({
                          story_id: item._id,
                          like_id: item.likes.find(like => like.user_id === stateVal.id)._id,
                        })
                      : likePost(item._id)
                  }
                >
                    <Icon
                      name= {item.likes.some(likeItem => likeItem.user_id === stateVal.id) ? "unfill-hang-luss" : "unfill-hang-luss"}
                      color={item.likes.some(likeItem => likeItem.user_id === stateVal.id) ? UiColor.SecondaryColor : UiColor.GrayLight}
                      size={18}
                    />
                  {/* <Image source={IconAsset.ThumbImage} style={{tintColor: item.likes.some(likeItem => likeItem.user_id === stateVal.id) ? UiColor.SecondaryColor : UiColor.GrayLight, width: 16, height: 16}} /> */}
                  <Text style={[Styles.PostLikeText, {marginLeft: 5, color: item.likes.some(likeItem => likeItem.user_id === stateVal.id) ? UiColor.SecondaryColor : UiColor.GrayLight,}]}>Like</Text>
               </TouchableOpacity>
                <TouchableOpacity
                  style={Styles.PostCardBtn}
                  onPress={() => {
                    fetchPostComment(item._id);
                  }}>
                  <Icon name="comment" size={20} color={'#536471'} />
                  <Text style={Styles.PostLikeText}>Comment</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>
      </>
    );
  };

  const CommentText = ({ comment }) => {
    const usernameRegex = /(@\w+\s\w+)/g;
    const parts = comment.split(usernameRegex);
    return (
      <Text>
        {parts.map((part, index) => {
          if (usernameRegex.test(part)) {
            return (
              <Text key={index} style={[StoryBoardStyle.CommentText, {fontSize: 14, fontFamily: Dm.semiBold, color: UiColor.DarkBlue}]}>
                {part}
              </Text>
            );
          } else {
            return (
              <Text key={index} style={[StoryBoardStyle.CommentText, {fontSize: 14,}]}>
                {part}
              </Text>
            );
          }
        })}
      </Text>
    );
  };

  const renderReplies = parentCommentId => {
    const params = {
      story_id: parentCommentId.story_id,
      comment_id: parentCommentId.comment_id,
      user_id: parentCommentId.user_id,
    };
    const replies = commentData.result?.filter(
      comment => comment.parent_comment_id === params.comment_id,
    );

    return replies.map(reply => {
      const formatTime = moment(
        reply.created_at,
        'DD MM YYYY hh:mm:ss a',
      ).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
      const fromNowTime = moment(formatTime).fromNow();
      return (
        <View key={reply._id}>
          <View
            style={[
              StoryBoardStyle.CommentWrap,
              StoryBoardStyle.CommentWrapInner,
            ]}>
            <TouchableOpacity
              style={[StoryBoardStyle.ProfileCta, {marginRight: 6}]}
              onPress={() =>
                navigateToProfile({
                  user_id: reply.user_id._id,
                  story_id: params.story_id,
                })
              }>
              {reply?.user_id.profile_image?.path ? (
                <Avatar.Image
                style={{backgroundColor: UiColor.ImageLoad}}
                  size={32}
                  source={{
                    uri: reply?.user_id?.profile_image.path,
                  }}
                />
              ) : (
                <Avatar.Image style={{backgroundColor: UiColor.ImageLoad}} size={32} source={IconAsset.BlankUser} />
              )}
            </TouchableOpacity>
            <View style={StoryBoardStyle.CommentCardHead}>
              <View style={StoryBoardStyle.CommentCard}>
                <View style={StoryBoardStyle.CommentCardTitle}>
                  <Text style={StoryBoardStyle.CommentTitle}>
                    {reply?.user_id?.first_name +
                      ' ' +
                      reply?.user_id?.last_name}
                  </Text>
                  <Text style={StoryBoardStyle.CommentDate}>{fromNowTime}</Text>
                </View>
                {/* <Text style={StoryBoardStyle.CommentText}>
                  {reply?.text_comment}
                </Text> */}
                <CommentText comment={reply?.text_comment} />
              </View>
              <View style={StoryBoardStyle.CommentRange}>
                {reply && reply.like_count === 0 ? (
                  ''
                ) : (
                  <Text style={StoryBoardStyle.CommentRangeText}>
                    {reply.like_count}
                  </Text>
                )}
                {reply.likes?.some(like => like.user_id === stateVal.id) ? (
                  <TouchableOpacity
                    onPress={() => {
                      dislikePost({
                        story_id: params.story_id,
                        isCommentDislike: true,
                        like_id: reply.likes.find(
                          like => like.user_id === stateVal.id,
                        )._id,
                      });
                    }}>
                    <Text style={StoryBoardStyle.CommentRangeText}>Unlike</Text>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity
                    onPress={() => {
                      postCommentLike({
                        story_id: params.story_id,
                        comment_id: reply._id,
                      });
                    }}>
                    <Text style={StoryBoardStyle.CommentRangeText}>Like</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity
                  onPress={() => {
                    setCommentItems({
                      comment_id: reply._id,
                      fullName:
                        reply.user_id.first_name +
                        ' ' +
                        reply.user_id.last_name,
                    });
                    setFormData({
                      ...formData,
                      comment: `@${reply.user_id.first_name } ${reply.user_id.last_name} `,
                      isReply: true,
                    });
                    commentInputRef.current && commentInputRef.current.focus();
                  }}>
                  <Text style={StoryBoardStyle.CommentRangeText}>Reply</Text>
                </TouchableOpacity>
                {reply.user_id._id === stateVal.id ||
                params.user_id === stateVal.id ? (
                  <TouchableOpacity
                    onPress={() => {
                      handleDeletePress({
                        story_id: params.story_id,
                        comment_id: reply._id,
                        isComment: true,
                      });
                    }}>
                    <Text style={StoryBoardStyle.CommentRangeText}>Delete</Text>
                  </TouchableOpacity>
                ) : (
                  ''
                )}
              </View>
            </View>
          </View>
          {renderReplies(
            {
              story_id: params.story_id,
              comment_id: reply._id,
              user_id: params.user_id,
            },
            commentData,
          )}
        </View>
      );
    });
  };
  return (
    <>
      <View style={{flex: 1, top: Platform.OS === 'ios' ? 150 : 130}}>
        <View style={{flex: 1}}>
          <SafeAreaView
            style={{
              flex: 1,
              paddingTop: Platform.OS === 'ios' ? 10 : 0,
              paddingBottom: Platform.OS === 'ios' ? 120 : 120,
            }}>
            {Object.keys(storyData).length === 0 && isLoadingMore ? (
              <SkeletonPlaceholder>
                {[...Array(4)].map((_, index) => (
                  <SkeletonPlaceholder.Item
                    key={index}
                    flexDirection="row"
                    alignItems="center"
                    marginBottom={0}
                    marginTop={20}
                    marginHorizontal={18}>
                    <SkeletonPlaceholder.Item
                      width="100%"
                      height={200}
                      borderRadius={6}
                    />
                  </SkeletonPlaceholder.Item>
                ))}
              </SkeletonPlaceholder>
            ) : (
              <>
                <FlatList
                  data={storyData}
                  onEndReached={handleEndReached}
                  onEndReachedThreshold={0.1}
                  showsVerticalScrollIndicator={false}
                  renderItem={({item, index}) => (
                    <StoryPost item={item} index={index} />
                  )}
                  keyExtractor={(item, index) => index.toString()}
                  contentContainerStyle={{
                    paddingBottom: Platform.OS === 'ios' ? 120 : 15,
                  }}
                  refreshing={stateValue.refreshing}
                  onRefresh={handleRefresh}
                  onScroll={handleScroll}
                  ListFooterComponent={() => {
                    return isEndOfFirstPage && shouldFetchNextPage ? (
                      <ActivityIndicator
                        animating={true}
                        size={32}
                        color={UiColor.BaseColor}
                      />
                    ) : null;
                  }}
                />
                {!isLoadingMore && storyData.length === 0 && (
                  <View style={GlobalStyles.NoData}>
                    <Text style={GlobalStyles.NoDataMsg}>No Story Found</Text>
                  </View>
                )}
              </>
              )}
            {storyData &&
              storyData?.map((item, index) => (
                <View key={index}>
                  <RBSheet
                    ref={ref => (refCommentSheet.current[item._id] = ref)}
                    closeOnDragDown={true}
                    closeOnPressMask={true}
                    onClose={() => closeCommentSheet()}
                    openDuration={1000}
                    customStyles={{
                      wrapper: {
                        backgroundColor: '#00000024',
                      },
                      draggableIcon: {
                        backgroundColor: '#000',
                      },
                      container: {
                        height: '55%',
                      },
                    }}>
                    <FlatList
                      data={commentData.result}
                      keyExtractor={commentItem => commentItem._id}
                      showsVerticalScrollIndicator={false}
                      ListEmptyComponent={() => (
                        <View style={GlobalStyles.NoData}>
                          <Text style={GlobalStyles.NoDataMsg}>
                            No Comments Found
                          </Text>
                        </View>
                      )}
                      renderItem={({item: commentItem}) => {
                        const hasChildComments = item.comments?.some(
                          c => c.parent_comment_id === commentItem._id,
                        );
                        const formatCommentTime = moment(
                          commentItem.created_at,
                          'DD MM YYYY hh:mm:ss a',
                        ).format('YYYY-MM-DDTHH:mm:ss.SSS[Z]');
                        const fromNowCommentTime =
                          moment(formatCommentTime).fromNow();
                        return (
                          <>
                            {commentItem.parent_comment_id === null && (
                              <View
                                style={StoryBoardStyle.CommentWrap}
                                key={commentItem._id}>
                                <TouchableOpacity
                                  style={StoryBoardStyle.ProfileCta}
                                  onPress={() =>
                                    navigateToProfile({
                                      user_id: commentItem.user_id._id,
                                      story_id: item._id,
                                    })
                                  }>
                                  {commentItem.user_id.profile_image?.path ? (
                                    <Avatar.Image
                                    style={{backgroundColor: UiColor.ImageLoad}}
                                      size={40}
                                      source={{
                                        uri: commentItem.user_id.profile_image
                                          .path,
                                      }}
                                    />
                                  ) : (
                                    <Avatar.Image
                                    style={{backgroundColor: UiColor.ImageLoad}}
                                      size={40}
                                      source={IconAsset.BlankUser}
                                    />
                                  )}
                                </TouchableOpacity>
                                <TouchableOpacity style={{width: '100%'}}>
                                  <View style={StoryBoardStyle.CommentCardHead}>
                                    <View style={StoryBoardStyle.CommentCard}>
                                      <View
                                        style={
                                          StoryBoardStyle.CommentCardTitle
                                        }>
                                        <Text
                                          style={StoryBoardStyle.CommentTitle}>
                                          {commentItem?.user_id.first_name +
                                            ' ' +
                                            commentItem?.user_id.last_name}
                                        </Text>
                                        <Text
                                          style={StoryBoardStyle.CommentDate}>
                                          {fromNowCommentTime}
                                        </Text>
                                      </View>
                                      <Text style={StoryBoardStyle.CommentText}>
                                        {commentItem.text_comment}
                                      </Text>
                                    </View>
                                    <View style={StoryBoardStyle.CommentRange}>
                                      {commentItem &&
                                      commentItem.like_count === 0 ? (
                                        ''
                                      ) : (
                                        <Text
                                          style={
                                            StoryBoardStyle.CommentRangeText
                                          }>
                                          {commentItem.like_count}
                                        </Text>
                                      )}
                                      {commentItem.likes?.some(
                                        like => like.user_id === stateVal.id,
                                      ) ? (
                                        <TouchableOpacity
                                          onPress={() => {
                                            dislikePost({
                                              story_id: item._id,
                                              isCommentDislike: true,
                                              like_id: commentItem.likes.find(
                                                like =>
                                                  like.user_id === stateVal.id,
                                              )._id,
                                            });
                                          }}>
                                          <Text
                                            style={
                                              StoryBoardStyle.CommentRangeText
                                            }>
                                            Unlike
                                          </Text>
                                        </TouchableOpacity>
                                      ) : (
                                        <TouchableOpacity
                                          onPress={() => {
                                            postCommentLike({
                                              story_id: item._id,
                                              comment_id: commentItem._id,
                                            });
                                          }}>
                                          <Text
                                            style={
                                              StoryBoardStyle.CommentRangeText
                                            }>
                                            Like
                                          </Text>
                                        </TouchableOpacity>
                                      )}
                                      <TouchableOpacity
                                        onPress={() => {
                                          setCommentItems({
                                            comment_id: commentItem._id,
                                            fullName:
                                              commentItem.user_id.first_name +
                                              ' ' +
                                              commentItem.user_id.last_name,
                                          });
                                          setFormData({
                                            ...formData,
                                            comment: `@${commentItem.user_id.first_name} ${commentItem.user_id.last_name} `,
                                            isReply: true,
                                          });
                                          commentInputRef.current &&
                                            commentInputRef.current.focus();
                                        }}>
                                        <Text
                                          style={
                                            StoryBoardStyle.CommentRangeText
                                          }>
                                          Reply
                                        </Text>
                                      </TouchableOpacity>
                                      {commentItem.user_id._id ===
                                        stateVal.id ||
                                      item.user === stateVal.id ? (
                                        <TouchableOpacity
                                          onPress={() => {
                                            handleDeletePress({
                                              story_id: item._id,
                                              comment_id: commentItem._id,
                                              isComment: true,
                                            });
                                          }}>
                                          <Text
                                            style={
                                              StoryBoardStyle.CommentRangeText
                                            }>
                                            Delete
                                          </Text>
                                        </TouchableOpacity>
                                      ) : (
                                        ''
                                      )}
                                    </View>
                                    {hasChildComments && (
                                      <>
                                        <TouchableOpacity
                                          onPress={() =>
                                            toggleRepliesVisibility(
                                              commentItem._id,
                                            )
                                          }>
                                          <Text
                                            style={[
                                              StoryBoardStyle.CommentCount,
                                              {
                                                marginTop: expandedComments[
                                                  commentItem._id
                                                ]
                                                  ? 0
                                                  : 8,
                                              },
                                            ]}>
                                            {expandedComments[commentItem._id]
                                              ? ''
                                              : 'View more replies...'}
                                          </Text>
                                        </TouchableOpacity>
                                        {/* Reply */}
                                        {expandedComments[commentItem._id] &&
                                          renderReplies(
                                            {
                                              story_id: item._id,
                                              comment_id: commentItem._id,
                                              user_id: item.user,
                                            },
                                            commentData,
                                          )}
                                        {expandedComments[commentItem._id] && (
                                          <TouchableOpacity
                                            onPress={() =>
                                              toggleRepliesVisibility(
                                                commentItem._id,
                                              )
                                            }>
                                            <Text
                                              style={
                                                StoryBoardStyle.CommentCount
                                              }>
                                              Hide replies
                                            </Text>
                                          </TouchableOpacity>
                                        )}
                                      </>
                                    )}
                                  </View>
                                </TouchableOpacity>
                              </View>
                            )}
                          </>
                        );
                      }}
                      ListFooterComponent={() => {
                        {
                          isFetchingNewComments && (
                            <View>
                              <ActivityIndicator
                                animating={true}
                                size={32}
                                color={UiColor.BaseColor}
                              />
                            </View>
                          );
                        }
                      }}
                    />
                    <KeyboardAvoidingView
                      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                      style={{
                        position: 'fixed',
                        bottom: 0,
                        ...Platform.select({
                          ios: {
                            bottom: 25,
                          },
                        }),
                        left: 0,
                        backgroundColor: '#fff',
                        width: '100%',
                        paddingVertical: 20,
                        paddingHorizontal: 16,
                        shadowColor: '#000',
                        shadowOffset: {
                          width: 0,
                          height: -20,
                        },
                        shadowOpacity: 0.1,
                        shadowRadius: 0,
                        elevation: 20,
                        ...Platform.select({
                          ios: {
                            shadowOffset: {
                              height: -5,
                            },
                            shadowRadius: 3.84,
                          },
                        }),
                      }}>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'center',
                        }}>
                        <View style={{width: '100%'}}>
                          <TextInput
                            placeholder={'Write a comment...'}
                            value={formData.comment}
                            ref={commentInputRef}
                            style={[StoryBoardStyle.FormInput]}
                            textColor={UiColor.PrimaryColor}
                            theme={StoryBoardStyle.TextInput}
                            onChangeText={text => {
                              const usernameExists =
                                commentItems && text.includes(`@${commentItems.fullName}`);
                              setFormData({
                                ...formData,
                                comment: text,
                                isReply: usernameExists,
                              });
                            }}
                            underlineStyle={{
                              backgroundColor: 'transparent',
                            }}
                            autoCapitalize="none"
                          />
                          <TouchableOpacity
                            style={{
                              position: 'absolute',
                              top: 0,
                              right: 0,
                            }}
                            onPress={() => {
                              postCommentOrReply({
                                story_id: item._id,
                                comment_id: commentItems,
                              });
                            }}>
                            {isSubmit ? (
                              <ActivityIndicator
                                style={{
                                  width: 39,
                                  height: 39,
                                  top: 8,
                                  right: 8,
                                }}
                              />
                            ) : (
                              <Image
                                source={IconAsset.Share}
                                style={{
                                  width: 39,
                                  height: 39,
                                  top: 8,
                                  right: 8,
                                }}
                              />
                            )}
                          </TouchableOpacity>
                        </View>
                      </View>
                    </KeyboardAvoidingView>
                  </RBSheet>
                </View>
              ))}
          </SafeAreaView>
        </View>
      </View>
    </>
  );
};
export default ChallengesStory;
