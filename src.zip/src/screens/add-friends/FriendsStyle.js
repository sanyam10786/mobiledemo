/* eslint-disable prettier/prettier */
import { StyleSheet, Platform } from 'react-native';
import { UiColor, Dm } from '../../../theme/Index';
export const FriendsStyle = StyleSheet.create({
    CardArea: {
        marginBottom: 316,
        paddingHorizontal: 10,
    },
    FullCardArea: {
        marginBottom: 140,
        paddingHorizontal: 10,
    },
    Container: {
        marginTop: 14,
        height: '100%',
        backgroundColor: UiColor.White,
        position: 'relative',
    },
    Card: {
        backgroundColor: UiColor.White,
        borderRadius: 10,
        padding: 12,
        margin: 4,
        marginBottom: 10,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexShrink: 1,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 1,
        },
        shadowOpacity: 0.20,
        shadowRadius: 1.41,
        elevation: 2,
    },
    CardLeft: {
        borderRadius: 10,
        flexDirection: 'row',
        alignItems: 'center',
        width: '100%',
        flexShrink: 1,
    },
    CardImg: {
        marginRight: 14,
    },
    CardImageIcon: {
        width: 39,
        height: 39,
        borderRadius: 39,
        backgroundColor: '#09193D',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 14
    },
    CardInputIcon: {
        marginRight: 3,
    },
    CardTitle: {
        fontSize: 16,
        color: UiColor.PrimaryColor,
        fontFamily: Dm.medium,
        flexShrink: 1,
        width: 170,
    },
    CardDisc: {
        fontSize: 14,
        color: UiColor.PrimaryColor,
        fontFamily: Dm.regular,
        marginTop: 4,
    },
    CardIcon: {
        borderWidth: 2,
        borderColor: '#CECCCC',
    },
    CopyLink: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        paddingHorizontal: 18,
        paddingTop: 14,
        paddingBottom: 24,
        backgroundColor: UiColor.White,
        width: '100%',
        shadowColor: "#586a8b",
        zIndex: 9,
        shadowOffset: {
            width: 0,
            height: -3,
        },
        shadowOpacity: 0.08,
        shadowRadius: 3.84,

        ...Platform.select({
            android: {
                elevation: 30,
            },
        }),

    },

    LinkInput: {
        position: 'relative',
        width: '100%',
        height: 38,
        borderColor: '#CCC',
        borderWidth: 1,
        borderRadius: 8,
    },
    CopyIcon: {
        position: 'absolute',
        top: -5,
        right: 0,
    },
    LinkInputBox: {
        paddingLeft: 12,
        paddingRight: 40,
        height: 38,
        paddingVertical: 0
    },
    Btn: {
        marginTop: 11,
    },
    TitleText: {
        color: UiColor.GrayLight,
        marginBottom: 5,
        marginLeft: 5,
        fontSize: 14,
    },

});


