import { View, Text, TextInput, TouchableOpacity, FlatList, SafeAreaView, } from 'react-native';
import { Appbar, Searchbar, Avatar, IconButton, ActivityIndicator,} from 'react-native-paper';
import { Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm,} from '../../../theme/Index';
import {fetchAllUsers, addFriends, removeFriends, acceptFriends} from '../../thunk';
import {useIsFocused, useNavigation} from '@react-navigation/native';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import React, {useState, useEffect, useContext} from 'react';
import files from '../../../assets/filebase64/FileBase64';
import Clipboard from '@react-native-clipboard/clipboard';
import {useDispatch, useSelector} from 'react-redux';
import {LoginStyle} from '../auth/login/LoginStyle';
import {NetworkContext} from '../../NetworkContext';
import {setRefreshing} from '../../slices/user';
import {FriendsStyle} from './FriendsStyle';
import Share from 'react-native-share';

const AddFriends = ({navigation}) => {
  const dispatch = useDispatch();
  const stateVal = useSelector(state => state.user);
  const loginUser = useSelector(state => state.login);
  const isFocused = useIsFocused();
  const isConnected = useContext(NetworkContext);
  const [loadedData, setLoadedData] = useState([]);
  const [currentPage, setCurrentPage] = React.useState(1);
  const [shouldFetchNextPage, setShouldFetchNextPage] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [search, setSearch] = useState('');
  const [params, setParamData] = useState({
    search: search,
    page: 1,
    limit: 20,
  });
  const [isLoad, setIsLoad] = useState(false);
  const [loadingStates, setLoadingStates] = useState({});
  const [shareUrl, setShareUrl] = useState(
    'https://bigfinfishingapi.exactink.in/v1/deep-linking',
  );
  useEffect(() => {
    if (isConnected && isFocused) {
      const params = {
        page: currentPage,
        limit: 20,
        search: '',
      };
      fetchUsers(currentPage, params);
    }
  }, [isConnected, isFocused, params]);

  const handleOnSearchChange = text => {
    setIsSearching(true);
    setSearch(text);
    params.search = text;
    params.page = 1;
    setCurrentPage(1);
    fetchUsers(currentPage, params).then(() => {
      setIsSearching(false);
    });
  };

  const fetchUsers = async (page, params) => {
    setIsLoadingMore(true);
    setIsLoad(true);
    try {
      if ('search' in params && params.search.trim() === '') {
        delete params.search;
      }
      const resultAction = await dispatch(fetchAllUsers(params));
      if (fetchAllUsers.fulfilled.match(resultAction)) {
        setIsLoadingMore(false);
        setIsLoad(false);

        const newData = resultAction.payload.data.users;
        if (newData.length < params.limit) {
          setShouldFetchNextPage(false);
        } else {
          setShouldFetchNextPage(true);
        }
        const filteredData = newData.filter(user => {
          const isFriendAccepted = user.friends.some(
            friend => friend.status === 'accepted',
          );
          return user.id !== loginUser.id && !isFriendAccepted && user.status === 'active';
        });
        if (params.page === 1) {
          setLoadedData(filteredData);
        } else {
          setLoadedData(prevData => {
            const uniqueFilteredData = filteredData.filter(
              item => !prevData.map(prevItem => prevItem.id).includes(item.id),
            );
            return [...prevData, ...uniqueFilteredData];
          });
        }
      }
    } catch (error) {
      setIsLoad(false);
      setIsLoadingMore(false);
      console.error('Error fetching users:', error);
    }
  };
  const copyToClipboard = () => {
    Clipboard.setString(shareUrl);
  };
  const sendUrlSocial = async () => {
    const inviteMessage =
      'Jake Richmann is inviting you to download the BIG FIN app and become friends on the app. Click the link to download and start your fishing experience today.\n\n';
    const message = inviteMessage + shareUrl;

    const shareOption = {
      message: message,
      url: files.appLogo,
    };

    try {
      const ShareResponse = await Share.open(shareOption);
    } catch (error) {
      console.log('Error => ', error);
    }
  };

  const handleRefresh = () => {
    dispatch(setRefreshing({}));
    params.page = 1;
    fetchUsers(currentPage, params);
  };

  const handleLoadMore = () => {
    if (!isLoadingMore && shouldFetchNextPage) {
      setIsLoadingMore(true);
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      const params = {
        page: nextPage,
        limit: 10,
        search: '',
      };
      fetchUsers(nextPage, params).then(() => setIsLoadingMore(false));
    }
  };

  const sendRequest = async id => {
    try {
      setLoadingStates(prevStates => ({...prevStates, [id]: true}));
      const params = {
        user_id: id,
      };
      const resultAction = await dispatch(addFriends(params));
      if (addFriends.fulfilled.match(resultAction)) {
        setLoadingStates(prevStates => ({...prevStates, [id]: false}));
        setLoadedData(prevData =>
          prevData.map(item =>
            item.id === id
              ? {
                  ...item,
                  friends: [
                    ...item.friends,
                    {id: resultAction.payload.data.id, status: 'pending'},
                  ],
                }
              : item,
          ),
        );
      }
    } catch (error) {
      console.error('Error sending request:', error);
      setLoadingStates(prevStates => ({...prevStates, [id]: false}));
    }
  };

  const removeRequest = async id => {
    try {
      setLoadingStates(prevStates => ({...prevStates, [id]: true}));
      const params = {friend_request_id: id};
      const resultAction = await dispatch(removeFriends(params));
      if (removeFriends.fulfilled.match(resultAction)) {
        setLoadingStates(prevStates => ({...prevStates, [id]: false}));
        setLoadedData(prevData =>
          prevData.map(item =>
            item.friends.some(friend => friend.id === id)
              ? {
                  ...item,
                  friends: item.friends.filter(friend => friend.id !== id),
                }
              : item,
          ),
        );
      }
    } catch (error) {
      console.error('Error removing request:', error);
      setLoadingStates(prevStates => ({...prevStates, [id]: false}));
    }
  };

  const acceptRequest = async id => {
    try {
      // Set the loading state for the current request
      setLoadingStates(prevStates => ({ ...prevStates, [id]: true }));
      const params = { friend_request_id: id };
      const resultAction = await dispatch(acceptFriends(params));
      if (acceptFriends.fulfilled.match(resultAction)) {
        handleRefresh();
        // Update the loaded data to reflect the accepted friend request
        setLoadedData(prevData =>
          prevData.map(item =>
            item.friends.some(friend => friend.id === id)
              ? {
                  ...item,
                  friends: item.friends.map(friend =>
                    friend.id === id ? { ...friend, status: 'accepted' } : friend
                  ),
                }
              : item
          )
        );
      }
    } catch (error) {
      console.error('Error accepting request:', error);
    } finally {
      // Remove the loading state after processing
      setLoadingStates(prevStates => ({ ...prevStates, [id]: false }));
    }
  };

  const ListItem = (item, index) => {
    const friendsData = item.friends;
    const userProfile = item.profile_image && item.profile_image.path;
    const loggedInUserId = loginUser.id;
    // Check if the user received or sent the friend request
    const receivedRequest = friendsData.some(friend => friend.to_id === loggedInUserId);

    return (
      <View style={FriendsStyle.Card} key={item.id}>
        <TouchableOpacity
          onPress={() => navigation.navigate('FriendProfile', item.id)}>
          <View style={FriendsStyle.CardLeft}>
            {userProfile ? (
              <Avatar.Image
                style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                size={51}
                source={{
                  uri: item.profile_image.path,
                }}
              />
            ) : (
              <Avatar.Image
                style={[FriendsStyle.CardImg, {backgroundColor: UiColor.ImageLoad}]}
                size={51}
                source={IconAsset.BlankUser}
              />
            )}
            <View>
              <Text style={FriendsStyle.CardTitle}>
                {item.first_name + ' ' + item.last_name}
              </Text>
              <Text
                style={[FriendsStyle.CardDisc, {maxWidth: '80%'}]}
                numberOfLines={3}
                ellipsizeMode="tail">
                {item.email}
              </Text>
            </View>
          </View>
        </TouchableOpacity>
        <View
          style={{
            flex: 1,
            flexDirection: 'row',
            position: 'absolute',
            right: 5,
            alignItems: 'center',
          }}>
            <>
              <>{receivedRequest ? (
                <>
                {loadingStates[friendsData[0].id] ? (
                    <ActivityIndicator
                      animating={true}
                      color={UiColor.BaseColor}
                      size={30}
                      style={{ marginRight: 5, paddingTop: 10 }}
                    />
                  ) : (
                    <>
                      <IconButton
                        style={[FriendsStyle.CardIcon, Styles.BorderSuccess]}
                        onPress={() => acceptRequest(friendsData[0].id)} // Accept function
                        icon={() => <Icon name={'check'} color={UiColor.Success} size={16} />}
                        size={28}
                        disabled={loadingStates[friendsData[0].id]} // Disable the button while loading
                      />
                      <IconButton
                        style={[FriendsStyle.CardIcon]}
                        onPress={() => removeRequest(friendsData[0].id)} // Decline function
                        icon={() => <Icon name={'cross'} size={16} />}
                        size={28}
                        disabled={loadingStates[friendsData[0].id]} // Disable the button while loading
                      />
                    </>
                  )}
                </>
              ) : (
                <>
                 {friendsData[0] && friendsData[0].status === 'pending' ? (
                  <>
                    {loadingStates[friendsData[0] && friendsData[0].id] ? (
                      <ActivityIndicator
                        animating={true}
                        color={UiColor.BaseColor}
                        size={30}
                        style={{marginRight: 5, paddingTop: 10}}
                      />
                    ) : (
                      <IconButton
                        style={[FriendsStyle.CardIcon]}
                        onPress={() => removeRequest(friendsData[0].id)}
                        icon={() => (
                          <Icon name={'cross'} color={UiColor.PrimaryColor} size={16} />
                        )}
                        size={28}
                      />
                    )}
                  </>
                ) : (
                  <>
                    {loadingStates[item.id] ? (
                      <ActivityIndicator
                        animating={true}
                        color={UiColor.BaseColor}
                        size={30}
                        style={{marginRight: 5, paddingTop: 10}}
                      />
                    ) : (
                      <IconButton
                        style={[FriendsStyle.CardIcon]}
                        onPress={() => sendRequest(item.id)}
                        icon={() => (
                          <Icon
                            name={'plus'}
                            color={UiColor.PrimaryColor}
                            size={18}
                          />
                        )}
                        size={28}
                      />
                    )}
                  </>
                )}
                </>
              )}
              </>
            </>
        </View>
      </View>
    );
  };
  return (
    <View style={{flex: 1}}>
      <View style={[Styles.AppBarShadow]}>
        <Appbar.Header style={[Styles.AppbarHeader, Styles.SubHeader]}>
          <Appbar.Action
            animated={false}
            size={20}
            rippleColor="#00000008"
            onPress={() => navigation.goBack()}
            style={{backgroundColor: UiColor.SecondaryColor}}
            icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
          />
          <Appbar.Content titleStyle={Styles.NavTitle} title="Add Friends" />
          <Appbar.Action />
        </Appbar.Header>
        <View style={Styles.SearchHead}>
          <Searchbar
            placeholder="Search..."
            value={search}
            theme={Styles.SearchInputTheme}
            style={[Styles.SearchInput]}
            onChangeText={text => handleOnSearchChange(text)}
            inputStyle={[Styles.SearchInputStyle]}
            placeholderTextColor={UiColor.PrimaryColor}
            iconColor={UiColor.PrimaryColor}
            icon={() => (
              <Icon name="search" size={24} color={UiColor.PrimaryColor} />
            )}
            clearIcon={() =>
              search.length > 0 ? (
                <Icon color={UiColor.PrimaryColor} name="cross" size={18} />
              ) : (
                ''
              )
            }
          />
        </View>
      </View>
      <View style={[FriendsStyle.Container, {backgroundColor: 'transparent'}]}>
        <SafeAreaView style={[FriendsStyle.CardArea]}>
          {!isConnected && loadedData && loadedData.length === 0 ? (
            <View style={[GlobalStyles.NoData, {marginTop: 80}]}>
              <Icon name="no-connection" size={50} />
              <Text style={[GlobalStyles.NoDataMsg, {fontFamily: Dm.semiBold}]}>
                No Internet Connection
              </Text>
            </View>
          ) : (
            <>
              {Object.keys(loadedData).length === 0 && isLoadingMore ? (
                <SkeletonPlaceholder>
                {Array.from({ length: 10 }).map((_, index) => (
                  <View style={[FriendsStyle.Card, {shadowOpacity: 0,
                    shadowRadius: 0,}]} key={index}>
                    <SkeletonPlaceholder.Item height={50} width="100%">
                      <View style={FriendsStyle.CardLeft}>
                        <SkeletonPlaceholder.Item
                          width={51}
                          height={51}
                          borderRadius={51}
                        />
                        <View>
                          <SkeletonPlaceholder.Item
                            height={20}
                            width={120}
                            marginLeft={10}
                          />
                          <SkeletonPlaceholder.Item
                            height={20}
                            width={180}
                            marginLeft={10}
                            marginTop={8}
                          />
                        </View>
                      </View>
                    </SkeletonPlaceholder.Item>
                  </View>
                ))}
              </SkeletonPlaceholder>
                ) : (
                <FlatList
                  data={loadedData}
                  renderItem={({item, index}) => ListItem(item, index)}
                  onEndReached={handleLoadMore}
                  showsVerticalScrollIndicator={false}
                  onEndReachedThreshold={0.1}
                  keyExtractor={(item, index) => index.toString()}
                  refreshing={stateVal.refreshing}
                  onRefresh={handleRefresh}
                  ListFooterComponent={() => {
                    return isLoad ? (
                      <ActivityIndicator
                        animating={true}
                        size={32}
                        color={UiColor.BaseColor}
                      />
                    ) : null;
                  }}
                />
              )}
              {!isLoadingMore && loadedData && loadedData.length === 0 && (
                <View style={GlobalStyles.NoData}>
                  <Text style={GlobalStyles.NoDataMsg}>No users Found</Text>
                </View>
              )}
            </>
          )}
        </SafeAreaView>
      </View>
      <View style={FriendsStyle.CopyLink}>
        <View style={FriendsStyle.LinkInput}>
          <TextInput
            // value={shareUrl}
            placeholder={shareUrl}
            onChangeText={text => setShareUrl({text})}
            underlineStyle={{backgroundColor: 'transparent'}}
            autoCapitalize="none"
            editable={false}
            selectTextOnFocus={false}
            style={FriendsStyle.LinkInputBox}
            textColor={UiColor.PrimaryColor}
            placeholderTextColor={UiColor.Black}
          />
          <IconButton
            rippleColor="#d2283d2e"
            onPress={copyToClipboard}
            style={[FriendsStyle.CopyIcon]}
            icon={() => (
              <Icon name="copy" color={UiColor.PrimaryColor} size={18} />
            )}
            size={20}
          />
        </View>
        <TouchableOpacity
          style={[LoginStyle.Btn, FriendsStyle.Btn]}
          onPress={sendUrlSocial}>
          <Text style={LoginStyle.BtnText}>Invite Friends</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};
export default AddFriends;
