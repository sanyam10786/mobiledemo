import { ReAuthenticateThunk, fetchUserData, addFriends, removeFriends,} from '../../thunk';
import { Styles, GlobalStyles, UiColor, IconAsset, Icon, Dm,} from '../../../theme/Index';
import {View, Text, TouchableOpacity, ScrollView, ImageBackground,} from 'react-native';
import {Appbar, Avatar, ActivityIndicator} from 'react-native-paper';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import {useIsFocused, useRoute} from '@react-navigation/native';
import {ProfileStyle} from '../user-profile/ProfileStyle';
import {useDispatch, useSelector} from 'react-redux';
import PTRView from 'react-native-pull-to-refresh';
import React, {useEffect, useState} from 'react';
import { resetState } from '../../slices/user';

const FriendProfile = ({navigation}) => {
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const route = useRoute();
  const freindId = route.params;
  const userData = useSelector(state => state.user);
  const [sentRequests, setSentRequests] = useState([]);
  const user = userData.details;
  const request = user.friend;
  const [selectedImageUri, setSelectedImageUri] = useState(null);
  const [formData, setFormData] = useState({
    profile_image: selectedImageUri,
  });
  
  useEffect(() => {
    if (isFocused) {
      if (freindId) {
        try {
          const params = {
            id: freindId,
          };
          dispatch(fetchUserData(params));
        } catch (error) {
          console.error('Error in refreshData:', error);
        }
      }
    }
    return () => {
      dispatch(resetState({}));
      if (!isFocused) {
      }
    };
  }, [freindId]);
  
  const handleRefresh = () => {
    dispatch(resetState({}));
    const params = {
      id: freindId,
    };
    dispatch(fetchUserData(params));
  };

  const sendRequest = async id => {
    const params = {
      user_id: id,
    };
    const resultAction = await dispatch(addFriends(params));
    const friend = {
      id: freindId,
    };
    dispatch(fetchUserData(friend));
    if (addFriends.fulfilled.match(resultAction)) {
      setSentRequests([...sentRequests, id]);
      const sentRequest = resultAction.payload.data;
    }
  };

  const removeRequest = async id => {
    const params = {friend_request_id: id};
    const resultAction = await dispatch(removeFriends(params));
    if (removeFriends.fulfilled.match(resultAction)) {
      const friend = {id: freindId};
      dispatch(fetchUserData(friend));
    }
  };


  return (
    <>
      <Appbar.Header style={[Styles.AppbarHeader, ProfileStyle.UserProfileBar]}>
        <Appbar.Action
          animated={false}
          size={20}
          rippleColor="#00000008"
          onPress={() => navigation.goBack()}
          style={{backgroundColor: UiColor.SecondaryColor}}
          icon={() => <Icon name="back" size={18} style={Styles.BackWhite} />}
        />
        <Appbar.Action
          animated={false}
          size={30}
          rippleColor="#00000008"
         
        />
      </Appbar.Header>
      {Object.keys(user).length === 0 ? (
        <SkeletonPlaceholder>
          <SkeletonPlaceholder.Item height={200} width="100%" />
          <SkeletonPlaceholder.Item
            position='absolute'
            top={140}
            left={10}
            width={135}
            height={135}
            borderRadius={67.5}
            alignSelf="center"
          />
          <SkeletonPlaceholder.Item paddingTop={80}>
            <SkeletonPlaceholder.Item height={30} width={200} borderRadius={4} marginLeft={20}/>
            <SkeletonPlaceholder.Item height={30} width={150} borderRadius={4} marginLeft={20} marginTop={6} />
          </SkeletonPlaceholder.Item>
          <SkeletonPlaceholder.Item flexDirection="row" justifyContent="space-between" padding={20}>
            <SkeletonPlaceholder.Item height={40} width={80} borderRadius={4} />
            <SkeletonPlaceholder.Item height={40} width={80} borderRadius={4} />
            <SkeletonPlaceholder.Item height={40} width={120} borderRadius={4} />
          </SkeletonPlaceholder.Item>
          <SkeletonPlaceholder.Item paddingTop={30} alignItems="center">
            <SkeletonPlaceholder.Item
              width={50}
              height={50}
              borderRadius={25}
            />
            <SkeletonPlaceholder.Item
              width={180}
              height={20}
              borderRadius={4}
              marginTop={10}
            />
            <SkeletonPlaceholder.Item
              width={250}
              height={20}
              borderRadius={4}
              marginTop={8}
            />
          </SkeletonPlaceholder.Item>
        </SkeletonPlaceholder>
      ) : (
        <>
          <>
            <ImageBackground
              source={
                user.cover_image
                  ? {uri: user.cover_image.path}
                  : IconAsset.Splash
              }
              resizeMode="cover"
              style={ProfileStyle.UserProfileBg}>
              <View style={Styles.BannerOverlay}></View>
            </ImageBackground>
            <Avatar.Image
              style={[
                ProfileStyle.ProfileAvatar,
                GlobalStyles.mb0,
                {marginTop: 40, backgroundColor: UiColor.ImageLoad},
              ]}
              size={113}
              source={
                user.profile_image
                  ? {uri: user.profile_image.path}
                  : IconAsset.BlankUser
              }
            />
          </>
          <PTRView onRefresh={handleRefresh}>
            <ScrollView>
              <View
                style={[
                  ProfileStyle.UserProfileCont,
                  {backgroundColor: 'transparent'},
                ]}>
                <View>
                  <Text style={ProfileStyle.UserTitle}>
                    {user.first_name + ' ' + user.last_name
                      ? user.first_name + ' ' + user.last_name
                      : ''}
                  </Text>
                  <Text style={ProfileStyle.UserEmail}>
                    {user.address ? user.address : ''}
                  </Text>
                </View>
                <View style={ProfileStyle.UserCountHead}>
                  <View style={ProfileStyle.UserCountList}>
                    <Text style={ProfileStyle.UserCountNo}>
                      {user.friend_count ? user.friend_count : '0'}
                    </Text>
                    <Text style={ProfileStyle.UserCountText}>
                      {user.friend_count === 1 ? 'Friend' : 'Friends'}
                    </Text>
                  </View>
                  <View>
                    <Text style={ProfileStyle.UserCountNo}>
                      {user.catch_count ? user.catch_count : '0'}
                    </Text>
                    <Text style={ProfileStyle.UserCountText}>Catches</Text>
                  </View>
                  {request[0] && request[0].status === 'pending' ? (
                    <>
                      {request?.map(friendRequest => (
                        <TouchableOpacity
                          style={[Styles.Btn, GlobalStyles.mlAuto]}
                          key={friendRequest.id}
                          onPress={() => removeRequest(friendRequest.id)}>
                          <Icon
                            style={Styles.BtnIcon}
                            name="check"
                            color={UiColor.White}
                            size={20}
                          />
                          <Text style={Styles.BtnText}>Request Sent</Text>
                        </TouchableOpacity>
                      ))}
                    </>
                  ) : (
                    <TouchableOpacity
                      style={[Styles.Btn, GlobalStyles.mlAuto]}
                      onPress={() => sendRequest(user.id)}>
                      <Icon
                        style={Styles.BtnIcon}
                        name="user-edit"
                        color={UiColor.White}
                        size={20}
                      />
                      <Text style={Styles.BtnText}>Add Friend</Text>
                    </TouchableOpacity>
                  )}
                </View>
                <Text
                  style={
                    user.about_us && user.about_us.length === 0
                      ? null
                      : ProfileStyle.ProfileDisc
                  }>
                  {user.about_us}
                </Text>
                <View style={Styles.PrivateProfile}>
                  <Icon
                    style={Styles.PrivateProfileIcon}
                    name="private"
                    color={UiColor.PrimaryColor}
                    size={24}
                  />
                  <Text style={Styles.PrivateProfileTitle}>
                    This Account is Private
                  </Text>
                  <Text style={Styles.PrivateProfileDisc}>
                    Add this Account to see their photos and videos
                  </Text>
                </View>
              </View>
            </ScrollView>
          </PTRView>
        </>
      )}
    </>
  );
};

export default FriendProfile;
